<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>

<h1>Welcome to My Website</h1>

<a href="<?php echo base_url() ?>index.php/test"> View User </a>
<br>
<a href="<?php echo base_url() ?>index.php/upload"> Upload Image </a>
<br>
<a href="<?php echo base_url() ?>index.php/email"> Email </a>
<br>
<a href="<?php echo base_url() ?>index.php/validation"> Test Validation </a>

</body>
</html>