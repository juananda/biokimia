<!DOCTYPE html>
<html>
<head>
	<title>Your post</title>
</head>
<body>
<h1><?php echo $title ?></h1>
<h3><?php echo $user . ' / ' . $date ?></h3>
<?php

// echo $user  . '<br>';
// echo $title . '<br>';
// echo $date  . '<br>';
echo $post  . '<br>';

?>

<a href="./">Post again</a>
</body>
</html>