<!DOCTYPE html>
<html>
<head>
	<title>Validation Success</title>
</head>
<body>
<h3>Your form has successfully submited!</h3>
<p><?php echo anchor('form', 'Try Again'); ?></p>
</body>
</html>