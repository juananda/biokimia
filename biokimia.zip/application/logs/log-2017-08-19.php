<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-19 07:26:46 --> Config Class Initialized
INFO - 2017-08-19 07:26:46 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:26:47 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:26:47 --> Utf8 Class Initialized
INFO - 2017-08-19 07:26:47 --> URI Class Initialized
INFO - 2017-08-19 07:26:47 --> Router Class Initialized
INFO - 2017-08-19 07:26:47 --> Output Class Initialized
INFO - 2017-08-19 07:26:47 --> Security Class Initialized
DEBUG - 2017-08-19 07:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:26:47 --> Input Class Initialized
INFO - 2017-08-19 07:26:47 --> Language Class Initialized
INFO - 2017-08-19 07:26:47 --> Loader Class Initialized
INFO - 2017-08-19 07:26:47 --> Helper loaded: url_helper
INFO - 2017-08-19 07:26:47 --> Helper loaded: file_helper
INFO - 2017-08-19 07:26:47 --> Database Driver Class Initialized
INFO - 2017-08-19 07:26:48 --> Email Class Initialized
DEBUG - 2017-08-19 07:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:26:48 --> Table Class Initialized
INFO - 2017-08-19 07:26:48 --> Controller Class Initialized
INFO - 2017-08-19 07:26:48 --> Helper loaded: form_helper
INFO - 2017-08-19 07:26:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:26:48 --> Final output sent to browser
DEBUG - 2017-08-19 07:26:48 --> Total execution time: 1.5928
INFO - 2017-08-19 07:27:15 --> Config Class Initialized
INFO - 2017-08-19 07:27:15 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:27:15 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:27:15 --> Utf8 Class Initialized
INFO - 2017-08-19 07:27:15 --> URI Class Initialized
INFO - 2017-08-19 07:27:15 --> Router Class Initialized
INFO - 2017-08-19 07:27:15 --> Output Class Initialized
INFO - 2017-08-19 07:27:15 --> Security Class Initialized
DEBUG - 2017-08-19 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:27:15 --> Input Class Initialized
INFO - 2017-08-19 07:27:15 --> Language Class Initialized
INFO - 2017-08-19 07:27:15 --> Loader Class Initialized
INFO - 2017-08-19 07:27:15 --> Helper loaded: url_helper
INFO - 2017-08-19 07:27:15 --> Helper loaded: file_helper
INFO - 2017-08-19 07:27:15 --> Database Driver Class Initialized
INFO - 2017-08-19 07:27:15 --> Email Class Initialized
DEBUG - 2017-08-19 07:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:27:15 --> Table Class Initialized
INFO - 2017-08-19 07:27:15 --> Controller Class Initialized
INFO - 2017-08-19 07:27:15 --> Helper loaded: form_helper
INFO - 2017-08-19 07:27:15 --> Upload Class Initialized
INFO - 2017-08-19 07:27:15 --> Final output sent to browser
DEBUG - 2017-08-19 07:27:15 --> Total execution time: 0.5380
INFO - 2017-08-19 07:28:03 --> Config Class Initialized
INFO - 2017-08-19 07:28:04 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:28:04 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:28:04 --> Utf8 Class Initialized
INFO - 2017-08-19 07:28:04 --> URI Class Initialized
INFO - 2017-08-19 07:28:04 --> Router Class Initialized
INFO - 2017-08-19 07:28:04 --> Output Class Initialized
INFO - 2017-08-19 07:28:04 --> Security Class Initialized
DEBUG - 2017-08-19 07:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:28:04 --> Input Class Initialized
INFO - 2017-08-19 07:28:04 --> Language Class Initialized
INFO - 2017-08-19 07:28:04 --> Loader Class Initialized
INFO - 2017-08-19 07:28:04 --> Helper loaded: url_helper
INFO - 2017-08-19 07:28:04 --> Helper loaded: file_helper
INFO - 2017-08-19 07:28:04 --> Database Driver Class Initialized
INFO - 2017-08-19 07:28:04 --> Email Class Initialized
DEBUG - 2017-08-19 07:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:28:04 --> Table Class Initialized
INFO - 2017-08-19 07:28:04 --> Controller Class Initialized
INFO - 2017-08-19 07:28:04 --> Helper loaded: form_helper
ERROR - 2017-08-19 07:28:04 --> Severity: error --> Exception: C:\xampp\htdocs\biokimia\application\models/Model_article.php exists, but doesn't declare class Model_article C:\xampp\htdocs\biokimia\system\core\Loader.php 336
INFO - 2017-08-19 07:29:24 --> Config Class Initialized
INFO - 2017-08-19 07:29:24 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:29:24 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:29:24 --> Utf8 Class Initialized
INFO - 2017-08-19 07:29:24 --> URI Class Initialized
INFO - 2017-08-19 07:29:24 --> Router Class Initialized
INFO - 2017-08-19 07:29:24 --> Output Class Initialized
INFO - 2017-08-19 07:29:24 --> Security Class Initialized
DEBUG - 2017-08-19 07:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:29:24 --> Input Class Initialized
INFO - 2017-08-19 07:29:24 --> Language Class Initialized
INFO - 2017-08-19 07:29:24 --> Loader Class Initialized
INFO - 2017-08-19 07:29:24 --> Helper loaded: url_helper
INFO - 2017-08-19 07:29:24 --> Helper loaded: file_helper
INFO - 2017-08-19 07:29:24 --> Database Driver Class Initialized
INFO - 2017-08-19 07:29:25 --> Email Class Initialized
DEBUG - 2017-08-19 07:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:29:25 --> Table Class Initialized
INFO - 2017-08-19 07:29:25 --> Controller Class Initialized
INFO - 2017-08-19 07:29:25 --> Helper loaded: form_helper
INFO - 2017-08-19 07:29:25 --> Model Class Initialized
INFO - 2017-08-19 07:29:56 --> Config Class Initialized
INFO - 2017-08-19 07:29:56 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:29:56 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:29:56 --> Utf8 Class Initialized
INFO - 2017-08-19 07:29:56 --> URI Class Initialized
INFO - 2017-08-19 07:29:56 --> Router Class Initialized
INFO - 2017-08-19 07:29:56 --> Output Class Initialized
INFO - 2017-08-19 07:29:56 --> Security Class Initialized
DEBUG - 2017-08-19 07:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:29:56 --> Input Class Initialized
INFO - 2017-08-19 07:29:56 --> Language Class Initialized
INFO - 2017-08-19 07:29:56 --> Loader Class Initialized
INFO - 2017-08-19 07:29:56 --> Helper loaded: url_helper
INFO - 2017-08-19 07:29:56 --> Helper loaded: file_helper
INFO - 2017-08-19 07:29:56 --> Database Driver Class Initialized
INFO - 2017-08-19 07:29:56 --> Email Class Initialized
DEBUG - 2017-08-19 07:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:29:56 --> Table Class Initialized
INFO - 2017-08-19 07:29:56 --> Controller Class Initialized
INFO - 2017-08-19 07:29:56 --> Helper loaded: form_helper
INFO - 2017-08-19 07:29:56 --> Model Class Initialized
INFO - 2017-08-19 07:29:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-19 07:29:56 --> Final output sent to browser
DEBUG - 2017-08-19 07:29:56 --> Total execution time: 0.2522
INFO - 2017-08-19 07:31:15 --> Config Class Initialized
INFO - 2017-08-19 07:31:15 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:31:16 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:31:16 --> Utf8 Class Initialized
INFO - 2017-08-19 07:31:16 --> URI Class Initialized
INFO - 2017-08-19 07:31:16 --> Router Class Initialized
INFO - 2017-08-19 07:31:16 --> Output Class Initialized
INFO - 2017-08-19 07:31:16 --> Security Class Initialized
DEBUG - 2017-08-19 07:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:31:16 --> Input Class Initialized
INFO - 2017-08-19 07:31:16 --> Language Class Initialized
INFO - 2017-08-19 07:31:16 --> Loader Class Initialized
INFO - 2017-08-19 07:31:16 --> Helper loaded: url_helper
INFO - 2017-08-19 07:31:16 --> Helper loaded: file_helper
INFO - 2017-08-19 07:31:16 --> Database Driver Class Initialized
INFO - 2017-08-19 07:31:16 --> Email Class Initialized
DEBUG - 2017-08-19 07:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:31:16 --> Table Class Initialized
INFO - 2017-08-19 07:31:16 --> Controller Class Initialized
INFO - 2017-08-19 07:31:16 --> Helper loaded: form_helper
INFO - 2017-08-19 07:31:16 --> Model Class Initialized
INFO - 2017-08-19 07:31:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-19 07:31:16 --> Final output sent to browser
DEBUG - 2017-08-19 07:31:16 --> Total execution time: 0.2378
INFO - 2017-08-19 07:32:26 --> Config Class Initialized
INFO - 2017-08-19 07:32:26 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:32:26 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:32:26 --> Utf8 Class Initialized
INFO - 2017-08-19 07:32:26 --> URI Class Initialized
INFO - 2017-08-19 07:32:26 --> Router Class Initialized
INFO - 2017-08-19 07:32:26 --> Output Class Initialized
INFO - 2017-08-19 07:32:26 --> Security Class Initialized
DEBUG - 2017-08-19 07:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:32:26 --> Input Class Initialized
INFO - 2017-08-19 07:32:26 --> Language Class Initialized
INFO - 2017-08-19 07:32:26 --> Loader Class Initialized
INFO - 2017-08-19 07:32:26 --> Helper loaded: url_helper
INFO - 2017-08-19 07:32:26 --> Helper loaded: file_helper
INFO - 2017-08-19 07:32:26 --> Database Driver Class Initialized
INFO - 2017-08-19 07:32:27 --> Email Class Initialized
DEBUG - 2017-08-19 07:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:32:27 --> Table Class Initialized
INFO - 2017-08-19 07:32:27 --> Controller Class Initialized
INFO - 2017-08-19 07:32:27 --> Helper loaded: form_helper
INFO - 2017-08-19 07:32:27 --> Model Class Initialized
INFO - 2017-08-19 07:32:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-19 07:32:27 --> Final output sent to browser
DEBUG - 2017-08-19 07:32:27 --> Total execution time: 0.2462
INFO - 2017-08-19 07:32:36 --> Config Class Initialized
INFO - 2017-08-19 07:32:36 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:32:36 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:32:36 --> Utf8 Class Initialized
INFO - 2017-08-19 07:32:36 --> URI Class Initialized
INFO - 2017-08-19 07:32:36 --> Router Class Initialized
INFO - 2017-08-19 07:32:36 --> Output Class Initialized
INFO - 2017-08-19 07:32:36 --> Security Class Initialized
DEBUG - 2017-08-19 07:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:32:36 --> Input Class Initialized
INFO - 2017-08-19 07:32:36 --> Language Class Initialized
INFO - 2017-08-19 07:32:36 --> Loader Class Initialized
INFO - 2017-08-19 07:32:36 --> Helper loaded: url_helper
INFO - 2017-08-19 07:32:36 --> Helper loaded: file_helper
INFO - 2017-08-19 07:32:36 --> Database Driver Class Initialized
INFO - 2017-08-19 07:32:36 --> Email Class Initialized
DEBUG - 2017-08-19 07:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:32:36 --> Table Class Initialized
INFO - 2017-08-19 07:32:36 --> Controller Class Initialized
INFO - 2017-08-19 07:32:36 --> Helper loaded: form_helper
INFO - 2017-08-19 07:32:36 --> Model Class Initialized
INFO - 2017-08-19 07:32:36 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-19 07:32:36 --> Final output sent to browser
DEBUG - 2017-08-19 07:32:36 --> Total execution time: 0.2628
INFO - 2017-08-19 07:33:27 --> Config Class Initialized
INFO - 2017-08-19 07:33:27 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:33:27 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:33:27 --> Utf8 Class Initialized
INFO - 2017-08-19 07:33:27 --> URI Class Initialized
INFO - 2017-08-19 07:33:27 --> Router Class Initialized
INFO - 2017-08-19 07:33:27 --> Output Class Initialized
INFO - 2017-08-19 07:33:27 --> Security Class Initialized
DEBUG - 2017-08-19 07:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:33:27 --> Input Class Initialized
INFO - 2017-08-19 07:33:27 --> Language Class Initialized
INFO - 2017-08-19 07:33:27 --> Loader Class Initialized
INFO - 2017-08-19 07:33:27 --> Helper loaded: url_helper
INFO - 2017-08-19 07:33:27 --> Helper loaded: file_helper
INFO - 2017-08-19 07:33:27 --> Database Driver Class Initialized
INFO - 2017-08-19 07:33:27 --> Email Class Initialized
DEBUG - 2017-08-19 07:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:33:27 --> Table Class Initialized
INFO - 2017-08-19 07:33:27 --> Controller Class Initialized
INFO - 2017-08-19 07:33:27 --> Helper loaded: form_helper
INFO - 2017-08-19 07:33:27 --> Model Class Initialized
INFO - 2017-08-19 07:33:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-19 07:33:27 --> Final output sent to browser
DEBUG - 2017-08-19 07:33:27 --> Total execution time: 0.2503
INFO - 2017-08-19 07:33:47 --> Config Class Initialized
INFO - 2017-08-19 07:33:47 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:33:47 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:33:47 --> Utf8 Class Initialized
INFO - 2017-08-19 07:33:47 --> URI Class Initialized
INFO - 2017-08-19 07:33:47 --> Router Class Initialized
INFO - 2017-08-19 07:33:47 --> Output Class Initialized
INFO - 2017-08-19 07:33:47 --> Security Class Initialized
DEBUG - 2017-08-19 07:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:33:47 --> Input Class Initialized
INFO - 2017-08-19 07:33:47 --> Language Class Initialized
INFO - 2017-08-19 07:33:47 --> Loader Class Initialized
INFO - 2017-08-19 07:33:47 --> Helper loaded: url_helper
INFO - 2017-08-19 07:33:47 --> Helper loaded: file_helper
INFO - 2017-08-19 07:33:47 --> Database Driver Class Initialized
INFO - 2017-08-19 07:33:47 --> Email Class Initialized
DEBUG - 2017-08-19 07:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:33:47 --> Table Class Initialized
INFO - 2017-08-19 07:33:47 --> Controller Class Initialized
INFO - 2017-08-19 07:33:47 --> Helper loaded: form_helper
INFO - 2017-08-19 07:33:47 --> Model Class Initialized
INFO - 2017-08-19 07:33:47 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-19 07:33:47 --> Final output sent to browser
DEBUG - 2017-08-19 07:33:47 --> Total execution time: 0.2628
INFO - 2017-08-19 07:34:00 --> Config Class Initialized
INFO - 2017-08-19 07:34:00 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:34:00 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:34:00 --> Utf8 Class Initialized
INFO - 2017-08-19 07:34:00 --> URI Class Initialized
INFO - 2017-08-19 07:34:00 --> Router Class Initialized
INFO - 2017-08-19 07:34:00 --> Output Class Initialized
INFO - 2017-08-19 07:34:00 --> Security Class Initialized
DEBUG - 2017-08-19 07:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:34:00 --> Input Class Initialized
INFO - 2017-08-19 07:34:00 --> Language Class Initialized
INFO - 2017-08-19 07:34:00 --> Loader Class Initialized
INFO - 2017-08-19 07:34:00 --> Helper loaded: url_helper
INFO - 2017-08-19 07:34:00 --> Helper loaded: file_helper
INFO - 2017-08-19 07:34:00 --> Database Driver Class Initialized
INFO - 2017-08-19 07:34:00 --> Email Class Initialized
DEBUG - 2017-08-19 07:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:34:00 --> Table Class Initialized
INFO - 2017-08-19 07:34:00 --> Controller Class Initialized
INFO - 2017-08-19 07:34:00 --> Helper loaded: form_helper
INFO - 2017-08-19 07:34:00 --> Model Class Initialized
INFO - 2017-08-19 07:34:00 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-19 07:34:00 --> Final output sent to browser
DEBUG - 2017-08-19 07:34:00 --> Total execution time: 0.2431
INFO - 2017-08-19 07:34:07 --> Config Class Initialized
INFO - 2017-08-19 07:34:07 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:34:07 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:34:07 --> Utf8 Class Initialized
INFO - 2017-08-19 07:34:07 --> URI Class Initialized
INFO - 2017-08-19 07:34:07 --> Router Class Initialized
INFO - 2017-08-19 07:34:07 --> Output Class Initialized
INFO - 2017-08-19 07:34:07 --> Security Class Initialized
DEBUG - 2017-08-19 07:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:34:07 --> Input Class Initialized
INFO - 2017-08-19 07:34:07 --> Language Class Initialized
INFO - 2017-08-19 07:34:07 --> Loader Class Initialized
INFO - 2017-08-19 07:34:07 --> Helper loaded: url_helper
INFO - 2017-08-19 07:34:07 --> Helper loaded: file_helper
INFO - 2017-08-19 07:34:07 --> Database Driver Class Initialized
INFO - 2017-08-19 07:34:07 --> Email Class Initialized
DEBUG - 2017-08-19 07:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:34:07 --> Table Class Initialized
INFO - 2017-08-19 07:34:07 --> Controller Class Initialized
INFO - 2017-08-19 07:34:07 --> Helper loaded: form_helper
INFO - 2017-08-19 07:34:07 --> Model Class Initialized
INFO - 2017-08-19 07:34:07 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-19 07:34:07 --> Final output sent to browser
DEBUG - 2017-08-19 07:34:07 --> Total execution time: 0.2458
INFO - 2017-08-19 07:34:12 --> Config Class Initialized
INFO - 2017-08-19 07:34:12 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:34:12 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:34:12 --> Utf8 Class Initialized
INFO - 2017-08-19 07:34:12 --> URI Class Initialized
INFO - 2017-08-19 07:34:12 --> Router Class Initialized
INFO - 2017-08-19 07:34:12 --> Output Class Initialized
INFO - 2017-08-19 07:34:12 --> Security Class Initialized
DEBUG - 2017-08-19 07:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:34:12 --> Input Class Initialized
INFO - 2017-08-19 07:34:12 --> Language Class Initialized
INFO - 2017-08-19 07:34:12 --> Loader Class Initialized
INFO - 2017-08-19 07:34:12 --> Helper loaded: url_helper
INFO - 2017-08-19 07:34:12 --> Helper loaded: file_helper
INFO - 2017-08-19 07:34:12 --> Database Driver Class Initialized
INFO - 2017-08-19 07:34:13 --> Email Class Initialized
DEBUG - 2017-08-19 07:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:34:13 --> Table Class Initialized
INFO - 2017-08-19 07:34:13 --> Controller Class Initialized
INFO - 2017-08-19 07:34:13 --> Helper loaded: form_helper
INFO - 2017-08-19 07:34:13 --> Model Class Initialized
INFO - 2017-08-19 07:34:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-19 07:34:13 --> Final output sent to browser
DEBUG - 2017-08-19 07:34:13 --> Total execution time: 0.2592
INFO - 2017-08-19 07:34:15 --> Config Class Initialized
INFO - 2017-08-19 07:34:15 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:34:15 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:34:15 --> Utf8 Class Initialized
INFO - 2017-08-19 07:34:15 --> URI Class Initialized
INFO - 2017-08-19 07:34:15 --> Router Class Initialized
INFO - 2017-08-19 07:34:15 --> Output Class Initialized
INFO - 2017-08-19 07:34:15 --> Security Class Initialized
DEBUG - 2017-08-19 07:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:34:15 --> Input Class Initialized
INFO - 2017-08-19 07:34:15 --> Language Class Initialized
INFO - 2017-08-19 07:34:15 --> Loader Class Initialized
INFO - 2017-08-19 07:34:15 --> Helper loaded: url_helper
INFO - 2017-08-19 07:34:15 --> Helper loaded: file_helper
INFO - 2017-08-19 07:34:15 --> Database Driver Class Initialized
INFO - 2017-08-19 07:34:15 --> Email Class Initialized
DEBUG - 2017-08-19 07:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:34:15 --> Table Class Initialized
INFO - 2017-08-19 07:34:15 --> Controller Class Initialized
INFO - 2017-08-19 07:34:15 --> Helper loaded: form_helper
INFO - 2017-08-19 07:34:15 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:34:15 --> Final output sent to browser
DEBUG - 2017-08-19 07:34:15 --> Total execution time: 0.2290
INFO - 2017-08-19 07:35:24 --> Config Class Initialized
INFO - 2017-08-19 07:35:24 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:35:24 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:35:24 --> Utf8 Class Initialized
INFO - 2017-08-19 07:35:24 --> URI Class Initialized
INFO - 2017-08-19 07:35:24 --> Router Class Initialized
INFO - 2017-08-19 07:35:24 --> Output Class Initialized
INFO - 2017-08-19 07:35:24 --> Security Class Initialized
DEBUG - 2017-08-19 07:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:35:24 --> Input Class Initialized
INFO - 2017-08-19 07:35:24 --> Language Class Initialized
INFO - 2017-08-19 07:35:24 --> Loader Class Initialized
INFO - 2017-08-19 07:35:24 --> Helper loaded: url_helper
INFO - 2017-08-19 07:35:24 --> Helper loaded: file_helper
INFO - 2017-08-19 07:35:24 --> Database Driver Class Initialized
INFO - 2017-08-19 07:35:24 --> Email Class Initialized
DEBUG - 2017-08-19 07:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:35:24 --> Table Class Initialized
INFO - 2017-08-19 07:35:24 --> Controller Class Initialized
INFO - 2017-08-19 07:35:24 --> Helper loaded: form_helper
INFO - 2017-08-19 07:35:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:35:24 --> Final output sent to browser
DEBUG - 2017-08-19 07:35:24 --> Total execution time: 0.1633
INFO - 2017-08-19 07:35:31 --> Config Class Initialized
INFO - 2017-08-19 07:35:31 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:35:31 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:35:31 --> Utf8 Class Initialized
INFO - 2017-08-19 07:35:31 --> URI Class Initialized
INFO - 2017-08-19 07:35:31 --> Router Class Initialized
INFO - 2017-08-19 07:35:31 --> Output Class Initialized
INFO - 2017-08-19 07:35:31 --> Security Class Initialized
DEBUG - 2017-08-19 07:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:35:31 --> Input Class Initialized
INFO - 2017-08-19 07:35:31 --> Language Class Initialized
INFO - 2017-08-19 07:35:31 --> Loader Class Initialized
INFO - 2017-08-19 07:35:31 --> Helper loaded: url_helper
INFO - 2017-08-19 07:35:31 --> Helper loaded: file_helper
INFO - 2017-08-19 07:35:31 --> Database Driver Class Initialized
INFO - 2017-08-19 07:35:31 --> Email Class Initialized
DEBUG - 2017-08-19 07:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:35:31 --> Table Class Initialized
INFO - 2017-08-19 07:35:31 --> Controller Class Initialized
INFO - 2017-08-19 07:35:31 --> Helper loaded: form_helper
INFO - 2017-08-19 07:35:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:35:31 --> Final output sent to browser
DEBUG - 2017-08-19 07:35:31 --> Total execution time: 0.1606
INFO - 2017-08-19 07:39:35 --> Config Class Initialized
INFO - 2017-08-19 07:39:35 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:39:35 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:39:35 --> Utf8 Class Initialized
INFO - 2017-08-19 07:39:35 --> URI Class Initialized
DEBUG - 2017-08-19 07:39:35 --> No URI present. Default controller set.
INFO - 2017-08-19 07:39:35 --> Router Class Initialized
INFO - 2017-08-19 07:39:35 --> Output Class Initialized
INFO - 2017-08-19 07:39:35 --> Security Class Initialized
DEBUG - 2017-08-19 07:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:39:35 --> Input Class Initialized
INFO - 2017-08-19 07:39:35 --> Language Class Initialized
INFO - 2017-08-19 07:39:35 --> Loader Class Initialized
INFO - 2017-08-19 07:39:35 --> Helper loaded: url_helper
INFO - 2017-08-19 07:39:35 --> Helper loaded: file_helper
INFO - 2017-08-19 07:39:35 --> Database Driver Class Initialized
INFO - 2017-08-19 07:39:35 --> Email Class Initialized
DEBUG - 2017-08-19 07:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:39:35 --> Table Class Initialized
INFO - 2017-08-19 07:39:35 --> Controller Class Initialized
INFO - 2017-08-19 07:39:35 --> Model Class Initialized
INFO - 2017-08-19 07:39:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-19 07:39:35 --> Final output sent to browser
DEBUG - 2017-08-19 07:39:35 --> Total execution time: 0.4035
INFO - 2017-08-19 07:39:54 --> Config Class Initialized
INFO - 2017-08-19 07:39:54 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:39:54 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:39:54 --> Utf8 Class Initialized
INFO - 2017-08-19 07:39:54 --> URI Class Initialized
INFO - 2017-08-19 07:39:54 --> Router Class Initialized
INFO - 2017-08-19 07:39:54 --> Output Class Initialized
INFO - 2017-08-19 07:39:54 --> Security Class Initialized
DEBUG - 2017-08-19 07:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:39:54 --> Input Class Initialized
INFO - 2017-08-19 07:39:54 --> Language Class Initialized
INFO - 2017-08-19 07:39:54 --> Loader Class Initialized
INFO - 2017-08-19 07:39:54 --> Helper loaded: url_helper
INFO - 2017-08-19 07:39:54 --> Helper loaded: file_helper
INFO - 2017-08-19 07:39:54 --> Database Driver Class Initialized
INFO - 2017-08-19 07:39:54 --> Email Class Initialized
DEBUG - 2017-08-19 07:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:39:54 --> Table Class Initialized
INFO - 2017-08-19 07:39:54 --> Controller Class Initialized
INFO - 2017-08-19 07:39:54 --> Helper loaded: form_helper
INFO - 2017-08-19 07:39:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:39:54 --> Final output sent to browser
DEBUG - 2017-08-19 07:39:54 --> Total execution time: 0.1709
INFO - 2017-08-19 07:40:41 --> Config Class Initialized
INFO - 2017-08-19 07:40:41 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:40:41 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:40:41 --> Utf8 Class Initialized
INFO - 2017-08-19 07:40:41 --> URI Class Initialized
INFO - 2017-08-19 07:40:41 --> Router Class Initialized
INFO - 2017-08-19 07:40:41 --> Output Class Initialized
INFO - 2017-08-19 07:40:41 --> Security Class Initialized
DEBUG - 2017-08-19 07:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:40:41 --> Input Class Initialized
INFO - 2017-08-19 07:40:41 --> Language Class Initialized
INFO - 2017-08-19 07:40:41 --> Loader Class Initialized
INFO - 2017-08-19 07:40:41 --> Helper loaded: url_helper
INFO - 2017-08-19 07:40:41 --> Helper loaded: file_helper
INFO - 2017-08-19 07:40:41 --> Database Driver Class Initialized
INFO - 2017-08-19 07:40:41 --> Email Class Initialized
DEBUG - 2017-08-19 07:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:40:41 --> Table Class Initialized
INFO - 2017-08-19 07:40:41 --> Controller Class Initialized
INFO - 2017-08-19 07:40:41 --> Helper loaded: form_helper
INFO - 2017-08-19 07:40:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:40:41 --> Final output sent to browser
DEBUG - 2017-08-19 07:40:41 --> Total execution time: 0.1695
INFO - 2017-08-19 07:40:48 --> Config Class Initialized
INFO - 2017-08-19 07:40:48 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:40:48 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:40:48 --> Utf8 Class Initialized
INFO - 2017-08-19 07:40:48 --> URI Class Initialized
INFO - 2017-08-19 07:40:48 --> Router Class Initialized
INFO - 2017-08-19 07:40:48 --> Output Class Initialized
INFO - 2017-08-19 07:40:48 --> Security Class Initialized
DEBUG - 2017-08-19 07:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:40:48 --> Input Class Initialized
INFO - 2017-08-19 07:40:48 --> Language Class Initialized
INFO - 2017-08-19 07:40:48 --> Loader Class Initialized
INFO - 2017-08-19 07:40:48 --> Helper loaded: url_helper
INFO - 2017-08-19 07:40:48 --> Helper loaded: file_helper
INFO - 2017-08-19 07:40:48 --> Database Driver Class Initialized
INFO - 2017-08-19 07:40:48 --> Email Class Initialized
DEBUG - 2017-08-19 07:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:40:48 --> Table Class Initialized
INFO - 2017-08-19 07:40:48 --> Controller Class Initialized
INFO - 2017-08-19 07:40:48 --> Helper loaded: form_helper
INFO - 2017-08-19 07:40:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:40:48 --> Final output sent to browser
DEBUG - 2017-08-19 07:40:48 --> Total execution time: 0.1785
INFO - 2017-08-19 07:42:55 --> Config Class Initialized
INFO - 2017-08-19 07:42:55 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:42:55 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:42:55 --> Utf8 Class Initialized
INFO - 2017-08-19 07:42:55 --> URI Class Initialized
INFO - 2017-08-19 07:42:55 --> Router Class Initialized
INFO - 2017-08-19 07:42:55 --> Output Class Initialized
INFO - 2017-08-19 07:42:55 --> Security Class Initialized
DEBUG - 2017-08-19 07:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:42:55 --> Input Class Initialized
INFO - 2017-08-19 07:42:55 --> Language Class Initialized
INFO - 2017-08-19 07:42:55 --> Loader Class Initialized
INFO - 2017-08-19 07:42:55 --> Helper loaded: url_helper
INFO - 2017-08-19 07:42:55 --> Helper loaded: file_helper
INFO - 2017-08-19 07:42:55 --> Database Driver Class Initialized
INFO - 2017-08-19 07:42:55 --> Email Class Initialized
DEBUG - 2017-08-19 07:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:42:55 --> Table Class Initialized
INFO - 2017-08-19 07:42:55 --> Controller Class Initialized
INFO - 2017-08-19 07:42:55 --> Helper loaded: form_helper
INFO - 2017-08-19 07:42:55 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:42:55 --> Final output sent to browser
DEBUG - 2017-08-19 07:42:55 --> Total execution time: 0.1820
INFO - 2017-08-19 07:43:00 --> Config Class Initialized
INFO - 2017-08-19 07:43:00 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:43:00 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:43:00 --> Utf8 Class Initialized
INFO - 2017-08-19 07:43:00 --> URI Class Initialized
INFO - 2017-08-19 07:43:00 --> Router Class Initialized
INFO - 2017-08-19 07:43:00 --> Output Class Initialized
INFO - 2017-08-19 07:43:00 --> Security Class Initialized
DEBUG - 2017-08-19 07:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:43:01 --> Input Class Initialized
INFO - 2017-08-19 07:43:01 --> Language Class Initialized
INFO - 2017-08-19 07:43:01 --> Loader Class Initialized
INFO - 2017-08-19 07:43:01 --> Helper loaded: url_helper
INFO - 2017-08-19 07:43:01 --> Helper loaded: file_helper
INFO - 2017-08-19 07:43:01 --> Database Driver Class Initialized
INFO - 2017-08-19 07:43:01 --> Email Class Initialized
DEBUG - 2017-08-19 07:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:43:01 --> Table Class Initialized
INFO - 2017-08-19 07:43:01 --> Controller Class Initialized
INFO - 2017-08-19 07:43:01 --> Helper loaded: form_helper
INFO - 2017-08-19 07:43:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:43:01 --> Final output sent to browser
DEBUG - 2017-08-19 07:43:01 --> Total execution time: 0.1688
INFO - 2017-08-19 07:46:02 --> Config Class Initialized
INFO - 2017-08-19 07:46:02 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:46:02 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:46:02 --> Utf8 Class Initialized
INFO - 2017-08-19 07:46:02 --> URI Class Initialized
INFO - 2017-08-19 07:46:02 --> Router Class Initialized
INFO - 2017-08-19 07:46:02 --> Output Class Initialized
INFO - 2017-08-19 07:46:02 --> Security Class Initialized
DEBUG - 2017-08-19 07:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:46:02 --> Input Class Initialized
INFO - 2017-08-19 07:46:02 --> Language Class Initialized
INFO - 2017-08-19 07:46:02 --> Loader Class Initialized
INFO - 2017-08-19 07:46:02 --> Helper loaded: url_helper
INFO - 2017-08-19 07:46:02 --> Helper loaded: file_helper
INFO - 2017-08-19 07:46:02 --> Database Driver Class Initialized
INFO - 2017-08-19 07:46:02 --> Email Class Initialized
DEBUG - 2017-08-19 07:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:46:02 --> Table Class Initialized
INFO - 2017-08-19 07:46:02 --> Controller Class Initialized
INFO - 2017-08-19 07:46:02 --> Helper loaded: form_helper
INFO - 2017-08-19 07:46:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:46:02 --> Final output sent to browser
DEBUG - 2017-08-19 07:46:02 --> Total execution time: 0.1706
INFO - 2017-08-19 07:46:36 --> Config Class Initialized
INFO - 2017-08-19 07:46:36 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:46:36 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:46:36 --> Utf8 Class Initialized
INFO - 2017-08-19 07:46:36 --> URI Class Initialized
INFO - 2017-08-19 07:46:36 --> Router Class Initialized
INFO - 2017-08-19 07:46:36 --> Output Class Initialized
INFO - 2017-08-19 07:46:36 --> Security Class Initialized
DEBUG - 2017-08-19 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:46:36 --> Input Class Initialized
INFO - 2017-08-19 07:46:36 --> Language Class Initialized
INFO - 2017-08-19 07:46:36 --> Loader Class Initialized
INFO - 2017-08-19 07:46:36 --> Helper loaded: url_helper
INFO - 2017-08-19 07:46:36 --> Helper loaded: file_helper
INFO - 2017-08-19 07:46:36 --> Database Driver Class Initialized
INFO - 2017-08-19 07:46:36 --> Email Class Initialized
DEBUG - 2017-08-19 07:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:46:36 --> Table Class Initialized
INFO - 2017-08-19 07:46:36 --> Controller Class Initialized
INFO - 2017-08-19 07:46:36 --> Helper loaded: form_helper
INFO - 2017-08-19 07:46:36 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:46:36 --> Final output sent to browser
DEBUG - 2017-08-19 07:46:36 --> Total execution time: 0.1708
INFO - 2017-08-19 07:46:53 --> Config Class Initialized
INFO - 2017-08-19 07:46:53 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:46:53 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:46:53 --> Utf8 Class Initialized
INFO - 2017-08-19 07:46:53 --> URI Class Initialized
INFO - 2017-08-19 07:46:53 --> Router Class Initialized
INFO - 2017-08-19 07:46:53 --> Output Class Initialized
INFO - 2017-08-19 07:46:53 --> Security Class Initialized
DEBUG - 2017-08-19 07:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:46:53 --> Input Class Initialized
INFO - 2017-08-19 07:46:53 --> Language Class Initialized
INFO - 2017-08-19 07:46:53 --> Loader Class Initialized
INFO - 2017-08-19 07:46:53 --> Helper loaded: url_helper
INFO - 2017-08-19 07:46:53 --> Helper loaded: file_helper
INFO - 2017-08-19 07:46:53 --> Database Driver Class Initialized
INFO - 2017-08-19 07:46:53 --> Email Class Initialized
DEBUG - 2017-08-19 07:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:46:53 --> Table Class Initialized
INFO - 2017-08-19 07:46:53 --> Controller Class Initialized
INFO - 2017-08-19 07:46:53 --> Helper loaded: form_helper
INFO - 2017-08-19 07:46:53 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:46:53 --> Final output sent to browser
DEBUG - 2017-08-19 07:46:53 --> Total execution time: 0.1735
INFO - 2017-08-19 07:47:03 --> Config Class Initialized
INFO - 2017-08-19 07:47:03 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:47:03 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:47:03 --> Utf8 Class Initialized
INFO - 2017-08-19 07:47:03 --> URI Class Initialized
INFO - 2017-08-19 07:47:03 --> Router Class Initialized
INFO - 2017-08-19 07:47:03 --> Output Class Initialized
INFO - 2017-08-19 07:47:03 --> Security Class Initialized
DEBUG - 2017-08-19 07:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:47:03 --> Input Class Initialized
INFO - 2017-08-19 07:47:03 --> Language Class Initialized
INFO - 2017-08-19 07:47:03 --> Loader Class Initialized
INFO - 2017-08-19 07:47:03 --> Helper loaded: url_helper
INFO - 2017-08-19 07:47:03 --> Helper loaded: file_helper
INFO - 2017-08-19 07:47:03 --> Database Driver Class Initialized
INFO - 2017-08-19 07:47:03 --> Email Class Initialized
DEBUG - 2017-08-19 07:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:47:03 --> Table Class Initialized
INFO - 2017-08-19 07:47:04 --> Controller Class Initialized
INFO - 2017-08-19 07:47:04 --> Helper loaded: form_helper
INFO - 2017-08-19 07:47:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:47:04 --> Final output sent to browser
DEBUG - 2017-08-19 07:47:04 --> Total execution time: 0.1726
INFO - 2017-08-19 07:47:06 --> Config Class Initialized
INFO - 2017-08-19 07:47:06 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:47:06 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:47:06 --> Utf8 Class Initialized
INFO - 2017-08-19 07:47:06 --> URI Class Initialized
INFO - 2017-08-19 07:47:06 --> Router Class Initialized
INFO - 2017-08-19 07:47:06 --> Output Class Initialized
INFO - 2017-08-19 07:47:06 --> Security Class Initialized
DEBUG - 2017-08-19 07:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:47:06 --> Input Class Initialized
INFO - 2017-08-19 07:47:06 --> Language Class Initialized
INFO - 2017-08-19 07:47:06 --> Loader Class Initialized
INFO - 2017-08-19 07:47:06 --> Helper loaded: url_helper
INFO - 2017-08-19 07:47:06 --> Helper loaded: file_helper
INFO - 2017-08-19 07:47:06 --> Database Driver Class Initialized
INFO - 2017-08-19 07:47:06 --> Email Class Initialized
DEBUG - 2017-08-19 07:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:47:06 --> Table Class Initialized
INFO - 2017-08-19 07:47:06 --> Controller Class Initialized
INFO - 2017-08-19 07:47:06 --> Helper loaded: form_helper
INFO - 2017-08-19 07:47:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:47:06 --> Final output sent to browser
DEBUG - 2017-08-19 07:47:06 --> Total execution time: 0.1770
INFO - 2017-08-19 07:47:10 --> Config Class Initialized
INFO - 2017-08-19 07:47:10 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:47:10 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:47:10 --> Utf8 Class Initialized
INFO - 2017-08-19 07:47:10 --> URI Class Initialized
INFO - 2017-08-19 07:47:10 --> Router Class Initialized
INFO - 2017-08-19 07:47:10 --> Output Class Initialized
INFO - 2017-08-19 07:47:10 --> Security Class Initialized
DEBUG - 2017-08-19 07:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:47:10 --> Input Class Initialized
INFO - 2017-08-19 07:47:10 --> Language Class Initialized
INFO - 2017-08-19 07:47:10 --> Loader Class Initialized
INFO - 2017-08-19 07:47:10 --> Helper loaded: url_helper
INFO - 2017-08-19 07:47:10 --> Helper loaded: file_helper
INFO - 2017-08-19 07:47:10 --> Database Driver Class Initialized
INFO - 2017-08-19 07:47:10 --> Email Class Initialized
DEBUG - 2017-08-19 07:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:47:10 --> Table Class Initialized
INFO - 2017-08-19 07:47:10 --> Controller Class Initialized
INFO - 2017-08-19 07:47:10 --> Helper loaded: form_helper
INFO - 2017-08-19 07:47:10 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:47:10 --> Final output sent to browser
DEBUG - 2017-08-19 07:47:10 --> Total execution time: 0.1761
INFO - 2017-08-19 07:47:14 --> Config Class Initialized
INFO - 2017-08-19 07:47:14 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:47:14 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:47:14 --> Utf8 Class Initialized
INFO - 2017-08-19 07:47:14 --> URI Class Initialized
INFO - 2017-08-19 07:47:14 --> Router Class Initialized
INFO - 2017-08-19 07:47:14 --> Output Class Initialized
INFO - 2017-08-19 07:47:14 --> Security Class Initialized
DEBUG - 2017-08-19 07:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:47:14 --> Input Class Initialized
INFO - 2017-08-19 07:47:14 --> Language Class Initialized
INFO - 2017-08-19 07:47:14 --> Loader Class Initialized
INFO - 2017-08-19 07:47:14 --> Helper loaded: url_helper
INFO - 2017-08-19 07:47:14 --> Helper loaded: file_helper
INFO - 2017-08-19 07:47:14 --> Database Driver Class Initialized
INFO - 2017-08-19 07:47:14 --> Email Class Initialized
DEBUG - 2017-08-19 07:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:47:14 --> Table Class Initialized
INFO - 2017-08-19 07:47:14 --> Controller Class Initialized
INFO - 2017-08-19 07:47:14 --> Helper loaded: form_helper
INFO - 2017-08-19 07:47:14 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:47:14 --> Final output sent to browser
DEBUG - 2017-08-19 07:47:14 --> Total execution time: 0.1707
INFO - 2017-08-19 07:47:48 --> Config Class Initialized
INFO - 2017-08-19 07:47:48 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:47:48 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:47:48 --> Utf8 Class Initialized
INFO - 2017-08-19 07:47:48 --> URI Class Initialized
INFO - 2017-08-19 07:47:48 --> Router Class Initialized
INFO - 2017-08-19 07:47:48 --> Output Class Initialized
INFO - 2017-08-19 07:47:48 --> Security Class Initialized
DEBUG - 2017-08-19 07:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:47:48 --> Input Class Initialized
INFO - 2017-08-19 07:47:48 --> Language Class Initialized
INFO - 2017-08-19 07:47:48 --> Loader Class Initialized
INFO - 2017-08-19 07:47:48 --> Helper loaded: url_helper
INFO - 2017-08-19 07:47:48 --> Helper loaded: file_helper
INFO - 2017-08-19 07:47:48 --> Database Driver Class Initialized
INFO - 2017-08-19 07:47:48 --> Email Class Initialized
DEBUG - 2017-08-19 07:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:47:48 --> Table Class Initialized
INFO - 2017-08-19 07:47:48 --> Controller Class Initialized
INFO - 2017-08-19 07:47:48 --> Helper loaded: form_helper
INFO - 2017-08-19 07:47:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:47:48 --> Final output sent to browser
DEBUG - 2017-08-19 07:47:48 --> Total execution time: 0.1749
INFO - 2017-08-19 07:47:58 --> Config Class Initialized
INFO - 2017-08-19 07:47:58 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:47:58 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:47:58 --> Utf8 Class Initialized
INFO - 2017-08-19 07:47:58 --> URI Class Initialized
INFO - 2017-08-19 07:47:58 --> Router Class Initialized
INFO - 2017-08-19 07:47:59 --> Output Class Initialized
INFO - 2017-08-19 07:47:59 --> Security Class Initialized
DEBUG - 2017-08-19 07:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:47:59 --> Input Class Initialized
INFO - 2017-08-19 07:47:59 --> Language Class Initialized
INFO - 2017-08-19 07:47:59 --> Loader Class Initialized
INFO - 2017-08-19 07:47:59 --> Helper loaded: url_helper
INFO - 2017-08-19 07:47:59 --> Helper loaded: file_helper
INFO - 2017-08-19 07:47:59 --> Database Driver Class Initialized
INFO - 2017-08-19 07:47:59 --> Email Class Initialized
DEBUG - 2017-08-19 07:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:47:59 --> Table Class Initialized
INFO - 2017-08-19 07:47:59 --> Controller Class Initialized
INFO - 2017-08-19 07:47:59 --> Helper loaded: form_helper
INFO - 2017-08-19 07:47:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:47:59 --> Final output sent to browser
DEBUG - 2017-08-19 07:47:59 --> Total execution time: 0.1757
INFO - 2017-08-19 07:48:05 --> Config Class Initialized
INFO - 2017-08-19 07:48:05 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:48:05 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:48:05 --> Utf8 Class Initialized
INFO - 2017-08-19 07:48:05 --> URI Class Initialized
INFO - 2017-08-19 07:48:05 --> Router Class Initialized
INFO - 2017-08-19 07:48:05 --> Output Class Initialized
INFO - 2017-08-19 07:48:05 --> Security Class Initialized
DEBUG - 2017-08-19 07:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:48:05 --> Input Class Initialized
INFO - 2017-08-19 07:48:05 --> Language Class Initialized
INFO - 2017-08-19 07:48:05 --> Loader Class Initialized
INFO - 2017-08-19 07:48:05 --> Helper loaded: url_helper
INFO - 2017-08-19 07:48:05 --> Helper loaded: file_helper
INFO - 2017-08-19 07:48:05 --> Database Driver Class Initialized
INFO - 2017-08-19 07:48:05 --> Email Class Initialized
DEBUG - 2017-08-19 07:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:48:05 --> Table Class Initialized
INFO - 2017-08-19 07:48:05 --> Controller Class Initialized
INFO - 2017-08-19 07:48:05 --> Helper loaded: form_helper
INFO - 2017-08-19 07:48:05 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:48:05 --> Final output sent to browser
DEBUG - 2017-08-19 07:48:05 --> Total execution time: 0.1828
INFO - 2017-08-19 07:48:17 --> Config Class Initialized
INFO - 2017-08-19 07:48:17 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:48:17 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:48:17 --> Utf8 Class Initialized
INFO - 2017-08-19 07:48:17 --> URI Class Initialized
INFO - 2017-08-19 07:48:17 --> Router Class Initialized
INFO - 2017-08-19 07:48:17 --> Output Class Initialized
INFO - 2017-08-19 07:48:17 --> Security Class Initialized
DEBUG - 2017-08-19 07:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:48:17 --> Input Class Initialized
INFO - 2017-08-19 07:48:17 --> Language Class Initialized
INFO - 2017-08-19 07:48:17 --> Loader Class Initialized
INFO - 2017-08-19 07:48:17 --> Helper loaded: url_helper
INFO - 2017-08-19 07:48:17 --> Helper loaded: file_helper
INFO - 2017-08-19 07:48:17 --> Database Driver Class Initialized
INFO - 2017-08-19 07:48:17 --> Email Class Initialized
DEBUG - 2017-08-19 07:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:48:17 --> Table Class Initialized
INFO - 2017-08-19 07:48:17 --> Controller Class Initialized
INFO - 2017-08-19 07:48:17 --> Helper loaded: form_helper
INFO - 2017-08-19 07:48:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:48:17 --> Final output sent to browser
DEBUG - 2017-08-19 07:48:17 --> Total execution time: 0.1760
INFO - 2017-08-19 07:48:28 --> Config Class Initialized
INFO - 2017-08-19 07:48:28 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:48:28 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:48:28 --> Utf8 Class Initialized
INFO - 2017-08-19 07:48:28 --> URI Class Initialized
INFO - 2017-08-19 07:48:28 --> Router Class Initialized
INFO - 2017-08-19 07:48:28 --> Output Class Initialized
INFO - 2017-08-19 07:48:28 --> Security Class Initialized
DEBUG - 2017-08-19 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:48:28 --> Input Class Initialized
INFO - 2017-08-19 07:48:28 --> Language Class Initialized
INFO - 2017-08-19 07:48:28 --> Loader Class Initialized
INFO - 2017-08-19 07:48:28 --> Helper loaded: url_helper
INFO - 2017-08-19 07:48:28 --> Helper loaded: file_helper
INFO - 2017-08-19 07:48:29 --> Database Driver Class Initialized
INFO - 2017-08-19 07:48:29 --> Email Class Initialized
DEBUG - 2017-08-19 07:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:48:29 --> Table Class Initialized
INFO - 2017-08-19 07:48:29 --> Controller Class Initialized
INFO - 2017-08-19 07:48:29 --> Helper loaded: form_helper
INFO - 2017-08-19 07:48:29 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:48:29 --> Final output sent to browser
DEBUG - 2017-08-19 07:48:29 --> Total execution time: 0.1907
INFO - 2017-08-19 07:48:45 --> Config Class Initialized
INFO - 2017-08-19 07:48:45 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:48:45 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:48:45 --> Utf8 Class Initialized
INFO - 2017-08-19 07:48:45 --> URI Class Initialized
INFO - 2017-08-19 07:48:45 --> Router Class Initialized
INFO - 2017-08-19 07:48:45 --> Output Class Initialized
INFO - 2017-08-19 07:48:45 --> Security Class Initialized
DEBUG - 2017-08-19 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:48:45 --> Input Class Initialized
INFO - 2017-08-19 07:48:45 --> Language Class Initialized
INFO - 2017-08-19 07:48:45 --> Loader Class Initialized
INFO - 2017-08-19 07:48:45 --> Helper loaded: url_helper
INFO - 2017-08-19 07:48:45 --> Helper loaded: file_helper
INFO - 2017-08-19 07:48:45 --> Database Driver Class Initialized
INFO - 2017-08-19 07:48:45 --> Email Class Initialized
DEBUG - 2017-08-19 07:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:48:45 --> Table Class Initialized
INFO - 2017-08-19 07:48:45 --> Controller Class Initialized
INFO - 2017-08-19 07:48:45 --> Helper loaded: form_helper
INFO - 2017-08-19 07:48:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:48:45 --> Final output sent to browser
DEBUG - 2017-08-19 07:48:45 --> Total execution time: 0.1830
INFO - 2017-08-19 07:48:51 --> Config Class Initialized
INFO - 2017-08-19 07:48:51 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:48:51 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:48:51 --> Utf8 Class Initialized
INFO - 2017-08-19 07:48:51 --> URI Class Initialized
INFO - 2017-08-19 07:48:52 --> Router Class Initialized
INFO - 2017-08-19 07:48:52 --> Output Class Initialized
INFO - 2017-08-19 07:48:52 --> Security Class Initialized
DEBUG - 2017-08-19 07:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:48:52 --> Input Class Initialized
INFO - 2017-08-19 07:48:52 --> Language Class Initialized
INFO - 2017-08-19 07:48:52 --> Loader Class Initialized
INFO - 2017-08-19 07:48:52 --> Helper loaded: url_helper
INFO - 2017-08-19 07:48:52 --> Helper loaded: file_helper
INFO - 2017-08-19 07:48:52 --> Database Driver Class Initialized
INFO - 2017-08-19 07:48:52 --> Email Class Initialized
DEBUG - 2017-08-19 07:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:48:52 --> Table Class Initialized
INFO - 2017-08-19 07:48:52 --> Controller Class Initialized
INFO - 2017-08-19 07:48:52 --> Helper loaded: form_helper
INFO - 2017-08-19 07:48:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:48:52 --> Final output sent to browser
DEBUG - 2017-08-19 07:48:52 --> Total execution time: 0.1864
INFO - 2017-08-19 07:58:32 --> Config Class Initialized
INFO - 2017-08-19 07:58:32 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:58:32 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:58:32 --> Utf8 Class Initialized
INFO - 2017-08-19 07:58:32 --> URI Class Initialized
INFO - 2017-08-19 07:58:32 --> Router Class Initialized
INFO - 2017-08-19 07:58:32 --> Output Class Initialized
INFO - 2017-08-19 07:58:32 --> Security Class Initialized
DEBUG - 2017-08-19 07:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:58:32 --> Input Class Initialized
INFO - 2017-08-19 07:58:32 --> Language Class Initialized
INFO - 2017-08-19 07:58:32 --> Loader Class Initialized
INFO - 2017-08-19 07:58:32 --> Helper loaded: url_helper
INFO - 2017-08-19 07:58:32 --> Helper loaded: file_helper
INFO - 2017-08-19 07:58:32 --> Database Driver Class Initialized
INFO - 2017-08-19 07:58:32 --> Email Class Initialized
DEBUG - 2017-08-19 07:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 07:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 07:58:32 --> Table Class Initialized
INFO - 2017-08-19 07:58:32 --> Controller Class Initialized
INFO - 2017-08-19 07:58:32 --> Helper loaded: form_helper
INFO - 2017-08-19 07:58:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 07:58:32 --> Final output sent to browser
DEBUG - 2017-08-19 07:58:32 --> Total execution time: 0.1692
INFO - 2017-08-19 08:04:08 --> Config Class Initialized
INFO - 2017-08-19 08:04:08 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:04:08 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:04:08 --> Utf8 Class Initialized
INFO - 2017-08-19 08:04:08 --> URI Class Initialized
INFO - 2017-08-19 08:04:08 --> Router Class Initialized
INFO - 2017-08-19 08:04:08 --> Output Class Initialized
INFO - 2017-08-19 08:04:08 --> Security Class Initialized
DEBUG - 2017-08-19 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:04:08 --> Input Class Initialized
INFO - 2017-08-19 08:04:08 --> Language Class Initialized
INFO - 2017-08-19 08:04:08 --> Loader Class Initialized
INFO - 2017-08-19 08:04:08 --> Helper loaded: url_helper
INFO - 2017-08-19 08:04:08 --> Helper loaded: file_helper
INFO - 2017-08-19 08:04:08 --> Database Driver Class Initialized
INFO - 2017-08-19 08:04:08 --> Email Class Initialized
DEBUG - 2017-08-19 08:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:04:08 --> Table Class Initialized
INFO - 2017-08-19 08:04:08 --> Controller Class Initialized
INFO - 2017-08-19 08:04:08 --> Helper loaded: form_helper
INFO - 2017-08-19 08:04:08 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:04:08 --> Final output sent to browser
DEBUG - 2017-08-19 08:04:08 --> Total execution time: 0.1931
INFO - 2017-08-19 08:07:04 --> Config Class Initialized
INFO - 2017-08-19 08:07:04 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:07:04 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:07:04 --> Utf8 Class Initialized
INFO - 2017-08-19 08:07:04 --> URI Class Initialized
INFO - 2017-08-19 08:07:04 --> Router Class Initialized
INFO - 2017-08-19 08:07:04 --> Output Class Initialized
INFO - 2017-08-19 08:07:04 --> Security Class Initialized
DEBUG - 2017-08-19 08:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:07:04 --> Input Class Initialized
INFO - 2017-08-19 08:07:04 --> Language Class Initialized
INFO - 2017-08-19 08:07:04 --> Loader Class Initialized
INFO - 2017-08-19 08:07:04 --> Helper loaded: url_helper
INFO - 2017-08-19 08:07:04 --> Helper loaded: file_helper
INFO - 2017-08-19 08:07:04 --> Database Driver Class Initialized
INFO - 2017-08-19 08:07:04 --> Email Class Initialized
DEBUG - 2017-08-19 08:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:07:04 --> Table Class Initialized
INFO - 2017-08-19 08:07:04 --> Controller Class Initialized
INFO - 2017-08-19 08:07:04 --> Helper loaded: form_helper
INFO - 2017-08-19 08:07:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:07:04 --> Final output sent to browser
DEBUG - 2017-08-19 08:07:04 --> Total execution time: 0.1700
INFO - 2017-08-19 08:07:45 --> Config Class Initialized
INFO - 2017-08-19 08:07:45 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:07:45 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:07:45 --> Utf8 Class Initialized
INFO - 2017-08-19 08:07:45 --> URI Class Initialized
INFO - 2017-08-19 08:07:45 --> Router Class Initialized
INFO - 2017-08-19 08:07:45 --> Output Class Initialized
INFO - 2017-08-19 08:07:45 --> Security Class Initialized
DEBUG - 2017-08-19 08:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:07:45 --> Input Class Initialized
INFO - 2017-08-19 08:07:45 --> Language Class Initialized
INFO - 2017-08-19 08:07:46 --> Loader Class Initialized
INFO - 2017-08-19 08:07:46 --> Helper loaded: url_helper
INFO - 2017-08-19 08:07:46 --> Helper loaded: file_helper
INFO - 2017-08-19 08:07:46 --> Database Driver Class Initialized
INFO - 2017-08-19 08:07:46 --> Email Class Initialized
DEBUG - 2017-08-19 08:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:07:46 --> Table Class Initialized
INFO - 2017-08-19 08:07:46 --> Controller Class Initialized
INFO - 2017-08-19 08:07:46 --> Helper loaded: form_helper
INFO - 2017-08-19 08:07:46 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:07:46 --> Final output sent to browser
DEBUG - 2017-08-19 08:07:46 --> Total execution time: 0.1864
INFO - 2017-08-19 08:07:53 --> Config Class Initialized
INFO - 2017-08-19 08:07:53 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:07:53 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:07:53 --> Utf8 Class Initialized
INFO - 2017-08-19 08:07:53 --> URI Class Initialized
INFO - 2017-08-19 08:07:53 --> Router Class Initialized
INFO - 2017-08-19 08:07:53 --> Output Class Initialized
INFO - 2017-08-19 08:07:53 --> Security Class Initialized
DEBUG - 2017-08-19 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:07:53 --> Input Class Initialized
INFO - 2017-08-19 08:07:53 --> Language Class Initialized
INFO - 2017-08-19 08:07:53 --> Loader Class Initialized
INFO - 2017-08-19 08:07:53 --> Helper loaded: url_helper
INFO - 2017-08-19 08:07:53 --> Helper loaded: file_helper
INFO - 2017-08-19 08:07:53 --> Database Driver Class Initialized
INFO - 2017-08-19 08:07:53 --> Email Class Initialized
DEBUG - 2017-08-19 08:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:07:53 --> Table Class Initialized
INFO - 2017-08-19 08:07:53 --> Controller Class Initialized
INFO - 2017-08-19 08:07:53 --> Helper loaded: form_helper
INFO - 2017-08-19 08:07:53 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:07:53 --> Final output sent to browser
DEBUG - 2017-08-19 08:07:53 --> Total execution time: 0.1781
INFO - 2017-08-19 08:08:31 --> Config Class Initialized
INFO - 2017-08-19 08:08:31 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:08:31 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:08:31 --> Utf8 Class Initialized
INFO - 2017-08-19 08:08:31 --> URI Class Initialized
INFO - 2017-08-19 08:08:31 --> Router Class Initialized
INFO - 2017-08-19 08:08:31 --> Output Class Initialized
INFO - 2017-08-19 08:08:31 --> Security Class Initialized
DEBUG - 2017-08-19 08:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:08:31 --> Input Class Initialized
INFO - 2017-08-19 08:08:31 --> Language Class Initialized
INFO - 2017-08-19 08:08:31 --> Loader Class Initialized
INFO - 2017-08-19 08:08:31 --> Helper loaded: url_helper
INFO - 2017-08-19 08:08:31 --> Helper loaded: file_helper
INFO - 2017-08-19 08:08:31 --> Database Driver Class Initialized
INFO - 2017-08-19 08:08:31 --> Email Class Initialized
DEBUG - 2017-08-19 08:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:08:31 --> Table Class Initialized
INFO - 2017-08-19 08:08:31 --> Controller Class Initialized
INFO - 2017-08-19 08:08:31 --> Helper loaded: form_helper
INFO - 2017-08-19 08:08:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:08:31 --> Final output sent to browser
DEBUG - 2017-08-19 08:08:31 --> Total execution time: 0.1740
INFO - 2017-08-19 08:08:51 --> Config Class Initialized
INFO - 2017-08-19 08:08:51 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:08:51 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:08:51 --> Utf8 Class Initialized
INFO - 2017-08-19 08:08:51 --> URI Class Initialized
INFO - 2017-08-19 08:08:51 --> Router Class Initialized
INFO - 2017-08-19 08:08:51 --> Output Class Initialized
INFO - 2017-08-19 08:08:51 --> Security Class Initialized
DEBUG - 2017-08-19 08:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:08:51 --> Input Class Initialized
INFO - 2017-08-19 08:08:51 --> Language Class Initialized
INFO - 2017-08-19 08:08:51 --> Loader Class Initialized
INFO - 2017-08-19 08:08:52 --> Helper loaded: url_helper
INFO - 2017-08-19 08:08:52 --> Helper loaded: file_helper
INFO - 2017-08-19 08:08:52 --> Database Driver Class Initialized
INFO - 2017-08-19 08:08:52 --> Email Class Initialized
DEBUG - 2017-08-19 08:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:08:52 --> Table Class Initialized
INFO - 2017-08-19 08:08:52 --> Controller Class Initialized
INFO - 2017-08-19 08:08:52 --> Helper loaded: form_helper
INFO - 2017-08-19 08:08:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:08:52 --> Final output sent to browser
DEBUG - 2017-08-19 08:08:52 --> Total execution time: 0.1866
INFO - 2017-08-19 08:09:17 --> Config Class Initialized
INFO - 2017-08-19 08:09:17 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:09:17 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:09:17 --> Utf8 Class Initialized
INFO - 2017-08-19 08:09:17 --> URI Class Initialized
DEBUG - 2017-08-19 08:09:17 --> No URI present. Default controller set.
INFO - 2017-08-19 08:09:17 --> Router Class Initialized
INFO - 2017-08-19 08:09:17 --> Output Class Initialized
INFO - 2017-08-19 08:09:18 --> Security Class Initialized
DEBUG - 2017-08-19 08:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:09:18 --> Input Class Initialized
INFO - 2017-08-19 08:09:18 --> Language Class Initialized
INFO - 2017-08-19 08:09:18 --> Loader Class Initialized
INFO - 2017-08-19 08:09:18 --> Helper loaded: url_helper
INFO - 2017-08-19 08:09:18 --> Helper loaded: file_helper
INFO - 2017-08-19 08:09:18 --> Database Driver Class Initialized
INFO - 2017-08-19 08:09:18 --> Email Class Initialized
DEBUG - 2017-08-19 08:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:09:18 --> Table Class Initialized
INFO - 2017-08-19 08:09:18 --> Controller Class Initialized
INFO - 2017-08-19 08:09:18 --> Model Class Initialized
INFO - 2017-08-19 08:09:18 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-19 08:09:18 --> Final output sent to browser
DEBUG - 2017-08-19 08:09:18 --> Total execution time: 0.1879
INFO - 2017-08-19 08:09:50 --> Config Class Initialized
INFO - 2017-08-19 08:09:50 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:09:50 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:09:50 --> Utf8 Class Initialized
INFO - 2017-08-19 08:09:50 --> URI Class Initialized
INFO - 2017-08-19 08:09:50 --> Router Class Initialized
INFO - 2017-08-19 08:09:50 --> Output Class Initialized
INFO - 2017-08-19 08:09:50 --> Security Class Initialized
DEBUG - 2017-08-19 08:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:09:50 --> Input Class Initialized
INFO - 2017-08-19 08:09:50 --> Language Class Initialized
INFO - 2017-08-19 08:09:50 --> Loader Class Initialized
INFO - 2017-08-19 08:09:50 --> Helper loaded: url_helper
INFO - 2017-08-19 08:09:50 --> Helper loaded: file_helper
INFO - 2017-08-19 08:09:50 --> Database Driver Class Initialized
INFO - 2017-08-19 08:09:50 --> Email Class Initialized
DEBUG - 2017-08-19 08:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:09:50 --> Table Class Initialized
INFO - 2017-08-19 08:09:50 --> Controller Class Initialized
INFO - 2017-08-19 08:09:50 --> Model Class Initialized
INFO - 2017-08-19 08:10:03 --> Config Class Initialized
INFO - 2017-08-19 08:10:03 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:10:03 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:10:03 --> Utf8 Class Initialized
INFO - 2017-08-19 08:10:03 --> URI Class Initialized
DEBUG - 2017-08-19 08:10:03 --> No URI present. Default controller set.
INFO - 2017-08-19 08:10:03 --> Router Class Initialized
INFO - 2017-08-19 08:10:03 --> Output Class Initialized
INFO - 2017-08-19 08:10:03 --> Security Class Initialized
DEBUG - 2017-08-19 08:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:10:03 --> Input Class Initialized
INFO - 2017-08-19 08:10:03 --> Language Class Initialized
INFO - 2017-08-19 08:10:03 --> Loader Class Initialized
INFO - 2017-08-19 08:10:03 --> Helper loaded: url_helper
INFO - 2017-08-19 08:10:03 --> Helper loaded: file_helper
INFO - 2017-08-19 08:10:03 --> Database Driver Class Initialized
INFO - 2017-08-19 08:10:03 --> Email Class Initialized
DEBUG - 2017-08-19 08:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:10:03 --> Table Class Initialized
INFO - 2017-08-19 08:10:03 --> Controller Class Initialized
INFO - 2017-08-19 08:10:03 --> Model Class Initialized
INFO - 2017-08-19 08:10:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-19 08:10:03 --> Final output sent to browser
DEBUG - 2017-08-19 08:10:03 --> Total execution time: 0.1869
INFO - 2017-08-19 08:10:45 --> Config Class Initialized
INFO - 2017-08-19 08:10:45 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:10:45 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:10:45 --> Utf8 Class Initialized
INFO - 2017-08-19 08:10:45 --> URI Class Initialized
INFO - 2017-08-19 08:10:45 --> Router Class Initialized
INFO - 2017-08-19 08:10:45 --> Output Class Initialized
INFO - 2017-08-19 08:10:45 --> Security Class Initialized
DEBUG - 2017-08-19 08:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:10:45 --> Input Class Initialized
INFO - 2017-08-19 08:10:45 --> Language Class Initialized
INFO - 2017-08-19 08:10:45 --> Loader Class Initialized
INFO - 2017-08-19 08:10:45 --> Helper loaded: url_helper
INFO - 2017-08-19 08:10:45 --> Helper loaded: file_helper
INFO - 2017-08-19 08:10:45 --> Database Driver Class Initialized
INFO - 2017-08-19 08:10:45 --> Email Class Initialized
DEBUG - 2017-08-19 08:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:10:45 --> Table Class Initialized
INFO - 2017-08-19 08:10:45 --> Controller Class Initialized
INFO - 2017-08-19 08:10:45 --> Helper loaded: form_helper
INFO - 2017-08-19 08:10:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:10:45 --> Final output sent to browser
DEBUG - 2017-08-19 08:10:45 --> Total execution time: 0.2089
INFO - 2017-08-19 08:10:52 --> Config Class Initialized
INFO - 2017-08-19 08:10:52 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:10:52 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:10:52 --> Utf8 Class Initialized
INFO - 2017-08-19 08:10:52 --> URI Class Initialized
INFO - 2017-08-19 08:10:52 --> Router Class Initialized
INFO - 2017-08-19 08:10:52 --> Output Class Initialized
INFO - 2017-08-19 08:10:52 --> Security Class Initialized
DEBUG - 2017-08-19 08:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:10:52 --> Input Class Initialized
INFO - 2017-08-19 08:10:52 --> Language Class Initialized
INFO - 2017-08-19 08:10:52 --> Loader Class Initialized
INFO - 2017-08-19 08:10:52 --> Helper loaded: url_helper
INFO - 2017-08-19 08:10:52 --> Helper loaded: file_helper
INFO - 2017-08-19 08:10:52 --> Database Driver Class Initialized
INFO - 2017-08-19 08:10:52 --> Email Class Initialized
DEBUG - 2017-08-19 08:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:10:52 --> Table Class Initialized
INFO - 2017-08-19 08:10:52 --> Controller Class Initialized
INFO - 2017-08-19 08:10:52 --> Helper loaded: form_helper
INFO - 2017-08-19 08:10:52 --> Upload Class Initialized
INFO - 2017-08-19 08:10:52 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-08-19 08:10:52 --> The upload path does not appear to be valid.
INFO - 2017-08-19 08:10:52 --> Final output sent to browser
DEBUG - 2017-08-19 08:10:52 --> Total execution time: 0.2490
INFO - 2017-08-19 08:11:06 --> Config Class Initialized
INFO - 2017-08-19 08:11:06 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:11:06 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:11:06 --> Utf8 Class Initialized
INFO - 2017-08-19 08:11:06 --> URI Class Initialized
INFO - 2017-08-19 08:11:06 --> Router Class Initialized
INFO - 2017-08-19 08:11:06 --> Output Class Initialized
INFO - 2017-08-19 08:11:06 --> Security Class Initialized
DEBUG - 2017-08-19 08:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:11:06 --> Input Class Initialized
INFO - 2017-08-19 08:11:06 --> Language Class Initialized
INFO - 2017-08-19 08:11:06 --> Loader Class Initialized
INFO - 2017-08-19 08:11:06 --> Helper loaded: url_helper
INFO - 2017-08-19 08:11:06 --> Helper loaded: file_helper
INFO - 2017-08-19 08:11:06 --> Database Driver Class Initialized
INFO - 2017-08-19 08:11:06 --> Email Class Initialized
DEBUG - 2017-08-19 08:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:11:06 --> Table Class Initialized
INFO - 2017-08-19 08:11:06 --> Controller Class Initialized
INFO - 2017-08-19 08:11:06 --> Helper loaded: form_helper
INFO - 2017-08-19 08:11:06 --> Upload Class Initialized
INFO - 2017-08-19 08:11:06 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-08-19 08:11:06 --> The upload path does not appear to be valid.
INFO - 2017-08-19 08:11:06 --> Final output sent to browser
DEBUG - 2017-08-19 08:11:06 --> Total execution time: 0.2128
INFO - 2017-08-19 08:11:34 --> Config Class Initialized
INFO - 2017-08-19 08:11:34 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:11:34 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:11:34 --> Utf8 Class Initialized
INFO - 2017-08-19 08:11:34 --> URI Class Initialized
INFO - 2017-08-19 08:11:34 --> Router Class Initialized
INFO - 2017-08-19 08:11:34 --> Output Class Initialized
INFO - 2017-08-19 08:11:34 --> Security Class Initialized
DEBUG - 2017-08-19 08:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:11:34 --> Input Class Initialized
INFO - 2017-08-19 08:11:34 --> Language Class Initialized
INFO - 2017-08-19 08:11:34 --> Loader Class Initialized
INFO - 2017-08-19 08:11:34 --> Helper loaded: url_helper
INFO - 2017-08-19 08:11:34 --> Helper loaded: file_helper
INFO - 2017-08-19 08:11:34 --> Database Driver Class Initialized
INFO - 2017-08-19 08:11:34 --> Email Class Initialized
DEBUG - 2017-08-19 08:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:11:34 --> Table Class Initialized
INFO - 2017-08-19 08:11:34 --> Controller Class Initialized
INFO - 2017-08-19 08:11:34 --> Helper loaded: form_helper
INFO - 2017-08-19 08:11:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:11:34 --> Final output sent to browser
DEBUG - 2017-08-19 08:11:34 --> Total execution time: 0.2221
INFO - 2017-08-19 08:11:39 --> Config Class Initialized
INFO - 2017-08-19 08:11:39 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:11:39 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:11:39 --> Utf8 Class Initialized
INFO - 2017-08-19 08:11:39 --> URI Class Initialized
INFO - 2017-08-19 08:11:39 --> Router Class Initialized
INFO - 2017-08-19 08:11:39 --> Output Class Initialized
INFO - 2017-08-19 08:11:39 --> Security Class Initialized
DEBUG - 2017-08-19 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:11:39 --> Input Class Initialized
INFO - 2017-08-19 08:11:39 --> Language Class Initialized
INFO - 2017-08-19 08:11:39 --> Loader Class Initialized
INFO - 2017-08-19 08:11:39 --> Helper loaded: url_helper
INFO - 2017-08-19 08:11:39 --> Helper loaded: file_helper
INFO - 2017-08-19 08:11:39 --> Database Driver Class Initialized
INFO - 2017-08-19 08:11:39 --> Email Class Initialized
DEBUG - 2017-08-19 08:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:11:39 --> Table Class Initialized
INFO - 2017-08-19 08:11:39 --> Controller Class Initialized
INFO - 2017-08-19 08:11:39 --> Helper loaded: form_helper
INFO - 2017-08-19 08:11:39 --> Upload Class Initialized
INFO - 2017-08-19 08:11:39 --> Final output sent to browser
DEBUG - 2017-08-19 08:11:39 --> Total execution time: 0.2314
INFO - 2017-08-19 08:12:30 --> Config Class Initialized
INFO - 2017-08-19 08:12:30 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:12:30 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:12:30 --> Utf8 Class Initialized
INFO - 2017-08-19 08:12:30 --> URI Class Initialized
INFO - 2017-08-19 08:12:30 --> Router Class Initialized
INFO - 2017-08-19 08:12:30 --> Output Class Initialized
INFO - 2017-08-19 08:12:30 --> Security Class Initialized
DEBUG - 2017-08-19 08:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:12:30 --> Input Class Initialized
INFO - 2017-08-19 08:12:30 --> Language Class Initialized
INFO - 2017-08-19 08:12:30 --> Loader Class Initialized
INFO - 2017-08-19 08:12:30 --> Helper loaded: url_helper
INFO - 2017-08-19 08:12:30 --> Helper loaded: file_helper
INFO - 2017-08-19 08:12:30 --> Database Driver Class Initialized
INFO - 2017-08-19 08:12:30 --> Email Class Initialized
DEBUG - 2017-08-19 08:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:12:30 --> Table Class Initialized
INFO - 2017-08-19 08:12:30 --> Controller Class Initialized
INFO - 2017-08-19 08:12:30 --> Helper loaded: form_helper
INFO - 2017-08-19 08:12:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:12:30 --> Final output sent to browser
DEBUG - 2017-08-19 08:12:30 --> Total execution time: 0.1929
INFO - 2017-08-19 08:12:35 --> Config Class Initialized
INFO - 2017-08-19 08:12:35 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:12:35 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:12:35 --> Utf8 Class Initialized
INFO - 2017-08-19 08:12:35 --> URI Class Initialized
INFO - 2017-08-19 08:12:35 --> Router Class Initialized
INFO - 2017-08-19 08:12:35 --> Output Class Initialized
INFO - 2017-08-19 08:12:35 --> Security Class Initialized
DEBUG - 2017-08-19 08:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:12:35 --> Input Class Initialized
INFO - 2017-08-19 08:12:35 --> Language Class Initialized
INFO - 2017-08-19 08:12:35 --> Loader Class Initialized
INFO - 2017-08-19 08:12:35 --> Helper loaded: url_helper
INFO - 2017-08-19 08:12:35 --> Helper loaded: file_helper
INFO - 2017-08-19 08:12:35 --> Database Driver Class Initialized
INFO - 2017-08-19 08:12:35 --> Email Class Initialized
DEBUG - 2017-08-19 08:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:12:35 --> Table Class Initialized
INFO - 2017-08-19 08:12:35 --> Controller Class Initialized
INFO - 2017-08-19 08:12:35 --> Helper loaded: form_helper
INFO - 2017-08-19 08:12:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:12:35 --> Final output sent to browser
DEBUG - 2017-08-19 08:12:35 --> Total execution time: 0.1757
INFO - 2017-08-19 08:14:09 --> Config Class Initialized
INFO - 2017-08-19 08:14:09 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:14:09 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:14:09 --> Utf8 Class Initialized
INFO - 2017-08-19 08:14:09 --> URI Class Initialized
INFO - 2017-08-19 08:14:09 --> Router Class Initialized
INFO - 2017-08-19 08:14:09 --> Output Class Initialized
INFO - 2017-08-19 08:14:09 --> Security Class Initialized
DEBUG - 2017-08-19 08:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:14:09 --> Input Class Initialized
INFO - 2017-08-19 08:14:09 --> Language Class Initialized
INFO - 2017-08-19 08:14:09 --> Loader Class Initialized
INFO - 2017-08-19 08:14:09 --> Helper loaded: url_helper
INFO - 2017-08-19 08:14:09 --> Helper loaded: file_helper
INFO - 2017-08-19 08:14:09 --> Database Driver Class Initialized
INFO - 2017-08-19 08:14:09 --> Email Class Initialized
DEBUG - 2017-08-19 08:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:14:09 --> Table Class Initialized
INFO - 2017-08-19 08:14:09 --> Controller Class Initialized
INFO - 2017-08-19 08:14:09 --> Helper loaded: form_helper
INFO - 2017-08-19 08:14:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:14:09 --> Final output sent to browser
DEBUG - 2017-08-19 08:14:09 --> Total execution time: 0.1756
INFO - 2017-08-19 08:14:24 --> Config Class Initialized
INFO - 2017-08-19 08:14:24 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:14:24 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:14:24 --> Utf8 Class Initialized
INFO - 2017-08-19 08:14:24 --> URI Class Initialized
INFO - 2017-08-19 08:14:24 --> Router Class Initialized
INFO - 2017-08-19 08:14:24 --> Output Class Initialized
INFO - 2017-08-19 08:14:24 --> Security Class Initialized
DEBUG - 2017-08-19 08:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:14:24 --> Input Class Initialized
INFO - 2017-08-19 08:14:24 --> Language Class Initialized
INFO - 2017-08-19 08:14:24 --> Loader Class Initialized
INFO - 2017-08-19 08:14:24 --> Helper loaded: url_helper
INFO - 2017-08-19 08:14:24 --> Helper loaded: file_helper
INFO - 2017-08-19 08:14:24 --> Database Driver Class Initialized
INFO - 2017-08-19 08:14:24 --> Email Class Initialized
DEBUG - 2017-08-19 08:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:14:24 --> Table Class Initialized
INFO - 2017-08-19 08:14:24 --> Controller Class Initialized
INFO - 2017-08-19 08:14:24 --> Helper loaded: form_helper
INFO - 2017-08-19 08:14:24 --> Upload Class Initialized
INFO - 2017-08-19 08:14:24 --> Final output sent to browser
DEBUG - 2017-08-19 08:14:24 --> Total execution time: 0.1892
INFO - 2017-08-19 08:15:26 --> Config Class Initialized
INFO - 2017-08-19 08:15:26 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:15:26 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:15:26 --> Utf8 Class Initialized
INFO - 2017-08-19 08:15:26 --> URI Class Initialized
INFO - 2017-08-19 08:15:26 --> Router Class Initialized
INFO - 2017-08-19 08:15:26 --> Output Class Initialized
INFO - 2017-08-19 08:15:26 --> Security Class Initialized
DEBUG - 2017-08-19 08:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:15:26 --> Input Class Initialized
INFO - 2017-08-19 08:15:26 --> Language Class Initialized
INFO - 2017-08-19 08:15:26 --> Loader Class Initialized
INFO - 2017-08-19 08:15:26 --> Helper loaded: url_helper
INFO - 2017-08-19 08:15:26 --> Helper loaded: file_helper
INFO - 2017-08-19 08:15:26 --> Database Driver Class Initialized
INFO - 2017-08-19 08:15:26 --> Email Class Initialized
DEBUG - 2017-08-19 08:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:15:26 --> Table Class Initialized
INFO - 2017-08-19 08:15:26 --> Controller Class Initialized
INFO - 2017-08-19 08:15:26 --> Helper loaded: form_helper
INFO - 2017-08-19 08:15:26 --> Model Class Initialized
ERROR - 2017-08-19 08:15:26 --> Query error: Column 'Title' cannot be null - Invalid query: INSERT INTO `article` (`user`, `date`, `title`, `post`) VALUES ('Juananda', '2017-08-19', NULL, NULL)
INFO - 2017-08-19 08:15:26 --> Language file loaded: language/english/db_lang.php
INFO - 2017-08-19 08:20:33 --> Config Class Initialized
INFO - 2017-08-19 08:20:33 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:20:33 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:20:33 --> Utf8 Class Initialized
INFO - 2017-08-19 08:20:33 --> URI Class Initialized
INFO - 2017-08-19 08:20:33 --> Router Class Initialized
INFO - 2017-08-19 08:20:33 --> Output Class Initialized
INFO - 2017-08-19 08:20:33 --> Security Class Initialized
DEBUG - 2017-08-19 08:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:20:33 --> Input Class Initialized
INFO - 2017-08-19 08:20:33 --> Language Class Initialized
INFO - 2017-08-19 08:20:33 --> Loader Class Initialized
INFO - 2017-08-19 08:20:33 --> Helper loaded: url_helper
INFO - 2017-08-19 08:20:33 --> Helper loaded: file_helper
INFO - 2017-08-19 08:20:33 --> Database Driver Class Initialized
INFO - 2017-08-19 08:20:33 --> Email Class Initialized
DEBUG - 2017-08-19 08:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:20:33 --> Table Class Initialized
INFO - 2017-08-19 08:20:33 --> Controller Class Initialized
INFO - 2017-08-19 08:20:33 --> Helper loaded: form_helper
INFO - 2017-08-19 08:20:33 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:20:33 --> Final output sent to browser
DEBUG - 2017-08-19 08:20:33 --> Total execution time: 0.2388
INFO - 2017-08-19 08:20:39 --> Config Class Initialized
INFO - 2017-08-19 08:20:39 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:20:39 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:20:39 --> Utf8 Class Initialized
INFO - 2017-08-19 08:20:39 --> URI Class Initialized
INFO - 2017-08-19 08:20:39 --> Router Class Initialized
INFO - 2017-08-19 08:20:39 --> Output Class Initialized
INFO - 2017-08-19 08:20:39 --> Security Class Initialized
DEBUG - 2017-08-19 08:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:20:39 --> Input Class Initialized
INFO - 2017-08-19 08:20:39 --> Language Class Initialized
INFO - 2017-08-19 08:20:39 --> Loader Class Initialized
INFO - 2017-08-19 08:20:39 --> Helper loaded: url_helper
INFO - 2017-08-19 08:20:39 --> Helper loaded: file_helper
INFO - 2017-08-19 08:20:39 --> Database Driver Class Initialized
INFO - 2017-08-19 08:20:39 --> Email Class Initialized
DEBUG - 2017-08-19 08:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:20:39 --> Table Class Initialized
INFO - 2017-08-19 08:20:39 --> Controller Class Initialized
INFO - 2017-08-19 08:20:39 --> Helper loaded: form_helper
INFO - 2017-08-19 08:20:39 --> Upload Class Initialized
INFO - 2017-08-19 08:20:39 --> Final output sent to browser
DEBUG - 2017-08-19 08:20:39 --> Total execution time: 0.2198
INFO - 2017-08-19 08:20:39 --> Config Class Initialized
INFO - 2017-08-19 08:20:39 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:20:39 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:20:39 --> Utf8 Class Initialized
INFO - 2017-08-19 08:20:39 --> URI Class Initialized
INFO - 2017-08-19 08:20:39 --> Router Class Initialized
INFO - 2017-08-19 08:20:39 --> Output Class Initialized
INFO - 2017-08-19 08:20:39 --> Security Class Initialized
DEBUG - 2017-08-19 08:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:20:39 --> Input Class Initialized
INFO - 2017-08-19 08:20:39 --> Language Class Initialized
ERROR - 2017-08-19 08:20:39 --> 404 Page Not Found: Uploads/images524c478071aae_524c478074298.jpg
INFO - 2017-08-19 08:20:50 --> Config Class Initialized
INFO - 2017-08-19 08:20:50 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:20:50 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:20:50 --> Utf8 Class Initialized
INFO - 2017-08-19 08:20:50 --> URI Class Initialized
INFO - 2017-08-19 08:20:50 --> Router Class Initialized
INFO - 2017-08-19 08:20:50 --> Output Class Initialized
INFO - 2017-08-19 08:20:50 --> Security Class Initialized
DEBUG - 2017-08-19 08:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:20:50 --> Input Class Initialized
INFO - 2017-08-19 08:20:50 --> Language Class Initialized
INFO - 2017-08-19 08:20:50 --> Loader Class Initialized
INFO - 2017-08-19 08:20:50 --> Helper loaded: url_helper
INFO - 2017-08-19 08:20:50 --> Helper loaded: file_helper
INFO - 2017-08-19 08:20:50 --> Database Driver Class Initialized
INFO - 2017-08-19 08:20:50 --> Email Class Initialized
DEBUG - 2017-08-19 08:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:20:50 --> Table Class Initialized
INFO - 2017-08-19 08:20:50 --> Controller Class Initialized
INFO - 2017-08-19 08:20:50 --> Helper loaded: form_helper
INFO - 2017-08-19 08:20:50 --> Upload Class Initialized
INFO - 2017-08-19 08:20:50 --> Final output sent to browser
DEBUG - 2017-08-19 08:20:50 --> Total execution time: 0.2116
INFO - 2017-08-19 08:20:50 --> Config Class Initialized
INFO - 2017-08-19 08:20:50 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:20:50 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:20:50 --> Utf8 Class Initialized
INFO - 2017-08-19 08:20:50 --> URI Class Initialized
INFO - 2017-08-19 08:20:50 --> Router Class Initialized
INFO - 2017-08-19 08:20:50 --> Output Class Initialized
INFO - 2017-08-19 08:20:50 --> Security Class Initialized
DEBUG - 2017-08-19 08:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:20:50 --> Input Class Initialized
INFO - 2017-08-19 08:20:50 --> Language Class Initialized
ERROR - 2017-08-19 08:20:50 --> 404 Page Not Found: Uploads/images524c478071aae_524c4780742981.jpg
INFO - 2017-08-19 08:21:37 --> Config Class Initialized
INFO - 2017-08-19 08:21:37 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:21:37 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:21:37 --> Utf8 Class Initialized
INFO - 2017-08-19 08:21:37 --> URI Class Initialized
INFO - 2017-08-19 08:21:37 --> Router Class Initialized
INFO - 2017-08-19 08:21:37 --> Output Class Initialized
INFO - 2017-08-19 08:21:37 --> Security Class Initialized
DEBUG - 2017-08-19 08:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:21:37 --> Input Class Initialized
INFO - 2017-08-19 08:21:37 --> Language Class Initialized
INFO - 2017-08-19 08:21:37 --> Loader Class Initialized
INFO - 2017-08-19 08:21:37 --> Helper loaded: url_helper
INFO - 2017-08-19 08:21:37 --> Helper loaded: file_helper
INFO - 2017-08-19 08:21:37 --> Database Driver Class Initialized
INFO - 2017-08-19 08:21:37 --> Email Class Initialized
DEBUG - 2017-08-19 08:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:21:37 --> Table Class Initialized
INFO - 2017-08-19 08:21:37 --> Controller Class Initialized
INFO - 2017-08-19 08:21:37 --> Helper loaded: form_helper
INFO - 2017-08-19 08:21:37 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:21:37 --> Final output sent to browser
DEBUG - 2017-08-19 08:21:37 --> Total execution time: 0.2169
INFO - 2017-08-19 08:21:42 --> Config Class Initialized
INFO - 2017-08-19 08:21:42 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:21:42 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:21:42 --> Utf8 Class Initialized
INFO - 2017-08-19 08:21:42 --> URI Class Initialized
INFO - 2017-08-19 08:21:42 --> Router Class Initialized
INFO - 2017-08-19 08:21:43 --> Output Class Initialized
INFO - 2017-08-19 08:21:43 --> Security Class Initialized
DEBUG - 2017-08-19 08:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:21:43 --> Input Class Initialized
INFO - 2017-08-19 08:21:43 --> Language Class Initialized
INFO - 2017-08-19 08:21:43 --> Loader Class Initialized
INFO - 2017-08-19 08:21:43 --> Helper loaded: url_helper
INFO - 2017-08-19 08:21:43 --> Helper loaded: file_helper
INFO - 2017-08-19 08:21:43 --> Database Driver Class Initialized
INFO - 2017-08-19 08:21:43 --> Email Class Initialized
DEBUG - 2017-08-19 08:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:21:43 --> Table Class Initialized
INFO - 2017-08-19 08:21:43 --> Controller Class Initialized
INFO - 2017-08-19 08:21:43 --> Helper loaded: form_helper
INFO - 2017-08-19 08:21:43 --> Upload Class Initialized
INFO - 2017-08-19 08:21:43 --> Final output sent to browser
DEBUG - 2017-08-19 08:21:43 --> Total execution time: 0.2343
INFO - 2017-08-19 08:23:40 --> Config Class Initialized
INFO - 2017-08-19 08:23:40 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:23:40 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:23:40 --> Utf8 Class Initialized
INFO - 2017-08-19 08:23:40 --> URI Class Initialized
INFO - 2017-08-19 08:23:40 --> Router Class Initialized
INFO - 2017-08-19 08:23:40 --> Output Class Initialized
INFO - 2017-08-19 08:23:40 --> Security Class Initialized
DEBUG - 2017-08-19 08:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:23:40 --> Input Class Initialized
INFO - 2017-08-19 08:23:40 --> Language Class Initialized
INFO - 2017-08-19 08:23:40 --> Loader Class Initialized
INFO - 2017-08-19 08:23:40 --> Helper loaded: url_helper
INFO - 2017-08-19 08:23:40 --> Helper loaded: file_helper
INFO - 2017-08-19 08:23:40 --> Database Driver Class Initialized
INFO - 2017-08-19 08:23:40 --> Email Class Initialized
DEBUG - 2017-08-19 08:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:23:40 --> Table Class Initialized
INFO - 2017-08-19 08:23:40 --> Controller Class Initialized
INFO - 2017-08-19 08:23:40 --> Helper loaded: form_helper
INFO - 2017-08-19 08:23:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:23:40 --> Final output sent to browser
DEBUG - 2017-08-19 08:23:40 --> Total execution time: 0.1903
INFO - 2017-08-19 08:24:11 --> Config Class Initialized
INFO - 2017-08-19 08:24:11 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:24:11 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:24:11 --> Utf8 Class Initialized
INFO - 2017-08-19 08:24:11 --> URI Class Initialized
INFO - 2017-08-19 08:24:11 --> Router Class Initialized
INFO - 2017-08-19 08:24:11 --> Output Class Initialized
INFO - 2017-08-19 08:24:11 --> Security Class Initialized
DEBUG - 2017-08-19 08:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:24:11 --> Input Class Initialized
INFO - 2017-08-19 08:24:11 --> Language Class Initialized
INFO - 2017-08-19 08:24:11 --> Loader Class Initialized
INFO - 2017-08-19 08:24:11 --> Helper loaded: url_helper
INFO - 2017-08-19 08:24:11 --> Helper loaded: file_helper
INFO - 2017-08-19 08:24:11 --> Database Driver Class Initialized
INFO - 2017-08-19 08:24:11 --> Email Class Initialized
DEBUG - 2017-08-19 08:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:24:11 --> Table Class Initialized
INFO - 2017-08-19 08:24:11 --> Controller Class Initialized
INFO - 2017-08-19 08:24:11 --> Helper loaded: form_helper
INFO - 2017-08-19 08:24:11 --> Upload Class Initialized
INFO - 2017-08-19 08:24:11 --> Final output sent to browser
DEBUG - 2017-08-19 08:24:11 --> Total execution time: 0.1849
INFO - 2017-08-19 08:24:52 --> Config Class Initialized
INFO - 2017-08-19 08:24:52 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:24:52 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:24:52 --> Utf8 Class Initialized
INFO - 2017-08-19 08:24:52 --> URI Class Initialized
INFO - 2017-08-19 08:24:52 --> Router Class Initialized
INFO - 2017-08-19 08:24:52 --> Output Class Initialized
INFO - 2017-08-19 08:24:52 --> Security Class Initialized
DEBUG - 2017-08-19 08:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:24:52 --> Input Class Initialized
INFO - 2017-08-19 08:24:52 --> Language Class Initialized
INFO - 2017-08-19 08:24:52 --> Loader Class Initialized
INFO - 2017-08-19 08:24:52 --> Helper loaded: url_helper
INFO - 2017-08-19 08:24:52 --> Helper loaded: file_helper
INFO - 2017-08-19 08:24:52 --> Database Driver Class Initialized
INFO - 2017-08-19 08:24:52 --> Email Class Initialized
DEBUG - 2017-08-19 08:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:24:52 --> Table Class Initialized
INFO - 2017-08-19 08:24:52 --> Controller Class Initialized
INFO - 2017-08-19 08:24:52 --> Helper loaded: form_helper
INFO - 2017-08-19 08:24:52 --> Model Class Initialized
INFO - 2017-08-19 08:24:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-19 08:24:52 --> Final output sent to browser
DEBUG - 2017-08-19 08:24:52 --> Total execution time: 0.2466
INFO - 2017-08-19 08:25:09 --> Config Class Initialized
INFO - 2017-08-19 08:25:09 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:25:09 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:25:09 --> Utf8 Class Initialized
INFO - 2017-08-19 08:25:09 --> URI Class Initialized
INFO - 2017-08-19 08:25:09 --> Router Class Initialized
INFO - 2017-08-19 08:25:09 --> Output Class Initialized
INFO - 2017-08-19 08:25:09 --> Security Class Initialized
DEBUG - 2017-08-19 08:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:25:09 --> Input Class Initialized
INFO - 2017-08-19 08:25:09 --> Language Class Initialized
INFO - 2017-08-19 08:25:09 --> Loader Class Initialized
INFO - 2017-08-19 08:25:09 --> Helper loaded: url_helper
INFO - 2017-08-19 08:25:09 --> Helper loaded: file_helper
INFO - 2017-08-19 08:25:09 --> Database Driver Class Initialized
INFO - 2017-08-19 08:25:09 --> Email Class Initialized
DEBUG - 2017-08-19 08:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:25:09 --> Table Class Initialized
INFO - 2017-08-19 08:25:09 --> Controller Class Initialized
INFO - 2017-08-19 08:25:09 --> Helper loaded: form_helper
INFO - 2017-08-19 08:25:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:25:09 --> Final output sent to browser
DEBUG - 2017-08-19 08:25:09 --> Total execution time: 0.1879
INFO - 2017-08-19 08:26:05 --> Config Class Initialized
INFO - 2017-08-19 08:26:05 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:26:05 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:26:05 --> Utf8 Class Initialized
INFO - 2017-08-19 08:26:05 --> URI Class Initialized
INFO - 2017-08-19 08:26:05 --> Router Class Initialized
INFO - 2017-08-19 08:26:06 --> Output Class Initialized
INFO - 2017-08-19 08:26:06 --> Security Class Initialized
DEBUG - 2017-08-19 08:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:26:06 --> Input Class Initialized
INFO - 2017-08-19 08:26:06 --> Language Class Initialized
INFO - 2017-08-19 08:26:06 --> Loader Class Initialized
INFO - 2017-08-19 08:26:06 --> Helper loaded: url_helper
INFO - 2017-08-19 08:26:06 --> Helper loaded: file_helper
INFO - 2017-08-19 08:26:06 --> Database Driver Class Initialized
INFO - 2017-08-19 08:26:06 --> Email Class Initialized
DEBUG - 2017-08-19 08:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:26:06 --> Table Class Initialized
INFO - 2017-08-19 08:26:06 --> Controller Class Initialized
INFO - 2017-08-19 08:26:06 --> Helper loaded: form_helper
INFO - 2017-08-19 08:26:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:26:06 --> Final output sent to browser
DEBUG - 2017-08-19 08:26:06 --> Total execution time: 0.1929
INFO - 2017-08-19 08:26:35 --> Config Class Initialized
INFO - 2017-08-19 08:26:35 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:26:35 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:26:35 --> Utf8 Class Initialized
INFO - 2017-08-19 08:26:35 --> URI Class Initialized
INFO - 2017-08-19 08:26:35 --> Router Class Initialized
INFO - 2017-08-19 08:26:35 --> Output Class Initialized
INFO - 2017-08-19 08:26:35 --> Security Class Initialized
DEBUG - 2017-08-19 08:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:26:35 --> Input Class Initialized
INFO - 2017-08-19 08:26:35 --> Language Class Initialized
INFO - 2017-08-19 08:26:35 --> Loader Class Initialized
INFO - 2017-08-19 08:26:35 --> Helper loaded: url_helper
INFO - 2017-08-19 08:26:35 --> Helper loaded: file_helper
INFO - 2017-08-19 08:26:35 --> Database Driver Class Initialized
INFO - 2017-08-19 08:26:35 --> Email Class Initialized
DEBUG - 2017-08-19 08:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:26:35 --> Table Class Initialized
INFO - 2017-08-19 08:26:35 --> Controller Class Initialized
INFO - 2017-08-19 08:26:35 --> Helper loaded: form_helper
INFO - 2017-08-19 08:26:35 --> Upload Class Initialized
INFO - 2017-08-19 08:26:35 --> Final output sent to browser
DEBUG - 2017-08-19 08:26:35 --> Total execution time: 0.2007
INFO - 2017-08-19 08:26:52 --> Config Class Initialized
INFO - 2017-08-19 08:26:52 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:26:52 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:26:52 --> Utf8 Class Initialized
INFO - 2017-08-19 08:26:52 --> URI Class Initialized
INFO - 2017-08-19 08:26:52 --> Router Class Initialized
INFO - 2017-08-19 08:26:52 --> Output Class Initialized
INFO - 2017-08-19 08:26:52 --> Security Class Initialized
DEBUG - 2017-08-19 08:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:26:52 --> Input Class Initialized
INFO - 2017-08-19 08:26:52 --> Language Class Initialized
INFO - 2017-08-19 08:26:52 --> Loader Class Initialized
INFO - 2017-08-19 08:26:52 --> Helper loaded: url_helper
INFO - 2017-08-19 08:26:52 --> Helper loaded: file_helper
INFO - 2017-08-19 08:26:52 --> Database Driver Class Initialized
INFO - 2017-08-19 08:26:52 --> Email Class Initialized
DEBUG - 2017-08-19 08:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:26:52 --> Table Class Initialized
INFO - 2017-08-19 08:26:52 --> Controller Class Initialized
INFO - 2017-08-19 08:26:52 --> Helper loaded: form_helper
INFO - 2017-08-19 08:26:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:26:52 --> Final output sent to browser
DEBUG - 2017-08-19 08:26:52 --> Total execution time: 0.1804
INFO - 2017-08-19 08:27:05 --> Config Class Initialized
INFO - 2017-08-19 08:27:05 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:27:05 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:27:05 --> Utf8 Class Initialized
INFO - 2017-08-19 08:27:05 --> URI Class Initialized
INFO - 2017-08-19 08:27:05 --> Router Class Initialized
INFO - 2017-08-19 08:27:05 --> Output Class Initialized
INFO - 2017-08-19 08:27:05 --> Security Class Initialized
DEBUG - 2017-08-19 08:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:27:05 --> Input Class Initialized
INFO - 2017-08-19 08:27:05 --> Language Class Initialized
INFO - 2017-08-19 08:27:05 --> Loader Class Initialized
INFO - 2017-08-19 08:27:05 --> Helper loaded: url_helper
INFO - 2017-08-19 08:27:05 --> Helper loaded: file_helper
INFO - 2017-08-19 08:27:05 --> Database Driver Class Initialized
INFO - 2017-08-19 08:27:05 --> Email Class Initialized
DEBUG - 2017-08-19 08:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:27:05 --> Table Class Initialized
INFO - 2017-08-19 08:27:05 --> Controller Class Initialized
INFO - 2017-08-19 08:27:05 --> Helper loaded: form_helper
INFO - 2017-08-19 08:27:05 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:27:05 --> Final output sent to browser
DEBUG - 2017-08-19 08:27:05 --> Total execution time: 0.1931
INFO - 2017-08-19 08:27:19 --> Config Class Initialized
INFO - 2017-08-19 08:27:19 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:27:19 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:27:19 --> Utf8 Class Initialized
INFO - 2017-08-19 08:27:19 --> URI Class Initialized
INFO - 2017-08-19 08:27:19 --> Router Class Initialized
INFO - 2017-08-19 08:27:19 --> Output Class Initialized
INFO - 2017-08-19 08:27:19 --> Security Class Initialized
DEBUG - 2017-08-19 08:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:27:19 --> Input Class Initialized
INFO - 2017-08-19 08:27:19 --> Language Class Initialized
INFO - 2017-08-19 08:27:20 --> Loader Class Initialized
INFO - 2017-08-19 08:27:20 --> Helper loaded: url_helper
INFO - 2017-08-19 08:27:20 --> Helper loaded: file_helper
INFO - 2017-08-19 08:27:20 --> Database Driver Class Initialized
INFO - 2017-08-19 08:27:20 --> Email Class Initialized
DEBUG - 2017-08-19 08:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:27:20 --> Table Class Initialized
INFO - 2017-08-19 08:27:20 --> Controller Class Initialized
INFO - 2017-08-19 08:27:20 --> Helper loaded: form_helper
INFO - 2017-08-19 08:27:20 --> Upload Class Initialized
INFO - 2017-08-19 08:27:20 --> Final output sent to browser
DEBUG - 2017-08-19 08:27:20 --> Total execution time: 0.1977
INFO - 2017-08-19 08:27:53 --> Config Class Initialized
INFO - 2017-08-19 08:27:53 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:27:53 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:27:53 --> Utf8 Class Initialized
INFO - 2017-08-19 08:27:53 --> URI Class Initialized
INFO - 2017-08-19 08:27:53 --> Router Class Initialized
INFO - 2017-08-19 08:27:53 --> Output Class Initialized
INFO - 2017-08-19 08:27:53 --> Security Class Initialized
DEBUG - 2017-08-19 08:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:27:53 --> Input Class Initialized
INFO - 2017-08-19 08:27:53 --> Language Class Initialized
INFO - 2017-08-19 08:27:53 --> Loader Class Initialized
INFO - 2017-08-19 08:27:53 --> Helper loaded: url_helper
INFO - 2017-08-19 08:27:53 --> Helper loaded: file_helper
INFO - 2017-08-19 08:27:53 --> Database Driver Class Initialized
INFO - 2017-08-19 08:27:53 --> Email Class Initialized
DEBUG - 2017-08-19 08:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:27:53 --> Table Class Initialized
INFO - 2017-08-19 08:27:53 --> Controller Class Initialized
INFO - 2017-08-19 08:27:53 --> Helper loaded: form_helper
INFO - 2017-08-19 08:27:53 --> Model Class Initialized
INFO - 2017-08-19 08:27:53 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-19 08:27:53 --> Final output sent to browser
DEBUG - 2017-08-19 08:27:53 --> Total execution time: 0.2414
INFO - 2017-08-19 08:28:12 --> Config Class Initialized
INFO - 2017-08-19 08:28:12 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:28:12 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:28:12 --> Utf8 Class Initialized
INFO - 2017-08-19 08:28:12 --> URI Class Initialized
INFO - 2017-08-19 08:28:12 --> Router Class Initialized
INFO - 2017-08-19 08:28:12 --> Output Class Initialized
INFO - 2017-08-19 08:28:12 --> Security Class Initialized
DEBUG - 2017-08-19 08:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:28:12 --> Input Class Initialized
INFO - 2017-08-19 08:28:12 --> Language Class Initialized
INFO - 2017-08-19 08:28:13 --> Loader Class Initialized
INFO - 2017-08-19 08:28:13 --> Helper loaded: url_helper
INFO - 2017-08-19 08:28:13 --> Helper loaded: file_helper
INFO - 2017-08-19 08:28:13 --> Database Driver Class Initialized
INFO - 2017-08-19 08:28:13 --> Email Class Initialized
DEBUG - 2017-08-19 08:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:28:13 --> Table Class Initialized
INFO - 2017-08-19 08:28:13 --> Controller Class Initialized
INFO - 2017-08-19 08:28:13 --> Helper loaded: form_helper
INFO - 2017-08-19 08:28:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:28:13 --> Final output sent to browser
DEBUG - 2017-08-19 08:28:13 --> Total execution time: 0.1888
INFO - 2017-08-19 08:30:21 --> Config Class Initialized
INFO - 2017-08-19 08:30:21 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:30:21 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:30:21 --> Utf8 Class Initialized
INFO - 2017-08-19 08:30:21 --> URI Class Initialized
INFO - 2017-08-19 08:30:21 --> Router Class Initialized
INFO - 2017-08-19 08:30:21 --> Output Class Initialized
INFO - 2017-08-19 08:30:21 --> Security Class Initialized
DEBUG - 2017-08-19 08:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:30:21 --> Input Class Initialized
INFO - 2017-08-19 08:30:21 --> Language Class Initialized
INFO - 2017-08-19 08:30:21 --> Loader Class Initialized
INFO - 2017-08-19 08:30:21 --> Helper loaded: url_helper
INFO - 2017-08-19 08:30:21 --> Helper loaded: file_helper
INFO - 2017-08-19 08:30:21 --> Database Driver Class Initialized
INFO - 2017-08-19 08:30:21 --> Email Class Initialized
DEBUG - 2017-08-19 08:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:30:21 --> Table Class Initialized
INFO - 2017-08-19 08:30:21 --> Controller Class Initialized
INFO - 2017-08-19 08:30:21 --> Helper loaded: form_helper
INFO - 2017-08-19 08:30:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:30:21 --> Final output sent to browser
DEBUG - 2017-08-19 08:30:21 --> Total execution time: 0.1979
INFO - 2017-08-19 08:41:53 --> Config Class Initialized
INFO - 2017-08-19 08:41:53 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:41:53 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:41:53 --> Utf8 Class Initialized
INFO - 2017-08-19 08:41:53 --> URI Class Initialized
INFO - 2017-08-19 08:41:53 --> Router Class Initialized
INFO - 2017-08-19 08:41:53 --> Output Class Initialized
INFO - 2017-08-19 08:41:53 --> Security Class Initialized
DEBUG - 2017-08-19 08:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:41:53 --> Input Class Initialized
INFO - 2017-08-19 08:41:53 --> Language Class Initialized
INFO - 2017-08-19 08:41:53 --> Loader Class Initialized
INFO - 2017-08-19 08:41:53 --> Helper loaded: url_helper
INFO - 2017-08-19 08:41:53 --> Helper loaded: file_helper
INFO - 2017-08-19 08:41:53 --> Database Driver Class Initialized
INFO - 2017-08-19 08:41:53 --> Email Class Initialized
DEBUG - 2017-08-19 08:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:41:53 --> Table Class Initialized
INFO - 2017-08-19 08:41:53 --> Controller Class Initialized
INFO - 2017-08-19 08:41:53 --> Helper loaded: form_helper
INFO - 2017-08-19 08:41:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:41:54 --> Final output sent to browser
DEBUG - 2017-08-19 08:41:54 --> Total execution time: 0.1848
INFO - 2017-08-19 08:43:56 --> Config Class Initialized
INFO - 2017-08-19 08:43:56 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:43:56 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:43:56 --> Utf8 Class Initialized
INFO - 2017-08-19 08:43:56 --> URI Class Initialized
INFO - 2017-08-19 08:43:56 --> Router Class Initialized
INFO - 2017-08-19 08:43:56 --> Output Class Initialized
INFO - 2017-08-19 08:43:56 --> Security Class Initialized
DEBUG - 2017-08-19 08:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:43:56 --> Input Class Initialized
INFO - 2017-08-19 08:43:56 --> Language Class Initialized
INFO - 2017-08-19 08:43:56 --> Loader Class Initialized
INFO - 2017-08-19 08:43:56 --> Helper loaded: url_helper
INFO - 2017-08-19 08:43:56 --> Helper loaded: file_helper
INFO - 2017-08-19 08:43:56 --> Database Driver Class Initialized
INFO - 2017-08-19 08:43:56 --> Email Class Initialized
DEBUG - 2017-08-19 08:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:43:56 --> Table Class Initialized
INFO - 2017-08-19 08:43:56 --> Controller Class Initialized
INFO - 2017-08-19 08:43:56 --> Helper loaded: form_helper
INFO - 2017-08-19 08:43:56 --> Upload Class Initialized
INFO - 2017-08-19 08:43:56 --> Final output sent to browser
DEBUG - 2017-08-19 08:43:56 --> Total execution time: 0.1992
INFO - 2017-08-19 08:45:36 --> Config Class Initialized
INFO - 2017-08-19 08:45:36 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:45:36 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:45:36 --> Utf8 Class Initialized
INFO - 2017-08-19 08:45:36 --> URI Class Initialized
INFO - 2017-08-19 08:45:36 --> Router Class Initialized
INFO - 2017-08-19 08:45:36 --> Output Class Initialized
INFO - 2017-08-19 08:45:36 --> Security Class Initialized
DEBUG - 2017-08-19 08:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:45:36 --> Input Class Initialized
INFO - 2017-08-19 08:45:36 --> Language Class Initialized
INFO - 2017-08-19 08:45:36 --> Loader Class Initialized
INFO - 2017-08-19 08:45:36 --> Helper loaded: url_helper
INFO - 2017-08-19 08:45:36 --> Helper loaded: file_helper
INFO - 2017-08-19 08:45:36 --> Database Driver Class Initialized
INFO - 2017-08-19 08:45:36 --> Email Class Initialized
DEBUG - 2017-08-19 08:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:45:36 --> Table Class Initialized
INFO - 2017-08-19 08:45:36 --> Controller Class Initialized
INFO - 2017-08-19 08:45:36 --> Helper loaded: form_helper
INFO - 2017-08-19 08:45:36 --> Model Class Initialized
INFO - 2017-08-19 08:45:36 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-19 08:45:36 --> Final output sent to browser
DEBUG - 2017-08-19 08:45:36 --> Total execution time: 0.2378
INFO - 2017-08-19 08:57:58 --> Config Class Initialized
INFO - 2017-08-19 08:57:58 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:57:58 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:57:58 --> Utf8 Class Initialized
INFO - 2017-08-19 08:57:58 --> URI Class Initialized
INFO - 2017-08-19 08:57:58 --> Router Class Initialized
INFO - 2017-08-19 08:57:58 --> Output Class Initialized
INFO - 2017-08-19 08:57:58 --> Security Class Initialized
DEBUG - 2017-08-19 08:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:57:58 --> Input Class Initialized
INFO - 2017-08-19 08:57:58 --> Language Class Initialized
INFO - 2017-08-19 08:57:58 --> Loader Class Initialized
INFO - 2017-08-19 08:57:58 --> Helper loaded: url_helper
INFO - 2017-08-19 08:57:58 --> Helper loaded: file_helper
INFO - 2017-08-19 08:57:58 --> Database Driver Class Initialized
INFO - 2017-08-19 08:57:58 --> Email Class Initialized
DEBUG - 2017-08-19 08:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:57:59 --> Table Class Initialized
INFO - 2017-08-19 08:57:59 --> Controller Class Initialized
INFO - 2017-08-19 08:57:59 --> Helper loaded: form_helper
INFO - 2017-08-19 08:57:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:57:59 --> Final output sent to browser
DEBUG - 2017-08-19 08:57:59 --> Total execution time: 0.1891
INFO - 2017-08-19 08:57:59 --> Config Class Initialized
INFO - 2017-08-19 08:57:59 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:57:59 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:57:59 --> Utf8 Class Initialized
INFO - 2017-08-19 08:57:59 --> URI Class Initialized
INFO - 2017-08-19 08:57:59 --> Router Class Initialized
INFO - 2017-08-19 08:57:59 --> Output Class Initialized
INFO - 2017-08-19 08:57:59 --> Security Class Initialized
DEBUG - 2017-08-19 08:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:57:59 --> Input Class Initialized
INFO - 2017-08-19 08:57:59 --> Language Class Initialized
INFO - 2017-08-19 08:57:59 --> Loader Class Initialized
INFO - 2017-08-19 08:57:59 --> Helper loaded: url_helper
INFO - 2017-08-19 08:57:59 --> Helper loaded: file_helper
INFO - 2017-08-19 08:57:59 --> Database Driver Class Initialized
INFO - 2017-08-19 08:57:59 --> Email Class Initialized
DEBUG - 2017-08-19 08:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:57:59 --> Table Class Initialized
INFO - 2017-08-19 08:57:59 --> Controller Class Initialized
INFO - 2017-08-19 08:57:59 --> Helper loaded: form_helper
INFO - 2017-08-19 08:57:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:57:59 --> Final output sent to browser
DEBUG - 2017-08-19 08:57:59 --> Total execution time: 0.1998
INFO - 2017-08-19 08:57:59 --> Config Class Initialized
INFO - 2017-08-19 08:57:59 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:57:59 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:57:59 --> Utf8 Class Initialized
INFO - 2017-08-19 08:57:59 --> URI Class Initialized
INFO - 2017-08-19 08:57:59 --> Router Class Initialized
INFO - 2017-08-19 08:57:59 --> Output Class Initialized
INFO - 2017-08-19 08:57:59 --> Security Class Initialized
DEBUG - 2017-08-19 08:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:57:59 --> Input Class Initialized
INFO - 2017-08-19 08:57:59 --> Language Class Initialized
INFO - 2017-08-19 08:57:59 --> Loader Class Initialized
INFO - 2017-08-19 08:57:59 --> Helper loaded: url_helper
INFO - 2017-08-19 08:57:59 --> Helper loaded: file_helper
INFO - 2017-08-19 08:57:59 --> Database Driver Class Initialized
INFO - 2017-08-19 08:57:59 --> Email Class Initialized
DEBUG - 2017-08-19 08:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:57:59 --> Table Class Initialized
INFO - 2017-08-19 08:57:59 --> Controller Class Initialized
INFO - 2017-08-19 08:57:59 --> Helper loaded: form_helper
INFO - 2017-08-19 08:57:59 --> Model Class Initialized
ERROR - 2017-08-19 08:57:59 --> Query error: Column 'Title' cannot be null - Invalid query: INSERT INTO `article` (`user`, `date`, `title`, `post`) VALUES ('Juananda', '2017-08-19', NULL, NULL)
INFO - 2017-08-19 08:57:59 --> Language file loaded: language/english/db_lang.php
INFO - 2017-08-19 08:57:59 --> Config Class Initialized
INFO - 2017-08-19 08:57:59 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:57:59 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:57:59 --> Utf8 Class Initialized
INFO - 2017-08-19 08:57:59 --> URI Class Initialized
INFO - 2017-08-19 08:57:59 --> Router Class Initialized
INFO - 2017-08-19 08:57:59 --> Output Class Initialized
INFO - 2017-08-19 08:57:59 --> Security Class Initialized
DEBUG - 2017-08-19 08:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:57:59 --> Input Class Initialized
INFO - 2017-08-19 08:57:59 --> Language Class Initialized
INFO - 2017-08-19 08:57:59 --> Loader Class Initialized
INFO - 2017-08-19 08:57:59 --> Helper loaded: url_helper
INFO - 2017-08-19 08:57:59 --> Helper loaded: file_helper
INFO - 2017-08-19 08:57:59 --> Database Driver Class Initialized
INFO - 2017-08-19 08:57:59 --> Email Class Initialized
DEBUG - 2017-08-19 08:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:58:00 --> Table Class Initialized
INFO - 2017-08-19 08:58:00 --> Controller Class Initialized
INFO - 2017-08-19 08:58:00 --> Helper loaded: form_helper
INFO - 2017-08-19 08:58:00 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 08:58:00 --> Final output sent to browser
DEBUG - 2017-08-19 08:58:00 --> Total execution time: 0.2005
INFO - 2017-08-19 08:58:00 --> Config Class Initialized
INFO - 2017-08-19 08:58:00 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:58:00 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:58:00 --> Utf8 Class Initialized
INFO - 2017-08-19 08:58:00 --> URI Class Initialized
DEBUG - 2017-08-19 08:58:00 --> No URI present. Default controller set.
INFO - 2017-08-19 08:58:00 --> Router Class Initialized
INFO - 2017-08-19 08:58:00 --> Output Class Initialized
INFO - 2017-08-19 08:58:00 --> Security Class Initialized
DEBUG - 2017-08-19 08:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:58:00 --> Input Class Initialized
INFO - 2017-08-19 08:58:00 --> Language Class Initialized
INFO - 2017-08-19 08:58:00 --> Loader Class Initialized
INFO - 2017-08-19 08:58:00 --> Helper loaded: url_helper
INFO - 2017-08-19 08:58:00 --> Helper loaded: file_helper
INFO - 2017-08-19 08:58:00 --> Database Driver Class Initialized
INFO - 2017-08-19 08:58:01 --> Email Class Initialized
DEBUG - 2017-08-19 08:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 08:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 08:58:01 --> Table Class Initialized
INFO - 2017-08-19 08:58:01 --> Controller Class Initialized
INFO - 2017-08-19 08:58:01 --> Model Class Initialized
INFO - 2017-08-19 08:58:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-19 08:58:01 --> Final output sent to browser
DEBUG - 2017-08-19 08:58:01 --> Total execution time: 0.2180
INFO - 2017-08-19 11:18:44 --> Config Class Initialized
INFO - 2017-08-19 11:18:44 --> Hooks Class Initialized
DEBUG - 2017-08-19 11:18:44 --> UTF-8 Support Enabled
INFO - 2017-08-19 11:18:44 --> Utf8 Class Initialized
INFO - 2017-08-19 11:18:44 --> URI Class Initialized
INFO - 2017-08-19 11:18:44 --> Router Class Initialized
INFO - 2017-08-19 11:18:44 --> Output Class Initialized
INFO - 2017-08-19 11:18:44 --> Security Class Initialized
DEBUG - 2017-08-19 11:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 11:18:44 --> Input Class Initialized
INFO - 2017-08-19 11:18:44 --> Language Class Initialized
INFO - 2017-08-19 11:18:44 --> Loader Class Initialized
INFO - 2017-08-19 11:18:44 --> Helper loaded: url_helper
INFO - 2017-08-19 11:18:44 --> Helper loaded: file_helper
INFO - 2017-08-19 11:18:45 --> Database Driver Class Initialized
INFO - 2017-08-19 11:18:45 --> Email Class Initialized
DEBUG - 2017-08-19 11:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 11:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 11:18:45 --> Table Class Initialized
INFO - 2017-08-19 11:18:45 --> Controller Class Initialized
INFO - 2017-08-19 11:18:45 --> Helper loaded: form_helper
INFO - 2017-08-19 11:18:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 11:18:45 --> Final output sent to browser
DEBUG - 2017-08-19 11:18:45 --> Total execution time: 1.0800
INFO - 2017-08-19 19:02:34 --> Config Class Initialized
INFO - 2017-08-19 19:02:34 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:02:34 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:02:34 --> Utf8 Class Initialized
INFO - 2017-08-19 19:02:34 --> URI Class Initialized
INFO - 2017-08-19 19:02:34 --> Router Class Initialized
INFO - 2017-08-19 19:02:34 --> Output Class Initialized
INFO - 2017-08-19 19:02:35 --> Security Class Initialized
DEBUG - 2017-08-19 19:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:02:35 --> Input Class Initialized
INFO - 2017-08-19 19:02:35 --> Language Class Initialized
INFO - 2017-08-19 19:02:35 --> Loader Class Initialized
INFO - 2017-08-19 19:02:35 --> Helper loaded: url_helper
INFO - 2017-08-19 19:02:35 --> Helper loaded: file_helper
INFO - 2017-08-19 19:02:35 --> Database Driver Class Initialized
INFO - 2017-08-19 19:02:35 --> Email Class Initialized
DEBUG - 2017-08-19 19:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:02:35 --> Table Class Initialized
INFO - 2017-08-19 19:02:35 --> Controller Class Initialized
INFO - 2017-08-19 19:02:35 --> Helper loaded: form_helper
INFO - 2017-08-19 19:02:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-19 19:02:35 --> Final output sent to browser
DEBUG - 2017-08-19 19:02:35 --> Total execution time: 1.3647
INFO - 2017-08-19 19:03:42 --> Config Class Initialized
INFO - 2017-08-19 19:03:42 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:03:42 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:03:42 --> Utf8 Class Initialized
INFO - 2017-08-19 19:03:42 --> URI Class Initialized
INFO - 2017-08-19 19:03:42 --> Router Class Initialized
INFO - 2017-08-19 19:03:42 --> Output Class Initialized
INFO - 2017-08-19 19:03:42 --> Security Class Initialized
DEBUG - 2017-08-19 19:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:03:42 --> Input Class Initialized
INFO - 2017-08-19 19:03:42 --> Language Class Initialized
INFO - 2017-08-19 19:03:42 --> Loader Class Initialized
INFO - 2017-08-19 19:03:42 --> Helper loaded: url_helper
INFO - 2017-08-19 19:03:42 --> Helper loaded: file_helper
INFO - 2017-08-19 19:03:42 --> Database Driver Class Initialized
INFO - 2017-08-19 19:03:42 --> Email Class Initialized
DEBUG - 2017-08-19 19:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:03:42 --> Table Class Initialized
INFO - 2017-08-19 19:03:42 --> Controller Class Initialized
INFO - 2017-08-19 19:03:42 --> Helper loaded: form_helper
INFO - 2017-08-19 19:03:42 --> Upload Class Initialized
INFO - 2017-08-19 19:03:42 --> Final output sent to browser
DEBUG - 2017-08-19 19:03:42 --> Total execution time: 0.3069
INFO - 2017-08-19 19:12:23 --> Config Class Initialized
INFO - 2017-08-19 19:12:23 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:12:23 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:12:23 --> Utf8 Class Initialized
INFO - 2017-08-19 19:12:23 --> URI Class Initialized
DEBUG - 2017-08-19 19:12:23 --> No URI present. Default controller set.
INFO - 2017-08-19 19:12:23 --> Router Class Initialized
INFO - 2017-08-19 19:12:23 --> Output Class Initialized
INFO - 2017-08-19 19:12:23 --> Security Class Initialized
DEBUG - 2017-08-19 19:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:12:23 --> Input Class Initialized
INFO - 2017-08-19 19:12:23 --> Language Class Initialized
INFO - 2017-08-19 19:12:23 --> Loader Class Initialized
INFO - 2017-08-19 19:12:23 --> Helper loaded: url_helper
INFO - 2017-08-19 19:12:23 --> Helper loaded: file_helper
INFO - 2017-08-19 19:12:23 --> Database Driver Class Initialized
INFO - 2017-08-19 19:12:23 --> Email Class Initialized
DEBUG - 2017-08-19 19:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:12:23 --> Table Class Initialized
INFO - 2017-08-19 19:12:23 --> Controller Class Initialized
INFO - 2017-08-19 19:12:49 --> Config Class Initialized
INFO - 2017-08-19 19:12:49 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:12:49 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:12:49 --> Utf8 Class Initialized
INFO - 2017-08-19 19:12:49 --> URI Class Initialized
DEBUG - 2017-08-19 19:12:49 --> No URI present. Default controller set.
INFO - 2017-08-19 19:12:49 --> Router Class Initialized
INFO - 2017-08-19 19:12:49 --> Output Class Initialized
INFO - 2017-08-19 19:12:49 --> Security Class Initialized
DEBUG - 2017-08-19 19:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:12:49 --> Input Class Initialized
INFO - 2017-08-19 19:12:49 --> Language Class Initialized
INFO - 2017-08-19 19:12:49 --> Loader Class Initialized
INFO - 2017-08-19 19:12:49 --> Helper loaded: url_helper
INFO - 2017-08-19 19:12:49 --> Helper loaded: file_helper
INFO - 2017-08-19 19:12:49 --> Database Driver Class Initialized
INFO - 2017-08-19 19:12:49 --> Email Class Initialized
DEBUG - 2017-08-19 19:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:12:49 --> Table Class Initialized
INFO - 2017-08-19 19:12:49 --> Controller Class Initialized
INFO - 2017-08-19 19:12:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:12:49 --> Final output sent to browser
DEBUG - 2017-08-19 19:12:49 --> Total execution time: 0.2061
INFO - 2017-08-19 19:13:09 --> Config Class Initialized
INFO - 2017-08-19 19:13:09 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:13:09 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:13:09 --> Utf8 Class Initialized
INFO - 2017-08-19 19:13:09 --> URI Class Initialized
DEBUG - 2017-08-19 19:13:09 --> No URI present. Default controller set.
INFO - 2017-08-19 19:13:09 --> Router Class Initialized
INFO - 2017-08-19 19:13:09 --> Output Class Initialized
INFO - 2017-08-19 19:13:09 --> Security Class Initialized
DEBUG - 2017-08-19 19:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:13:09 --> Input Class Initialized
INFO - 2017-08-19 19:13:09 --> Language Class Initialized
INFO - 2017-08-19 19:13:09 --> Loader Class Initialized
INFO - 2017-08-19 19:13:09 --> Helper loaded: url_helper
INFO - 2017-08-19 19:13:09 --> Helper loaded: file_helper
INFO - 2017-08-19 19:13:09 --> Database Driver Class Initialized
INFO - 2017-08-19 19:13:09 --> Email Class Initialized
DEBUG - 2017-08-19 19:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:13:09 --> Table Class Initialized
INFO - 2017-08-19 19:13:09 --> Controller Class Initialized
INFO - 2017-08-19 19:13:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:13:09 --> Final output sent to browser
DEBUG - 2017-08-19 19:13:09 --> Total execution time: 0.2553
INFO - 2017-08-19 19:13:38 --> Config Class Initialized
INFO - 2017-08-19 19:13:38 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:13:38 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:13:38 --> Utf8 Class Initialized
INFO - 2017-08-19 19:13:38 --> URI Class Initialized
DEBUG - 2017-08-19 19:13:38 --> No URI present. Default controller set.
INFO - 2017-08-19 19:13:38 --> Router Class Initialized
INFO - 2017-08-19 19:13:38 --> Output Class Initialized
INFO - 2017-08-19 19:13:38 --> Security Class Initialized
DEBUG - 2017-08-19 19:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:13:38 --> Input Class Initialized
INFO - 2017-08-19 19:13:38 --> Language Class Initialized
INFO - 2017-08-19 19:13:38 --> Loader Class Initialized
INFO - 2017-08-19 19:13:38 --> Helper loaded: url_helper
INFO - 2017-08-19 19:13:38 --> Helper loaded: file_helper
INFO - 2017-08-19 19:13:38 --> Database Driver Class Initialized
INFO - 2017-08-19 19:13:38 --> Email Class Initialized
DEBUG - 2017-08-19 19:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:13:38 --> Table Class Initialized
INFO - 2017-08-19 19:13:38 --> Controller Class Initialized
INFO - 2017-08-19 19:13:38 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:13:38 --> Final output sent to browser
DEBUG - 2017-08-19 19:13:38 --> Total execution time: 0.3333
INFO - 2017-08-19 19:16:21 --> Config Class Initialized
INFO - 2017-08-19 19:16:21 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:16:21 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:16:21 --> Utf8 Class Initialized
INFO - 2017-08-19 19:16:21 --> URI Class Initialized
DEBUG - 2017-08-19 19:16:21 --> No URI present. Default controller set.
INFO - 2017-08-19 19:16:21 --> Router Class Initialized
INFO - 2017-08-19 19:16:21 --> Output Class Initialized
INFO - 2017-08-19 19:16:21 --> Security Class Initialized
DEBUG - 2017-08-19 19:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:16:21 --> Input Class Initialized
INFO - 2017-08-19 19:16:21 --> Language Class Initialized
INFO - 2017-08-19 19:16:21 --> Loader Class Initialized
INFO - 2017-08-19 19:16:21 --> Helper loaded: url_helper
INFO - 2017-08-19 19:16:21 --> Helper loaded: file_helper
INFO - 2017-08-19 19:16:21 --> Database Driver Class Initialized
INFO - 2017-08-19 19:16:21 --> Email Class Initialized
DEBUG - 2017-08-19 19:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:16:21 --> Table Class Initialized
INFO - 2017-08-19 19:16:21 --> Controller Class Initialized
INFO - 2017-08-19 19:16:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:16:21 --> Final output sent to browser
DEBUG - 2017-08-19 19:16:21 --> Total execution time: 0.1986
INFO - 2017-08-19 19:18:34 --> Config Class Initialized
INFO - 2017-08-19 19:18:34 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:18:34 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:18:34 --> Utf8 Class Initialized
INFO - 2017-08-19 19:18:34 --> URI Class Initialized
DEBUG - 2017-08-19 19:18:34 --> No URI present. Default controller set.
INFO - 2017-08-19 19:18:34 --> Router Class Initialized
INFO - 2017-08-19 19:18:34 --> Output Class Initialized
INFO - 2017-08-19 19:18:34 --> Security Class Initialized
DEBUG - 2017-08-19 19:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:18:34 --> Input Class Initialized
INFO - 2017-08-19 19:18:34 --> Language Class Initialized
INFO - 2017-08-19 19:18:34 --> Loader Class Initialized
INFO - 2017-08-19 19:18:34 --> Helper loaded: url_helper
INFO - 2017-08-19 19:18:34 --> Helper loaded: file_helper
INFO - 2017-08-19 19:18:34 --> Database Driver Class Initialized
INFO - 2017-08-19 19:18:34 --> Email Class Initialized
DEBUG - 2017-08-19 19:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:18:34 --> Table Class Initialized
INFO - 2017-08-19 19:18:34 --> Controller Class Initialized
INFO - 2017-08-19 19:18:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:18:34 --> Final output sent to browser
DEBUG - 2017-08-19 19:18:34 --> Total execution time: 0.2023
INFO - 2017-08-19 19:18:49 --> Config Class Initialized
INFO - 2017-08-19 19:18:49 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:18:49 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:18:49 --> Utf8 Class Initialized
INFO - 2017-08-19 19:18:49 --> URI Class Initialized
DEBUG - 2017-08-19 19:18:49 --> No URI present. Default controller set.
INFO - 2017-08-19 19:18:49 --> Router Class Initialized
INFO - 2017-08-19 19:18:49 --> Output Class Initialized
INFO - 2017-08-19 19:18:49 --> Security Class Initialized
DEBUG - 2017-08-19 19:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:18:49 --> Input Class Initialized
INFO - 2017-08-19 19:18:49 --> Language Class Initialized
INFO - 2017-08-19 19:18:49 --> Loader Class Initialized
INFO - 2017-08-19 19:18:49 --> Helper loaded: url_helper
INFO - 2017-08-19 19:18:49 --> Helper loaded: file_helper
INFO - 2017-08-19 19:18:49 --> Database Driver Class Initialized
INFO - 2017-08-19 19:18:49 --> Email Class Initialized
DEBUG - 2017-08-19 19:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:18:49 --> Table Class Initialized
INFO - 2017-08-19 19:18:49 --> Controller Class Initialized
INFO - 2017-08-19 19:18:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:18:49 --> Final output sent to browser
DEBUG - 2017-08-19 19:18:49 --> Total execution time: 0.2009
INFO - 2017-08-19 19:20:31 --> Config Class Initialized
INFO - 2017-08-19 19:20:31 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:20:31 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:20:31 --> Utf8 Class Initialized
INFO - 2017-08-19 19:20:31 --> URI Class Initialized
DEBUG - 2017-08-19 19:20:31 --> No URI present. Default controller set.
INFO - 2017-08-19 19:20:31 --> Router Class Initialized
INFO - 2017-08-19 19:20:31 --> Output Class Initialized
INFO - 2017-08-19 19:20:31 --> Security Class Initialized
DEBUG - 2017-08-19 19:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:20:31 --> Input Class Initialized
INFO - 2017-08-19 19:20:31 --> Language Class Initialized
INFO - 2017-08-19 19:20:31 --> Loader Class Initialized
INFO - 2017-08-19 19:20:31 --> Helper loaded: url_helper
INFO - 2017-08-19 19:20:31 --> Helper loaded: file_helper
INFO - 2017-08-19 19:20:31 --> Database Driver Class Initialized
INFO - 2017-08-19 19:20:31 --> Email Class Initialized
DEBUG - 2017-08-19 19:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:20:31 --> Table Class Initialized
INFO - 2017-08-19 19:20:31 --> Controller Class Initialized
INFO - 2017-08-19 19:20:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:20:31 --> Final output sent to browser
DEBUG - 2017-08-19 19:20:31 --> Total execution time: 0.2127
INFO - 2017-08-19 19:21:24 --> Config Class Initialized
INFO - 2017-08-19 19:21:24 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:21:24 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:21:24 --> Utf8 Class Initialized
INFO - 2017-08-19 19:21:24 --> URI Class Initialized
DEBUG - 2017-08-19 19:21:24 --> No URI present. Default controller set.
INFO - 2017-08-19 19:21:24 --> Router Class Initialized
INFO - 2017-08-19 19:21:24 --> Output Class Initialized
INFO - 2017-08-19 19:21:24 --> Security Class Initialized
DEBUG - 2017-08-19 19:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:21:24 --> Input Class Initialized
INFO - 2017-08-19 19:21:24 --> Language Class Initialized
INFO - 2017-08-19 19:21:24 --> Loader Class Initialized
INFO - 2017-08-19 19:21:24 --> Helper loaded: url_helper
INFO - 2017-08-19 19:21:24 --> Helper loaded: file_helper
INFO - 2017-08-19 19:21:24 --> Database Driver Class Initialized
INFO - 2017-08-19 19:21:24 --> Email Class Initialized
DEBUG - 2017-08-19 19:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:21:24 --> Table Class Initialized
INFO - 2017-08-19 19:21:24 --> Controller Class Initialized
INFO - 2017-08-19 19:21:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:21:24 --> Final output sent to browser
DEBUG - 2017-08-19 19:21:24 --> Total execution time: 0.2042
INFO - 2017-08-19 19:21:37 --> Config Class Initialized
INFO - 2017-08-19 19:21:37 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:21:37 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:21:38 --> Utf8 Class Initialized
INFO - 2017-08-19 19:21:38 --> URI Class Initialized
DEBUG - 2017-08-19 19:21:38 --> No URI present. Default controller set.
INFO - 2017-08-19 19:21:38 --> Router Class Initialized
INFO - 2017-08-19 19:21:38 --> Output Class Initialized
INFO - 2017-08-19 19:21:38 --> Security Class Initialized
DEBUG - 2017-08-19 19:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:21:38 --> Input Class Initialized
INFO - 2017-08-19 19:21:38 --> Language Class Initialized
INFO - 2017-08-19 19:21:38 --> Loader Class Initialized
INFO - 2017-08-19 19:21:38 --> Helper loaded: url_helper
INFO - 2017-08-19 19:21:38 --> Helper loaded: file_helper
INFO - 2017-08-19 19:21:38 --> Database Driver Class Initialized
INFO - 2017-08-19 19:21:38 --> Email Class Initialized
DEBUG - 2017-08-19 19:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:21:38 --> Table Class Initialized
INFO - 2017-08-19 19:21:38 --> Controller Class Initialized
INFO - 2017-08-19 19:21:38 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:21:38 --> Final output sent to browser
DEBUG - 2017-08-19 19:21:38 --> Total execution time: 0.2105
INFO - 2017-08-19 19:21:46 --> Config Class Initialized
INFO - 2017-08-19 19:21:46 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:21:46 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:21:46 --> Utf8 Class Initialized
INFO - 2017-08-19 19:21:46 --> URI Class Initialized
DEBUG - 2017-08-19 19:21:46 --> No URI present. Default controller set.
INFO - 2017-08-19 19:21:46 --> Router Class Initialized
INFO - 2017-08-19 19:21:47 --> Output Class Initialized
INFO - 2017-08-19 19:21:47 --> Security Class Initialized
DEBUG - 2017-08-19 19:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:21:47 --> Input Class Initialized
INFO - 2017-08-19 19:21:47 --> Language Class Initialized
INFO - 2017-08-19 19:21:47 --> Loader Class Initialized
INFO - 2017-08-19 19:21:47 --> Helper loaded: url_helper
INFO - 2017-08-19 19:21:47 --> Helper loaded: file_helper
INFO - 2017-08-19 19:21:47 --> Database Driver Class Initialized
INFO - 2017-08-19 19:21:47 --> Email Class Initialized
DEBUG - 2017-08-19 19:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:21:47 --> Table Class Initialized
INFO - 2017-08-19 19:21:47 --> Controller Class Initialized
INFO - 2017-08-19 19:21:47 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:21:47 --> Final output sent to browser
DEBUG - 2017-08-19 19:21:47 --> Total execution time: 0.1956
INFO - 2017-08-19 19:22:34 --> Config Class Initialized
INFO - 2017-08-19 19:22:34 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:22:34 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:22:34 --> Utf8 Class Initialized
INFO - 2017-08-19 19:22:34 --> URI Class Initialized
DEBUG - 2017-08-19 19:22:34 --> No URI present. Default controller set.
INFO - 2017-08-19 19:22:34 --> Router Class Initialized
INFO - 2017-08-19 19:22:34 --> Output Class Initialized
INFO - 2017-08-19 19:22:34 --> Security Class Initialized
DEBUG - 2017-08-19 19:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:22:34 --> Input Class Initialized
INFO - 2017-08-19 19:22:34 --> Language Class Initialized
INFO - 2017-08-19 19:22:34 --> Loader Class Initialized
INFO - 2017-08-19 19:22:34 --> Helper loaded: url_helper
INFO - 2017-08-19 19:22:34 --> Helper loaded: file_helper
INFO - 2017-08-19 19:22:34 --> Database Driver Class Initialized
INFO - 2017-08-19 19:22:34 --> Email Class Initialized
DEBUG - 2017-08-19 19:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:22:34 --> Table Class Initialized
INFO - 2017-08-19 19:22:34 --> Controller Class Initialized
INFO - 2017-08-19 19:22:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:22:34 --> Final output sent to browser
DEBUG - 2017-08-19 19:22:34 --> Total execution time: 0.1982
INFO - 2017-08-19 19:22:39 --> Config Class Initialized
INFO - 2017-08-19 19:22:39 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:22:39 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:22:39 --> Utf8 Class Initialized
INFO - 2017-08-19 19:22:39 --> URI Class Initialized
DEBUG - 2017-08-19 19:22:39 --> No URI present. Default controller set.
INFO - 2017-08-19 19:22:39 --> Router Class Initialized
INFO - 2017-08-19 19:22:39 --> Output Class Initialized
INFO - 2017-08-19 19:22:39 --> Security Class Initialized
DEBUG - 2017-08-19 19:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:22:39 --> Input Class Initialized
INFO - 2017-08-19 19:22:39 --> Language Class Initialized
INFO - 2017-08-19 19:22:39 --> Loader Class Initialized
INFO - 2017-08-19 19:22:39 --> Helper loaded: url_helper
INFO - 2017-08-19 19:22:39 --> Helper loaded: file_helper
INFO - 2017-08-19 19:22:39 --> Database Driver Class Initialized
INFO - 2017-08-19 19:22:39 --> Email Class Initialized
DEBUG - 2017-08-19 19:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:22:39 --> Table Class Initialized
INFO - 2017-08-19 19:22:39 --> Controller Class Initialized
INFO - 2017-08-19 19:22:39 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:22:39 --> Final output sent to browser
DEBUG - 2017-08-19 19:22:39 --> Total execution time: 0.2010
INFO - 2017-08-19 19:22:43 --> Config Class Initialized
INFO - 2017-08-19 19:22:43 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:22:43 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:22:43 --> Utf8 Class Initialized
INFO - 2017-08-19 19:22:43 --> URI Class Initialized
DEBUG - 2017-08-19 19:22:43 --> No URI present. Default controller set.
INFO - 2017-08-19 19:22:43 --> Router Class Initialized
INFO - 2017-08-19 19:22:43 --> Output Class Initialized
INFO - 2017-08-19 19:22:43 --> Security Class Initialized
DEBUG - 2017-08-19 19:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:22:43 --> Input Class Initialized
INFO - 2017-08-19 19:22:43 --> Language Class Initialized
INFO - 2017-08-19 19:22:43 --> Loader Class Initialized
INFO - 2017-08-19 19:22:43 --> Helper loaded: url_helper
INFO - 2017-08-19 19:22:43 --> Helper loaded: file_helper
INFO - 2017-08-19 19:22:43 --> Database Driver Class Initialized
INFO - 2017-08-19 19:22:43 --> Email Class Initialized
DEBUG - 2017-08-19 19:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:22:43 --> Table Class Initialized
INFO - 2017-08-19 19:22:43 --> Controller Class Initialized
INFO - 2017-08-19 19:22:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:22:43 --> Final output sent to browser
DEBUG - 2017-08-19 19:22:43 --> Total execution time: 0.1970
INFO - 2017-08-19 19:22:58 --> Config Class Initialized
INFO - 2017-08-19 19:22:58 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:22:58 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:22:58 --> Utf8 Class Initialized
INFO - 2017-08-19 19:22:58 --> URI Class Initialized
DEBUG - 2017-08-19 19:22:58 --> No URI present. Default controller set.
INFO - 2017-08-19 19:22:58 --> Router Class Initialized
INFO - 2017-08-19 19:22:58 --> Output Class Initialized
INFO - 2017-08-19 19:22:58 --> Security Class Initialized
DEBUG - 2017-08-19 19:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:22:58 --> Input Class Initialized
INFO - 2017-08-19 19:22:58 --> Language Class Initialized
INFO - 2017-08-19 19:22:58 --> Loader Class Initialized
INFO - 2017-08-19 19:22:58 --> Helper loaded: url_helper
INFO - 2017-08-19 19:22:58 --> Helper loaded: file_helper
INFO - 2017-08-19 19:22:58 --> Database Driver Class Initialized
INFO - 2017-08-19 19:22:58 --> Email Class Initialized
DEBUG - 2017-08-19 19:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:22:58 --> Table Class Initialized
INFO - 2017-08-19 19:22:58 --> Controller Class Initialized
INFO - 2017-08-19 19:22:58 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:22:58 --> Final output sent to browser
DEBUG - 2017-08-19 19:22:58 --> Total execution time: 0.2045
INFO - 2017-08-19 19:23:09 --> Config Class Initialized
INFO - 2017-08-19 19:23:09 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:23:09 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:23:09 --> Utf8 Class Initialized
INFO - 2017-08-19 19:23:09 --> URI Class Initialized
DEBUG - 2017-08-19 19:23:09 --> No URI present. Default controller set.
INFO - 2017-08-19 19:23:09 --> Router Class Initialized
INFO - 2017-08-19 19:23:09 --> Output Class Initialized
INFO - 2017-08-19 19:23:09 --> Security Class Initialized
DEBUG - 2017-08-19 19:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:23:09 --> Input Class Initialized
INFO - 2017-08-19 19:23:09 --> Language Class Initialized
INFO - 2017-08-19 19:23:09 --> Loader Class Initialized
INFO - 2017-08-19 19:23:09 --> Helper loaded: url_helper
INFO - 2017-08-19 19:23:09 --> Helper loaded: file_helper
INFO - 2017-08-19 19:23:09 --> Database Driver Class Initialized
INFO - 2017-08-19 19:23:09 --> Email Class Initialized
DEBUG - 2017-08-19 19:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:23:09 --> Table Class Initialized
INFO - 2017-08-19 19:23:09 --> Controller Class Initialized
INFO - 2017-08-19 19:23:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:23:09 --> Final output sent to browser
DEBUG - 2017-08-19 19:23:09 --> Total execution time: 0.1986
INFO - 2017-08-19 19:23:50 --> Config Class Initialized
INFO - 2017-08-19 19:23:50 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:23:50 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:23:50 --> Utf8 Class Initialized
INFO - 2017-08-19 19:23:50 --> URI Class Initialized
DEBUG - 2017-08-19 19:23:50 --> No URI present. Default controller set.
INFO - 2017-08-19 19:23:50 --> Router Class Initialized
INFO - 2017-08-19 19:23:50 --> Output Class Initialized
INFO - 2017-08-19 19:23:50 --> Security Class Initialized
DEBUG - 2017-08-19 19:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:23:50 --> Input Class Initialized
INFO - 2017-08-19 19:23:50 --> Language Class Initialized
INFO - 2017-08-19 19:23:50 --> Loader Class Initialized
INFO - 2017-08-19 19:23:50 --> Helper loaded: url_helper
INFO - 2017-08-19 19:23:50 --> Helper loaded: file_helper
INFO - 2017-08-19 19:23:50 --> Database Driver Class Initialized
INFO - 2017-08-19 19:23:50 --> Email Class Initialized
DEBUG - 2017-08-19 19:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:23:50 --> Table Class Initialized
INFO - 2017-08-19 19:23:50 --> Controller Class Initialized
INFO - 2017-08-19 19:23:50 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:23:50 --> Final output sent to browser
DEBUG - 2017-08-19 19:23:50 --> Total execution time: 0.2149
INFO - 2017-08-19 19:24:00 --> Config Class Initialized
INFO - 2017-08-19 19:24:00 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:24:00 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:24:00 --> Utf8 Class Initialized
INFO - 2017-08-19 19:24:00 --> URI Class Initialized
DEBUG - 2017-08-19 19:24:00 --> No URI present. Default controller set.
INFO - 2017-08-19 19:24:00 --> Router Class Initialized
INFO - 2017-08-19 19:24:00 --> Output Class Initialized
INFO - 2017-08-19 19:24:00 --> Security Class Initialized
DEBUG - 2017-08-19 19:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:24:00 --> Input Class Initialized
INFO - 2017-08-19 19:24:00 --> Language Class Initialized
INFO - 2017-08-19 19:24:00 --> Loader Class Initialized
INFO - 2017-08-19 19:24:00 --> Helper loaded: url_helper
INFO - 2017-08-19 19:24:00 --> Helper loaded: file_helper
INFO - 2017-08-19 19:24:00 --> Database Driver Class Initialized
INFO - 2017-08-19 19:24:00 --> Email Class Initialized
DEBUG - 2017-08-19 19:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:24:00 --> Table Class Initialized
INFO - 2017-08-19 19:24:00 --> Controller Class Initialized
INFO - 2017-08-19 19:24:00 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:24:00 --> Final output sent to browser
DEBUG - 2017-08-19 19:24:00 --> Total execution time: 0.2044
INFO - 2017-08-19 19:24:39 --> Config Class Initialized
INFO - 2017-08-19 19:24:39 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:24:39 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:24:39 --> Utf8 Class Initialized
INFO - 2017-08-19 19:24:39 --> URI Class Initialized
DEBUG - 2017-08-19 19:24:39 --> No URI present. Default controller set.
INFO - 2017-08-19 19:24:39 --> Router Class Initialized
INFO - 2017-08-19 19:24:39 --> Output Class Initialized
INFO - 2017-08-19 19:24:39 --> Security Class Initialized
DEBUG - 2017-08-19 19:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:24:39 --> Input Class Initialized
INFO - 2017-08-19 19:24:39 --> Language Class Initialized
INFO - 2017-08-19 19:24:40 --> Loader Class Initialized
INFO - 2017-08-19 19:24:40 --> Helper loaded: url_helper
INFO - 2017-08-19 19:24:40 --> Helper loaded: file_helper
INFO - 2017-08-19 19:24:40 --> Database Driver Class Initialized
INFO - 2017-08-19 19:24:40 --> Email Class Initialized
DEBUG - 2017-08-19 19:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:24:40 --> Table Class Initialized
INFO - 2017-08-19 19:24:40 --> Controller Class Initialized
INFO - 2017-08-19 19:24:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:24:40 --> Final output sent to browser
DEBUG - 2017-08-19 19:24:40 --> Total execution time: 0.2050
INFO - 2017-08-19 19:24:51 --> Config Class Initialized
INFO - 2017-08-19 19:24:51 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:24:51 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:24:51 --> Utf8 Class Initialized
INFO - 2017-08-19 19:24:51 --> URI Class Initialized
DEBUG - 2017-08-19 19:24:51 --> No URI present. Default controller set.
INFO - 2017-08-19 19:24:51 --> Router Class Initialized
INFO - 2017-08-19 19:24:51 --> Output Class Initialized
INFO - 2017-08-19 19:24:51 --> Security Class Initialized
DEBUG - 2017-08-19 19:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:24:51 --> Input Class Initialized
INFO - 2017-08-19 19:24:51 --> Language Class Initialized
INFO - 2017-08-19 19:24:51 --> Loader Class Initialized
INFO - 2017-08-19 19:24:51 --> Helper loaded: url_helper
INFO - 2017-08-19 19:24:51 --> Helper loaded: file_helper
INFO - 2017-08-19 19:24:51 --> Database Driver Class Initialized
INFO - 2017-08-19 19:24:51 --> Email Class Initialized
DEBUG - 2017-08-19 19:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:24:51 --> Table Class Initialized
INFO - 2017-08-19 19:24:51 --> Controller Class Initialized
INFO - 2017-08-19 19:24:51 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:24:51 --> Final output sent to browser
DEBUG - 2017-08-19 19:24:51 --> Total execution time: 0.2112
INFO - 2017-08-19 19:29:13 --> Config Class Initialized
INFO - 2017-08-19 19:29:13 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:29:13 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:29:13 --> Utf8 Class Initialized
INFO - 2017-08-19 19:29:13 --> URI Class Initialized
DEBUG - 2017-08-19 19:29:13 --> No URI present. Default controller set.
INFO - 2017-08-19 19:29:13 --> Router Class Initialized
INFO - 2017-08-19 19:29:13 --> Output Class Initialized
INFO - 2017-08-19 19:29:13 --> Security Class Initialized
DEBUG - 2017-08-19 19:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:29:13 --> Input Class Initialized
INFO - 2017-08-19 19:29:13 --> Language Class Initialized
INFO - 2017-08-19 19:29:13 --> Loader Class Initialized
INFO - 2017-08-19 19:29:13 --> Helper loaded: url_helper
INFO - 2017-08-19 19:29:13 --> Helper loaded: file_helper
INFO - 2017-08-19 19:29:13 --> Database Driver Class Initialized
INFO - 2017-08-19 19:29:13 --> Email Class Initialized
DEBUG - 2017-08-19 19:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:29:13 --> Table Class Initialized
INFO - 2017-08-19 19:29:13 --> Controller Class Initialized
INFO - 2017-08-19 19:29:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:29:13 --> Final output sent to browser
DEBUG - 2017-08-19 19:29:13 --> Total execution time: 0.2562
INFO - 2017-08-19 19:29:24 --> Config Class Initialized
INFO - 2017-08-19 19:29:24 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:29:24 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:29:24 --> Utf8 Class Initialized
INFO - 2017-08-19 19:29:24 --> URI Class Initialized
DEBUG - 2017-08-19 19:29:24 --> No URI present. Default controller set.
INFO - 2017-08-19 19:29:24 --> Router Class Initialized
INFO - 2017-08-19 19:29:24 --> Output Class Initialized
INFO - 2017-08-19 19:29:24 --> Security Class Initialized
DEBUG - 2017-08-19 19:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:29:24 --> Input Class Initialized
INFO - 2017-08-19 19:29:24 --> Language Class Initialized
INFO - 2017-08-19 19:29:24 --> Loader Class Initialized
INFO - 2017-08-19 19:29:24 --> Helper loaded: url_helper
INFO - 2017-08-19 19:29:24 --> Helper loaded: file_helper
INFO - 2017-08-19 19:29:24 --> Database Driver Class Initialized
INFO - 2017-08-19 19:29:24 --> Email Class Initialized
DEBUG - 2017-08-19 19:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:29:24 --> Table Class Initialized
INFO - 2017-08-19 19:29:24 --> Controller Class Initialized
INFO - 2017-08-19 19:29:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:29:24 --> Final output sent to browser
DEBUG - 2017-08-19 19:29:24 --> Total execution time: 0.2061
INFO - 2017-08-19 19:30:30 --> Config Class Initialized
INFO - 2017-08-19 19:30:30 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:30:30 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:30:30 --> Utf8 Class Initialized
INFO - 2017-08-19 19:30:30 --> URI Class Initialized
DEBUG - 2017-08-19 19:30:30 --> No URI present. Default controller set.
INFO - 2017-08-19 19:30:30 --> Router Class Initialized
INFO - 2017-08-19 19:30:30 --> Output Class Initialized
INFO - 2017-08-19 19:30:30 --> Security Class Initialized
DEBUG - 2017-08-19 19:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:30:30 --> Input Class Initialized
INFO - 2017-08-19 19:30:30 --> Language Class Initialized
INFO - 2017-08-19 19:30:30 --> Loader Class Initialized
INFO - 2017-08-19 19:30:30 --> Helper loaded: url_helper
INFO - 2017-08-19 19:30:30 --> Helper loaded: file_helper
INFO - 2017-08-19 19:30:30 --> Database Driver Class Initialized
INFO - 2017-08-19 19:30:30 --> Email Class Initialized
DEBUG - 2017-08-19 19:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:30:30 --> Table Class Initialized
INFO - 2017-08-19 19:30:30 --> Controller Class Initialized
INFO - 2017-08-19 19:30:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:30:30 --> Final output sent to browser
DEBUG - 2017-08-19 19:30:30 --> Total execution time: 0.2026
INFO - 2017-08-19 19:30:34 --> Config Class Initialized
INFO - 2017-08-19 19:30:34 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:30:34 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:30:34 --> Utf8 Class Initialized
INFO - 2017-08-19 19:30:34 --> URI Class Initialized
DEBUG - 2017-08-19 19:30:34 --> No URI present. Default controller set.
INFO - 2017-08-19 19:30:34 --> Router Class Initialized
INFO - 2017-08-19 19:30:34 --> Output Class Initialized
INFO - 2017-08-19 19:30:34 --> Security Class Initialized
DEBUG - 2017-08-19 19:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:30:34 --> Input Class Initialized
INFO - 2017-08-19 19:30:34 --> Language Class Initialized
INFO - 2017-08-19 19:30:34 --> Loader Class Initialized
INFO - 2017-08-19 19:30:34 --> Helper loaded: url_helper
INFO - 2017-08-19 19:30:34 --> Helper loaded: file_helper
INFO - 2017-08-19 19:30:34 --> Database Driver Class Initialized
INFO - 2017-08-19 19:30:34 --> Email Class Initialized
DEBUG - 2017-08-19 19:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:30:34 --> Table Class Initialized
INFO - 2017-08-19 19:30:34 --> Controller Class Initialized
INFO - 2017-08-19 19:30:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:30:34 --> Final output sent to browser
DEBUG - 2017-08-19 19:30:34 --> Total execution time: 0.2580
INFO - 2017-08-19 19:41:07 --> Config Class Initialized
INFO - 2017-08-19 19:41:07 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:41:07 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:41:07 --> Utf8 Class Initialized
INFO - 2017-08-19 19:41:07 --> URI Class Initialized
DEBUG - 2017-08-19 19:41:07 --> No URI present. Default controller set.
INFO - 2017-08-19 19:41:07 --> Router Class Initialized
INFO - 2017-08-19 19:41:07 --> Output Class Initialized
INFO - 2017-08-19 19:41:07 --> Security Class Initialized
DEBUG - 2017-08-19 19:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:41:07 --> Input Class Initialized
INFO - 2017-08-19 19:41:07 --> Language Class Initialized
INFO - 2017-08-19 19:41:07 --> Loader Class Initialized
INFO - 2017-08-19 19:41:07 --> Helper loaded: url_helper
INFO - 2017-08-19 19:41:07 --> Helper loaded: file_helper
INFO - 2017-08-19 19:41:07 --> Database Driver Class Initialized
INFO - 2017-08-19 19:41:07 --> Email Class Initialized
DEBUG - 2017-08-19 19:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:41:07 --> Table Class Initialized
INFO - 2017-08-19 19:41:07 --> Controller Class Initialized
INFO - 2017-08-19 19:41:07 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:41:07 --> Final output sent to browser
DEBUG - 2017-08-19 19:41:07 --> Total execution time: 0.3347
INFO - 2017-08-19 19:41:20 --> Config Class Initialized
INFO - 2017-08-19 19:41:20 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:41:20 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:41:20 --> Utf8 Class Initialized
INFO - 2017-08-19 19:41:20 --> URI Class Initialized
DEBUG - 2017-08-19 19:41:20 --> No URI present. Default controller set.
INFO - 2017-08-19 19:41:20 --> Router Class Initialized
INFO - 2017-08-19 19:41:20 --> Output Class Initialized
INFO - 2017-08-19 19:41:20 --> Security Class Initialized
DEBUG - 2017-08-19 19:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:41:20 --> Input Class Initialized
INFO - 2017-08-19 19:41:20 --> Language Class Initialized
INFO - 2017-08-19 19:41:20 --> Loader Class Initialized
INFO - 2017-08-19 19:41:20 --> Helper loaded: url_helper
INFO - 2017-08-19 19:41:20 --> Helper loaded: file_helper
INFO - 2017-08-19 19:41:20 --> Database Driver Class Initialized
INFO - 2017-08-19 19:41:20 --> Email Class Initialized
DEBUG - 2017-08-19 19:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:41:20 --> Table Class Initialized
INFO - 2017-08-19 19:41:20 --> Controller Class Initialized
INFO - 2017-08-19 19:41:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:41:21 --> Final output sent to browser
DEBUG - 2017-08-19 19:41:21 --> Total execution time: 0.2177
INFO - 2017-08-19 19:41:53 --> Config Class Initialized
INFO - 2017-08-19 19:41:53 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:41:53 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:41:53 --> Utf8 Class Initialized
INFO - 2017-08-19 19:41:53 --> URI Class Initialized
DEBUG - 2017-08-19 19:41:53 --> No URI present. Default controller set.
INFO - 2017-08-19 19:41:53 --> Router Class Initialized
INFO - 2017-08-19 19:41:53 --> Output Class Initialized
INFO - 2017-08-19 19:41:53 --> Security Class Initialized
DEBUG - 2017-08-19 19:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:41:53 --> Input Class Initialized
INFO - 2017-08-19 19:41:53 --> Language Class Initialized
INFO - 2017-08-19 19:41:53 --> Loader Class Initialized
INFO - 2017-08-19 19:41:53 --> Helper loaded: url_helper
INFO - 2017-08-19 19:41:53 --> Helper loaded: file_helper
INFO - 2017-08-19 19:41:53 --> Database Driver Class Initialized
INFO - 2017-08-19 19:41:53 --> Email Class Initialized
DEBUG - 2017-08-19 19:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:41:53 --> Table Class Initialized
INFO - 2017-08-19 19:41:53 --> Controller Class Initialized
INFO - 2017-08-19 19:41:53 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:41:53 --> Final output sent to browser
DEBUG - 2017-08-19 19:41:53 --> Total execution time: 0.2190
INFO - 2017-08-19 19:42:28 --> Config Class Initialized
INFO - 2017-08-19 19:42:28 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:42:28 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:42:28 --> Utf8 Class Initialized
INFO - 2017-08-19 19:42:28 --> URI Class Initialized
DEBUG - 2017-08-19 19:42:28 --> No URI present. Default controller set.
INFO - 2017-08-19 19:42:28 --> Router Class Initialized
INFO - 2017-08-19 19:42:28 --> Output Class Initialized
INFO - 2017-08-19 19:42:28 --> Security Class Initialized
DEBUG - 2017-08-19 19:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:42:28 --> Input Class Initialized
INFO - 2017-08-19 19:42:28 --> Language Class Initialized
INFO - 2017-08-19 19:42:28 --> Loader Class Initialized
INFO - 2017-08-19 19:42:29 --> Helper loaded: url_helper
INFO - 2017-08-19 19:42:29 --> Helper loaded: file_helper
INFO - 2017-08-19 19:42:29 --> Database Driver Class Initialized
INFO - 2017-08-19 19:42:29 --> Email Class Initialized
DEBUG - 2017-08-19 19:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:42:29 --> Table Class Initialized
INFO - 2017-08-19 19:42:29 --> Controller Class Initialized
INFO - 2017-08-19 19:42:29 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:42:29 --> Final output sent to browser
DEBUG - 2017-08-19 19:42:29 --> Total execution time: 0.2111
INFO - 2017-08-19 19:43:08 --> Config Class Initialized
INFO - 2017-08-19 19:43:08 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:43:08 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:43:08 --> Utf8 Class Initialized
INFO - 2017-08-19 19:43:08 --> URI Class Initialized
DEBUG - 2017-08-19 19:43:08 --> No URI present. Default controller set.
INFO - 2017-08-19 19:43:08 --> Router Class Initialized
INFO - 2017-08-19 19:43:08 --> Output Class Initialized
INFO - 2017-08-19 19:43:08 --> Security Class Initialized
DEBUG - 2017-08-19 19:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:43:08 --> Input Class Initialized
INFO - 2017-08-19 19:43:08 --> Language Class Initialized
INFO - 2017-08-19 19:43:08 --> Loader Class Initialized
INFO - 2017-08-19 19:43:08 --> Helper loaded: url_helper
INFO - 2017-08-19 19:43:08 --> Helper loaded: file_helper
INFO - 2017-08-19 19:43:08 --> Database Driver Class Initialized
INFO - 2017-08-19 19:43:08 --> Email Class Initialized
DEBUG - 2017-08-19 19:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:43:08 --> Table Class Initialized
INFO - 2017-08-19 19:43:08 --> Controller Class Initialized
INFO - 2017-08-19 19:43:08 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:43:08 --> Final output sent to browser
DEBUG - 2017-08-19 19:43:08 --> Total execution time: 0.2121
INFO - 2017-08-19 19:43:47 --> Config Class Initialized
INFO - 2017-08-19 19:43:47 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:43:47 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:43:47 --> Utf8 Class Initialized
INFO - 2017-08-19 19:43:47 --> URI Class Initialized
DEBUG - 2017-08-19 19:43:47 --> No URI present. Default controller set.
INFO - 2017-08-19 19:43:47 --> Router Class Initialized
INFO - 2017-08-19 19:43:47 --> Output Class Initialized
INFO - 2017-08-19 19:43:47 --> Security Class Initialized
DEBUG - 2017-08-19 19:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:43:47 --> Input Class Initialized
INFO - 2017-08-19 19:43:47 --> Language Class Initialized
INFO - 2017-08-19 19:43:47 --> Loader Class Initialized
INFO - 2017-08-19 19:43:47 --> Helper loaded: url_helper
INFO - 2017-08-19 19:43:47 --> Helper loaded: file_helper
INFO - 2017-08-19 19:43:47 --> Database Driver Class Initialized
INFO - 2017-08-19 19:43:47 --> Email Class Initialized
DEBUG - 2017-08-19 19:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:43:47 --> Table Class Initialized
INFO - 2017-08-19 19:43:47 --> Controller Class Initialized
INFO - 2017-08-19 19:43:47 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:43:47 --> Final output sent to browser
DEBUG - 2017-08-19 19:43:47 --> Total execution time: 0.2216
INFO - 2017-08-19 19:45:27 --> Config Class Initialized
INFO - 2017-08-19 19:45:27 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:45:27 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:45:27 --> Utf8 Class Initialized
INFO - 2017-08-19 19:45:27 --> URI Class Initialized
DEBUG - 2017-08-19 19:45:27 --> No URI present. Default controller set.
INFO - 2017-08-19 19:45:27 --> Router Class Initialized
INFO - 2017-08-19 19:45:27 --> Output Class Initialized
INFO - 2017-08-19 19:45:27 --> Security Class Initialized
DEBUG - 2017-08-19 19:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:45:27 --> Input Class Initialized
INFO - 2017-08-19 19:45:27 --> Language Class Initialized
INFO - 2017-08-19 19:45:27 --> Loader Class Initialized
INFO - 2017-08-19 19:45:27 --> Helper loaded: url_helper
INFO - 2017-08-19 19:45:27 --> Helper loaded: file_helper
INFO - 2017-08-19 19:45:27 --> Database Driver Class Initialized
INFO - 2017-08-19 19:45:27 --> Email Class Initialized
DEBUG - 2017-08-19 19:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:45:27 --> Table Class Initialized
INFO - 2017-08-19 19:45:27 --> Controller Class Initialized
INFO - 2017-08-19 19:45:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:45:27 --> Final output sent to browser
DEBUG - 2017-08-19 19:45:27 --> Total execution time: 0.2097
INFO - 2017-08-19 19:45:40 --> Config Class Initialized
INFO - 2017-08-19 19:45:40 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:45:40 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:45:40 --> Utf8 Class Initialized
INFO - 2017-08-19 19:45:40 --> URI Class Initialized
DEBUG - 2017-08-19 19:45:40 --> No URI present. Default controller set.
INFO - 2017-08-19 19:45:40 --> Router Class Initialized
INFO - 2017-08-19 19:45:40 --> Output Class Initialized
INFO - 2017-08-19 19:45:40 --> Security Class Initialized
DEBUG - 2017-08-19 19:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:45:40 --> Input Class Initialized
INFO - 2017-08-19 19:45:40 --> Language Class Initialized
INFO - 2017-08-19 19:45:40 --> Loader Class Initialized
INFO - 2017-08-19 19:45:40 --> Helper loaded: url_helper
INFO - 2017-08-19 19:45:40 --> Helper loaded: file_helper
INFO - 2017-08-19 19:45:40 --> Database Driver Class Initialized
INFO - 2017-08-19 19:45:40 --> Email Class Initialized
DEBUG - 2017-08-19 19:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:45:41 --> Table Class Initialized
INFO - 2017-08-19 19:45:41 --> Controller Class Initialized
INFO - 2017-08-19 19:45:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:45:41 --> Final output sent to browser
DEBUG - 2017-08-19 19:45:41 --> Total execution time: 0.2116
INFO - 2017-08-19 19:50:16 --> Config Class Initialized
INFO - 2017-08-19 19:50:16 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:50:16 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:50:16 --> Utf8 Class Initialized
INFO - 2017-08-19 19:50:16 --> URI Class Initialized
DEBUG - 2017-08-19 19:50:16 --> No URI present. Default controller set.
INFO - 2017-08-19 19:50:16 --> Router Class Initialized
INFO - 2017-08-19 19:50:16 --> Output Class Initialized
INFO - 2017-08-19 19:50:16 --> Security Class Initialized
DEBUG - 2017-08-19 19:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:50:16 --> Input Class Initialized
INFO - 2017-08-19 19:50:16 --> Language Class Initialized
INFO - 2017-08-19 19:50:16 --> Loader Class Initialized
INFO - 2017-08-19 19:50:16 --> Helper loaded: url_helper
INFO - 2017-08-19 19:50:16 --> Helper loaded: file_helper
INFO - 2017-08-19 19:50:16 --> Database Driver Class Initialized
INFO - 2017-08-19 19:50:16 --> Email Class Initialized
DEBUG - 2017-08-19 19:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:50:16 --> Table Class Initialized
INFO - 2017-08-19 19:50:16 --> Controller Class Initialized
INFO - 2017-08-19 19:50:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:50:16 --> Final output sent to browser
DEBUG - 2017-08-19 19:50:16 --> Total execution time: 0.2122
INFO - 2017-08-19 19:50:28 --> Config Class Initialized
INFO - 2017-08-19 19:50:28 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:50:28 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:50:28 --> Utf8 Class Initialized
INFO - 2017-08-19 19:50:28 --> URI Class Initialized
DEBUG - 2017-08-19 19:50:28 --> No URI present. Default controller set.
INFO - 2017-08-19 19:50:28 --> Router Class Initialized
INFO - 2017-08-19 19:50:28 --> Output Class Initialized
INFO - 2017-08-19 19:50:28 --> Security Class Initialized
DEBUG - 2017-08-19 19:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:50:28 --> Input Class Initialized
INFO - 2017-08-19 19:50:28 --> Language Class Initialized
INFO - 2017-08-19 19:50:28 --> Loader Class Initialized
INFO - 2017-08-19 19:50:28 --> Helper loaded: url_helper
INFO - 2017-08-19 19:50:28 --> Helper loaded: file_helper
INFO - 2017-08-19 19:50:28 --> Database Driver Class Initialized
INFO - 2017-08-19 19:50:28 --> Email Class Initialized
DEBUG - 2017-08-19 19:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:50:28 --> Table Class Initialized
INFO - 2017-08-19 19:50:28 --> Controller Class Initialized
INFO - 2017-08-19 19:50:28 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:50:28 --> Final output sent to browser
DEBUG - 2017-08-19 19:50:28 --> Total execution time: 0.2133
INFO - 2017-08-19 19:50:29 --> Config Class Initialized
INFO - 2017-08-19 19:50:29 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:50:29 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:50:29 --> Utf8 Class Initialized
INFO - 2017-08-19 19:50:29 --> URI Class Initialized
DEBUG - 2017-08-19 19:50:29 --> No URI present. Default controller set.
INFO - 2017-08-19 19:50:29 --> Router Class Initialized
INFO - 2017-08-19 19:50:29 --> Output Class Initialized
INFO - 2017-08-19 19:50:29 --> Security Class Initialized
DEBUG - 2017-08-19 19:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:50:29 --> Input Class Initialized
INFO - 2017-08-19 19:50:29 --> Language Class Initialized
INFO - 2017-08-19 19:50:29 --> Loader Class Initialized
INFO - 2017-08-19 19:50:29 --> Helper loaded: url_helper
INFO - 2017-08-19 19:50:29 --> Helper loaded: file_helper
INFO - 2017-08-19 19:50:29 --> Database Driver Class Initialized
INFO - 2017-08-19 19:50:29 --> Email Class Initialized
DEBUG - 2017-08-19 19:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:50:29 --> Table Class Initialized
INFO - 2017-08-19 19:50:29 --> Controller Class Initialized
INFO - 2017-08-19 19:50:29 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:50:29 --> Final output sent to browser
DEBUG - 2017-08-19 19:50:29 --> Total execution time: 0.2146
INFO - 2017-08-19 19:52:21 --> Config Class Initialized
INFO - 2017-08-19 19:52:21 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:52:21 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:52:21 --> Utf8 Class Initialized
INFO - 2017-08-19 19:52:21 --> URI Class Initialized
DEBUG - 2017-08-19 19:52:21 --> No URI present. Default controller set.
INFO - 2017-08-19 19:52:21 --> Router Class Initialized
INFO - 2017-08-19 19:52:21 --> Output Class Initialized
INFO - 2017-08-19 19:52:21 --> Security Class Initialized
DEBUG - 2017-08-19 19:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:52:21 --> Input Class Initialized
INFO - 2017-08-19 19:52:21 --> Language Class Initialized
INFO - 2017-08-19 19:52:21 --> Loader Class Initialized
INFO - 2017-08-19 19:52:21 --> Helper loaded: url_helper
INFO - 2017-08-19 19:52:21 --> Helper loaded: file_helper
INFO - 2017-08-19 19:52:21 --> Database Driver Class Initialized
INFO - 2017-08-19 19:52:21 --> Email Class Initialized
DEBUG - 2017-08-19 19:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:52:21 --> Table Class Initialized
INFO - 2017-08-19 19:52:21 --> Controller Class Initialized
INFO - 2017-08-19 19:52:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:52:21 --> Final output sent to browser
DEBUG - 2017-08-19 19:52:21 --> Total execution time: 0.2227
INFO - 2017-08-19 19:53:07 --> Config Class Initialized
INFO - 2017-08-19 19:53:07 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:53:07 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:53:07 --> Utf8 Class Initialized
INFO - 2017-08-19 19:53:07 --> URI Class Initialized
DEBUG - 2017-08-19 19:53:07 --> No URI present. Default controller set.
INFO - 2017-08-19 19:53:07 --> Router Class Initialized
INFO - 2017-08-19 19:53:07 --> Output Class Initialized
INFO - 2017-08-19 19:53:07 --> Security Class Initialized
DEBUG - 2017-08-19 19:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:53:07 --> Input Class Initialized
INFO - 2017-08-19 19:53:07 --> Language Class Initialized
INFO - 2017-08-19 19:53:07 --> Loader Class Initialized
INFO - 2017-08-19 19:53:07 --> Helper loaded: url_helper
INFO - 2017-08-19 19:53:07 --> Helper loaded: file_helper
INFO - 2017-08-19 19:53:07 --> Database Driver Class Initialized
INFO - 2017-08-19 19:53:07 --> Email Class Initialized
DEBUG - 2017-08-19 19:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:53:07 --> Table Class Initialized
INFO - 2017-08-19 19:53:07 --> Controller Class Initialized
INFO - 2017-08-19 19:53:07 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:53:07 --> Final output sent to browser
DEBUG - 2017-08-19 19:53:07 --> Total execution time: 0.2372
INFO - 2017-08-19 19:56:47 --> Config Class Initialized
INFO - 2017-08-19 19:56:47 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:56:47 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:56:48 --> Utf8 Class Initialized
INFO - 2017-08-19 19:56:48 --> URI Class Initialized
DEBUG - 2017-08-19 19:56:48 --> No URI present. Default controller set.
INFO - 2017-08-19 19:56:48 --> Router Class Initialized
INFO - 2017-08-19 19:56:48 --> Output Class Initialized
INFO - 2017-08-19 19:56:48 --> Security Class Initialized
DEBUG - 2017-08-19 19:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:56:48 --> Input Class Initialized
INFO - 2017-08-19 19:56:48 --> Language Class Initialized
INFO - 2017-08-19 19:56:48 --> Loader Class Initialized
INFO - 2017-08-19 19:56:48 --> Helper loaded: url_helper
INFO - 2017-08-19 19:56:48 --> Helper loaded: file_helper
INFO - 2017-08-19 19:56:48 --> Database Driver Class Initialized
INFO - 2017-08-19 19:56:48 --> Email Class Initialized
DEBUG - 2017-08-19 19:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:56:48 --> Table Class Initialized
INFO - 2017-08-19 19:56:48 --> Controller Class Initialized
INFO - 2017-08-19 19:56:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:56:48 --> Final output sent to browser
DEBUG - 2017-08-19 19:56:48 --> Total execution time: 0.2116
INFO - 2017-08-19 19:57:35 --> Config Class Initialized
INFO - 2017-08-19 19:57:35 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:57:35 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:57:35 --> Utf8 Class Initialized
INFO - 2017-08-19 19:57:35 --> URI Class Initialized
DEBUG - 2017-08-19 19:57:35 --> No URI present. Default controller set.
INFO - 2017-08-19 19:57:35 --> Router Class Initialized
INFO - 2017-08-19 19:57:35 --> Output Class Initialized
INFO - 2017-08-19 19:57:35 --> Security Class Initialized
DEBUG - 2017-08-19 19:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:57:35 --> Input Class Initialized
INFO - 2017-08-19 19:57:35 --> Language Class Initialized
INFO - 2017-08-19 19:57:35 --> Loader Class Initialized
INFO - 2017-08-19 19:57:35 --> Helper loaded: url_helper
INFO - 2017-08-19 19:57:35 --> Helper loaded: file_helper
INFO - 2017-08-19 19:57:35 --> Database Driver Class Initialized
INFO - 2017-08-19 19:57:35 --> Email Class Initialized
DEBUG - 2017-08-19 19:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:57:35 --> Table Class Initialized
INFO - 2017-08-19 19:57:35 --> Controller Class Initialized
INFO - 2017-08-19 19:57:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:57:35 --> Final output sent to browser
DEBUG - 2017-08-19 19:57:35 --> Total execution time: 0.2290
INFO - 2017-08-19 19:57:44 --> Config Class Initialized
INFO - 2017-08-19 19:57:44 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:57:44 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:57:44 --> Utf8 Class Initialized
INFO - 2017-08-19 19:57:44 --> URI Class Initialized
DEBUG - 2017-08-19 19:57:44 --> No URI present. Default controller set.
INFO - 2017-08-19 19:57:44 --> Router Class Initialized
INFO - 2017-08-19 19:57:44 --> Output Class Initialized
INFO - 2017-08-19 19:57:44 --> Security Class Initialized
DEBUG - 2017-08-19 19:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:57:44 --> Input Class Initialized
INFO - 2017-08-19 19:57:44 --> Language Class Initialized
INFO - 2017-08-19 19:57:44 --> Loader Class Initialized
INFO - 2017-08-19 19:57:44 --> Helper loaded: url_helper
INFO - 2017-08-19 19:57:44 --> Helper loaded: file_helper
INFO - 2017-08-19 19:57:44 --> Database Driver Class Initialized
INFO - 2017-08-19 19:57:44 --> Email Class Initialized
DEBUG - 2017-08-19 19:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:57:44 --> Table Class Initialized
INFO - 2017-08-19 19:57:44 --> Controller Class Initialized
INFO - 2017-08-19 19:57:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:57:44 --> Final output sent to browser
DEBUG - 2017-08-19 19:57:44 --> Total execution time: 0.2302
INFO - 2017-08-19 19:58:15 --> Config Class Initialized
INFO - 2017-08-19 19:58:15 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:58:15 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:58:15 --> Utf8 Class Initialized
INFO - 2017-08-19 19:58:15 --> URI Class Initialized
DEBUG - 2017-08-19 19:58:16 --> No URI present. Default controller set.
INFO - 2017-08-19 19:58:16 --> Router Class Initialized
INFO - 2017-08-19 19:58:16 --> Output Class Initialized
INFO - 2017-08-19 19:58:16 --> Security Class Initialized
DEBUG - 2017-08-19 19:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:58:16 --> Input Class Initialized
INFO - 2017-08-19 19:58:16 --> Language Class Initialized
INFO - 2017-08-19 19:58:16 --> Loader Class Initialized
INFO - 2017-08-19 19:58:16 --> Helper loaded: url_helper
INFO - 2017-08-19 19:58:16 --> Helper loaded: file_helper
INFO - 2017-08-19 19:58:16 --> Database Driver Class Initialized
INFO - 2017-08-19 19:58:16 --> Email Class Initialized
DEBUG - 2017-08-19 19:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:58:16 --> Table Class Initialized
INFO - 2017-08-19 19:58:16 --> Controller Class Initialized
INFO - 2017-08-19 19:58:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:58:16 --> Final output sent to browser
DEBUG - 2017-08-19 19:58:16 --> Total execution time: 0.2152
INFO - 2017-08-19 19:58:39 --> Config Class Initialized
INFO - 2017-08-19 19:58:39 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:58:39 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:58:39 --> Utf8 Class Initialized
INFO - 2017-08-19 19:58:39 --> URI Class Initialized
DEBUG - 2017-08-19 19:58:39 --> No URI present. Default controller set.
INFO - 2017-08-19 19:58:39 --> Router Class Initialized
INFO - 2017-08-19 19:58:39 --> Output Class Initialized
INFO - 2017-08-19 19:58:39 --> Security Class Initialized
DEBUG - 2017-08-19 19:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:58:39 --> Input Class Initialized
INFO - 2017-08-19 19:58:39 --> Language Class Initialized
INFO - 2017-08-19 19:58:39 --> Loader Class Initialized
INFO - 2017-08-19 19:58:39 --> Helper loaded: url_helper
INFO - 2017-08-19 19:58:39 --> Helper loaded: file_helper
INFO - 2017-08-19 19:58:39 --> Database Driver Class Initialized
INFO - 2017-08-19 19:58:39 --> Email Class Initialized
DEBUG - 2017-08-19 19:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:58:39 --> Table Class Initialized
INFO - 2017-08-19 19:58:39 --> Controller Class Initialized
INFO - 2017-08-19 19:58:39 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:58:39 --> Final output sent to browser
DEBUG - 2017-08-19 19:58:39 --> Total execution time: 0.2314
INFO - 2017-08-19 19:59:17 --> Config Class Initialized
INFO - 2017-08-19 19:59:17 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:59:17 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:59:17 --> Utf8 Class Initialized
INFO - 2017-08-19 19:59:17 --> URI Class Initialized
DEBUG - 2017-08-19 19:59:17 --> No URI present. Default controller set.
INFO - 2017-08-19 19:59:17 --> Router Class Initialized
INFO - 2017-08-19 19:59:17 --> Output Class Initialized
INFO - 2017-08-19 19:59:17 --> Security Class Initialized
DEBUG - 2017-08-19 19:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:59:17 --> Input Class Initialized
INFO - 2017-08-19 19:59:17 --> Language Class Initialized
INFO - 2017-08-19 19:59:17 --> Loader Class Initialized
INFO - 2017-08-19 19:59:17 --> Helper loaded: url_helper
INFO - 2017-08-19 19:59:17 --> Helper loaded: file_helper
INFO - 2017-08-19 19:59:17 --> Database Driver Class Initialized
INFO - 2017-08-19 19:59:17 --> Email Class Initialized
DEBUG - 2017-08-19 19:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:59:17 --> Table Class Initialized
INFO - 2017-08-19 19:59:17 --> Controller Class Initialized
INFO - 2017-08-19 19:59:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:59:17 --> Final output sent to browser
DEBUG - 2017-08-19 19:59:17 --> Total execution time: 0.2260
INFO - 2017-08-19 19:59:53 --> Config Class Initialized
INFO - 2017-08-19 19:59:53 --> Hooks Class Initialized
DEBUG - 2017-08-19 19:59:53 --> UTF-8 Support Enabled
INFO - 2017-08-19 19:59:53 --> Utf8 Class Initialized
INFO - 2017-08-19 19:59:53 --> URI Class Initialized
DEBUG - 2017-08-19 19:59:53 --> No URI present. Default controller set.
INFO - 2017-08-19 19:59:53 --> Router Class Initialized
INFO - 2017-08-19 19:59:53 --> Output Class Initialized
INFO - 2017-08-19 19:59:53 --> Security Class Initialized
DEBUG - 2017-08-19 19:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 19:59:53 --> Input Class Initialized
INFO - 2017-08-19 19:59:53 --> Language Class Initialized
INFO - 2017-08-19 19:59:53 --> Loader Class Initialized
INFO - 2017-08-19 19:59:53 --> Helper loaded: url_helper
INFO - 2017-08-19 19:59:53 --> Helper loaded: file_helper
INFO - 2017-08-19 19:59:53 --> Database Driver Class Initialized
INFO - 2017-08-19 19:59:53 --> Email Class Initialized
DEBUG - 2017-08-19 19:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 19:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 19:59:53 --> Table Class Initialized
INFO - 2017-08-19 19:59:53 --> Controller Class Initialized
INFO - 2017-08-19 19:59:53 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 19:59:53 --> Final output sent to browser
DEBUG - 2017-08-19 19:59:53 --> Total execution time: 0.2283
INFO - 2017-08-19 20:00:03 --> Config Class Initialized
INFO - 2017-08-19 20:00:03 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:00:03 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:00:03 --> Utf8 Class Initialized
INFO - 2017-08-19 20:00:03 --> URI Class Initialized
DEBUG - 2017-08-19 20:00:03 --> No URI present. Default controller set.
INFO - 2017-08-19 20:00:03 --> Router Class Initialized
INFO - 2017-08-19 20:00:03 --> Output Class Initialized
INFO - 2017-08-19 20:00:03 --> Security Class Initialized
DEBUG - 2017-08-19 20:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:00:03 --> Input Class Initialized
INFO - 2017-08-19 20:00:03 --> Language Class Initialized
INFO - 2017-08-19 20:00:03 --> Loader Class Initialized
INFO - 2017-08-19 20:00:03 --> Helper loaded: url_helper
INFO - 2017-08-19 20:00:03 --> Helper loaded: file_helper
INFO - 2017-08-19 20:00:03 --> Database Driver Class Initialized
INFO - 2017-08-19 20:00:03 --> Email Class Initialized
DEBUG - 2017-08-19 20:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:00:03 --> Table Class Initialized
INFO - 2017-08-19 20:00:03 --> Controller Class Initialized
INFO - 2017-08-19 20:00:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:00:03 --> Final output sent to browser
DEBUG - 2017-08-19 20:00:03 --> Total execution time: 0.2397
INFO - 2017-08-19 20:00:41 --> Config Class Initialized
INFO - 2017-08-19 20:00:41 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:00:41 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:00:41 --> Utf8 Class Initialized
INFO - 2017-08-19 20:00:41 --> URI Class Initialized
DEBUG - 2017-08-19 20:00:41 --> No URI present. Default controller set.
INFO - 2017-08-19 20:00:41 --> Router Class Initialized
INFO - 2017-08-19 20:00:41 --> Output Class Initialized
INFO - 2017-08-19 20:00:41 --> Security Class Initialized
DEBUG - 2017-08-19 20:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:00:41 --> Input Class Initialized
INFO - 2017-08-19 20:00:41 --> Language Class Initialized
INFO - 2017-08-19 20:00:41 --> Loader Class Initialized
INFO - 2017-08-19 20:00:41 --> Helper loaded: url_helper
INFO - 2017-08-19 20:00:41 --> Helper loaded: file_helper
INFO - 2017-08-19 20:00:41 --> Database Driver Class Initialized
INFO - 2017-08-19 20:00:42 --> Email Class Initialized
DEBUG - 2017-08-19 20:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:00:42 --> Table Class Initialized
INFO - 2017-08-19 20:00:42 --> Controller Class Initialized
INFO - 2017-08-19 20:00:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:00:42 --> Final output sent to browser
DEBUG - 2017-08-19 20:00:42 --> Total execution time: 0.2177
INFO - 2017-08-19 20:01:03 --> Config Class Initialized
INFO - 2017-08-19 20:01:03 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:01:03 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:01:03 --> Utf8 Class Initialized
INFO - 2017-08-19 20:01:03 --> URI Class Initialized
DEBUG - 2017-08-19 20:01:03 --> No URI present. Default controller set.
INFO - 2017-08-19 20:01:03 --> Router Class Initialized
INFO - 2017-08-19 20:01:03 --> Output Class Initialized
INFO - 2017-08-19 20:01:03 --> Security Class Initialized
DEBUG - 2017-08-19 20:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:01:03 --> Input Class Initialized
INFO - 2017-08-19 20:01:03 --> Language Class Initialized
INFO - 2017-08-19 20:01:03 --> Loader Class Initialized
INFO - 2017-08-19 20:01:03 --> Helper loaded: url_helper
INFO - 2017-08-19 20:01:03 --> Helper loaded: file_helper
INFO - 2017-08-19 20:01:03 --> Database Driver Class Initialized
INFO - 2017-08-19 20:01:03 --> Email Class Initialized
DEBUG - 2017-08-19 20:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:01:03 --> Table Class Initialized
INFO - 2017-08-19 20:01:03 --> Controller Class Initialized
INFO - 2017-08-19 20:01:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:01:03 --> Final output sent to browser
DEBUG - 2017-08-19 20:01:03 --> Total execution time: 0.2415
INFO - 2017-08-19 20:01:20 --> Config Class Initialized
INFO - 2017-08-19 20:01:20 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:01:20 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:01:20 --> Utf8 Class Initialized
INFO - 2017-08-19 20:01:20 --> URI Class Initialized
DEBUG - 2017-08-19 20:01:20 --> No URI present. Default controller set.
INFO - 2017-08-19 20:01:20 --> Router Class Initialized
INFO - 2017-08-19 20:01:20 --> Output Class Initialized
INFO - 2017-08-19 20:01:20 --> Security Class Initialized
DEBUG - 2017-08-19 20:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:01:20 --> Input Class Initialized
INFO - 2017-08-19 20:01:20 --> Language Class Initialized
INFO - 2017-08-19 20:01:20 --> Loader Class Initialized
INFO - 2017-08-19 20:01:20 --> Helper loaded: url_helper
INFO - 2017-08-19 20:01:20 --> Helper loaded: file_helper
INFO - 2017-08-19 20:01:20 --> Database Driver Class Initialized
INFO - 2017-08-19 20:01:20 --> Email Class Initialized
DEBUG - 2017-08-19 20:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:01:20 --> Table Class Initialized
INFO - 2017-08-19 20:01:20 --> Controller Class Initialized
INFO - 2017-08-19 20:01:20 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:01:20 --> Final output sent to browser
DEBUG - 2017-08-19 20:01:20 --> Total execution time: 0.2197
INFO - 2017-08-19 20:01:34 --> Config Class Initialized
INFO - 2017-08-19 20:01:34 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:01:34 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:01:34 --> Utf8 Class Initialized
INFO - 2017-08-19 20:01:34 --> URI Class Initialized
DEBUG - 2017-08-19 20:01:34 --> No URI present. Default controller set.
INFO - 2017-08-19 20:01:34 --> Router Class Initialized
INFO - 2017-08-19 20:01:34 --> Output Class Initialized
INFO - 2017-08-19 20:01:34 --> Security Class Initialized
DEBUG - 2017-08-19 20:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:01:34 --> Input Class Initialized
INFO - 2017-08-19 20:01:34 --> Language Class Initialized
INFO - 2017-08-19 20:01:34 --> Loader Class Initialized
INFO - 2017-08-19 20:01:34 --> Helper loaded: url_helper
INFO - 2017-08-19 20:01:34 --> Helper loaded: file_helper
INFO - 2017-08-19 20:01:34 --> Database Driver Class Initialized
INFO - 2017-08-19 20:01:34 --> Email Class Initialized
DEBUG - 2017-08-19 20:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:01:34 --> Table Class Initialized
INFO - 2017-08-19 20:01:34 --> Controller Class Initialized
INFO - 2017-08-19 20:01:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:01:34 --> Final output sent to browser
DEBUG - 2017-08-19 20:01:34 --> Total execution time: 0.2188
INFO - 2017-08-19 20:02:19 --> Config Class Initialized
INFO - 2017-08-19 20:02:19 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:02:19 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:02:19 --> Utf8 Class Initialized
INFO - 2017-08-19 20:02:19 --> URI Class Initialized
DEBUG - 2017-08-19 20:02:19 --> No URI present. Default controller set.
INFO - 2017-08-19 20:02:19 --> Router Class Initialized
INFO - 2017-08-19 20:02:19 --> Output Class Initialized
INFO - 2017-08-19 20:02:19 --> Security Class Initialized
DEBUG - 2017-08-19 20:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:02:19 --> Input Class Initialized
INFO - 2017-08-19 20:02:19 --> Language Class Initialized
INFO - 2017-08-19 20:02:19 --> Loader Class Initialized
INFO - 2017-08-19 20:02:19 --> Helper loaded: url_helper
INFO - 2017-08-19 20:02:19 --> Helper loaded: file_helper
INFO - 2017-08-19 20:02:19 --> Database Driver Class Initialized
INFO - 2017-08-19 20:02:19 --> Email Class Initialized
DEBUG - 2017-08-19 20:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:02:20 --> Table Class Initialized
INFO - 2017-08-19 20:02:20 --> Controller Class Initialized
INFO - 2017-08-19 20:02:20 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:02:20 --> Final output sent to browser
DEBUG - 2017-08-19 20:02:20 --> Total execution time: 0.2181
INFO - 2017-08-19 20:03:05 --> Config Class Initialized
INFO - 2017-08-19 20:03:05 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:03:05 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:03:05 --> Utf8 Class Initialized
INFO - 2017-08-19 20:03:05 --> URI Class Initialized
DEBUG - 2017-08-19 20:03:05 --> No URI present. Default controller set.
INFO - 2017-08-19 20:03:05 --> Router Class Initialized
INFO - 2017-08-19 20:03:05 --> Output Class Initialized
INFO - 2017-08-19 20:03:05 --> Security Class Initialized
DEBUG - 2017-08-19 20:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:03:05 --> Input Class Initialized
INFO - 2017-08-19 20:03:05 --> Language Class Initialized
INFO - 2017-08-19 20:03:05 --> Loader Class Initialized
INFO - 2017-08-19 20:03:05 --> Helper loaded: url_helper
INFO - 2017-08-19 20:03:05 --> Helper loaded: file_helper
INFO - 2017-08-19 20:03:05 --> Database Driver Class Initialized
INFO - 2017-08-19 20:03:05 --> Email Class Initialized
DEBUG - 2017-08-19 20:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:03:05 --> Table Class Initialized
INFO - 2017-08-19 20:03:05 --> Controller Class Initialized
INFO - 2017-08-19 20:03:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:03:06 --> Final output sent to browser
DEBUG - 2017-08-19 20:03:06 --> Total execution time: 0.2349
INFO - 2017-08-19 20:04:24 --> Config Class Initialized
INFO - 2017-08-19 20:04:24 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:04:24 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:04:24 --> Utf8 Class Initialized
INFO - 2017-08-19 20:04:24 --> URI Class Initialized
DEBUG - 2017-08-19 20:04:24 --> No URI present. Default controller set.
INFO - 2017-08-19 20:04:24 --> Router Class Initialized
INFO - 2017-08-19 20:04:24 --> Output Class Initialized
INFO - 2017-08-19 20:04:24 --> Security Class Initialized
DEBUG - 2017-08-19 20:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:04:24 --> Input Class Initialized
INFO - 2017-08-19 20:04:24 --> Language Class Initialized
INFO - 2017-08-19 20:04:24 --> Loader Class Initialized
INFO - 2017-08-19 20:04:24 --> Helper loaded: url_helper
INFO - 2017-08-19 20:04:24 --> Helper loaded: file_helper
INFO - 2017-08-19 20:04:24 --> Database Driver Class Initialized
INFO - 2017-08-19 20:04:24 --> Email Class Initialized
DEBUG - 2017-08-19 20:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:04:24 --> Table Class Initialized
INFO - 2017-08-19 20:04:24 --> Controller Class Initialized
INFO - 2017-08-19 20:04:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:04:24 --> Final output sent to browser
DEBUG - 2017-08-19 20:04:24 --> Total execution time: 0.2335
INFO - 2017-08-19 20:05:03 --> Config Class Initialized
INFO - 2017-08-19 20:05:03 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:05:03 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:05:03 --> Utf8 Class Initialized
INFO - 2017-08-19 20:05:03 --> URI Class Initialized
DEBUG - 2017-08-19 20:05:03 --> No URI present. Default controller set.
INFO - 2017-08-19 20:05:03 --> Router Class Initialized
INFO - 2017-08-19 20:05:03 --> Output Class Initialized
INFO - 2017-08-19 20:05:03 --> Security Class Initialized
DEBUG - 2017-08-19 20:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:05:03 --> Input Class Initialized
INFO - 2017-08-19 20:05:03 --> Language Class Initialized
INFO - 2017-08-19 20:05:03 --> Loader Class Initialized
INFO - 2017-08-19 20:05:03 --> Helper loaded: url_helper
INFO - 2017-08-19 20:05:03 --> Helper loaded: file_helper
INFO - 2017-08-19 20:05:03 --> Database Driver Class Initialized
INFO - 2017-08-19 20:05:03 --> Email Class Initialized
DEBUG - 2017-08-19 20:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:05:03 --> Table Class Initialized
INFO - 2017-08-19 20:05:03 --> Controller Class Initialized
INFO - 2017-08-19 20:05:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:05:03 --> Final output sent to browser
DEBUG - 2017-08-19 20:05:03 --> Total execution time: 0.2351
INFO - 2017-08-19 20:05:09 --> Config Class Initialized
INFO - 2017-08-19 20:05:09 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:05:09 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:05:09 --> Utf8 Class Initialized
INFO - 2017-08-19 20:05:09 --> URI Class Initialized
DEBUG - 2017-08-19 20:05:09 --> No URI present. Default controller set.
INFO - 2017-08-19 20:05:09 --> Router Class Initialized
INFO - 2017-08-19 20:05:09 --> Output Class Initialized
INFO - 2017-08-19 20:05:09 --> Security Class Initialized
DEBUG - 2017-08-19 20:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:05:09 --> Input Class Initialized
INFO - 2017-08-19 20:05:09 --> Language Class Initialized
INFO - 2017-08-19 20:05:09 --> Loader Class Initialized
INFO - 2017-08-19 20:05:09 --> Helper loaded: url_helper
INFO - 2017-08-19 20:05:09 --> Helper loaded: file_helper
INFO - 2017-08-19 20:05:09 --> Database Driver Class Initialized
INFO - 2017-08-19 20:05:09 --> Email Class Initialized
DEBUG - 2017-08-19 20:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:05:09 --> Table Class Initialized
INFO - 2017-08-19 20:05:09 --> Controller Class Initialized
INFO - 2017-08-19 20:05:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:05:09 --> Final output sent to browser
DEBUG - 2017-08-19 20:05:09 --> Total execution time: 0.2235
INFO - 2017-08-19 20:05:21 --> Config Class Initialized
INFO - 2017-08-19 20:05:21 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:05:21 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:05:21 --> Utf8 Class Initialized
INFO - 2017-08-19 20:05:21 --> URI Class Initialized
DEBUG - 2017-08-19 20:05:21 --> No URI present. Default controller set.
INFO - 2017-08-19 20:05:21 --> Router Class Initialized
INFO - 2017-08-19 20:05:21 --> Output Class Initialized
INFO - 2017-08-19 20:05:21 --> Security Class Initialized
DEBUG - 2017-08-19 20:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:05:21 --> Input Class Initialized
INFO - 2017-08-19 20:05:21 --> Language Class Initialized
INFO - 2017-08-19 20:05:21 --> Loader Class Initialized
INFO - 2017-08-19 20:05:21 --> Helper loaded: url_helper
INFO - 2017-08-19 20:05:21 --> Helper loaded: file_helper
INFO - 2017-08-19 20:05:21 --> Database Driver Class Initialized
INFO - 2017-08-19 20:05:21 --> Email Class Initialized
DEBUG - 2017-08-19 20:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:05:21 --> Table Class Initialized
INFO - 2017-08-19 20:05:21 --> Controller Class Initialized
INFO - 2017-08-19 20:05:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:05:21 --> Final output sent to browser
DEBUG - 2017-08-19 20:05:21 --> Total execution time: 0.2206
INFO - 2017-08-19 20:05:35 --> Config Class Initialized
INFO - 2017-08-19 20:05:35 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:05:35 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:05:35 --> Utf8 Class Initialized
INFO - 2017-08-19 20:05:35 --> URI Class Initialized
DEBUG - 2017-08-19 20:05:35 --> No URI present. Default controller set.
INFO - 2017-08-19 20:05:35 --> Router Class Initialized
INFO - 2017-08-19 20:05:35 --> Output Class Initialized
INFO - 2017-08-19 20:05:35 --> Security Class Initialized
DEBUG - 2017-08-19 20:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:05:35 --> Input Class Initialized
INFO - 2017-08-19 20:05:35 --> Language Class Initialized
INFO - 2017-08-19 20:05:35 --> Loader Class Initialized
INFO - 2017-08-19 20:05:35 --> Helper loaded: url_helper
INFO - 2017-08-19 20:05:35 --> Helper loaded: file_helper
INFO - 2017-08-19 20:05:35 --> Database Driver Class Initialized
INFO - 2017-08-19 20:05:35 --> Email Class Initialized
DEBUG - 2017-08-19 20:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:05:35 --> Table Class Initialized
INFO - 2017-08-19 20:05:35 --> Controller Class Initialized
INFO - 2017-08-19 20:05:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:05:35 --> Final output sent to browser
DEBUG - 2017-08-19 20:05:35 --> Total execution time: 0.2405
INFO - 2017-08-19 20:05:39 --> Config Class Initialized
INFO - 2017-08-19 20:05:39 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:05:39 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:05:39 --> Utf8 Class Initialized
INFO - 2017-08-19 20:05:39 --> URI Class Initialized
DEBUG - 2017-08-19 20:05:39 --> No URI present. Default controller set.
INFO - 2017-08-19 20:05:39 --> Router Class Initialized
INFO - 2017-08-19 20:05:39 --> Output Class Initialized
INFO - 2017-08-19 20:05:39 --> Security Class Initialized
DEBUG - 2017-08-19 20:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:05:39 --> Input Class Initialized
INFO - 2017-08-19 20:05:39 --> Language Class Initialized
INFO - 2017-08-19 20:05:39 --> Loader Class Initialized
INFO - 2017-08-19 20:05:39 --> Helper loaded: url_helper
INFO - 2017-08-19 20:05:39 --> Helper loaded: file_helper
INFO - 2017-08-19 20:05:39 --> Database Driver Class Initialized
INFO - 2017-08-19 20:05:39 --> Email Class Initialized
DEBUG - 2017-08-19 20:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:05:39 --> Table Class Initialized
INFO - 2017-08-19 20:05:39 --> Controller Class Initialized
INFO - 2017-08-19 20:05:39 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:05:39 --> Final output sent to browser
DEBUG - 2017-08-19 20:05:39 --> Total execution time: 0.2301
INFO - 2017-08-19 20:07:46 --> Config Class Initialized
INFO - 2017-08-19 20:07:46 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:07:46 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:07:46 --> Utf8 Class Initialized
INFO - 2017-08-19 20:07:46 --> URI Class Initialized
DEBUG - 2017-08-19 20:07:46 --> No URI present. Default controller set.
INFO - 2017-08-19 20:07:46 --> Router Class Initialized
INFO - 2017-08-19 20:07:46 --> Output Class Initialized
INFO - 2017-08-19 20:07:46 --> Security Class Initialized
DEBUG - 2017-08-19 20:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:07:46 --> Input Class Initialized
INFO - 2017-08-19 20:07:46 --> Language Class Initialized
INFO - 2017-08-19 20:07:46 --> Loader Class Initialized
INFO - 2017-08-19 20:07:46 --> Helper loaded: url_helper
INFO - 2017-08-19 20:07:46 --> Helper loaded: file_helper
INFO - 2017-08-19 20:07:46 --> Database Driver Class Initialized
INFO - 2017-08-19 20:07:46 --> Email Class Initialized
DEBUG - 2017-08-19 20:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:07:46 --> Table Class Initialized
INFO - 2017-08-19 20:07:46 --> Controller Class Initialized
INFO - 2017-08-19 20:07:46 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:07:46 --> Final output sent to browser
DEBUG - 2017-08-19 20:07:46 --> Total execution time: 0.2330
INFO - 2017-08-19 20:08:06 --> Config Class Initialized
INFO - 2017-08-19 20:08:06 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:08:06 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:08:06 --> Utf8 Class Initialized
INFO - 2017-08-19 20:08:06 --> URI Class Initialized
DEBUG - 2017-08-19 20:08:06 --> No URI present. Default controller set.
INFO - 2017-08-19 20:08:06 --> Router Class Initialized
INFO - 2017-08-19 20:08:06 --> Output Class Initialized
INFO - 2017-08-19 20:08:06 --> Security Class Initialized
DEBUG - 2017-08-19 20:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:08:06 --> Input Class Initialized
INFO - 2017-08-19 20:08:06 --> Language Class Initialized
INFO - 2017-08-19 20:08:06 --> Loader Class Initialized
INFO - 2017-08-19 20:08:06 --> Helper loaded: url_helper
INFO - 2017-08-19 20:08:06 --> Helper loaded: file_helper
INFO - 2017-08-19 20:08:06 --> Database Driver Class Initialized
INFO - 2017-08-19 20:08:06 --> Email Class Initialized
DEBUG - 2017-08-19 20:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:08:06 --> Table Class Initialized
INFO - 2017-08-19 20:08:06 --> Controller Class Initialized
INFO - 2017-08-19 20:08:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:08:06 --> Final output sent to browser
DEBUG - 2017-08-19 20:08:06 --> Total execution time: 0.2221
INFO - 2017-08-19 20:08:14 --> Config Class Initialized
INFO - 2017-08-19 20:08:14 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:08:14 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:08:14 --> Utf8 Class Initialized
INFO - 2017-08-19 20:08:14 --> URI Class Initialized
DEBUG - 2017-08-19 20:08:14 --> No URI present. Default controller set.
INFO - 2017-08-19 20:08:14 --> Router Class Initialized
INFO - 2017-08-19 20:08:14 --> Output Class Initialized
INFO - 2017-08-19 20:08:14 --> Security Class Initialized
DEBUG - 2017-08-19 20:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:08:14 --> Input Class Initialized
INFO - 2017-08-19 20:08:14 --> Language Class Initialized
INFO - 2017-08-19 20:08:14 --> Loader Class Initialized
INFO - 2017-08-19 20:08:14 --> Helper loaded: url_helper
INFO - 2017-08-19 20:08:14 --> Helper loaded: file_helper
INFO - 2017-08-19 20:08:14 --> Database Driver Class Initialized
INFO - 2017-08-19 20:08:14 --> Email Class Initialized
DEBUG - 2017-08-19 20:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:08:14 --> Table Class Initialized
INFO - 2017-08-19 20:08:14 --> Controller Class Initialized
INFO - 2017-08-19 20:08:14 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:08:14 --> Final output sent to browser
DEBUG - 2017-08-19 20:08:14 --> Total execution time: 0.2289
INFO - 2017-08-19 20:08:44 --> Config Class Initialized
INFO - 2017-08-19 20:08:44 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:08:44 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:08:44 --> Utf8 Class Initialized
INFO - 2017-08-19 20:08:44 --> URI Class Initialized
DEBUG - 2017-08-19 20:08:44 --> No URI present. Default controller set.
INFO - 2017-08-19 20:08:44 --> Router Class Initialized
INFO - 2017-08-19 20:08:44 --> Output Class Initialized
INFO - 2017-08-19 20:08:44 --> Security Class Initialized
DEBUG - 2017-08-19 20:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:08:44 --> Input Class Initialized
INFO - 2017-08-19 20:08:44 --> Language Class Initialized
INFO - 2017-08-19 20:08:44 --> Loader Class Initialized
INFO - 2017-08-19 20:08:44 --> Helper loaded: url_helper
INFO - 2017-08-19 20:08:44 --> Helper loaded: file_helper
INFO - 2017-08-19 20:08:44 --> Database Driver Class Initialized
INFO - 2017-08-19 20:08:44 --> Email Class Initialized
DEBUG - 2017-08-19 20:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:08:44 --> Table Class Initialized
INFO - 2017-08-19 20:08:44 --> Controller Class Initialized
INFO - 2017-08-19 20:08:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:08:44 --> Final output sent to browser
DEBUG - 2017-08-19 20:08:44 --> Total execution time: 0.2368
INFO - 2017-08-19 20:09:26 --> Config Class Initialized
INFO - 2017-08-19 20:09:26 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:09:26 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:09:26 --> Utf8 Class Initialized
INFO - 2017-08-19 20:09:26 --> URI Class Initialized
DEBUG - 2017-08-19 20:09:26 --> No URI present. Default controller set.
INFO - 2017-08-19 20:09:26 --> Router Class Initialized
INFO - 2017-08-19 20:09:26 --> Output Class Initialized
INFO - 2017-08-19 20:09:26 --> Security Class Initialized
DEBUG - 2017-08-19 20:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:09:26 --> Input Class Initialized
INFO - 2017-08-19 20:09:26 --> Language Class Initialized
INFO - 2017-08-19 20:09:26 --> Loader Class Initialized
INFO - 2017-08-19 20:09:26 --> Helper loaded: url_helper
INFO - 2017-08-19 20:09:26 --> Helper loaded: file_helper
INFO - 2017-08-19 20:09:26 --> Database Driver Class Initialized
INFO - 2017-08-19 20:09:26 --> Email Class Initialized
DEBUG - 2017-08-19 20:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:09:26 --> Table Class Initialized
INFO - 2017-08-19 20:09:26 --> Controller Class Initialized
INFO - 2017-08-19 20:09:26 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:09:26 --> Final output sent to browser
DEBUG - 2017-08-19 20:09:26 --> Total execution time: 0.3845
INFO - 2017-08-19 20:09:31 --> Config Class Initialized
INFO - 2017-08-19 20:09:31 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:09:31 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:09:31 --> Utf8 Class Initialized
INFO - 2017-08-19 20:09:31 --> URI Class Initialized
DEBUG - 2017-08-19 20:09:31 --> No URI present. Default controller set.
INFO - 2017-08-19 20:09:31 --> Router Class Initialized
INFO - 2017-08-19 20:09:31 --> Output Class Initialized
INFO - 2017-08-19 20:09:31 --> Security Class Initialized
DEBUG - 2017-08-19 20:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:09:31 --> Input Class Initialized
INFO - 2017-08-19 20:09:31 --> Language Class Initialized
INFO - 2017-08-19 20:09:31 --> Loader Class Initialized
INFO - 2017-08-19 20:09:31 --> Helper loaded: url_helper
INFO - 2017-08-19 20:09:31 --> Helper loaded: file_helper
INFO - 2017-08-19 20:09:31 --> Database Driver Class Initialized
INFO - 2017-08-19 20:09:31 --> Email Class Initialized
DEBUG - 2017-08-19 20:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:09:31 --> Table Class Initialized
INFO - 2017-08-19 20:09:31 --> Controller Class Initialized
INFO - 2017-08-19 20:09:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:09:31 --> Final output sent to browser
DEBUG - 2017-08-19 20:09:31 --> Total execution time: 0.2210
INFO - 2017-08-19 20:11:59 --> Config Class Initialized
INFO - 2017-08-19 20:11:59 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:11:59 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:11:59 --> Utf8 Class Initialized
INFO - 2017-08-19 20:11:59 --> URI Class Initialized
DEBUG - 2017-08-19 20:11:59 --> No URI present. Default controller set.
INFO - 2017-08-19 20:11:59 --> Router Class Initialized
INFO - 2017-08-19 20:11:59 --> Output Class Initialized
INFO - 2017-08-19 20:11:59 --> Security Class Initialized
DEBUG - 2017-08-19 20:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:11:59 --> Input Class Initialized
INFO - 2017-08-19 20:11:59 --> Language Class Initialized
INFO - 2017-08-19 20:11:59 --> Loader Class Initialized
INFO - 2017-08-19 20:11:59 --> Helper loaded: url_helper
INFO - 2017-08-19 20:11:59 --> Helper loaded: file_helper
INFO - 2017-08-19 20:11:59 --> Database Driver Class Initialized
INFO - 2017-08-19 20:11:59 --> Email Class Initialized
DEBUG - 2017-08-19 20:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:11:59 --> Table Class Initialized
INFO - 2017-08-19 20:11:59 --> Controller Class Initialized
INFO - 2017-08-19 20:11:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:11:59 --> Final output sent to browser
DEBUG - 2017-08-19 20:11:59 --> Total execution time: 0.3449
INFO - 2017-08-19 20:12:24 --> Config Class Initialized
INFO - 2017-08-19 20:12:24 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:12:24 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:12:24 --> Utf8 Class Initialized
INFO - 2017-08-19 20:12:24 --> URI Class Initialized
DEBUG - 2017-08-19 20:12:24 --> No URI present. Default controller set.
INFO - 2017-08-19 20:12:24 --> Router Class Initialized
INFO - 2017-08-19 20:12:24 --> Output Class Initialized
INFO - 2017-08-19 20:12:24 --> Security Class Initialized
DEBUG - 2017-08-19 20:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:12:24 --> Input Class Initialized
INFO - 2017-08-19 20:12:24 --> Language Class Initialized
INFO - 2017-08-19 20:12:24 --> Loader Class Initialized
INFO - 2017-08-19 20:12:24 --> Helper loaded: url_helper
INFO - 2017-08-19 20:12:24 --> Helper loaded: file_helper
INFO - 2017-08-19 20:12:24 --> Database Driver Class Initialized
INFO - 2017-08-19 20:12:24 --> Email Class Initialized
DEBUG - 2017-08-19 20:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:12:24 --> Table Class Initialized
INFO - 2017-08-19 20:12:24 --> Controller Class Initialized
INFO - 2017-08-19 20:12:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:12:24 --> Final output sent to browser
DEBUG - 2017-08-19 20:12:24 --> Total execution time: 0.2288
INFO - 2017-08-19 20:12:32 --> Config Class Initialized
INFO - 2017-08-19 20:12:32 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:12:32 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:12:32 --> Utf8 Class Initialized
INFO - 2017-08-19 20:12:32 --> URI Class Initialized
DEBUG - 2017-08-19 20:12:32 --> No URI present. Default controller set.
INFO - 2017-08-19 20:12:32 --> Router Class Initialized
INFO - 2017-08-19 20:12:32 --> Output Class Initialized
INFO - 2017-08-19 20:12:32 --> Security Class Initialized
DEBUG - 2017-08-19 20:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:12:32 --> Input Class Initialized
INFO - 2017-08-19 20:12:32 --> Language Class Initialized
INFO - 2017-08-19 20:12:32 --> Loader Class Initialized
INFO - 2017-08-19 20:12:32 --> Helper loaded: url_helper
INFO - 2017-08-19 20:12:32 --> Helper loaded: file_helper
INFO - 2017-08-19 20:12:33 --> Database Driver Class Initialized
INFO - 2017-08-19 20:12:33 --> Email Class Initialized
DEBUG - 2017-08-19 20:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:12:33 --> Table Class Initialized
INFO - 2017-08-19 20:12:33 --> Controller Class Initialized
INFO - 2017-08-19 20:12:33 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:12:33 --> Final output sent to browser
DEBUG - 2017-08-19 20:12:33 --> Total execution time: 0.2291
INFO - 2017-08-19 20:14:19 --> Config Class Initialized
INFO - 2017-08-19 20:14:19 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:14:19 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:14:19 --> Utf8 Class Initialized
INFO - 2017-08-19 20:14:19 --> URI Class Initialized
DEBUG - 2017-08-19 20:14:19 --> No URI present. Default controller set.
INFO - 2017-08-19 20:14:19 --> Router Class Initialized
INFO - 2017-08-19 20:14:19 --> Output Class Initialized
INFO - 2017-08-19 20:14:19 --> Security Class Initialized
DEBUG - 2017-08-19 20:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:14:19 --> Input Class Initialized
INFO - 2017-08-19 20:14:19 --> Language Class Initialized
INFO - 2017-08-19 20:14:19 --> Loader Class Initialized
INFO - 2017-08-19 20:14:19 --> Helper loaded: url_helper
INFO - 2017-08-19 20:14:19 --> Helper loaded: file_helper
INFO - 2017-08-19 20:14:19 --> Database Driver Class Initialized
INFO - 2017-08-19 20:14:19 --> Email Class Initialized
DEBUG - 2017-08-19 20:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:14:19 --> Table Class Initialized
INFO - 2017-08-19 20:14:19 --> Controller Class Initialized
INFO - 2017-08-19 20:14:19 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:14:19 --> Final output sent to browser
DEBUG - 2017-08-19 20:14:19 --> Total execution time: 0.2447
INFO - 2017-08-19 20:14:26 --> Config Class Initialized
INFO - 2017-08-19 20:14:26 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:14:26 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:14:26 --> Utf8 Class Initialized
INFO - 2017-08-19 20:14:26 --> URI Class Initialized
DEBUG - 2017-08-19 20:14:26 --> No URI present. Default controller set.
INFO - 2017-08-19 20:14:26 --> Router Class Initialized
INFO - 2017-08-19 20:14:26 --> Output Class Initialized
INFO - 2017-08-19 20:14:26 --> Security Class Initialized
DEBUG - 2017-08-19 20:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:14:26 --> Input Class Initialized
INFO - 2017-08-19 20:14:26 --> Language Class Initialized
INFO - 2017-08-19 20:14:26 --> Loader Class Initialized
INFO - 2017-08-19 20:14:26 --> Helper loaded: url_helper
INFO - 2017-08-19 20:14:26 --> Helper loaded: file_helper
INFO - 2017-08-19 20:14:26 --> Database Driver Class Initialized
INFO - 2017-08-19 20:14:26 --> Email Class Initialized
DEBUG - 2017-08-19 20:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:14:26 --> Table Class Initialized
INFO - 2017-08-19 20:14:26 --> Controller Class Initialized
INFO - 2017-08-19 20:14:26 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:14:26 --> Final output sent to browser
DEBUG - 2017-08-19 20:14:26 --> Total execution time: 0.2539
INFO - 2017-08-19 20:16:01 --> Config Class Initialized
INFO - 2017-08-19 20:16:01 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:16:01 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:16:01 --> Utf8 Class Initialized
INFO - 2017-08-19 20:16:01 --> URI Class Initialized
DEBUG - 2017-08-19 20:16:01 --> No URI present. Default controller set.
INFO - 2017-08-19 20:16:01 --> Router Class Initialized
INFO - 2017-08-19 20:16:01 --> Output Class Initialized
INFO - 2017-08-19 20:16:01 --> Security Class Initialized
DEBUG - 2017-08-19 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:16:01 --> Input Class Initialized
INFO - 2017-08-19 20:16:01 --> Language Class Initialized
INFO - 2017-08-19 20:16:01 --> Loader Class Initialized
INFO - 2017-08-19 20:16:01 --> Helper loaded: url_helper
INFO - 2017-08-19 20:16:01 --> Helper loaded: file_helper
INFO - 2017-08-19 20:16:01 --> Database Driver Class Initialized
INFO - 2017-08-19 20:16:01 --> Email Class Initialized
DEBUG - 2017-08-19 20:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:16:01 --> Table Class Initialized
INFO - 2017-08-19 20:16:01 --> Controller Class Initialized
INFO - 2017-08-19 20:16:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:16:01 --> Final output sent to browser
DEBUG - 2017-08-19 20:16:01 --> Total execution time: 0.3499
INFO - 2017-08-19 20:16:08 --> Config Class Initialized
INFO - 2017-08-19 20:16:08 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:16:08 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:16:08 --> Utf8 Class Initialized
INFO - 2017-08-19 20:16:08 --> URI Class Initialized
DEBUG - 2017-08-19 20:16:08 --> No URI present. Default controller set.
INFO - 2017-08-19 20:16:08 --> Router Class Initialized
INFO - 2017-08-19 20:16:08 --> Output Class Initialized
INFO - 2017-08-19 20:16:08 --> Security Class Initialized
DEBUG - 2017-08-19 20:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:16:08 --> Input Class Initialized
INFO - 2017-08-19 20:16:08 --> Language Class Initialized
INFO - 2017-08-19 20:16:08 --> Loader Class Initialized
INFO - 2017-08-19 20:16:08 --> Helper loaded: url_helper
INFO - 2017-08-19 20:16:08 --> Helper loaded: file_helper
INFO - 2017-08-19 20:16:08 --> Database Driver Class Initialized
INFO - 2017-08-19 20:16:08 --> Email Class Initialized
DEBUG - 2017-08-19 20:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:16:08 --> Table Class Initialized
INFO - 2017-08-19 20:16:08 --> Controller Class Initialized
INFO - 2017-08-19 20:16:08 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:16:08 --> Final output sent to browser
DEBUG - 2017-08-19 20:16:08 --> Total execution time: 0.2289
INFO - 2017-08-19 20:16:37 --> Config Class Initialized
INFO - 2017-08-19 20:16:37 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:16:37 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:16:37 --> Utf8 Class Initialized
INFO - 2017-08-19 20:16:37 --> URI Class Initialized
DEBUG - 2017-08-19 20:16:37 --> No URI present. Default controller set.
INFO - 2017-08-19 20:16:37 --> Router Class Initialized
INFO - 2017-08-19 20:16:37 --> Output Class Initialized
INFO - 2017-08-19 20:16:37 --> Security Class Initialized
DEBUG - 2017-08-19 20:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:16:37 --> Input Class Initialized
INFO - 2017-08-19 20:16:37 --> Language Class Initialized
INFO - 2017-08-19 20:16:37 --> Loader Class Initialized
INFO - 2017-08-19 20:16:37 --> Helper loaded: url_helper
INFO - 2017-08-19 20:16:37 --> Helper loaded: file_helper
INFO - 2017-08-19 20:16:37 --> Database Driver Class Initialized
INFO - 2017-08-19 20:16:37 --> Email Class Initialized
DEBUG - 2017-08-19 20:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:16:37 --> Table Class Initialized
INFO - 2017-08-19 20:16:37 --> Controller Class Initialized
INFO - 2017-08-19 20:16:37 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:16:37 --> Final output sent to browser
DEBUG - 2017-08-19 20:16:37 --> Total execution time: 0.2406
INFO - 2017-08-19 20:16:58 --> Config Class Initialized
INFO - 2017-08-19 20:16:58 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:16:58 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:16:58 --> Utf8 Class Initialized
INFO - 2017-08-19 20:16:58 --> URI Class Initialized
DEBUG - 2017-08-19 20:16:58 --> No URI present. Default controller set.
INFO - 2017-08-19 20:16:58 --> Router Class Initialized
INFO - 2017-08-19 20:16:58 --> Output Class Initialized
INFO - 2017-08-19 20:16:58 --> Security Class Initialized
DEBUG - 2017-08-19 20:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:16:58 --> Input Class Initialized
INFO - 2017-08-19 20:16:58 --> Language Class Initialized
INFO - 2017-08-19 20:16:58 --> Loader Class Initialized
INFO - 2017-08-19 20:16:58 --> Helper loaded: url_helper
INFO - 2017-08-19 20:16:58 --> Helper loaded: file_helper
INFO - 2017-08-19 20:16:58 --> Database Driver Class Initialized
INFO - 2017-08-19 20:16:58 --> Email Class Initialized
DEBUG - 2017-08-19 20:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:16:58 --> Table Class Initialized
INFO - 2017-08-19 20:16:58 --> Controller Class Initialized
INFO - 2017-08-19 20:16:58 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:16:58 --> Final output sent to browser
DEBUG - 2017-08-19 20:16:58 --> Total execution time: 0.2545
INFO - 2017-08-19 20:17:05 --> Config Class Initialized
INFO - 2017-08-19 20:17:05 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:17:05 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:17:05 --> Utf8 Class Initialized
INFO - 2017-08-19 20:17:05 --> URI Class Initialized
DEBUG - 2017-08-19 20:17:05 --> No URI present. Default controller set.
INFO - 2017-08-19 20:17:05 --> Router Class Initialized
INFO - 2017-08-19 20:17:05 --> Output Class Initialized
INFO - 2017-08-19 20:17:05 --> Security Class Initialized
DEBUG - 2017-08-19 20:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:17:05 --> Input Class Initialized
INFO - 2017-08-19 20:17:05 --> Language Class Initialized
INFO - 2017-08-19 20:17:05 --> Loader Class Initialized
INFO - 2017-08-19 20:17:05 --> Helper loaded: url_helper
INFO - 2017-08-19 20:17:05 --> Helper loaded: file_helper
INFO - 2017-08-19 20:17:05 --> Database Driver Class Initialized
INFO - 2017-08-19 20:17:05 --> Email Class Initialized
DEBUG - 2017-08-19 20:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:17:05 --> Table Class Initialized
INFO - 2017-08-19 20:17:05 --> Controller Class Initialized
INFO - 2017-08-19 20:17:05 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:17:05 --> Final output sent to browser
DEBUG - 2017-08-19 20:17:05 --> Total execution time: 0.2329
INFO - 2017-08-19 20:17:23 --> Config Class Initialized
INFO - 2017-08-19 20:17:23 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:17:23 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:17:23 --> Utf8 Class Initialized
INFO - 2017-08-19 20:17:23 --> URI Class Initialized
DEBUG - 2017-08-19 20:17:23 --> No URI present. Default controller set.
INFO - 2017-08-19 20:17:23 --> Router Class Initialized
INFO - 2017-08-19 20:17:23 --> Output Class Initialized
INFO - 2017-08-19 20:17:23 --> Security Class Initialized
DEBUG - 2017-08-19 20:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:17:23 --> Input Class Initialized
INFO - 2017-08-19 20:17:23 --> Language Class Initialized
INFO - 2017-08-19 20:17:23 --> Loader Class Initialized
INFO - 2017-08-19 20:17:23 --> Helper loaded: url_helper
INFO - 2017-08-19 20:17:23 --> Helper loaded: file_helper
INFO - 2017-08-19 20:17:23 --> Database Driver Class Initialized
INFO - 2017-08-19 20:17:23 --> Email Class Initialized
DEBUG - 2017-08-19 20:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:17:23 --> Table Class Initialized
INFO - 2017-08-19 20:17:23 --> Controller Class Initialized
INFO - 2017-08-19 20:17:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:17:23 --> Final output sent to browser
DEBUG - 2017-08-19 20:17:23 --> Total execution time: 0.2315
INFO - 2017-08-19 20:17:57 --> Config Class Initialized
INFO - 2017-08-19 20:17:57 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:17:57 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:17:57 --> Utf8 Class Initialized
INFO - 2017-08-19 20:17:57 --> URI Class Initialized
DEBUG - 2017-08-19 20:17:57 --> No URI present. Default controller set.
INFO - 2017-08-19 20:17:57 --> Router Class Initialized
INFO - 2017-08-19 20:17:57 --> Output Class Initialized
INFO - 2017-08-19 20:17:57 --> Security Class Initialized
DEBUG - 2017-08-19 20:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:17:57 --> Input Class Initialized
INFO - 2017-08-19 20:17:57 --> Language Class Initialized
INFO - 2017-08-19 20:17:57 --> Loader Class Initialized
INFO - 2017-08-19 20:17:57 --> Helper loaded: url_helper
INFO - 2017-08-19 20:17:57 --> Helper loaded: file_helper
INFO - 2017-08-19 20:17:57 --> Database Driver Class Initialized
INFO - 2017-08-19 20:17:57 --> Email Class Initialized
DEBUG - 2017-08-19 20:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:17:57 --> Table Class Initialized
INFO - 2017-08-19 20:17:57 --> Controller Class Initialized
INFO - 2017-08-19 20:17:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:17:57 --> Final output sent to browser
DEBUG - 2017-08-19 20:17:58 --> Total execution time: 0.2249
INFO - 2017-08-19 20:20:49 --> Config Class Initialized
INFO - 2017-08-19 20:20:49 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:20:49 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:20:49 --> Utf8 Class Initialized
INFO - 2017-08-19 20:20:49 --> URI Class Initialized
DEBUG - 2017-08-19 20:20:49 --> No URI present. Default controller set.
INFO - 2017-08-19 20:20:49 --> Router Class Initialized
INFO - 2017-08-19 20:20:49 --> Output Class Initialized
INFO - 2017-08-19 20:20:49 --> Security Class Initialized
DEBUG - 2017-08-19 20:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:20:49 --> Input Class Initialized
INFO - 2017-08-19 20:20:49 --> Language Class Initialized
INFO - 2017-08-19 20:20:49 --> Loader Class Initialized
INFO - 2017-08-19 20:20:49 --> Helper loaded: url_helper
INFO - 2017-08-19 20:20:49 --> Helper loaded: file_helper
INFO - 2017-08-19 20:20:49 --> Database Driver Class Initialized
INFO - 2017-08-19 20:20:49 --> Email Class Initialized
DEBUG - 2017-08-19 20:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:20:49 --> Table Class Initialized
INFO - 2017-08-19 20:20:49 --> Controller Class Initialized
INFO - 2017-08-19 20:20:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:20:49 --> Final output sent to browser
DEBUG - 2017-08-19 20:20:49 --> Total execution time: 0.2488
INFO - 2017-08-19 20:20:58 --> Config Class Initialized
INFO - 2017-08-19 20:20:58 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:20:58 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:20:58 --> Utf8 Class Initialized
INFO - 2017-08-19 20:20:58 --> URI Class Initialized
DEBUG - 2017-08-19 20:20:58 --> No URI present. Default controller set.
INFO - 2017-08-19 20:20:58 --> Router Class Initialized
INFO - 2017-08-19 20:20:58 --> Output Class Initialized
INFO - 2017-08-19 20:20:58 --> Security Class Initialized
DEBUG - 2017-08-19 20:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:20:58 --> Input Class Initialized
INFO - 2017-08-19 20:20:58 --> Language Class Initialized
INFO - 2017-08-19 20:20:58 --> Loader Class Initialized
INFO - 2017-08-19 20:20:58 --> Helper loaded: url_helper
INFO - 2017-08-19 20:20:58 --> Helper loaded: file_helper
INFO - 2017-08-19 20:20:58 --> Database Driver Class Initialized
INFO - 2017-08-19 20:20:58 --> Email Class Initialized
DEBUG - 2017-08-19 20:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:20:58 --> Table Class Initialized
INFO - 2017-08-19 20:20:58 --> Controller Class Initialized
INFO - 2017-08-19 20:20:58 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:20:59 --> Final output sent to browser
DEBUG - 2017-08-19 20:20:59 --> Total execution time: 0.2403
INFO - 2017-08-19 20:23:47 --> Config Class Initialized
INFO - 2017-08-19 20:23:47 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:23:47 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:23:47 --> Utf8 Class Initialized
INFO - 2017-08-19 20:23:47 --> URI Class Initialized
DEBUG - 2017-08-19 20:23:47 --> No URI present. Default controller set.
INFO - 2017-08-19 20:23:47 --> Router Class Initialized
INFO - 2017-08-19 20:23:47 --> Output Class Initialized
INFO - 2017-08-19 20:23:47 --> Security Class Initialized
DEBUG - 2017-08-19 20:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:23:47 --> Input Class Initialized
INFO - 2017-08-19 20:23:47 --> Language Class Initialized
INFO - 2017-08-19 20:23:47 --> Loader Class Initialized
INFO - 2017-08-19 20:23:47 --> Helper loaded: url_helper
INFO - 2017-08-19 20:23:47 --> Helper loaded: file_helper
INFO - 2017-08-19 20:23:48 --> Database Driver Class Initialized
INFO - 2017-08-19 20:23:48 --> Email Class Initialized
DEBUG - 2017-08-19 20:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:23:48 --> Table Class Initialized
INFO - 2017-08-19 20:23:48 --> Controller Class Initialized
INFO - 2017-08-19 20:23:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:23:48 --> Final output sent to browser
DEBUG - 2017-08-19 20:23:48 --> Total execution time: 0.2442
INFO - 2017-08-19 20:24:01 --> Config Class Initialized
INFO - 2017-08-19 20:24:01 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:24:01 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:24:01 --> Utf8 Class Initialized
INFO - 2017-08-19 20:24:01 --> URI Class Initialized
DEBUG - 2017-08-19 20:24:01 --> No URI present. Default controller set.
INFO - 2017-08-19 20:24:01 --> Router Class Initialized
INFO - 2017-08-19 20:24:01 --> Output Class Initialized
INFO - 2017-08-19 20:24:01 --> Security Class Initialized
DEBUG - 2017-08-19 20:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:24:01 --> Input Class Initialized
INFO - 2017-08-19 20:24:01 --> Language Class Initialized
INFO - 2017-08-19 20:24:01 --> Loader Class Initialized
INFO - 2017-08-19 20:24:01 --> Helper loaded: url_helper
INFO - 2017-08-19 20:24:01 --> Helper loaded: file_helper
INFO - 2017-08-19 20:24:01 --> Database Driver Class Initialized
INFO - 2017-08-19 20:24:01 --> Email Class Initialized
DEBUG - 2017-08-19 20:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:24:01 --> Table Class Initialized
INFO - 2017-08-19 20:24:01 --> Controller Class Initialized
INFO - 2017-08-19 20:24:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:24:01 --> Final output sent to browser
DEBUG - 2017-08-19 20:24:01 --> Total execution time: 0.2562
INFO - 2017-08-19 20:25:06 --> Config Class Initialized
INFO - 2017-08-19 20:25:06 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:25:06 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:25:06 --> Utf8 Class Initialized
INFO - 2017-08-19 20:25:06 --> URI Class Initialized
DEBUG - 2017-08-19 20:25:07 --> No URI present. Default controller set.
INFO - 2017-08-19 20:25:07 --> Router Class Initialized
INFO - 2017-08-19 20:25:07 --> Output Class Initialized
INFO - 2017-08-19 20:25:07 --> Security Class Initialized
DEBUG - 2017-08-19 20:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:25:07 --> Input Class Initialized
INFO - 2017-08-19 20:25:07 --> Language Class Initialized
INFO - 2017-08-19 20:25:07 --> Loader Class Initialized
INFO - 2017-08-19 20:25:07 --> Helper loaded: url_helper
INFO - 2017-08-19 20:25:07 --> Helper loaded: file_helper
INFO - 2017-08-19 20:25:07 --> Database Driver Class Initialized
INFO - 2017-08-19 20:25:07 --> Email Class Initialized
DEBUG - 2017-08-19 20:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:25:07 --> Table Class Initialized
INFO - 2017-08-19 20:25:07 --> Controller Class Initialized
INFO - 2017-08-19 20:25:07 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:25:07 --> Final output sent to browser
DEBUG - 2017-08-19 20:25:07 --> Total execution time: 0.2475
INFO - 2017-08-19 20:25:28 --> Config Class Initialized
INFO - 2017-08-19 20:25:28 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:25:28 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:25:28 --> Utf8 Class Initialized
INFO - 2017-08-19 20:25:28 --> URI Class Initialized
DEBUG - 2017-08-19 20:25:28 --> No URI present. Default controller set.
INFO - 2017-08-19 20:25:28 --> Router Class Initialized
INFO - 2017-08-19 20:25:28 --> Output Class Initialized
INFO - 2017-08-19 20:25:28 --> Security Class Initialized
DEBUG - 2017-08-19 20:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:25:28 --> Input Class Initialized
INFO - 2017-08-19 20:25:28 --> Language Class Initialized
INFO - 2017-08-19 20:25:28 --> Loader Class Initialized
INFO - 2017-08-19 20:25:28 --> Helper loaded: url_helper
INFO - 2017-08-19 20:25:28 --> Helper loaded: file_helper
INFO - 2017-08-19 20:25:28 --> Database Driver Class Initialized
INFO - 2017-08-19 20:25:28 --> Email Class Initialized
DEBUG - 2017-08-19 20:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:25:28 --> Table Class Initialized
INFO - 2017-08-19 20:25:28 --> Controller Class Initialized
INFO - 2017-08-19 20:25:28 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:25:28 --> Final output sent to browser
DEBUG - 2017-08-19 20:25:28 --> Total execution time: 0.2565
INFO - 2017-08-19 20:25:43 --> Config Class Initialized
INFO - 2017-08-19 20:25:43 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:25:43 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:25:43 --> Utf8 Class Initialized
INFO - 2017-08-19 20:25:43 --> URI Class Initialized
DEBUG - 2017-08-19 20:25:43 --> No URI present. Default controller set.
INFO - 2017-08-19 20:25:43 --> Router Class Initialized
INFO - 2017-08-19 20:25:43 --> Output Class Initialized
INFO - 2017-08-19 20:25:43 --> Security Class Initialized
DEBUG - 2017-08-19 20:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:25:43 --> Input Class Initialized
INFO - 2017-08-19 20:25:43 --> Language Class Initialized
INFO - 2017-08-19 20:25:43 --> Loader Class Initialized
INFO - 2017-08-19 20:25:43 --> Helper loaded: url_helper
INFO - 2017-08-19 20:25:43 --> Helper loaded: file_helper
INFO - 2017-08-19 20:25:43 --> Database Driver Class Initialized
INFO - 2017-08-19 20:25:43 --> Email Class Initialized
DEBUG - 2017-08-19 20:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:25:43 --> Table Class Initialized
INFO - 2017-08-19 20:25:43 --> Controller Class Initialized
INFO - 2017-08-19 20:25:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:25:43 --> Final output sent to browser
DEBUG - 2017-08-19 20:25:43 --> Total execution time: 0.2457
INFO - 2017-08-19 20:26:01 --> Config Class Initialized
INFO - 2017-08-19 20:26:01 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:26:01 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:26:01 --> Utf8 Class Initialized
INFO - 2017-08-19 20:26:01 --> URI Class Initialized
DEBUG - 2017-08-19 20:26:01 --> No URI present. Default controller set.
INFO - 2017-08-19 20:26:01 --> Router Class Initialized
INFO - 2017-08-19 20:26:01 --> Output Class Initialized
INFO - 2017-08-19 20:26:01 --> Security Class Initialized
DEBUG - 2017-08-19 20:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:26:01 --> Input Class Initialized
INFO - 2017-08-19 20:26:01 --> Language Class Initialized
INFO - 2017-08-19 20:26:01 --> Loader Class Initialized
INFO - 2017-08-19 20:26:01 --> Helper loaded: url_helper
INFO - 2017-08-19 20:26:01 --> Helper loaded: file_helper
INFO - 2017-08-19 20:26:01 --> Database Driver Class Initialized
INFO - 2017-08-19 20:26:01 --> Email Class Initialized
DEBUG - 2017-08-19 20:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:26:01 --> Table Class Initialized
INFO - 2017-08-19 20:26:01 --> Controller Class Initialized
INFO - 2017-08-19 20:26:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:26:01 --> Final output sent to browser
DEBUG - 2017-08-19 20:26:01 --> Total execution time: 0.2385
INFO - 2017-08-19 20:26:26 --> Config Class Initialized
INFO - 2017-08-19 20:26:26 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:26:26 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:26:26 --> Utf8 Class Initialized
INFO - 2017-08-19 20:26:26 --> URI Class Initialized
DEBUG - 2017-08-19 20:26:26 --> No URI present. Default controller set.
INFO - 2017-08-19 20:26:27 --> Router Class Initialized
INFO - 2017-08-19 20:26:27 --> Output Class Initialized
INFO - 2017-08-19 20:26:27 --> Security Class Initialized
DEBUG - 2017-08-19 20:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:26:27 --> Input Class Initialized
INFO - 2017-08-19 20:26:27 --> Language Class Initialized
INFO - 2017-08-19 20:26:27 --> Loader Class Initialized
INFO - 2017-08-19 20:26:27 --> Helper loaded: url_helper
INFO - 2017-08-19 20:26:27 --> Helper loaded: file_helper
INFO - 2017-08-19 20:26:27 --> Database Driver Class Initialized
INFO - 2017-08-19 20:26:27 --> Email Class Initialized
DEBUG - 2017-08-19 20:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:26:27 --> Table Class Initialized
INFO - 2017-08-19 20:26:27 --> Controller Class Initialized
INFO - 2017-08-19 20:26:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:26:27 --> Final output sent to browser
DEBUG - 2017-08-19 20:26:27 --> Total execution time: 0.2563
INFO - 2017-08-19 20:26:46 --> Config Class Initialized
INFO - 2017-08-19 20:26:46 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:26:46 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:26:46 --> Utf8 Class Initialized
INFO - 2017-08-19 20:26:46 --> URI Class Initialized
DEBUG - 2017-08-19 20:26:46 --> No URI present. Default controller set.
INFO - 2017-08-19 20:26:46 --> Router Class Initialized
INFO - 2017-08-19 20:26:46 --> Output Class Initialized
INFO - 2017-08-19 20:26:46 --> Security Class Initialized
DEBUG - 2017-08-19 20:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:26:46 --> Input Class Initialized
INFO - 2017-08-19 20:26:46 --> Language Class Initialized
INFO - 2017-08-19 20:26:46 --> Loader Class Initialized
INFO - 2017-08-19 20:26:46 --> Helper loaded: url_helper
INFO - 2017-08-19 20:26:46 --> Helper loaded: file_helper
INFO - 2017-08-19 20:26:46 --> Database Driver Class Initialized
INFO - 2017-08-19 20:26:46 --> Email Class Initialized
DEBUG - 2017-08-19 20:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:26:46 --> Table Class Initialized
INFO - 2017-08-19 20:26:46 --> Controller Class Initialized
INFO - 2017-08-19 20:26:46 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:26:46 --> Final output sent to browser
DEBUG - 2017-08-19 20:26:46 --> Total execution time: 0.2417
INFO - 2017-08-19 20:31:41 --> Config Class Initialized
INFO - 2017-08-19 20:31:41 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:31:41 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:31:41 --> Utf8 Class Initialized
INFO - 2017-08-19 20:31:41 --> URI Class Initialized
DEBUG - 2017-08-19 20:31:41 --> No URI present. Default controller set.
INFO - 2017-08-19 20:31:41 --> Router Class Initialized
INFO - 2017-08-19 20:31:41 --> Output Class Initialized
INFO - 2017-08-19 20:31:41 --> Security Class Initialized
DEBUG - 2017-08-19 20:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:31:41 --> Input Class Initialized
INFO - 2017-08-19 20:31:41 --> Language Class Initialized
INFO - 2017-08-19 20:31:41 --> Loader Class Initialized
INFO - 2017-08-19 20:31:41 --> Helper loaded: url_helper
INFO - 2017-08-19 20:31:41 --> Helper loaded: file_helper
INFO - 2017-08-19 20:31:41 --> Database Driver Class Initialized
INFO - 2017-08-19 20:31:41 --> Email Class Initialized
DEBUG - 2017-08-19 20:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:31:41 --> Table Class Initialized
INFO - 2017-08-19 20:31:41 --> Controller Class Initialized
INFO - 2017-08-19 20:31:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:31:41 --> Final output sent to browser
DEBUG - 2017-08-19 20:31:41 --> Total execution time: 0.2452
INFO - 2017-08-19 20:32:15 --> Config Class Initialized
INFO - 2017-08-19 20:32:15 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:32:15 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:32:15 --> Utf8 Class Initialized
INFO - 2017-08-19 20:32:15 --> URI Class Initialized
DEBUG - 2017-08-19 20:32:15 --> No URI present. Default controller set.
INFO - 2017-08-19 20:32:15 --> Router Class Initialized
INFO - 2017-08-19 20:32:15 --> Output Class Initialized
INFO - 2017-08-19 20:32:15 --> Security Class Initialized
DEBUG - 2017-08-19 20:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:32:15 --> Input Class Initialized
INFO - 2017-08-19 20:32:15 --> Language Class Initialized
INFO - 2017-08-19 20:32:15 --> Loader Class Initialized
INFO - 2017-08-19 20:32:15 --> Helper loaded: url_helper
INFO - 2017-08-19 20:32:15 --> Helper loaded: file_helper
INFO - 2017-08-19 20:32:15 --> Database Driver Class Initialized
INFO - 2017-08-19 20:32:15 --> Email Class Initialized
DEBUG - 2017-08-19 20:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:32:15 --> Table Class Initialized
INFO - 2017-08-19 20:32:15 --> Controller Class Initialized
INFO - 2017-08-19 20:32:15 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:32:15 --> Final output sent to browser
DEBUG - 2017-08-19 20:32:15 --> Total execution time: 0.2373
INFO - 2017-08-19 20:32:16 --> Config Class Initialized
INFO - 2017-08-19 20:32:16 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:32:16 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:32:16 --> Utf8 Class Initialized
INFO - 2017-08-19 20:32:16 --> URI Class Initialized
DEBUG - 2017-08-19 20:32:16 --> No URI present. Default controller set.
INFO - 2017-08-19 20:32:16 --> Router Class Initialized
INFO - 2017-08-19 20:32:16 --> Output Class Initialized
INFO - 2017-08-19 20:32:16 --> Security Class Initialized
DEBUG - 2017-08-19 20:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:32:16 --> Input Class Initialized
INFO - 2017-08-19 20:32:16 --> Language Class Initialized
INFO - 2017-08-19 20:32:16 --> Loader Class Initialized
INFO - 2017-08-19 20:32:16 --> Helper loaded: url_helper
INFO - 2017-08-19 20:32:16 --> Helper loaded: file_helper
INFO - 2017-08-19 20:32:16 --> Database Driver Class Initialized
INFO - 2017-08-19 20:32:16 --> Email Class Initialized
DEBUG - 2017-08-19 20:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:32:16 --> Table Class Initialized
INFO - 2017-08-19 20:32:16 --> Controller Class Initialized
INFO - 2017-08-19 20:32:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:32:16 --> Final output sent to browser
DEBUG - 2017-08-19 20:32:16 --> Total execution time: 0.2484
INFO - 2017-08-19 20:32:30 --> Config Class Initialized
INFO - 2017-08-19 20:32:30 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:32:30 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:32:30 --> Utf8 Class Initialized
INFO - 2017-08-19 20:32:30 --> URI Class Initialized
DEBUG - 2017-08-19 20:32:30 --> No URI present. Default controller set.
INFO - 2017-08-19 20:32:30 --> Router Class Initialized
INFO - 2017-08-19 20:32:30 --> Output Class Initialized
INFO - 2017-08-19 20:32:30 --> Security Class Initialized
DEBUG - 2017-08-19 20:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:32:30 --> Input Class Initialized
INFO - 2017-08-19 20:32:30 --> Language Class Initialized
INFO - 2017-08-19 20:32:30 --> Loader Class Initialized
INFO - 2017-08-19 20:32:30 --> Helper loaded: url_helper
INFO - 2017-08-19 20:32:30 --> Helper loaded: file_helper
INFO - 2017-08-19 20:32:30 --> Database Driver Class Initialized
INFO - 2017-08-19 20:32:30 --> Email Class Initialized
DEBUG - 2017-08-19 20:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:32:30 --> Table Class Initialized
INFO - 2017-08-19 20:32:30 --> Controller Class Initialized
INFO - 2017-08-19 20:32:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:32:30 --> Final output sent to browser
DEBUG - 2017-08-19 20:32:30 --> Total execution time: 0.2460
INFO - 2017-08-19 20:32:40 --> Config Class Initialized
INFO - 2017-08-19 20:32:40 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:32:40 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:32:40 --> Utf8 Class Initialized
INFO - 2017-08-19 20:32:40 --> URI Class Initialized
INFO - 2017-08-19 20:32:40 --> Router Class Initialized
INFO - 2017-08-19 20:32:40 --> Output Class Initialized
INFO - 2017-08-19 20:32:40 --> Security Class Initialized
DEBUG - 2017-08-19 20:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:32:40 --> Input Class Initialized
INFO - 2017-08-19 20:32:40 --> Language Class Initialized
ERROR - 2017-08-19 20:32:40 --> 404 Page Not Found: Article/index
INFO - 2017-08-19 20:32:43 --> Config Class Initialized
INFO - 2017-08-19 20:32:43 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:32:43 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:32:44 --> Utf8 Class Initialized
INFO - 2017-08-19 20:32:44 --> URI Class Initialized
DEBUG - 2017-08-19 20:32:44 --> No URI present. Default controller set.
INFO - 2017-08-19 20:32:44 --> Router Class Initialized
INFO - 2017-08-19 20:32:44 --> Output Class Initialized
INFO - 2017-08-19 20:32:44 --> Security Class Initialized
DEBUG - 2017-08-19 20:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:32:44 --> Input Class Initialized
INFO - 2017-08-19 20:32:44 --> Language Class Initialized
INFO - 2017-08-19 20:32:44 --> Loader Class Initialized
INFO - 2017-08-19 20:32:44 --> Helper loaded: url_helper
INFO - 2017-08-19 20:32:44 --> Helper loaded: file_helper
INFO - 2017-08-19 20:32:44 --> Database Driver Class Initialized
INFO - 2017-08-19 20:32:44 --> Email Class Initialized
DEBUG - 2017-08-19 20:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:32:44 --> Table Class Initialized
INFO - 2017-08-19 20:32:44 --> Controller Class Initialized
INFO - 2017-08-19 20:32:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:32:44 --> Final output sent to browser
DEBUG - 2017-08-19 20:32:44 --> Total execution time: 0.2541
INFO - 2017-08-19 20:32:55 --> Config Class Initialized
INFO - 2017-08-19 20:32:55 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:32:55 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:32:55 --> Utf8 Class Initialized
INFO - 2017-08-19 20:32:55 --> URI Class Initialized
DEBUG - 2017-08-19 20:32:55 --> No URI present. Default controller set.
INFO - 2017-08-19 20:32:55 --> Router Class Initialized
INFO - 2017-08-19 20:32:55 --> Output Class Initialized
INFO - 2017-08-19 20:32:55 --> Security Class Initialized
DEBUG - 2017-08-19 20:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:32:55 --> Input Class Initialized
INFO - 2017-08-19 20:32:55 --> Language Class Initialized
INFO - 2017-08-19 20:32:55 --> Loader Class Initialized
INFO - 2017-08-19 20:32:55 --> Helper loaded: url_helper
INFO - 2017-08-19 20:32:55 --> Helper loaded: file_helper
INFO - 2017-08-19 20:32:55 --> Database Driver Class Initialized
INFO - 2017-08-19 20:32:55 --> Email Class Initialized
DEBUG - 2017-08-19 20:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:32:55 --> Table Class Initialized
INFO - 2017-08-19 20:32:55 --> Controller Class Initialized
INFO - 2017-08-19 20:32:55 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:32:55 --> Final output sent to browser
DEBUG - 2017-08-19 20:32:55 --> Total execution time: 0.2402
INFO - 2017-08-19 20:33:51 --> Config Class Initialized
INFO - 2017-08-19 20:33:51 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:33:51 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:33:51 --> Utf8 Class Initialized
INFO - 2017-08-19 20:33:51 --> URI Class Initialized
DEBUG - 2017-08-19 20:33:51 --> No URI present. Default controller set.
INFO - 2017-08-19 20:33:51 --> Router Class Initialized
INFO - 2017-08-19 20:33:51 --> Output Class Initialized
INFO - 2017-08-19 20:33:51 --> Security Class Initialized
DEBUG - 2017-08-19 20:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:33:51 --> Input Class Initialized
INFO - 2017-08-19 20:33:51 --> Language Class Initialized
INFO - 2017-08-19 20:33:51 --> Loader Class Initialized
INFO - 2017-08-19 20:33:51 --> Helper loaded: url_helper
INFO - 2017-08-19 20:33:51 --> Helper loaded: file_helper
INFO - 2017-08-19 20:33:52 --> Database Driver Class Initialized
INFO - 2017-08-19 20:33:52 --> Email Class Initialized
DEBUG - 2017-08-19 20:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:33:52 --> Table Class Initialized
INFO - 2017-08-19 20:33:52 --> Controller Class Initialized
INFO - 2017-08-19 20:33:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:33:52 --> Final output sent to browser
DEBUG - 2017-08-19 20:33:52 --> Total execution time: 0.2436
INFO - 2017-08-19 20:34:10 --> Config Class Initialized
INFO - 2017-08-19 20:34:10 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:10 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:10 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:10 --> URI Class Initialized
DEBUG - 2017-08-19 20:34:10 --> No URI present. Default controller set.
INFO - 2017-08-19 20:34:10 --> Router Class Initialized
INFO - 2017-08-19 20:34:10 --> Output Class Initialized
INFO - 2017-08-19 20:34:10 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:10 --> Input Class Initialized
INFO - 2017-08-19 20:34:10 --> Language Class Initialized
INFO - 2017-08-19 20:34:10 --> Loader Class Initialized
INFO - 2017-08-19 20:34:10 --> Helper loaded: url_helper
INFO - 2017-08-19 20:34:10 --> Helper loaded: file_helper
INFO - 2017-08-19 20:34:10 --> Database Driver Class Initialized
INFO - 2017-08-19 20:34:10 --> Email Class Initialized
DEBUG - 2017-08-19 20:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:34:10 --> Table Class Initialized
INFO - 2017-08-19 20:34:10 --> Controller Class Initialized
INFO - 2017-08-19 20:34:10 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:34:10 --> Final output sent to browser
DEBUG - 2017-08-19 20:34:10 --> Total execution time: 0.2446
INFO - 2017-08-19 20:34:14 --> Config Class Initialized
INFO - 2017-08-19 20:34:14 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:14 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:14 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:14 --> URI Class Initialized
INFO - 2017-08-19 20:34:14 --> Router Class Initialized
INFO - 2017-08-19 20:34:14 --> Output Class Initialized
INFO - 2017-08-19 20:34:14 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:14 --> Input Class Initialized
INFO - 2017-08-19 20:34:14 --> Language Class Initialized
INFO - 2017-08-19 20:34:14 --> Loader Class Initialized
INFO - 2017-08-19 20:34:14 --> Helper loaded: url_helper
INFO - 2017-08-19 20:34:14 --> Helper loaded: file_helper
INFO - 2017-08-19 20:34:14 --> Database Driver Class Initialized
INFO - 2017-08-19 20:34:14 --> Email Class Initialized
DEBUG - 2017-08-19 20:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:34:15 --> Table Class Initialized
INFO - 2017-08-19 20:34:15 --> Controller Class Initialized
INFO - 2017-08-19 20:34:15 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-19 20:34:15 --> Final output sent to browser
DEBUG - 2017-08-19 20:34:15 --> Total execution time: 0.2350
INFO - 2017-08-19 20:34:15 --> Config Class Initialized
INFO - 2017-08-19 20:34:15 --> Config Class Initialized
INFO - 2017-08-19 20:34:15 --> Config Class Initialized
INFO - 2017-08-19 20:34:15 --> Hooks Class Initialized
INFO - 2017-08-19 20:34:15 --> Config Class Initialized
INFO - 2017-08-19 20:34:15 --> Config Class Initialized
INFO - 2017-08-19 20:34:15 --> Hooks Class Initialized
INFO - 2017-08-19 20:34:15 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:15 --> UTF-8 Support Enabled
DEBUG - 2017-08-19 20:34:15 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:15 --> Hooks Class Initialized
INFO - 2017-08-19 20:34:15 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:15 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:15 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:15 --> Utf8 Class Initialized
DEBUG - 2017-08-19 20:34:15 --> UTF-8 Support Enabled
DEBUG - 2017-08-19 20:34:15 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:15 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:15 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:15 --> URI Class Initialized
INFO - 2017-08-19 20:34:15 --> URI Class Initialized
INFO - 2017-08-19 20:34:15 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:15 --> URI Class Initialized
INFO - 2017-08-19 20:34:15 --> URI Class Initialized
INFO - 2017-08-19 20:34:15 --> URI Class Initialized
INFO - 2017-08-19 20:34:15 --> Router Class Initialized
INFO - 2017-08-19 20:34:15 --> Router Class Initialized
INFO - 2017-08-19 20:34:15 --> Router Class Initialized
INFO - 2017-08-19 20:34:15 --> Router Class Initialized
INFO - 2017-08-19 20:34:15 --> Output Class Initialized
INFO - 2017-08-19 20:34:15 --> Router Class Initialized
INFO - 2017-08-19 20:34:15 --> Output Class Initialized
INFO - 2017-08-19 20:34:15 --> Output Class Initialized
INFO - 2017-08-19 20:34:15 --> Output Class Initialized
INFO - 2017-08-19 20:34:15 --> Output Class Initialized
INFO - 2017-08-19 20:34:15 --> Security Class Initialized
INFO - 2017-08-19 20:34:15 --> Security Class Initialized
INFO - 2017-08-19 20:34:15 --> Security Class Initialized
INFO - 2017-08-19 20:34:15 --> Security Class Initialized
INFO - 2017-08-19 20:34:15 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-19 20:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:15 --> Input Class Initialized
INFO - 2017-08-19 20:34:15 --> Input Class Initialized
DEBUG - 2017-08-19 20:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-19 20:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:15 --> Input Class Initialized
INFO - 2017-08-19 20:34:15 --> Input Class Initialized
DEBUG - 2017-08-19 20:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:15 --> Language Class Initialized
INFO - 2017-08-19 20:34:15 --> Language Class Initialized
INFO - 2017-08-19 20:34:15 --> Input Class Initialized
INFO - 2017-08-19 20:34:15 --> Language Class Initialized
INFO - 2017-08-19 20:34:15 --> Language Class Initialized
INFO - 2017-08-19 20:34:15 --> Language Class Initialized
ERROR - 2017-08-19 20:34:15 --> 404 Page Not Found: Home/vendor
ERROR - 2017-08-19 20:34:15 --> 404 Page Not Found: Home/vendor
ERROR - 2017-08-19 20:34:15 --> 404 Page Not Found: Home/css
ERROR - 2017-08-19 20:34:15 --> 404 Page Not Found: Home/vendor
ERROR - 2017-08-19 20:34:15 --> 404 Page Not Found: Home/vendor
INFO - 2017-08-19 20:34:15 --> Config Class Initialized
INFO - 2017-08-19 20:34:15 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:15 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:15 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:15 --> URI Class Initialized
INFO - 2017-08-19 20:34:15 --> Router Class Initialized
INFO - 2017-08-19 20:34:15 --> Output Class Initialized
INFO - 2017-08-19 20:34:15 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:15 --> Input Class Initialized
INFO - 2017-08-19 20:34:15 --> Language Class Initialized
ERROR - 2017-08-19 20:34:15 --> 404 Page Not Found: Home/vendor
INFO - 2017-08-19 20:34:15 --> Config Class Initialized
INFO - 2017-08-19 20:34:15 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:15 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:15 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:15 --> URI Class Initialized
INFO - 2017-08-19 20:34:15 --> Router Class Initialized
INFO - 2017-08-19 20:34:15 --> Output Class Initialized
INFO - 2017-08-19 20:34:15 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:15 --> Input Class Initialized
INFO - 2017-08-19 20:34:15 --> Language Class Initialized
ERROR - 2017-08-19 20:34:15 --> 404 Page Not Found: Home/vendor
INFO - 2017-08-19 20:34:18 --> Config Class Initialized
INFO - 2017-08-19 20:34:18 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:18 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:18 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:18 --> URI Class Initialized
DEBUG - 2017-08-19 20:34:18 --> No URI present. Default controller set.
INFO - 2017-08-19 20:34:18 --> Router Class Initialized
INFO - 2017-08-19 20:34:18 --> Output Class Initialized
INFO - 2017-08-19 20:34:18 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:18 --> Input Class Initialized
INFO - 2017-08-19 20:34:18 --> Language Class Initialized
INFO - 2017-08-19 20:34:18 --> Loader Class Initialized
INFO - 2017-08-19 20:34:18 --> Helper loaded: url_helper
INFO - 2017-08-19 20:34:18 --> Helper loaded: file_helper
INFO - 2017-08-19 20:34:18 --> Database Driver Class Initialized
INFO - 2017-08-19 20:34:18 --> Email Class Initialized
DEBUG - 2017-08-19 20:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:34:18 --> Table Class Initialized
INFO - 2017-08-19 20:34:18 --> Controller Class Initialized
INFO - 2017-08-19 20:34:18 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:34:18 --> Final output sent to browser
DEBUG - 2017-08-19 20:34:18 --> Total execution time: 0.2577
INFO - 2017-08-19 20:34:36 --> Config Class Initialized
INFO - 2017-08-19 20:34:36 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:36 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:36 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:36 --> URI Class Initialized
DEBUG - 2017-08-19 20:34:36 --> No URI present. Default controller set.
INFO - 2017-08-19 20:34:36 --> Router Class Initialized
INFO - 2017-08-19 20:34:36 --> Output Class Initialized
INFO - 2017-08-19 20:34:36 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:36 --> Input Class Initialized
INFO - 2017-08-19 20:34:36 --> Language Class Initialized
INFO - 2017-08-19 20:34:36 --> Loader Class Initialized
INFO - 2017-08-19 20:34:36 --> Helper loaded: url_helper
INFO - 2017-08-19 20:34:36 --> Helper loaded: file_helper
INFO - 2017-08-19 20:34:36 --> Database Driver Class Initialized
INFO - 2017-08-19 20:34:36 --> Email Class Initialized
DEBUG - 2017-08-19 20:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:34:36 --> Table Class Initialized
INFO - 2017-08-19 20:34:36 --> Controller Class Initialized
INFO - 2017-08-19 20:34:36 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:34:36 --> Final output sent to browser
DEBUG - 2017-08-19 20:34:36 --> Total execution time: 0.2428
INFO - 2017-08-19 20:34:38 --> Config Class Initialized
INFO - 2017-08-19 20:34:38 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:38 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:38 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:38 --> URI Class Initialized
INFO - 2017-08-19 20:34:38 --> Router Class Initialized
INFO - 2017-08-19 20:34:38 --> Output Class Initialized
INFO - 2017-08-19 20:34:38 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:38 --> Input Class Initialized
INFO - 2017-08-19 20:34:38 --> Language Class Initialized
INFO - 2017-08-19 20:34:38 --> Loader Class Initialized
INFO - 2017-08-19 20:34:38 --> Helper loaded: url_helper
INFO - 2017-08-19 20:34:38 --> Helper loaded: file_helper
INFO - 2017-08-19 20:34:38 --> Database Driver Class Initialized
INFO - 2017-08-19 20:34:38 --> Email Class Initialized
DEBUG - 2017-08-19 20:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:34:38 --> Table Class Initialized
INFO - 2017-08-19 20:34:38 --> Controller Class Initialized
INFO - 2017-08-19 20:34:38 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-19 20:34:38 --> Final output sent to browser
DEBUG - 2017-08-19 20:34:39 --> Total execution time: 0.2338
INFO - 2017-08-19 20:34:39 --> Config Class Initialized
INFO - 2017-08-19 20:34:39 --> Config Class Initialized
INFO - 2017-08-19 20:34:39 --> Config Class Initialized
INFO - 2017-08-19 20:34:39 --> Config Class Initialized
INFO - 2017-08-19 20:34:39 --> Config Class Initialized
INFO - 2017-08-19 20:34:39 --> Hooks Class Initialized
INFO - 2017-08-19 20:34:39 --> Hooks Class Initialized
INFO - 2017-08-19 20:34:39 --> Hooks Class Initialized
INFO - 2017-08-19 20:34:39 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:39 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:39 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:39 --> UTF-8 Support Enabled
DEBUG - 2017-08-19 20:34:39 --> UTF-8 Support Enabled
DEBUG - 2017-08-19 20:34:39 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:39 --> Utf8 Class Initialized
DEBUG - 2017-08-19 20:34:39 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:39 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:39 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:39 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:39 --> URI Class Initialized
INFO - 2017-08-19 20:34:39 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:39 --> URI Class Initialized
INFO - 2017-08-19 20:34:39 --> URI Class Initialized
INFO - 2017-08-19 20:34:39 --> URI Class Initialized
INFO - 2017-08-19 20:34:39 --> Router Class Initialized
INFO - 2017-08-19 20:34:39 --> Router Class Initialized
INFO - 2017-08-19 20:34:39 --> URI Class Initialized
INFO - 2017-08-19 20:34:39 --> Router Class Initialized
INFO - 2017-08-19 20:34:39 --> Router Class Initialized
INFO - 2017-08-19 20:34:39 --> Output Class Initialized
INFO - 2017-08-19 20:34:39 --> Output Class Initialized
INFO - 2017-08-19 20:34:39 --> Router Class Initialized
INFO - 2017-08-19 20:34:39 --> Output Class Initialized
INFO - 2017-08-19 20:34:39 --> Output Class Initialized
INFO - 2017-08-19 20:34:39 --> Security Class Initialized
INFO - 2017-08-19 20:34:39 --> Security Class Initialized
INFO - 2017-08-19 20:34:39 --> Security Class Initialized
INFO - 2017-08-19 20:34:39 --> Output Class Initialized
INFO - 2017-08-19 20:34:39 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:39 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-19 20:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-19 20:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:39 --> Input Class Initialized
INFO - 2017-08-19 20:34:39 --> Input Class Initialized
INFO - 2017-08-19 20:34:39 --> Input Class Initialized
DEBUG - 2017-08-19 20:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:39 --> Input Class Initialized
INFO - 2017-08-19 20:34:39 --> Language Class Initialized
INFO - 2017-08-19 20:34:39 --> Language Class Initialized
INFO - 2017-08-19 20:34:39 --> Language Class Initialized
INFO - 2017-08-19 20:34:39 --> Input Class Initialized
INFO - 2017-08-19 20:34:39 --> Language Class Initialized
ERROR - 2017-08-19 20:34:39 --> 404 Page Not Found: Home/css
INFO - 2017-08-19 20:34:39 --> Language Class Initialized
ERROR - 2017-08-19 20:34:39 --> 404 Page Not Found: Home/vendor
ERROR - 2017-08-19 20:34:39 --> 404 Page Not Found: Home/vendor
ERROR - 2017-08-19 20:34:39 --> 404 Page Not Found: Home/vendor
ERROR - 2017-08-19 20:34:39 --> 404 Page Not Found: Home/vendor
INFO - 2017-08-19 20:34:39 --> Config Class Initialized
INFO - 2017-08-19 20:34:39 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:39 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:39 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:39 --> URI Class Initialized
INFO - 2017-08-19 20:34:39 --> Router Class Initialized
INFO - 2017-08-19 20:34:39 --> Output Class Initialized
INFO - 2017-08-19 20:34:39 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:39 --> Input Class Initialized
INFO - 2017-08-19 20:34:39 --> Language Class Initialized
ERROR - 2017-08-19 20:34:39 --> 404 Page Not Found: Home/vendor
INFO - 2017-08-19 20:34:39 --> Config Class Initialized
INFO - 2017-08-19 20:34:39 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:39 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:39 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:39 --> URI Class Initialized
INFO - 2017-08-19 20:34:39 --> Router Class Initialized
INFO - 2017-08-19 20:34:39 --> Output Class Initialized
INFO - 2017-08-19 20:34:39 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:39 --> Input Class Initialized
INFO - 2017-08-19 20:34:39 --> Language Class Initialized
ERROR - 2017-08-19 20:34:39 --> 404 Page Not Found: Home/vendor
INFO - 2017-08-19 20:34:40 --> Config Class Initialized
INFO - 2017-08-19 20:34:40 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:34:40 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:34:41 --> Utf8 Class Initialized
INFO - 2017-08-19 20:34:41 --> URI Class Initialized
DEBUG - 2017-08-19 20:34:41 --> No URI present. Default controller set.
INFO - 2017-08-19 20:34:41 --> Router Class Initialized
INFO - 2017-08-19 20:34:41 --> Output Class Initialized
INFO - 2017-08-19 20:34:41 --> Security Class Initialized
DEBUG - 2017-08-19 20:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:34:41 --> Input Class Initialized
INFO - 2017-08-19 20:34:41 --> Language Class Initialized
INFO - 2017-08-19 20:34:41 --> Loader Class Initialized
INFO - 2017-08-19 20:34:41 --> Helper loaded: url_helper
INFO - 2017-08-19 20:34:41 --> Helper loaded: file_helper
INFO - 2017-08-19 20:34:41 --> Database Driver Class Initialized
INFO - 2017-08-19 20:34:41 --> Email Class Initialized
DEBUG - 2017-08-19 20:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:34:41 --> Table Class Initialized
INFO - 2017-08-19 20:34:41 --> Controller Class Initialized
INFO - 2017-08-19 20:34:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:34:41 --> Final output sent to browser
DEBUG - 2017-08-19 20:34:41 --> Total execution time: 0.2563
INFO - 2017-08-19 20:35:34 --> Config Class Initialized
INFO - 2017-08-19 20:35:34 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:35:34 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:35:34 --> Utf8 Class Initialized
INFO - 2017-08-19 20:35:34 --> URI Class Initialized
DEBUG - 2017-08-19 20:35:34 --> No URI present. Default controller set.
INFO - 2017-08-19 20:35:34 --> Router Class Initialized
INFO - 2017-08-19 20:35:34 --> Output Class Initialized
INFO - 2017-08-19 20:35:34 --> Security Class Initialized
DEBUG - 2017-08-19 20:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:35:34 --> Input Class Initialized
INFO - 2017-08-19 20:35:34 --> Language Class Initialized
INFO - 2017-08-19 20:35:35 --> Loader Class Initialized
INFO - 2017-08-19 20:35:35 --> Helper loaded: url_helper
INFO - 2017-08-19 20:35:35 --> Helper loaded: file_helper
INFO - 2017-08-19 20:35:35 --> Database Driver Class Initialized
INFO - 2017-08-19 20:35:35 --> Email Class Initialized
DEBUG - 2017-08-19 20:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:35:35 --> Table Class Initialized
INFO - 2017-08-19 20:35:35 --> Controller Class Initialized
INFO - 2017-08-19 20:35:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:35:35 --> Final output sent to browser
DEBUG - 2017-08-19 20:35:35 --> Total execution time: 0.2460
INFO - 2017-08-19 20:35:37 --> Config Class Initialized
INFO - 2017-08-19 20:35:37 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:35:37 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:35:37 --> Utf8 Class Initialized
INFO - 2017-08-19 20:35:37 --> URI Class Initialized
INFO - 2017-08-19 20:35:37 --> Router Class Initialized
INFO - 2017-08-19 20:35:37 --> Output Class Initialized
INFO - 2017-08-19 20:35:37 --> Security Class Initialized
DEBUG - 2017-08-19 20:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:35:37 --> Input Class Initialized
INFO - 2017-08-19 20:35:37 --> Language Class Initialized
INFO - 2017-08-19 20:35:37 --> Loader Class Initialized
INFO - 2017-08-19 20:35:37 --> Helper loaded: url_helper
INFO - 2017-08-19 20:35:37 --> Helper loaded: file_helper
INFO - 2017-08-19 20:35:37 --> Database Driver Class Initialized
INFO - 2017-08-19 20:35:37 --> Email Class Initialized
DEBUG - 2017-08-19 20:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:35:37 --> Table Class Initialized
INFO - 2017-08-19 20:35:37 --> Controller Class Initialized
INFO - 2017-08-19 20:35:37 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-19 20:35:37 --> Final output sent to browser
DEBUG - 2017-08-19 20:35:37 --> Total execution time: 0.2384
INFO - 2017-08-19 20:35:37 --> Config Class Initialized
INFO - 2017-08-19 20:35:37 --> Config Class Initialized
INFO - 2017-08-19 20:35:37 --> Config Class Initialized
INFO - 2017-08-19 20:35:37 --> Config Class Initialized
INFO - 2017-08-19 20:35:37 --> Config Class Initialized
INFO - 2017-08-19 20:35:37 --> Hooks Class Initialized
INFO - 2017-08-19 20:35:37 --> Hooks Class Initialized
INFO - 2017-08-19 20:35:37 --> Hooks Class Initialized
INFO - 2017-08-19 20:35:37 --> Hooks Class Initialized
INFO - 2017-08-19 20:35:37 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:35:37 --> UTF-8 Support Enabled
DEBUG - 2017-08-19 20:35:37 --> UTF-8 Support Enabled
DEBUG - 2017-08-19 20:35:37 --> UTF-8 Support Enabled
DEBUG - 2017-08-19 20:35:37 --> UTF-8 Support Enabled
DEBUG - 2017-08-19 20:35:37 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:35:37 --> Utf8 Class Initialized
INFO - 2017-08-19 20:35:37 --> Utf8 Class Initialized
INFO - 2017-08-19 20:35:37 --> Utf8 Class Initialized
INFO - 2017-08-19 20:35:37 --> Utf8 Class Initialized
INFO - 2017-08-19 20:35:37 --> Utf8 Class Initialized
INFO - 2017-08-19 20:35:37 --> URI Class Initialized
INFO - 2017-08-19 20:35:37 --> URI Class Initialized
INFO - 2017-08-19 20:35:37 --> URI Class Initialized
INFO - 2017-08-19 20:35:37 --> URI Class Initialized
INFO - 2017-08-19 20:35:37 --> URI Class Initialized
INFO - 2017-08-19 20:35:37 --> Router Class Initialized
INFO - 2017-08-19 20:35:37 --> Router Class Initialized
INFO - 2017-08-19 20:35:37 --> Router Class Initialized
INFO - 2017-08-19 20:35:37 --> Router Class Initialized
INFO - 2017-08-19 20:35:37 --> Router Class Initialized
INFO - 2017-08-19 20:35:37 --> Output Class Initialized
INFO - 2017-08-19 20:35:38 --> Output Class Initialized
INFO - 2017-08-19 20:35:38 --> Output Class Initialized
INFO - 2017-08-19 20:35:38 --> Output Class Initialized
INFO - 2017-08-19 20:35:38 --> Output Class Initialized
INFO - 2017-08-19 20:35:38 --> Security Class Initialized
INFO - 2017-08-19 20:35:38 --> Security Class Initialized
INFO - 2017-08-19 20:35:38 --> Security Class Initialized
INFO - 2017-08-19 20:35:38 --> Security Class Initialized
INFO - 2017-08-19 20:35:38 --> Security Class Initialized
DEBUG - 2017-08-19 20:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-19 20:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-19 20:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-19 20:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-19 20:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:35:38 --> Input Class Initialized
INFO - 2017-08-19 20:35:38 --> Input Class Initialized
INFO - 2017-08-19 20:35:38 --> Input Class Initialized
INFO - 2017-08-19 20:35:38 --> Input Class Initialized
INFO - 2017-08-19 20:35:38 --> Input Class Initialized
INFO - 2017-08-19 20:35:38 --> Language Class Initialized
INFO - 2017-08-19 20:35:38 --> Language Class Initialized
INFO - 2017-08-19 20:35:38 --> Language Class Initialized
INFO - 2017-08-19 20:35:38 --> Language Class Initialized
INFO - 2017-08-19 20:35:38 --> Language Class Initialized
ERROR - 2017-08-19 20:35:38 --> 404 Page Not Found: Home/ext
ERROR - 2017-08-19 20:35:38 --> 404 Page Not Found: Home/ext
ERROR - 2017-08-19 20:35:38 --> 404 Page Not Found: Home/ext
ERROR - 2017-08-19 20:35:38 --> 404 Page Not Found: Home/ext
ERROR - 2017-08-19 20:35:38 --> 404 Page Not Found: Home/ext
INFO - 2017-08-19 20:35:38 --> Config Class Initialized
INFO - 2017-08-19 20:35:38 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:35:38 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:35:38 --> Utf8 Class Initialized
INFO - 2017-08-19 20:35:38 --> URI Class Initialized
INFO - 2017-08-19 20:35:38 --> Router Class Initialized
INFO - 2017-08-19 20:35:38 --> Output Class Initialized
INFO - 2017-08-19 20:35:38 --> Security Class Initialized
DEBUG - 2017-08-19 20:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:35:38 --> Input Class Initialized
INFO - 2017-08-19 20:35:38 --> Language Class Initialized
ERROR - 2017-08-19 20:35:38 --> 404 Page Not Found: Home/ext
INFO - 2017-08-19 20:35:38 --> Config Class Initialized
INFO - 2017-08-19 20:35:38 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:35:38 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:35:38 --> Utf8 Class Initialized
INFO - 2017-08-19 20:35:38 --> URI Class Initialized
INFO - 2017-08-19 20:35:38 --> Router Class Initialized
INFO - 2017-08-19 20:35:38 --> Output Class Initialized
INFO - 2017-08-19 20:35:38 --> Security Class Initialized
DEBUG - 2017-08-19 20:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:35:38 --> Input Class Initialized
INFO - 2017-08-19 20:35:38 --> Language Class Initialized
ERROR - 2017-08-19 20:35:38 --> 404 Page Not Found: Home/ext
INFO - 2017-08-19 20:37:44 --> Config Class Initialized
INFO - 2017-08-19 20:37:44 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:37:44 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:37:44 --> Utf8 Class Initialized
INFO - 2017-08-19 20:37:44 --> URI Class Initialized
INFO - 2017-08-19 20:37:44 --> Router Class Initialized
INFO - 2017-08-19 20:37:44 --> Output Class Initialized
INFO - 2017-08-19 20:37:44 --> Security Class Initialized
DEBUG - 2017-08-19 20:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:37:44 --> Input Class Initialized
INFO - 2017-08-19 20:37:44 --> Language Class Initialized
INFO - 2017-08-19 20:37:44 --> Loader Class Initialized
INFO - 2017-08-19 20:37:44 --> Helper loaded: url_helper
INFO - 2017-08-19 20:37:44 --> Helper loaded: file_helper
INFO - 2017-08-19 20:37:44 --> Database Driver Class Initialized
INFO - 2017-08-19 20:37:44 --> Email Class Initialized
DEBUG - 2017-08-19 20:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:37:45 --> Table Class Initialized
INFO - 2017-08-19 20:37:45 --> Controller Class Initialized
INFO - 2017-08-19 20:37:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-19 20:37:45 --> Final output sent to browser
DEBUG - 2017-08-19 20:37:45 --> Total execution time: 0.2403
INFO - 2017-08-19 20:38:25 --> Config Class Initialized
INFO - 2017-08-19 20:38:25 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:38:25 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:38:25 --> Utf8 Class Initialized
INFO - 2017-08-19 20:38:25 --> URI Class Initialized
INFO - 2017-08-19 20:38:25 --> Router Class Initialized
INFO - 2017-08-19 20:38:25 --> Output Class Initialized
INFO - 2017-08-19 20:38:25 --> Security Class Initialized
DEBUG - 2017-08-19 20:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:38:25 --> Input Class Initialized
INFO - 2017-08-19 20:38:25 --> Language Class Initialized
INFO - 2017-08-19 20:38:25 --> Loader Class Initialized
INFO - 2017-08-19 20:38:25 --> Helper loaded: url_helper
INFO - 2017-08-19 20:38:25 --> Helper loaded: file_helper
INFO - 2017-08-19 20:38:25 --> Database Driver Class Initialized
INFO - 2017-08-19 20:38:25 --> Email Class Initialized
DEBUG - 2017-08-19 20:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:38:25 --> Table Class Initialized
INFO - 2017-08-19 20:38:25 --> Controller Class Initialized
INFO - 2017-08-19 20:38:25 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-19 20:38:25 --> Final output sent to browser
DEBUG - 2017-08-19 20:38:25 --> Total execution time: 0.2481
INFO - 2017-08-19 20:39:40 --> Config Class Initialized
INFO - 2017-08-19 20:39:40 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:39:40 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:39:40 --> Utf8 Class Initialized
INFO - 2017-08-19 20:39:40 --> URI Class Initialized
INFO - 2017-08-19 20:39:40 --> Router Class Initialized
INFO - 2017-08-19 20:39:40 --> Output Class Initialized
INFO - 2017-08-19 20:39:40 --> Security Class Initialized
DEBUG - 2017-08-19 20:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:39:40 --> Input Class Initialized
INFO - 2017-08-19 20:39:40 --> Language Class Initialized
INFO - 2017-08-19 20:39:40 --> Loader Class Initialized
INFO - 2017-08-19 20:39:40 --> Helper loaded: url_helper
INFO - 2017-08-19 20:39:40 --> Helper loaded: file_helper
INFO - 2017-08-19 20:39:40 --> Database Driver Class Initialized
INFO - 2017-08-19 20:39:40 --> Email Class Initialized
DEBUG - 2017-08-19 20:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:39:40 --> Table Class Initialized
INFO - 2017-08-19 20:39:40 --> Controller Class Initialized
INFO - 2017-08-19 20:39:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-19 20:39:40 --> Final output sent to browser
DEBUG - 2017-08-19 20:39:40 --> Total execution time: 0.2498
INFO - 2017-08-19 20:40:23 --> Config Class Initialized
INFO - 2017-08-19 20:40:23 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:40:23 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:40:23 --> Utf8 Class Initialized
INFO - 2017-08-19 20:40:23 --> URI Class Initialized
INFO - 2017-08-19 20:40:23 --> Router Class Initialized
INFO - 2017-08-19 20:40:23 --> Output Class Initialized
INFO - 2017-08-19 20:40:23 --> Security Class Initialized
DEBUG - 2017-08-19 20:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:40:23 --> Input Class Initialized
INFO - 2017-08-19 20:40:23 --> Language Class Initialized
INFO - 2017-08-19 20:40:23 --> Loader Class Initialized
INFO - 2017-08-19 20:40:23 --> Helper loaded: url_helper
INFO - 2017-08-19 20:40:23 --> Helper loaded: file_helper
INFO - 2017-08-19 20:40:23 --> Database Driver Class Initialized
INFO - 2017-08-19 20:40:23 --> Email Class Initialized
DEBUG - 2017-08-19 20:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:40:23 --> Table Class Initialized
INFO - 2017-08-19 20:40:23 --> Controller Class Initialized
INFO - 2017-08-19 20:40:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-19 20:40:23 --> Final output sent to browser
DEBUG - 2017-08-19 20:40:23 --> Total execution time: 0.2495
INFO - 2017-08-19 20:43:30 --> Config Class Initialized
INFO - 2017-08-19 20:43:30 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:43:30 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:43:30 --> Utf8 Class Initialized
INFO - 2017-08-19 20:43:30 --> URI Class Initialized
INFO - 2017-08-19 20:43:30 --> Router Class Initialized
INFO - 2017-08-19 20:43:30 --> Output Class Initialized
INFO - 2017-08-19 20:43:30 --> Security Class Initialized
DEBUG - 2017-08-19 20:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:43:30 --> Input Class Initialized
INFO - 2017-08-19 20:43:30 --> Language Class Initialized
INFO - 2017-08-19 20:43:30 --> Loader Class Initialized
INFO - 2017-08-19 20:43:30 --> Helper loaded: url_helper
INFO - 2017-08-19 20:43:30 --> Helper loaded: file_helper
INFO - 2017-08-19 20:43:30 --> Database Driver Class Initialized
INFO - 2017-08-19 20:43:30 --> Email Class Initialized
DEBUG - 2017-08-19 20:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:43:30 --> Table Class Initialized
INFO - 2017-08-19 20:43:30 --> Controller Class Initialized
INFO - 2017-08-19 20:43:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-19 20:43:30 --> Final output sent to browser
DEBUG - 2017-08-19 20:43:30 --> Total execution time: 0.2413
INFO - 2017-08-19 20:43:35 --> Config Class Initialized
INFO - 2017-08-19 20:43:35 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:43:35 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:43:35 --> Utf8 Class Initialized
INFO - 2017-08-19 20:43:35 --> URI Class Initialized
DEBUG - 2017-08-19 20:43:35 --> No URI present. Default controller set.
INFO - 2017-08-19 20:43:35 --> Router Class Initialized
INFO - 2017-08-19 20:43:35 --> Output Class Initialized
INFO - 2017-08-19 20:43:35 --> Security Class Initialized
DEBUG - 2017-08-19 20:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:43:35 --> Input Class Initialized
INFO - 2017-08-19 20:43:35 --> Language Class Initialized
INFO - 2017-08-19 20:43:35 --> Loader Class Initialized
INFO - 2017-08-19 20:43:35 --> Helper loaded: url_helper
INFO - 2017-08-19 20:43:35 --> Helper loaded: file_helper
INFO - 2017-08-19 20:43:35 --> Database Driver Class Initialized
INFO - 2017-08-19 20:43:35 --> Email Class Initialized
DEBUG - 2017-08-19 20:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:43:35 --> Table Class Initialized
INFO - 2017-08-19 20:43:35 --> Controller Class Initialized
INFO - 2017-08-19 20:43:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:43:35 --> Final output sent to browser
DEBUG - 2017-08-19 20:43:35 --> Total execution time: 0.2602
INFO - 2017-08-19 20:43:37 --> Config Class Initialized
INFO - 2017-08-19 20:43:37 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:43:37 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:43:37 --> Utf8 Class Initialized
INFO - 2017-08-19 20:43:37 --> URI Class Initialized
DEBUG - 2017-08-19 20:43:37 --> No URI present. Default controller set.
INFO - 2017-08-19 20:43:37 --> Router Class Initialized
INFO - 2017-08-19 20:43:37 --> Output Class Initialized
INFO - 2017-08-19 20:43:37 --> Security Class Initialized
DEBUG - 2017-08-19 20:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:43:37 --> Input Class Initialized
INFO - 2017-08-19 20:43:37 --> Language Class Initialized
INFO - 2017-08-19 20:43:37 --> Loader Class Initialized
INFO - 2017-08-19 20:43:37 --> Helper loaded: url_helper
INFO - 2017-08-19 20:43:37 --> Helper loaded: file_helper
INFO - 2017-08-19 20:43:37 --> Database Driver Class Initialized
INFO - 2017-08-19 20:43:37 --> Email Class Initialized
DEBUG - 2017-08-19 20:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:43:37 --> Table Class Initialized
INFO - 2017-08-19 20:43:37 --> Controller Class Initialized
INFO - 2017-08-19 20:43:37 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:43:38 --> Final output sent to browser
DEBUG - 2017-08-19 20:43:38 --> Total execution time: 0.2483
INFO - 2017-08-19 20:43:45 --> Config Class Initialized
INFO - 2017-08-19 20:43:45 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:43:45 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:43:45 --> Utf8 Class Initialized
INFO - 2017-08-19 20:43:45 --> URI Class Initialized
INFO - 2017-08-19 20:43:45 --> Router Class Initialized
INFO - 2017-08-19 20:43:45 --> Output Class Initialized
INFO - 2017-08-19 20:43:45 --> Security Class Initialized
DEBUG - 2017-08-19 20:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:43:45 --> Input Class Initialized
INFO - 2017-08-19 20:43:45 --> Language Class Initialized
INFO - 2017-08-19 20:43:45 --> Loader Class Initialized
INFO - 2017-08-19 20:43:45 --> Helper loaded: url_helper
INFO - 2017-08-19 20:43:45 --> Helper loaded: file_helper
INFO - 2017-08-19 20:43:45 --> Database Driver Class Initialized
INFO - 2017-08-19 20:43:45 --> Email Class Initialized
DEBUG - 2017-08-19 20:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:43:45 --> Table Class Initialized
INFO - 2017-08-19 20:43:45 --> Controller Class Initialized
INFO - 2017-08-19 20:43:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-19 20:43:45 --> Final output sent to browser
DEBUG - 2017-08-19 20:43:45 --> Total execution time: 0.2508
INFO - 2017-08-19 20:43:52 --> Config Class Initialized
INFO - 2017-08-19 20:43:52 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:43:52 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:43:52 --> Utf8 Class Initialized
INFO - 2017-08-19 20:43:52 --> URI Class Initialized
DEBUG - 2017-08-19 20:43:52 --> No URI present. Default controller set.
INFO - 2017-08-19 20:43:52 --> Router Class Initialized
INFO - 2017-08-19 20:43:52 --> Output Class Initialized
INFO - 2017-08-19 20:43:52 --> Security Class Initialized
DEBUG - 2017-08-19 20:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:43:52 --> Input Class Initialized
INFO - 2017-08-19 20:43:52 --> Language Class Initialized
INFO - 2017-08-19 20:43:52 --> Loader Class Initialized
INFO - 2017-08-19 20:43:52 --> Helper loaded: url_helper
INFO - 2017-08-19 20:43:52 --> Helper loaded: file_helper
INFO - 2017-08-19 20:43:52 --> Database Driver Class Initialized
INFO - 2017-08-19 20:43:52 --> Email Class Initialized
DEBUG - 2017-08-19 20:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:43:52 --> Table Class Initialized
INFO - 2017-08-19 20:43:52 --> Controller Class Initialized
INFO - 2017-08-19 20:43:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:43:52 --> Final output sent to browser
DEBUG - 2017-08-19 20:43:52 --> Total execution time: 0.2629
INFO - 2017-08-19 20:44:54 --> Config Class Initialized
INFO - 2017-08-19 20:44:54 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:44:54 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:44:54 --> Utf8 Class Initialized
INFO - 2017-08-19 20:44:54 --> URI Class Initialized
DEBUG - 2017-08-19 20:44:54 --> No URI present. Default controller set.
INFO - 2017-08-19 20:44:54 --> Router Class Initialized
INFO - 2017-08-19 20:44:54 --> Output Class Initialized
INFO - 2017-08-19 20:44:54 --> Security Class Initialized
DEBUG - 2017-08-19 20:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:44:54 --> Input Class Initialized
INFO - 2017-08-19 20:44:54 --> Language Class Initialized
INFO - 2017-08-19 20:44:54 --> Loader Class Initialized
INFO - 2017-08-19 20:44:54 --> Helper loaded: url_helper
INFO - 2017-08-19 20:44:54 --> Helper loaded: file_helper
INFO - 2017-08-19 20:44:54 --> Database Driver Class Initialized
INFO - 2017-08-19 20:44:54 --> Email Class Initialized
DEBUG - 2017-08-19 20:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:44:54 --> Table Class Initialized
INFO - 2017-08-19 20:44:55 --> Controller Class Initialized
INFO - 2017-08-19 20:44:55 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:44:55 --> Final output sent to browser
DEBUG - 2017-08-19 20:44:55 --> Total execution time: 0.2615
INFO - 2017-08-19 20:45:03 --> Config Class Initialized
INFO - 2017-08-19 20:45:03 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:45:03 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:45:03 --> Utf8 Class Initialized
INFO - 2017-08-19 20:45:03 --> URI Class Initialized
DEBUG - 2017-08-19 20:45:03 --> No URI present. Default controller set.
INFO - 2017-08-19 20:45:03 --> Router Class Initialized
INFO - 2017-08-19 20:45:03 --> Output Class Initialized
INFO - 2017-08-19 20:45:03 --> Security Class Initialized
DEBUG - 2017-08-19 20:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:45:03 --> Input Class Initialized
INFO - 2017-08-19 20:45:03 --> Language Class Initialized
INFO - 2017-08-19 20:45:03 --> Loader Class Initialized
INFO - 2017-08-19 20:45:03 --> Helper loaded: url_helper
INFO - 2017-08-19 20:45:03 --> Helper loaded: file_helper
INFO - 2017-08-19 20:45:03 --> Database Driver Class Initialized
INFO - 2017-08-19 20:45:03 --> Email Class Initialized
DEBUG - 2017-08-19 20:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:45:04 --> Table Class Initialized
INFO - 2017-08-19 20:45:04 --> Controller Class Initialized
INFO - 2017-08-19 20:45:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:45:04 --> Final output sent to browser
DEBUG - 2017-08-19 20:45:04 --> Total execution time: 0.2443
INFO - 2017-08-19 20:55:52 --> Config Class Initialized
INFO - 2017-08-19 20:55:52 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:55:52 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:55:52 --> Utf8 Class Initialized
INFO - 2017-08-19 20:55:52 --> URI Class Initialized
DEBUG - 2017-08-19 20:55:52 --> No URI present. Default controller set.
INFO - 2017-08-19 20:55:52 --> Router Class Initialized
INFO - 2017-08-19 20:55:52 --> Output Class Initialized
INFO - 2017-08-19 20:55:52 --> Security Class Initialized
DEBUG - 2017-08-19 20:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:55:52 --> Input Class Initialized
INFO - 2017-08-19 20:55:52 --> Language Class Initialized
INFO - 2017-08-19 20:55:52 --> Loader Class Initialized
INFO - 2017-08-19 20:55:52 --> Helper loaded: url_helper
INFO - 2017-08-19 20:55:52 --> Helper loaded: file_helper
INFO - 2017-08-19 20:55:52 --> Database Driver Class Initialized
INFO - 2017-08-19 20:55:52 --> Email Class Initialized
DEBUG - 2017-08-19 20:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:55:52 --> Table Class Initialized
INFO - 2017-08-19 20:55:52 --> Controller Class Initialized
INFO - 2017-08-19 20:55:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:55:52 --> Final output sent to browser
DEBUG - 2017-08-19 20:55:52 --> Total execution time: 0.2433
INFO - 2017-08-19 20:55:59 --> Config Class Initialized
INFO - 2017-08-19 20:55:59 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:55:59 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:55:59 --> Utf8 Class Initialized
INFO - 2017-08-19 20:55:59 --> URI Class Initialized
INFO - 2017-08-19 20:55:59 --> Router Class Initialized
INFO - 2017-08-19 20:55:59 --> Output Class Initialized
INFO - 2017-08-19 20:55:59 --> Security Class Initialized
DEBUG - 2017-08-19 20:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:55:59 --> Input Class Initialized
INFO - 2017-08-19 20:55:59 --> Language Class Initialized
INFO - 2017-08-19 20:55:59 --> Loader Class Initialized
INFO - 2017-08-19 20:55:59 --> Helper loaded: url_helper
INFO - 2017-08-19 20:55:59 --> Helper loaded: file_helper
INFO - 2017-08-19 20:55:59 --> Database Driver Class Initialized
INFO - 2017-08-19 20:55:59 --> Email Class Initialized
DEBUG - 2017-08-19 20:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:55:59 --> Table Class Initialized
INFO - 2017-08-19 20:55:59 --> Controller Class Initialized
INFO - 2017-08-19 20:55:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-19 20:55:59 --> Final output sent to browser
DEBUG - 2017-08-19 20:55:59 --> Total execution time: 0.2619
INFO - 2017-08-19 20:56:10 --> Config Class Initialized
INFO - 2017-08-19 20:56:10 --> Hooks Class Initialized
DEBUG - 2017-08-19 20:56:10 --> UTF-8 Support Enabled
INFO - 2017-08-19 20:56:10 --> Utf8 Class Initialized
INFO - 2017-08-19 20:56:10 --> URI Class Initialized
DEBUG - 2017-08-19 20:56:11 --> No URI present. Default controller set.
INFO - 2017-08-19 20:56:11 --> Router Class Initialized
INFO - 2017-08-19 20:56:11 --> Output Class Initialized
INFO - 2017-08-19 20:56:11 --> Security Class Initialized
DEBUG - 2017-08-19 20:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 20:56:11 --> Input Class Initialized
INFO - 2017-08-19 20:56:11 --> Language Class Initialized
INFO - 2017-08-19 20:56:11 --> Loader Class Initialized
INFO - 2017-08-19 20:56:11 --> Helper loaded: url_helper
INFO - 2017-08-19 20:56:11 --> Helper loaded: file_helper
INFO - 2017-08-19 20:56:11 --> Database Driver Class Initialized
INFO - 2017-08-19 20:56:11 --> Email Class Initialized
DEBUG - 2017-08-19 20:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-19 20:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-19 20:56:11 --> Table Class Initialized
INFO - 2017-08-19 20:56:11 --> Controller Class Initialized
INFO - 2017-08-19 20:56:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-19 20:56:11 --> Final output sent to browser
DEBUG - 2017-08-19 20:56:11 --> Total execution time: 0.2568
