<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-22 04:48:26 --> Config Class Initialized
INFO - 2017-08-22 04:48:26 --> Hooks Class Initialized
DEBUG - 2017-08-22 04:48:26 --> UTF-8 Support Enabled
INFO - 2017-08-22 04:48:26 --> Utf8 Class Initialized
INFO - 2017-08-22 04:48:26 --> URI Class Initialized
DEBUG - 2017-08-22 04:48:26 --> No URI present. Default controller set.
INFO - 2017-08-22 04:48:26 --> Router Class Initialized
INFO - 2017-08-22 04:48:26 --> Output Class Initialized
INFO - 2017-08-22 04:48:26 --> Security Class Initialized
DEBUG - 2017-08-22 04:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 04:48:26 --> Input Class Initialized
INFO - 2017-08-22 04:48:26 --> Language Class Initialized
INFO - 2017-08-22 04:48:26 --> Loader Class Initialized
INFO - 2017-08-22 04:48:26 --> Helper loaded: url_helper
INFO - 2017-08-22 04:48:26 --> Helper loaded: file_helper
INFO - 2017-08-22 04:48:26 --> Database Driver Class Initialized
INFO - 2017-08-22 04:48:26 --> Email Class Initialized
DEBUG - 2017-08-22 04:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 04:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 04:48:27 --> Table Class Initialized
INFO - 2017-08-22 04:48:27 --> Controller Class Initialized
INFO - 2017-08-22 04:48:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 04:48:27 --> Final output sent to browser
DEBUG - 2017-08-22 04:48:27 --> Total execution time: 1.1252
INFO - 2017-08-22 04:51:32 --> Config Class Initialized
INFO - 2017-08-22 04:51:32 --> Hooks Class Initialized
DEBUG - 2017-08-22 04:51:32 --> UTF-8 Support Enabled
INFO - 2017-08-22 04:51:32 --> Utf8 Class Initialized
INFO - 2017-08-22 04:51:32 --> URI Class Initialized
DEBUG - 2017-08-22 04:51:32 --> No URI present. Default controller set.
INFO - 2017-08-22 04:51:32 --> Router Class Initialized
INFO - 2017-08-22 04:51:32 --> Output Class Initialized
INFO - 2017-08-22 04:51:32 --> Security Class Initialized
DEBUG - 2017-08-22 04:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 04:51:32 --> Input Class Initialized
INFO - 2017-08-22 04:51:32 --> Language Class Initialized
INFO - 2017-08-22 04:51:32 --> Loader Class Initialized
INFO - 2017-08-22 04:51:32 --> Helper loaded: url_helper
INFO - 2017-08-22 04:51:32 --> Helper loaded: file_helper
INFO - 2017-08-22 04:51:32 --> Database Driver Class Initialized
INFO - 2017-08-22 04:51:32 --> Email Class Initialized
DEBUG - 2017-08-22 04:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 04:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 04:51:32 --> Table Class Initialized
INFO - 2017-08-22 04:51:32 --> Controller Class Initialized
INFO - 2017-08-22 04:51:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 04:51:32 --> Final output sent to browser
DEBUG - 2017-08-22 04:51:32 --> Total execution time: 0.1647
INFO - 2017-08-22 05:07:07 --> Config Class Initialized
INFO - 2017-08-22 05:07:07 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:07:07 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:07:07 --> Utf8 Class Initialized
INFO - 2017-08-22 05:07:07 --> URI Class Initialized
DEBUG - 2017-08-22 05:07:07 --> No URI present. Default controller set.
INFO - 2017-08-22 05:07:07 --> Router Class Initialized
INFO - 2017-08-22 05:07:07 --> Output Class Initialized
INFO - 2017-08-22 05:07:07 --> Security Class Initialized
DEBUG - 2017-08-22 05:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:07:08 --> Input Class Initialized
INFO - 2017-08-22 05:07:08 --> Language Class Initialized
INFO - 2017-08-22 05:07:08 --> Loader Class Initialized
INFO - 2017-08-22 05:07:08 --> Helper loaded: url_helper
INFO - 2017-08-22 05:07:08 --> Helper loaded: file_helper
INFO - 2017-08-22 05:07:08 --> Database Driver Class Initialized
INFO - 2017-08-22 05:07:08 --> Email Class Initialized
DEBUG - 2017-08-22 05:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:07:08 --> Table Class Initialized
INFO - 2017-08-22 05:07:08 --> Controller Class Initialized
INFO - 2017-08-22 05:07:08 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:07:08 --> Final output sent to browser
DEBUG - 2017-08-22 05:07:08 --> Total execution time: 0.1583
INFO - 2017-08-22 05:07:40 --> Config Class Initialized
INFO - 2017-08-22 05:07:41 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:07:41 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:07:41 --> Utf8 Class Initialized
INFO - 2017-08-22 05:07:41 --> URI Class Initialized
DEBUG - 2017-08-22 05:07:41 --> No URI present. Default controller set.
INFO - 2017-08-22 05:07:41 --> Router Class Initialized
INFO - 2017-08-22 05:07:41 --> Output Class Initialized
INFO - 2017-08-22 05:07:41 --> Security Class Initialized
DEBUG - 2017-08-22 05:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:07:41 --> Input Class Initialized
INFO - 2017-08-22 05:07:41 --> Language Class Initialized
INFO - 2017-08-22 05:07:41 --> Loader Class Initialized
INFO - 2017-08-22 05:07:41 --> Helper loaded: url_helper
INFO - 2017-08-22 05:07:41 --> Helper loaded: file_helper
INFO - 2017-08-22 05:07:41 --> Database Driver Class Initialized
INFO - 2017-08-22 05:07:41 --> Email Class Initialized
DEBUG - 2017-08-22 05:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:07:41 --> Table Class Initialized
INFO - 2017-08-22 05:07:41 --> Controller Class Initialized
INFO - 2017-08-22 05:07:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:07:41 --> Final output sent to browser
DEBUG - 2017-08-22 05:07:41 --> Total execution time: 0.1582
INFO - 2017-08-22 05:07:56 --> Config Class Initialized
INFO - 2017-08-22 05:07:56 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:07:56 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:07:56 --> Utf8 Class Initialized
INFO - 2017-08-22 05:07:56 --> URI Class Initialized
DEBUG - 2017-08-22 05:07:56 --> No URI present. Default controller set.
INFO - 2017-08-22 05:07:56 --> Router Class Initialized
INFO - 2017-08-22 05:07:56 --> Output Class Initialized
INFO - 2017-08-22 05:07:56 --> Security Class Initialized
DEBUG - 2017-08-22 05:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:07:56 --> Input Class Initialized
INFO - 2017-08-22 05:07:56 --> Language Class Initialized
INFO - 2017-08-22 05:07:56 --> Loader Class Initialized
INFO - 2017-08-22 05:07:56 --> Helper loaded: url_helper
INFO - 2017-08-22 05:07:56 --> Helper loaded: file_helper
INFO - 2017-08-22 05:07:56 --> Database Driver Class Initialized
INFO - 2017-08-22 05:07:56 --> Email Class Initialized
DEBUG - 2017-08-22 05:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:07:56 --> Table Class Initialized
INFO - 2017-08-22 05:07:56 --> Controller Class Initialized
INFO - 2017-08-22 05:07:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:07:56 --> Final output sent to browser
DEBUG - 2017-08-22 05:07:56 --> Total execution time: 0.1609
INFO - 2017-08-22 05:08:27 --> Config Class Initialized
INFO - 2017-08-22 05:08:27 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:08:27 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:08:27 --> Utf8 Class Initialized
INFO - 2017-08-22 05:08:27 --> URI Class Initialized
DEBUG - 2017-08-22 05:08:27 --> No URI present. Default controller set.
INFO - 2017-08-22 05:08:27 --> Router Class Initialized
INFO - 2017-08-22 05:08:27 --> Output Class Initialized
INFO - 2017-08-22 05:08:27 --> Security Class Initialized
DEBUG - 2017-08-22 05:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:08:27 --> Input Class Initialized
INFO - 2017-08-22 05:08:27 --> Language Class Initialized
INFO - 2017-08-22 05:08:27 --> Loader Class Initialized
INFO - 2017-08-22 05:08:27 --> Helper loaded: url_helper
INFO - 2017-08-22 05:08:27 --> Helper loaded: file_helper
INFO - 2017-08-22 05:08:27 --> Database Driver Class Initialized
INFO - 2017-08-22 05:08:27 --> Email Class Initialized
DEBUG - 2017-08-22 05:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:08:27 --> Table Class Initialized
INFO - 2017-08-22 05:08:27 --> Controller Class Initialized
INFO - 2017-08-22 05:08:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:08:27 --> Final output sent to browser
DEBUG - 2017-08-22 05:08:27 --> Total execution time: 0.1737
INFO - 2017-08-22 05:08:40 --> Config Class Initialized
INFO - 2017-08-22 05:08:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:08:40 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:08:40 --> Utf8 Class Initialized
INFO - 2017-08-22 05:08:40 --> URI Class Initialized
DEBUG - 2017-08-22 05:08:40 --> No URI present. Default controller set.
INFO - 2017-08-22 05:08:40 --> Router Class Initialized
INFO - 2017-08-22 05:08:40 --> Output Class Initialized
INFO - 2017-08-22 05:08:40 --> Security Class Initialized
DEBUG - 2017-08-22 05:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:08:40 --> Input Class Initialized
INFO - 2017-08-22 05:08:40 --> Language Class Initialized
INFO - 2017-08-22 05:08:40 --> Loader Class Initialized
INFO - 2017-08-22 05:08:40 --> Helper loaded: url_helper
INFO - 2017-08-22 05:08:40 --> Helper loaded: file_helper
INFO - 2017-08-22 05:08:40 --> Database Driver Class Initialized
INFO - 2017-08-22 05:08:40 --> Email Class Initialized
DEBUG - 2017-08-22 05:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:08:40 --> Table Class Initialized
INFO - 2017-08-22 05:08:40 --> Controller Class Initialized
INFO - 2017-08-22 05:08:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:08:40 --> Final output sent to browser
DEBUG - 2017-08-22 05:08:40 --> Total execution time: 0.1737
INFO - 2017-08-22 05:08:48 --> Config Class Initialized
INFO - 2017-08-22 05:08:48 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:08:48 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:08:48 --> Utf8 Class Initialized
INFO - 2017-08-22 05:08:48 --> URI Class Initialized
DEBUG - 2017-08-22 05:08:48 --> No URI present. Default controller set.
INFO - 2017-08-22 05:08:48 --> Router Class Initialized
INFO - 2017-08-22 05:08:48 --> Output Class Initialized
INFO - 2017-08-22 05:08:48 --> Security Class Initialized
DEBUG - 2017-08-22 05:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:08:48 --> Input Class Initialized
INFO - 2017-08-22 05:08:48 --> Language Class Initialized
INFO - 2017-08-22 05:08:48 --> Loader Class Initialized
INFO - 2017-08-22 05:08:48 --> Helper loaded: url_helper
INFO - 2017-08-22 05:08:48 --> Helper loaded: file_helper
INFO - 2017-08-22 05:08:48 --> Database Driver Class Initialized
INFO - 2017-08-22 05:08:48 --> Email Class Initialized
DEBUG - 2017-08-22 05:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:08:48 --> Table Class Initialized
INFO - 2017-08-22 05:08:48 --> Controller Class Initialized
INFO - 2017-08-22 05:08:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:08:48 --> Final output sent to browser
DEBUG - 2017-08-22 05:08:48 --> Total execution time: 0.1631
INFO - 2017-08-22 05:08:54 --> Config Class Initialized
INFO - 2017-08-22 05:08:54 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:08:54 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:08:54 --> Utf8 Class Initialized
INFO - 2017-08-22 05:08:54 --> URI Class Initialized
DEBUG - 2017-08-22 05:08:54 --> No URI present. Default controller set.
INFO - 2017-08-22 05:08:54 --> Router Class Initialized
INFO - 2017-08-22 05:08:54 --> Output Class Initialized
INFO - 2017-08-22 05:08:54 --> Security Class Initialized
DEBUG - 2017-08-22 05:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:08:54 --> Input Class Initialized
INFO - 2017-08-22 05:08:54 --> Language Class Initialized
INFO - 2017-08-22 05:08:54 --> Loader Class Initialized
INFO - 2017-08-22 05:08:54 --> Helper loaded: url_helper
INFO - 2017-08-22 05:08:54 --> Helper loaded: file_helper
INFO - 2017-08-22 05:08:54 --> Database Driver Class Initialized
INFO - 2017-08-22 05:08:54 --> Email Class Initialized
DEBUG - 2017-08-22 05:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:08:54 --> Table Class Initialized
INFO - 2017-08-22 05:08:54 --> Controller Class Initialized
INFO - 2017-08-22 05:08:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:08:54 --> Final output sent to browser
DEBUG - 2017-08-22 05:08:55 --> Total execution time: 0.1867
INFO - 2017-08-22 05:10:41 --> Config Class Initialized
INFO - 2017-08-22 05:10:41 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:10:41 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:10:41 --> Utf8 Class Initialized
INFO - 2017-08-22 05:10:41 --> URI Class Initialized
DEBUG - 2017-08-22 05:10:41 --> No URI present. Default controller set.
INFO - 2017-08-22 05:10:41 --> Router Class Initialized
INFO - 2017-08-22 05:10:41 --> Output Class Initialized
INFO - 2017-08-22 05:10:41 --> Security Class Initialized
DEBUG - 2017-08-22 05:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:10:41 --> Input Class Initialized
INFO - 2017-08-22 05:10:41 --> Language Class Initialized
INFO - 2017-08-22 05:10:41 --> Loader Class Initialized
INFO - 2017-08-22 05:10:41 --> Helper loaded: url_helper
INFO - 2017-08-22 05:10:41 --> Helper loaded: file_helper
INFO - 2017-08-22 05:10:41 --> Database Driver Class Initialized
INFO - 2017-08-22 05:10:41 --> Email Class Initialized
DEBUG - 2017-08-22 05:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:10:41 --> Table Class Initialized
INFO - 2017-08-22 05:10:41 --> Controller Class Initialized
INFO - 2017-08-22 05:10:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:10:41 --> Final output sent to browser
DEBUG - 2017-08-22 05:10:41 --> Total execution time: 0.1768
INFO - 2017-08-22 05:11:10 --> Config Class Initialized
INFO - 2017-08-22 05:11:10 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:11:10 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:11:10 --> Utf8 Class Initialized
INFO - 2017-08-22 05:11:10 --> URI Class Initialized
DEBUG - 2017-08-22 05:11:10 --> No URI present. Default controller set.
INFO - 2017-08-22 05:11:10 --> Router Class Initialized
INFO - 2017-08-22 05:11:10 --> Output Class Initialized
INFO - 2017-08-22 05:11:10 --> Security Class Initialized
DEBUG - 2017-08-22 05:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:11:10 --> Input Class Initialized
INFO - 2017-08-22 05:11:10 --> Language Class Initialized
INFO - 2017-08-22 05:11:10 --> Loader Class Initialized
INFO - 2017-08-22 05:11:10 --> Helper loaded: url_helper
INFO - 2017-08-22 05:11:10 --> Helper loaded: file_helper
INFO - 2017-08-22 05:11:10 --> Database Driver Class Initialized
INFO - 2017-08-22 05:11:10 --> Email Class Initialized
DEBUG - 2017-08-22 05:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:11:10 --> Table Class Initialized
INFO - 2017-08-22 05:11:10 --> Controller Class Initialized
INFO - 2017-08-22 05:11:10 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:11:10 --> Final output sent to browser
DEBUG - 2017-08-22 05:11:10 --> Total execution time: 0.1749
INFO - 2017-08-22 05:11:26 --> Config Class Initialized
INFO - 2017-08-22 05:11:26 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:11:26 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:11:26 --> Utf8 Class Initialized
INFO - 2017-08-22 05:11:26 --> URI Class Initialized
DEBUG - 2017-08-22 05:11:26 --> No URI present. Default controller set.
INFO - 2017-08-22 05:11:26 --> Router Class Initialized
INFO - 2017-08-22 05:11:26 --> Output Class Initialized
INFO - 2017-08-22 05:11:26 --> Security Class Initialized
DEBUG - 2017-08-22 05:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:11:26 --> Input Class Initialized
INFO - 2017-08-22 05:11:26 --> Language Class Initialized
INFO - 2017-08-22 05:11:26 --> Loader Class Initialized
INFO - 2017-08-22 05:11:26 --> Helper loaded: url_helper
INFO - 2017-08-22 05:11:26 --> Helper loaded: file_helper
INFO - 2017-08-22 05:11:26 --> Database Driver Class Initialized
INFO - 2017-08-22 05:11:26 --> Email Class Initialized
DEBUG - 2017-08-22 05:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:11:26 --> Table Class Initialized
INFO - 2017-08-22 05:11:26 --> Controller Class Initialized
INFO - 2017-08-22 05:11:26 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:11:26 --> Final output sent to browser
DEBUG - 2017-08-22 05:11:26 --> Total execution time: 0.1754
INFO - 2017-08-22 05:11:35 --> Config Class Initialized
INFO - 2017-08-22 05:11:35 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:11:35 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:11:35 --> Utf8 Class Initialized
INFO - 2017-08-22 05:11:35 --> URI Class Initialized
DEBUG - 2017-08-22 05:11:35 --> No URI present. Default controller set.
INFO - 2017-08-22 05:11:35 --> Router Class Initialized
INFO - 2017-08-22 05:11:35 --> Output Class Initialized
INFO - 2017-08-22 05:11:35 --> Security Class Initialized
DEBUG - 2017-08-22 05:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:11:35 --> Input Class Initialized
INFO - 2017-08-22 05:11:35 --> Language Class Initialized
INFO - 2017-08-22 05:11:35 --> Loader Class Initialized
INFO - 2017-08-22 05:11:35 --> Helper loaded: url_helper
INFO - 2017-08-22 05:11:35 --> Helper loaded: file_helper
INFO - 2017-08-22 05:11:35 --> Database Driver Class Initialized
INFO - 2017-08-22 05:11:35 --> Email Class Initialized
DEBUG - 2017-08-22 05:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:11:35 --> Table Class Initialized
INFO - 2017-08-22 05:11:35 --> Controller Class Initialized
INFO - 2017-08-22 05:11:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:11:35 --> Final output sent to browser
DEBUG - 2017-08-22 05:11:35 --> Total execution time: 0.1777
INFO - 2017-08-22 05:12:17 --> Config Class Initialized
INFO - 2017-08-22 05:12:17 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:12:17 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:12:17 --> Utf8 Class Initialized
INFO - 2017-08-22 05:12:17 --> URI Class Initialized
DEBUG - 2017-08-22 05:12:17 --> No URI present. Default controller set.
INFO - 2017-08-22 05:12:17 --> Router Class Initialized
INFO - 2017-08-22 05:12:17 --> Output Class Initialized
INFO - 2017-08-22 05:12:17 --> Security Class Initialized
DEBUG - 2017-08-22 05:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:12:17 --> Input Class Initialized
INFO - 2017-08-22 05:12:17 --> Language Class Initialized
INFO - 2017-08-22 05:12:17 --> Loader Class Initialized
INFO - 2017-08-22 05:12:17 --> Helper loaded: url_helper
INFO - 2017-08-22 05:12:17 --> Helper loaded: file_helper
INFO - 2017-08-22 05:12:17 --> Database Driver Class Initialized
INFO - 2017-08-22 05:12:17 --> Email Class Initialized
DEBUG - 2017-08-22 05:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:12:17 --> Table Class Initialized
INFO - 2017-08-22 05:12:17 --> Controller Class Initialized
INFO - 2017-08-22 05:12:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:12:17 --> Final output sent to browser
DEBUG - 2017-08-22 05:12:17 --> Total execution time: 0.1756
INFO - 2017-08-22 05:12:27 --> Config Class Initialized
INFO - 2017-08-22 05:12:27 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:12:27 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:12:27 --> Utf8 Class Initialized
INFO - 2017-08-22 05:12:27 --> URI Class Initialized
DEBUG - 2017-08-22 05:12:27 --> No URI present. Default controller set.
INFO - 2017-08-22 05:12:27 --> Router Class Initialized
INFO - 2017-08-22 05:12:27 --> Output Class Initialized
INFO - 2017-08-22 05:12:27 --> Security Class Initialized
DEBUG - 2017-08-22 05:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:12:27 --> Input Class Initialized
INFO - 2017-08-22 05:12:27 --> Language Class Initialized
INFO - 2017-08-22 05:12:27 --> Loader Class Initialized
INFO - 2017-08-22 05:12:27 --> Helper loaded: url_helper
INFO - 2017-08-22 05:12:27 --> Helper loaded: file_helper
INFO - 2017-08-22 05:12:27 --> Database Driver Class Initialized
INFO - 2017-08-22 05:12:27 --> Email Class Initialized
DEBUG - 2017-08-22 05:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:12:27 --> Table Class Initialized
INFO - 2017-08-22 05:12:27 --> Controller Class Initialized
INFO - 2017-08-22 05:12:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:12:27 --> Final output sent to browser
DEBUG - 2017-08-22 05:12:27 --> Total execution time: 0.1651
INFO - 2017-08-22 05:13:20 --> Config Class Initialized
INFO - 2017-08-22 05:13:20 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:13:20 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:13:20 --> Utf8 Class Initialized
INFO - 2017-08-22 05:13:20 --> URI Class Initialized
DEBUG - 2017-08-22 05:13:20 --> No URI present. Default controller set.
INFO - 2017-08-22 05:13:20 --> Router Class Initialized
INFO - 2017-08-22 05:13:20 --> Output Class Initialized
INFO - 2017-08-22 05:13:20 --> Security Class Initialized
DEBUG - 2017-08-22 05:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:13:20 --> Input Class Initialized
INFO - 2017-08-22 05:13:20 --> Language Class Initialized
INFO - 2017-08-22 05:13:20 --> Loader Class Initialized
INFO - 2017-08-22 05:13:20 --> Helper loaded: url_helper
INFO - 2017-08-22 05:13:20 --> Helper loaded: file_helper
INFO - 2017-08-22 05:13:20 --> Database Driver Class Initialized
INFO - 2017-08-22 05:13:20 --> Email Class Initialized
DEBUG - 2017-08-22 05:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:13:20 --> Table Class Initialized
INFO - 2017-08-22 05:13:20 --> Controller Class Initialized
INFO - 2017-08-22 05:13:20 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:13:20 --> Final output sent to browser
DEBUG - 2017-08-22 05:13:20 --> Total execution time: 0.1794
INFO - 2017-08-22 05:13:27 --> Config Class Initialized
INFO - 2017-08-22 05:13:27 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:13:27 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:13:27 --> Utf8 Class Initialized
INFO - 2017-08-22 05:13:27 --> URI Class Initialized
DEBUG - 2017-08-22 05:13:27 --> No URI present. Default controller set.
INFO - 2017-08-22 05:13:27 --> Router Class Initialized
INFO - 2017-08-22 05:13:27 --> Output Class Initialized
INFO - 2017-08-22 05:13:27 --> Security Class Initialized
DEBUG - 2017-08-22 05:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:13:27 --> Input Class Initialized
INFO - 2017-08-22 05:13:27 --> Language Class Initialized
INFO - 2017-08-22 05:13:27 --> Loader Class Initialized
INFO - 2017-08-22 05:13:27 --> Helper loaded: url_helper
INFO - 2017-08-22 05:13:27 --> Helper loaded: file_helper
INFO - 2017-08-22 05:13:27 --> Database Driver Class Initialized
INFO - 2017-08-22 05:13:27 --> Email Class Initialized
DEBUG - 2017-08-22 05:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:13:27 --> Table Class Initialized
INFO - 2017-08-22 05:13:27 --> Controller Class Initialized
INFO - 2017-08-22 05:13:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:13:27 --> Final output sent to browser
DEBUG - 2017-08-22 05:13:27 --> Total execution time: 0.1799
INFO - 2017-08-22 05:17:12 --> Config Class Initialized
INFO - 2017-08-22 05:17:12 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:17:12 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:17:12 --> Utf8 Class Initialized
INFO - 2017-08-22 05:17:12 --> URI Class Initialized
DEBUG - 2017-08-22 05:17:12 --> No URI present. Default controller set.
INFO - 2017-08-22 05:17:12 --> Router Class Initialized
INFO - 2017-08-22 05:17:12 --> Output Class Initialized
INFO - 2017-08-22 05:17:12 --> Security Class Initialized
DEBUG - 2017-08-22 05:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:17:13 --> Input Class Initialized
INFO - 2017-08-22 05:17:13 --> Language Class Initialized
INFO - 2017-08-22 05:17:13 --> Loader Class Initialized
INFO - 2017-08-22 05:17:13 --> Helper loaded: url_helper
INFO - 2017-08-22 05:17:13 --> Helper loaded: file_helper
INFO - 2017-08-22 05:17:13 --> Database Driver Class Initialized
INFO - 2017-08-22 05:17:13 --> Email Class Initialized
DEBUG - 2017-08-22 05:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:17:13 --> Table Class Initialized
INFO - 2017-08-22 05:17:13 --> Controller Class Initialized
INFO - 2017-08-22 05:17:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:17:13 --> Final output sent to browser
DEBUG - 2017-08-22 05:17:13 --> Total execution time: 0.1832
INFO - 2017-08-22 05:17:15 --> Config Class Initialized
INFO - 2017-08-22 05:17:15 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:17:15 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:17:15 --> Utf8 Class Initialized
INFO - 2017-08-22 05:17:15 --> URI Class Initialized
DEBUG - 2017-08-22 05:17:15 --> No URI present. Default controller set.
INFO - 2017-08-22 05:17:15 --> Router Class Initialized
INFO - 2017-08-22 05:17:15 --> Output Class Initialized
INFO - 2017-08-22 05:17:15 --> Security Class Initialized
DEBUG - 2017-08-22 05:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:17:15 --> Input Class Initialized
INFO - 2017-08-22 05:17:15 --> Language Class Initialized
INFO - 2017-08-22 05:17:15 --> Loader Class Initialized
INFO - 2017-08-22 05:17:15 --> Helper loaded: url_helper
INFO - 2017-08-22 05:17:15 --> Helper loaded: file_helper
INFO - 2017-08-22 05:17:15 --> Database Driver Class Initialized
INFO - 2017-08-22 05:17:15 --> Email Class Initialized
DEBUG - 2017-08-22 05:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:17:15 --> Table Class Initialized
INFO - 2017-08-22 05:17:15 --> Controller Class Initialized
INFO - 2017-08-22 05:17:15 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:17:15 --> Final output sent to browser
DEBUG - 2017-08-22 05:17:15 --> Total execution time: 0.1744
INFO - 2017-08-22 05:17:16 --> Config Class Initialized
INFO - 2017-08-22 05:17:16 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:17:16 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:17:16 --> Utf8 Class Initialized
INFO - 2017-08-22 05:17:16 --> URI Class Initialized
DEBUG - 2017-08-22 05:17:16 --> No URI present. Default controller set.
INFO - 2017-08-22 05:17:16 --> Router Class Initialized
INFO - 2017-08-22 05:17:16 --> Output Class Initialized
INFO - 2017-08-22 05:17:16 --> Security Class Initialized
DEBUG - 2017-08-22 05:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:17:16 --> Input Class Initialized
INFO - 2017-08-22 05:17:16 --> Language Class Initialized
INFO - 2017-08-22 05:17:16 --> Loader Class Initialized
INFO - 2017-08-22 05:17:16 --> Helper loaded: url_helper
INFO - 2017-08-22 05:17:16 --> Helper loaded: file_helper
INFO - 2017-08-22 05:17:16 --> Database Driver Class Initialized
INFO - 2017-08-22 05:17:16 --> Email Class Initialized
DEBUG - 2017-08-22 05:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:17:16 --> Table Class Initialized
INFO - 2017-08-22 05:17:16 --> Controller Class Initialized
INFO - 2017-08-22 05:17:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:17:16 --> Final output sent to browser
DEBUG - 2017-08-22 05:17:16 --> Total execution time: 0.1793
INFO - 2017-08-22 05:17:21 --> Config Class Initialized
INFO - 2017-08-22 05:17:21 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:17:21 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:17:21 --> Utf8 Class Initialized
INFO - 2017-08-22 05:17:21 --> URI Class Initialized
DEBUG - 2017-08-22 05:17:21 --> No URI present. Default controller set.
INFO - 2017-08-22 05:17:21 --> Router Class Initialized
INFO - 2017-08-22 05:17:21 --> Output Class Initialized
INFO - 2017-08-22 05:17:21 --> Security Class Initialized
DEBUG - 2017-08-22 05:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:17:21 --> Input Class Initialized
INFO - 2017-08-22 05:17:21 --> Language Class Initialized
INFO - 2017-08-22 05:17:21 --> Loader Class Initialized
INFO - 2017-08-22 05:17:21 --> Helper loaded: url_helper
INFO - 2017-08-22 05:17:21 --> Helper loaded: file_helper
INFO - 2017-08-22 05:17:21 --> Database Driver Class Initialized
INFO - 2017-08-22 05:17:21 --> Email Class Initialized
DEBUG - 2017-08-22 05:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:17:21 --> Table Class Initialized
INFO - 2017-08-22 05:17:21 --> Controller Class Initialized
INFO - 2017-08-22 05:17:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:17:21 --> Final output sent to browser
DEBUG - 2017-08-22 05:17:21 --> Total execution time: 0.1785
INFO - 2017-08-22 05:17:23 --> Config Class Initialized
INFO - 2017-08-22 05:17:23 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:17:23 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:17:23 --> Utf8 Class Initialized
INFO - 2017-08-22 05:17:23 --> URI Class Initialized
DEBUG - 2017-08-22 05:17:23 --> No URI present. Default controller set.
INFO - 2017-08-22 05:17:23 --> Router Class Initialized
INFO - 2017-08-22 05:17:23 --> Output Class Initialized
INFO - 2017-08-22 05:17:23 --> Security Class Initialized
DEBUG - 2017-08-22 05:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:17:23 --> Input Class Initialized
INFO - 2017-08-22 05:17:23 --> Language Class Initialized
INFO - 2017-08-22 05:17:23 --> Loader Class Initialized
INFO - 2017-08-22 05:17:23 --> Helper loaded: url_helper
INFO - 2017-08-22 05:17:23 --> Helper loaded: file_helper
INFO - 2017-08-22 05:17:23 --> Database Driver Class Initialized
INFO - 2017-08-22 05:17:23 --> Email Class Initialized
DEBUG - 2017-08-22 05:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:17:23 --> Table Class Initialized
INFO - 2017-08-22 05:17:23 --> Controller Class Initialized
INFO - 2017-08-22 05:17:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:17:23 --> Final output sent to browser
DEBUG - 2017-08-22 05:17:23 --> Total execution time: 0.1753
INFO - 2017-08-22 05:17:25 --> Config Class Initialized
INFO - 2017-08-22 05:17:25 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:17:25 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:17:25 --> Utf8 Class Initialized
INFO - 2017-08-22 05:17:25 --> URI Class Initialized
DEBUG - 2017-08-22 05:17:25 --> No URI present. Default controller set.
INFO - 2017-08-22 05:17:25 --> Router Class Initialized
INFO - 2017-08-22 05:17:25 --> Output Class Initialized
INFO - 2017-08-22 05:17:25 --> Security Class Initialized
DEBUG - 2017-08-22 05:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:17:25 --> Input Class Initialized
INFO - 2017-08-22 05:17:25 --> Language Class Initialized
INFO - 2017-08-22 05:17:25 --> Loader Class Initialized
INFO - 2017-08-22 05:17:25 --> Helper loaded: url_helper
INFO - 2017-08-22 05:17:25 --> Helper loaded: file_helper
INFO - 2017-08-22 05:17:25 --> Database Driver Class Initialized
INFO - 2017-08-22 05:17:25 --> Email Class Initialized
DEBUG - 2017-08-22 05:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:17:25 --> Table Class Initialized
INFO - 2017-08-22 05:17:25 --> Controller Class Initialized
INFO - 2017-08-22 05:17:25 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:17:25 --> Final output sent to browser
DEBUG - 2017-08-22 05:17:25 --> Total execution time: 0.1804
INFO - 2017-08-22 05:18:15 --> Config Class Initialized
INFO - 2017-08-22 05:18:15 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:18:15 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:18:15 --> Utf8 Class Initialized
INFO - 2017-08-22 05:18:15 --> URI Class Initialized
DEBUG - 2017-08-22 05:18:15 --> No URI present. Default controller set.
INFO - 2017-08-22 05:18:15 --> Router Class Initialized
INFO - 2017-08-22 05:18:15 --> Output Class Initialized
INFO - 2017-08-22 05:18:15 --> Security Class Initialized
DEBUG - 2017-08-22 05:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:18:15 --> Input Class Initialized
INFO - 2017-08-22 05:18:15 --> Language Class Initialized
INFO - 2017-08-22 05:18:15 --> Loader Class Initialized
INFO - 2017-08-22 05:18:15 --> Helper loaded: url_helper
INFO - 2017-08-22 05:18:15 --> Helper loaded: file_helper
INFO - 2017-08-22 05:18:15 --> Database Driver Class Initialized
INFO - 2017-08-22 05:18:15 --> Email Class Initialized
DEBUG - 2017-08-22 05:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:18:15 --> Table Class Initialized
INFO - 2017-08-22 05:18:15 --> Controller Class Initialized
INFO - 2017-08-22 05:18:15 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:18:15 --> Final output sent to browser
DEBUG - 2017-08-22 05:18:15 --> Total execution time: 0.1926
INFO - 2017-08-22 05:18:33 --> Config Class Initialized
INFO - 2017-08-22 05:18:33 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:18:33 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:18:33 --> Utf8 Class Initialized
INFO - 2017-08-22 05:18:33 --> URI Class Initialized
DEBUG - 2017-08-22 05:18:33 --> No URI present. Default controller set.
INFO - 2017-08-22 05:18:33 --> Router Class Initialized
INFO - 2017-08-22 05:18:33 --> Output Class Initialized
INFO - 2017-08-22 05:18:33 --> Security Class Initialized
DEBUG - 2017-08-22 05:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:18:33 --> Input Class Initialized
INFO - 2017-08-22 05:18:33 --> Language Class Initialized
INFO - 2017-08-22 05:18:33 --> Loader Class Initialized
INFO - 2017-08-22 05:18:33 --> Helper loaded: url_helper
INFO - 2017-08-22 05:18:33 --> Helper loaded: file_helper
INFO - 2017-08-22 05:18:33 --> Database Driver Class Initialized
INFO - 2017-08-22 05:18:33 --> Email Class Initialized
DEBUG - 2017-08-22 05:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:18:33 --> Table Class Initialized
INFO - 2017-08-22 05:18:33 --> Controller Class Initialized
INFO - 2017-08-22 05:18:33 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:18:33 --> Final output sent to browser
DEBUG - 2017-08-22 05:18:33 --> Total execution time: 0.1837
INFO - 2017-08-22 05:22:20 --> Config Class Initialized
INFO - 2017-08-22 05:22:20 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:22:20 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:22:20 --> Utf8 Class Initialized
INFO - 2017-08-22 05:22:20 --> URI Class Initialized
DEBUG - 2017-08-22 05:22:20 --> No URI present. Default controller set.
INFO - 2017-08-22 05:22:20 --> Router Class Initialized
INFO - 2017-08-22 05:22:20 --> Output Class Initialized
INFO - 2017-08-22 05:22:20 --> Security Class Initialized
DEBUG - 2017-08-22 05:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:22:20 --> Input Class Initialized
INFO - 2017-08-22 05:22:20 --> Language Class Initialized
INFO - 2017-08-22 05:22:20 --> Loader Class Initialized
INFO - 2017-08-22 05:22:20 --> Helper loaded: url_helper
INFO - 2017-08-22 05:22:20 --> Helper loaded: file_helper
INFO - 2017-08-22 05:22:20 --> Database Driver Class Initialized
INFO - 2017-08-22 05:22:20 --> Email Class Initialized
DEBUG - 2017-08-22 05:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:22:20 --> Table Class Initialized
INFO - 2017-08-22 05:22:20 --> Controller Class Initialized
INFO - 2017-08-22 05:22:20 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:22:20 --> Final output sent to browser
DEBUG - 2017-08-22 05:22:20 --> Total execution time: 0.1869
INFO - 2017-08-22 05:22:26 --> Config Class Initialized
INFO - 2017-08-22 05:22:26 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:22:26 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:22:26 --> Utf8 Class Initialized
INFO - 2017-08-22 05:22:26 --> URI Class Initialized
DEBUG - 2017-08-22 05:22:26 --> No URI present. Default controller set.
INFO - 2017-08-22 05:22:26 --> Router Class Initialized
INFO - 2017-08-22 05:22:26 --> Output Class Initialized
INFO - 2017-08-22 05:22:26 --> Security Class Initialized
DEBUG - 2017-08-22 05:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:22:26 --> Input Class Initialized
INFO - 2017-08-22 05:22:26 --> Language Class Initialized
INFO - 2017-08-22 05:22:26 --> Loader Class Initialized
INFO - 2017-08-22 05:22:26 --> Helper loaded: url_helper
INFO - 2017-08-22 05:22:26 --> Helper loaded: file_helper
INFO - 2017-08-22 05:22:26 --> Database Driver Class Initialized
INFO - 2017-08-22 05:22:26 --> Email Class Initialized
DEBUG - 2017-08-22 05:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:22:26 --> Table Class Initialized
INFO - 2017-08-22 05:22:26 --> Controller Class Initialized
INFO - 2017-08-22 05:22:26 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:22:26 --> Final output sent to browser
DEBUG - 2017-08-22 05:22:26 --> Total execution time: 0.1755
INFO - 2017-08-22 05:23:25 --> Config Class Initialized
INFO - 2017-08-22 05:23:25 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:23:25 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:23:25 --> Utf8 Class Initialized
INFO - 2017-08-22 05:23:25 --> URI Class Initialized
DEBUG - 2017-08-22 05:23:25 --> No URI present. Default controller set.
INFO - 2017-08-22 05:23:25 --> Router Class Initialized
INFO - 2017-08-22 05:23:25 --> Output Class Initialized
INFO - 2017-08-22 05:23:25 --> Security Class Initialized
DEBUG - 2017-08-22 05:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:23:25 --> Input Class Initialized
INFO - 2017-08-22 05:23:25 --> Language Class Initialized
INFO - 2017-08-22 05:23:25 --> Loader Class Initialized
INFO - 2017-08-22 05:23:25 --> Helper loaded: url_helper
INFO - 2017-08-22 05:23:25 --> Helper loaded: file_helper
INFO - 2017-08-22 05:23:25 --> Database Driver Class Initialized
INFO - 2017-08-22 05:23:25 --> Email Class Initialized
DEBUG - 2017-08-22 05:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:23:25 --> Table Class Initialized
INFO - 2017-08-22 05:23:25 --> Controller Class Initialized
INFO - 2017-08-22 05:23:25 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:23:25 --> Final output sent to browser
DEBUG - 2017-08-22 05:23:25 --> Total execution time: 0.2089
INFO - 2017-08-22 05:23:49 --> Config Class Initialized
INFO - 2017-08-22 05:23:49 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:23:49 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:23:49 --> Utf8 Class Initialized
INFO - 2017-08-22 05:23:49 --> URI Class Initialized
DEBUG - 2017-08-22 05:23:49 --> No URI present. Default controller set.
INFO - 2017-08-22 05:23:49 --> Router Class Initialized
INFO - 2017-08-22 05:23:49 --> Output Class Initialized
INFO - 2017-08-22 05:23:49 --> Security Class Initialized
DEBUG - 2017-08-22 05:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:23:49 --> Input Class Initialized
INFO - 2017-08-22 05:23:49 --> Language Class Initialized
INFO - 2017-08-22 05:23:49 --> Loader Class Initialized
INFO - 2017-08-22 05:23:49 --> Helper loaded: url_helper
INFO - 2017-08-22 05:23:49 --> Helper loaded: file_helper
INFO - 2017-08-22 05:23:49 --> Database Driver Class Initialized
INFO - 2017-08-22 05:23:49 --> Email Class Initialized
DEBUG - 2017-08-22 05:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:23:49 --> Table Class Initialized
INFO - 2017-08-22 05:23:49 --> Controller Class Initialized
INFO - 2017-08-22 05:23:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:23:49 --> Final output sent to browser
DEBUG - 2017-08-22 05:23:49 --> Total execution time: 0.1826
INFO - 2017-08-22 05:24:09 --> Config Class Initialized
INFO - 2017-08-22 05:24:09 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:24:09 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:24:09 --> Utf8 Class Initialized
INFO - 2017-08-22 05:24:09 --> URI Class Initialized
DEBUG - 2017-08-22 05:24:09 --> No URI present. Default controller set.
INFO - 2017-08-22 05:24:09 --> Router Class Initialized
INFO - 2017-08-22 05:24:09 --> Output Class Initialized
INFO - 2017-08-22 05:24:09 --> Security Class Initialized
DEBUG - 2017-08-22 05:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:24:09 --> Input Class Initialized
INFO - 2017-08-22 05:24:09 --> Language Class Initialized
INFO - 2017-08-22 05:24:09 --> Loader Class Initialized
INFO - 2017-08-22 05:24:09 --> Helper loaded: url_helper
INFO - 2017-08-22 05:24:09 --> Helper loaded: file_helper
INFO - 2017-08-22 05:24:09 --> Database Driver Class Initialized
INFO - 2017-08-22 05:24:09 --> Email Class Initialized
DEBUG - 2017-08-22 05:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:24:09 --> Table Class Initialized
INFO - 2017-08-22 05:24:09 --> Controller Class Initialized
INFO - 2017-08-22 05:24:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:24:09 --> Final output sent to browser
DEBUG - 2017-08-22 05:24:09 --> Total execution time: 0.1768
INFO - 2017-08-22 05:24:11 --> Config Class Initialized
INFO - 2017-08-22 05:24:11 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:24:11 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:24:11 --> Utf8 Class Initialized
INFO - 2017-08-22 05:24:11 --> URI Class Initialized
DEBUG - 2017-08-22 05:24:11 --> No URI present. Default controller set.
INFO - 2017-08-22 05:24:11 --> Router Class Initialized
INFO - 2017-08-22 05:24:11 --> Output Class Initialized
INFO - 2017-08-22 05:24:11 --> Security Class Initialized
DEBUG - 2017-08-22 05:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:24:11 --> Input Class Initialized
INFO - 2017-08-22 05:24:11 --> Language Class Initialized
INFO - 2017-08-22 05:24:11 --> Loader Class Initialized
INFO - 2017-08-22 05:24:11 --> Helper loaded: url_helper
INFO - 2017-08-22 05:24:11 --> Helper loaded: file_helper
INFO - 2017-08-22 05:24:11 --> Database Driver Class Initialized
INFO - 2017-08-22 05:24:11 --> Email Class Initialized
DEBUG - 2017-08-22 05:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:24:11 --> Table Class Initialized
INFO - 2017-08-22 05:24:11 --> Controller Class Initialized
INFO - 2017-08-22 05:24:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:24:11 --> Final output sent to browser
DEBUG - 2017-08-22 05:24:11 --> Total execution time: 0.1848
INFO - 2017-08-22 05:24:43 --> Config Class Initialized
INFO - 2017-08-22 05:24:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:24:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:24:43 --> Utf8 Class Initialized
INFO - 2017-08-22 05:24:43 --> URI Class Initialized
DEBUG - 2017-08-22 05:24:43 --> No URI present. Default controller set.
INFO - 2017-08-22 05:24:43 --> Router Class Initialized
INFO - 2017-08-22 05:24:43 --> Output Class Initialized
INFO - 2017-08-22 05:24:43 --> Security Class Initialized
DEBUG - 2017-08-22 05:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:24:43 --> Input Class Initialized
INFO - 2017-08-22 05:24:43 --> Language Class Initialized
INFO - 2017-08-22 05:24:43 --> Loader Class Initialized
INFO - 2017-08-22 05:24:43 --> Helper loaded: url_helper
INFO - 2017-08-22 05:24:43 --> Helper loaded: file_helper
INFO - 2017-08-22 05:24:43 --> Database Driver Class Initialized
INFO - 2017-08-22 05:24:43 --> Email Class Initialized
DEBUG - 2017-08-22 05:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:24:43 --> Table Class Initialized
INFO - 2017-08-22 05:24:43 --> Controller Class Initialized
INFO - 2017-08-22 05:24:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:24:43 --> Final output sent to browser
DEBUG - 2017-08-22 05:24:43 --> Total execution time: 0.1785
INFO - 2017-08-22 05:24:50 --> Config Class Initialized
INFO - 2017-08-22 05:24:50 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:24:50 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:24:50 --> Utf8 Class Initialized
INFO - 2017-08-22 05:24:50 --> URI Class Initialized
DEBUG - 2017-08-22 05:24:50 --> No URI present. Default controller set.
INFO - 2017-08-22 05:24:50 --> Router Class Initialized
INFO - 2017-08-22 05:24:50 --> Output Class Initialized
INFO - 2017-08-22 05:24:50 --> Security Class Initialized
DEBUG - 2017-08-22 05:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:24:50 --> Input Class Initialized
INFO - 2017-08-22 05:24:50 --> Language Class Initialized
INFO - 2017-08-22 05:24:50 --> Loader Class Initialized
INFO - 2017-08-22 05:24:50 --> Helper loaded: url_helper
INFO - 2017-08-22 05:24:50 --> Helper loaded: file_helper
INFO - 2017-08-22 05:24:50 --> Database Driver Class Initialized
INFO - 2017-08-22 05:24:50 --> Email Class Initialized
DEBUG - 2017-08-22 05:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:24:50 --> Table Class Initialized
INFO - 2017-08-22 05:24:50 --> Controller Class Initialized
INFO - 2017-08-22 05:24:50 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:24:50 --> Final output sent to browser
DEBUG - 2017-08-22 05:24:50 --> Total execution time: 0.2019
INFO - 2017-08-22 05:24:59 --> Config Class Initialized
INFO - 2017-08-22 05:24:59 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:24:59 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:24:59 --> Utf8 Class Initialized
INFO - 2017-08-22 05:24:59 --> URI Class Initialized
DEBUG - 2017-08-22 05:24:59 --> No URI present. Default controller set.
INFO - 2017-08-22 05:24:59 --> Router Class Initialized
INFO - 2017-08-22 05:24:59 --> Output Class Initialized
INFO - 2017-08-22 05:24:59 --> Security Class Initialized
DEBUG - 2017-08-22 05:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:24:59 --> Input Class Initialized
INFO - 2017-08-22 05:24:59 --> Language Class Initialized
INFO - 2017-08-22 05:24:59 --> Loader Class Initialized
INFO - 2017-08-22 05:24:59 --> Helper loaded: url_helper
INFO - 2017-08-22 05:24:59 --> Helper loaded: file_helper
INFO - 2017-08-22 05:24:59 --> Database Driver Class Initialized
INFO - 2017-08-22 05:24:59 --> Email Class Initialized
DEBUG - 2017-08-22 05:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:24:59 --> Table Class Initialized
INFO - 2017-08-22 05:24:59 --> Controller Class Initialized
INFO - 2017-08-22 05:24:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:24:59 --> Final output sent to browser
DEBUG - 2017-08-22 05:24:59 --> Total execution time: 0.1882
INFO - 2017-08-22 05:25:06 --> Config Class Initialized
INFO - 2017-08-22 05:25:06 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:25:06 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:25:06 --> Utf8 Class Initialized
INFO - 2017-08-22 05:25:06 --> URI Class Initialized
DEBUG - 2017-08-22 05:25:06 --> No URI present. Default controller set.
INFO - 2017-08-22 05:25:06 --> Router Class Initialized
INFO - 2017-08-22 05:25:06 --> Output Class Initialized
INFO - 2017-08-22 05:25:06 --> Security Class Initialized
DEBUG - 2017-08-22 05:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:25:06 --> Input Class Initialized
INFO - 2017-08-22 05:25:06 --> Language Class Initialized
INFO - 2017-08-22 05:25:06 --> Loader Class Initialized
INFO - 2017-08-22 05:25:06 --> Helper loaded: url_helper
INFO - 2017-08-22 05:25:06 --> Helper loaded: file_helper
INFO - 2017-08-22 05:25:06 --> Database Driver Class Initialized
INFO - 2017-08-22 05:25:06 --> Email Class Initialized
DEBUG - 2017-08-22 05:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:25:06 --> Table Class Initialized
INFO - 2017-08-22 05:25:06 --> Controller Class Initialized
INFO - 2017-08-22 05:25:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:25:06 --> Final output sent to browser
DEBUG - 2017-08-22 05:25:06 --> Total execution time: 0.1900
INFO - 2017-08-22 05:25:11 --> Config Class Initialized
INFO - 2017-08-22 05:25:11 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:25:11 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:25:11 --> Utf8 Class Initialized
INFO - 2017-08-22 05:25:11 --> URI Class Initialized
DEBUG - 2017-08-22 05:25:11 --> No URI present. Default controller set.
INFO - 2017-08-22 05:25:11 --> Router Class Initialized
INFO - 2017-08-22 05:25:11 --> Output Class Initialized
INFO - 2017-08-22 05:25:11 --> Security Class Initialized
DEBUG - 2017-08-22 05:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:25:11 --> Input Class Initialized
INFO - 2017-08-22 05:25:11 --> Language Class Initialized
INFO - 2017-08-22 05:25:11 --> Loader Class Initialized
INFO - 2017-08-22 05:25:11 --> Helper loaded: url_helper
INFO - 2017-08-22 05:25:11 --> Helper loaded: file_helper
INFO - 2017-08-22 05:25:11 --> Database Driver Class Initialized
INFO - 2017-08-22 05:25:11 --> Email Class Initialized
DEBUG - 2017-08-22 05:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:25:11 --> Table Class Initialized
INFO - 2017-08-22 05:25:11 --> Controller Class Initialized
INFO - 2017-08-22 05:25:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:25:11 --> Final output sent to browser
DEBUG - 2017-08-22 05:25:11 --> Total execution time: 0.1911
INFO - 2017-08-22 05:25:13 --> Config Class Initialized
INFO - 2017-08-22 05:25:13 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:25:13 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:25:13 --> Utf8 Class Initialized
INFO - 2017-08-22 05:25:13 --> URI Class Initialized
DEBUG - 2017-08-22 05:25:13 --> No URI present. Default controller set.
INFO - 2017-08-22 05:25:13 --> Router Class Initialized
INFO - 2017-08-22 05:25:13 --> Output Class Initialized
INFO - 2017-08-22 05:25:13 --> Security Class Initialized
DEBUG - 2017-08-22 05:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:25:13 --> Input Class Initialized
INFO - 2017-08-22 05:25:13 --> Language Class Initialized
INFO - 2017-08-22 05:25:13 --> Loader Class Initialized
INFO - 2017-08-22 05:25:13 --> Helper loaded: url_helper
INFO - 2017-08-22 05:25:13 --> Helper loaded: file_helper
INFO - 2017-08-22 05:25:13 --> Database Driver Class Initialized
INFO - 2017-08-22 05:25:13 --> Email Class Initialized
DEBUG - 2017-08-22 05:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:25:13 --> Table Class Initialized
INFO - 2017-08-22 05:25:13 --> Controller Class Initialized
INFO - 2017-08-22 05:25:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:25:13 --> Final output sent to browser
DEBUG - 2017-08-22 05:25:13 --> Total execution time: 0.1885
INFO - 2017-08-22 05:25:17 --> Config Class Initialized
INFO - 2017-08-22 05:25:17 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:25:17 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:25:17 --> Utf8 Class Initialized
INFO - 2017-08-22 05:25:17 --> URI Class Initialized
DEBUG - 2017-08-22 05:25:17 --> No URI present. Default controller set.
INFO - 2017-08-22 05:25:17 --> Router Class Initialized
INFO - 2017-08-22 05:25:17 --> Output Class Initialized
INFO - 2017-08-22 05:25:17 --> Security Class Initialized
DEBUG - 2017-08-22 05:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:25:17 --> Input Class Initialized
INFO - 2017-08-22 05:25:17 --> Language Class Initialized
INFO - 2017-08-22 05:25:17 --> Loader Class Initialized
INFO - 2017-08-22 05:25:17 --> Helper loaded: url_helper
INFO - 2017-08-22 05:25:17 --> Helper loaded: file_helper
INFO - 2017-08-22 05:25:17 --> Database Driver Class Initialized
INFO - 2017-08-22 05:25:17 --> Email Class Initialized
DEBUG - 2017-08-22 05:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:25:17 --> Table Class Initialized
INFO - 2017-08-22 05:25:17 --> Controller Class Initialized
INFO - 2017-08-22 05:25:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:25:17 --> Final output sent to browser
DEBUG - 2017-08-22 05:25:17 --> Total execution time: 0.1874
INFO - 2017-08-22 05:25:23 --> Config Class Initialized
INFO - 2017-08-22 05:25:23 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:25:23 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:25:23 --> Utf8 Class Initialized
INFO - 2017-08-22 05:25:23 --> URI Class Initialized
DEBUG - 2017-08-22 05:25:23 --> No URI present. Default controller set.
INFO - 2017-08-22 05:25:23 --> Router Class Initialized
INFO - 2017-08-22 05:25:23 --> Output Class Initialized
INFO - 2017-08-22 05:25:23 --> Security Class Initialized
DEBUG - 2017-08-22 05:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:25:23 --> Input Class Initialized
INFO - 2017-08-22 05:25:23 --> Language Class Initialized
INFO - 2017-08-22 05:25:23 --> Loader Class Initialized
INFO - 2017-08-22 05:25:23 --> Helper loaded: url_helper
INFO - 2017-08-22 05:25:23 --> Helper loaded: file_helper
INFO - 2017-08-22 05:25:23 --> Database Driver Class Initialized
INFO - 2017-08-22 05:25:23 --> Email Class Initialized
DEBUG - 2017-08-22 05:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:25:23 --> Table Class Initialized
INFO - 2017-08-22 05:25:23 --> Controller Class Initialized
INFO - 2017-08-22 05:25:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:25:23 --> Final output sent to browser
DEBUG - 2017-08-22 05:25:23 --> Total execution time: 0.1957
INFO - 2017-08-22 05:25:34 --> Config Class Initialized
INFO - 2017-08-22 05:25:34 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:25:34 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:25:34 --> Utf8 Class Initialized
INFO - 2017-08-22 05:25:34 --> URI Class Initialized
DEBUG - 2017-08-22 05:25:34 --> No URI present. Default controller set.
INFO - 2017-08-22 05:25:34 --> Router Class Initialized
INFO - 2017-08-22 05:25:34 --> Output Class Initialized
INFO - 2017-08-22 05:25:34 --> Security Class Initialized
DEBUG - 2017-08-22 05:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:25:34 --> Input Class Initialized
INFO - 2017-08-22 05:25:34 --> Language Class Initialized
INFO - 2017-08-22 05:25:34 --> Loader Class Initialized
INFO - 2017-08-22 05:25:34 --> Helper loaded: url_helper
INFO - 2017-08-22 05:25:34 --> Helper loaded: file_helper
INFO - 2017-08-22 05:25:34 --> Database Driver Class Initialized
INFO - 2017-08-22 05:25:34 --> Email Class Initialized
DEBUG - 2017-08-22 05:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:25:34 --> Table Class Initialized
INFO - 2017-08-22 05:25:34 --> Controller Class Initialized
INFO - 2017-08-22 05:25:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:25:34 --> Final output sent to browser
DEBUG - 2017-08-22 05:25:34 --> Total execution time: 0.1947
INFO - 2017-08-22 05:25:43 --> Config Class Initialized
INFO - 2017-08-22 05:25:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:25:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:25:43 --> Utf8 Class Initialized
INFO - 2017-08-22 05:25:43 --> URI Class Initialized
DEBUG - 2017-08-22 05:25:43 --> No URI present. Default controller set.
INFO - 2017-08-22 05:25:43 --> Router Class Initialized
INFO - 2017-08-22 05:25:43 --> Output Class Initialized
INFO - 2017-08-22 05:25:43 --> Security Class Initialized
DEBUG - 2017-08-22 05:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:25:43 --> Input Class Initialized
INFO - 2017-08-22 05:25:43 --> Language Class Initialized
INFO - 2017-08-22 05:25:43 --> Loader Class Initialized
INFO - 2017-08-22 05:25:43 --> Helper loaded: url_helper
INFO - 2017-08-22 05:25:43 --> Helper loaded: file_helper
INFO - 2017-08-22 05:25:43 --> Database Driver Class Initialized
INFO - 2017-08-22 05:25:43 --> Email Class Initialized
DEBUG - 2017-08-22 05:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:25:43 --> Table Class Initialized
INFO - 2017-08-22 05:25:43 --> Controller Class Initialized
INFO - 2017-08-22 05:25:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:25:43 --> Final output sent to browser
DEBUG - 2017-08-22 05:25:43 --> Total execution time: 0.2037
INFO - 2017-08-22 05:25:48 --> Config Class Initialized
INFO - 2017-08-22 05:25:48 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:25:48 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:25:48 --> Utf8 Class Initialized
INFO - 2017-08-22 05:25:48 --> URI Class Initialized
DEBUG - 2017-08-22 05:25:48 --> No URI present. Default controller set.
INFO - 2017-08-22 05:25:48 --> Router Class Initialized
INFO - 2017-08-22 05:25:48 --> Output Class Initialized
INFO - 2017-08-22 05:25:48 --> Security Class Initialized
DEBUG - 2017-08-22 05:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:25:48 --> Input Class Initialized
INFO - 2017-08-22 05:25:48 --> Language Class Initialized
INFO - 2017-08-22 05:25:48 --> Loader Class Initialized
INFO - 2017-08-22 05:25:48 --> Helper loaded: url_helper
INFO - 2017-08-22 05:25:48 --> Helper loaded: file_helper
INFO - 2017-08-22 05:25:48 --> Database Driver Class Initialized
INFO - 2017-08-22 05:25:48 --> Email Class Initialized
DEBUG - 2017-08-22 05:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:25:48 --> Table Class Initialized
INFO - 2017-08-22 05:25:48 --> Controller Class Initialized
INFO - 2017-08-22 05:25:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:25:48 --> Final output sent to browser
DEBUG - 2017-08-22 05:25:48 --> Total execution time: 0.1923
INFO - 2017-08-22 05:25:53 --> Config Class Initialized
INFO - 2017-08-22 05:25:53 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:25:53 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:25:53 --> Utf8 Class Initialized
INFO - 2017-08-22 05:25:53 --> URI Class Initialized
DEBUG - 2017-08-22 05:25:53 --> No URI present. Default controller set.
INFO - 2017-08-22 05:25:53 --> Router Class Initialized
INFO - 2017-08-22 05:25:53 --> Output Class Initialized
INFO - 2017-08-22 05:25:53 --> Security Class Initialized
DEBUG - 2017-08-22 05:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:25:53 --> Input Class Initialized
INFO - 2017-08-22 05:25:53 --> Language Class Initialized
INFO - 2017-08-22 05:25:53 --> Loader Class Initialized
INFO - 2017-08-22 05:25:53 --> Helper loaded: url_helper
INFO - 2017-08-22 05:25:53 --> Helper loaded: file_helper
INFO - 2017-08-22 05:25:53 --> Database Driver Class Initialized
INFO - 2017-08-22 05:25:53 --> Email Class Initialized
DEBUG - 2017-08-22 05:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:25:54 --> Table Class Initialized
INFO - 2017-08-22 05:25:54 --> Controller Class Initialized
INFO - 2017-08-22 05:25:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:25:54 --> Final output sent to browser
DEBUG - 2017-08-22 05:25:54 --> Total execution time: 0.1945
INFO - 2017-08-22 05:25:58 --> Config Class Initialized
INFO - 2017-08-22 05:25:58 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:25:58 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:25:58 --> Utf8 Class Initialized
INFO - 2017-08-22 05:25:58 --> URI Class Initialized
DEBUG - 2017-08-22 05:25:58 --> No URI present. Default controller set.
INFO - 2017-08-22 05:25:58 --> Router Class Initialized
INFO - 2017-08-22 05:25:58 --> Output Class Initialized
INFO - 2017-08-22 05:25:58 --> Security Class Initialized
DEBUG - 2017-08-22 05:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:25:58 --> Input Class Initialized
INFO - 2017-08-22 05:25:58 --> Language Class Initialized
INFO - 2017-08-22 05:25:58 --> Loader Class Initialized
INFO - 2017-08-22 05:25:58 --> Helper loaded: url_helper
INFO - 2017-08-22 05:25:58 --> Helper loaded: file_helper
INFO - 2017-08-22 05:25:58 --> Database Driver Class Initialized
INFO - 2017-08-22 05:25:58 --> Email Class Initialized
DEBUG - 2017-08-22 05:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:25:58 --> Table Class Initialized
INFO - 2017-08-22 05:25:58 --> Controller Class Initialized
INFO - 2017-08-22 05:25:58 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:25:58 --> Final output sent to browser
DEBUG - 2017-08-22 05:25:58 --> Total execution time: 0.1811
INFO - 2017-08-22 05:26:08 --> Config Class Initialized
INFO - 2017-08-22 05:26:08 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:26:08 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:26:08 --> Utf8 Class Initialized
INFO - 2017-08-22 05:26:08 --> URI Class Initialized
DEBUG - 2017-08-22 05:26:08 --> No URI present. Default controller set.
INFO - 2017-08-22 05:26:08 --> Router Class Initialized
INFO - 2017-08-22 05:26:08 --> Output Class Initialized
INFO - 2017-08-22 05:26:08 --> Security Class Initialized
DEBUG - 2017-08-22 05:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:26:08 --> Input Class Initialized
INFO - 2017-08-22 05:26:08 --> Language Class Initialized
INFO - 2017-08-22 05:26:08 --> Loader Class Initialized
INFO - 2017-08-22 05:26:08 --> Helper loaded: url_helper
INFO - 2017-08-22 05:26:09 --> Helper loaded: file_helper
INFO - 2017-08-22 05:26:09 --> Database Driver Class Initialized
INFO - 2017-08-22 05:26:09 --> Email Class Initialized
DEBUG - 2017-08-22 05:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:26:09 --> Table Class Initialized
INFO - 2017-08-22 05:26:09 --> Controller Class Initialized
INFO - 2017-08-22 05:26:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:26:09 --> Final output sent to browser
DEBUG - 2017-08-22 05:26:09 --> Total execution time: 0.1831
INFO - 2017-08-22 05:26:48 --> Config Class Initialized
INFO - 2017-08-22 05:26:48 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:26:48 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:26:48 --> Utf8 Class Initialized
INFO - 2017-08-22 05:26:48 --> URI Class Initialized
DEBUG - 2017-08-22 05:26:48 --> No URI present. Default controller set.
INFO - 2017-08-22 05:26:48 --> Router Class Initialized
INFO - 2017-08-22 05:26:48 --> Output Class Initialized
INFO - 2017-08-22 05:26:48 --> Security Class Initialized
DEBUG - 2017-08-22 05:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:26:48 --> Input Class Initialized
INFO - 2017-08-22 05:26:48 --> Language Class Initialized
INFO - 2017-08-22 05:26:48 --> Loader Class Initialized
INFO - 2017-08-22 05:26:48 --> Helper loaded: url_helper
INFO - 2017-08-22 05:26:48 --> Helper loaded: file_helper
INFO - 2017-08-22 05:26:48 --> Database Driver Class Initialized
INFO - 2017-08-22 05:26:48 --> Email Class Initialized
DEBUG - 2017-08-22 05:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:26:48 --> Table Class Initialized
INFO - 2017-08-22 05:26:48 --> Controller Class Initialized
INFO - 2017-08-22 05:26:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:26:48 --> Final output sent to browser
DEBUG - 2017-08-22 05:26:48 --> Total execution time: 0.1834
INFO - 2017-08-22 05:27:01 --> Config Class Initialized
INFO - 2017-08-22 05:27:01 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:27:01 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:27:01 --> Utf8 Class Initialized
INFO - 2017-08-22 05:27:01 --> URI Class Initialized
DEBUG - 2017-08-22 05:27:01 --> No URI present. Default controller set.
INFO - 2017-08-22 05:27:01 --> Router Class Initialized
INFO - 2017-08-22 05:27:01 --> Output Class Initialized
INFO - 2017-08-22 05:27:01 --> Security Class Initialized
DEBUG - 2017-08-22 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:27:01 --> Input Class Initialized
INFO - 2017-08-22 05:27:01 --> Language Class Initialized
INFO - 2017-08-22 05:27:01 --> Loader Class Initialized
INFO - 2017-08-22 05:27:01 --> Helper loaded: url_helper
INFO - 2017-08-22 05:27:01 --> Helper loaded: file_helper
INFO - 2017-08-22 05:27:01 --> Database Driver Class Initialized
INFO - 2017-08-22 05:27:01 --> Email Class Initialized
DEBUG - 2017-08-22 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:27:01 --> Table Class Initialized
INFO - 2017-08-22 05:27:01 --> Controller Class Initialized
INFO - 2017-08-22 05:27:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:27:01 --> Final output sent to browser
DEBUG - 2017-08-22 05:27:01 --> Total execution time: 0.1984
INFO - 2017-08-22 05:27:11 --> Config Class Initialized
INFO - 2017-08-22 05:27:11 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:27:11 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:27:11 --> Utf8 Class Initialized
INFO - 2017-08-22 05:27:11 --> URI Class Initialized
DEBUG - 2017-08-22 05:27:11 --> No URI present. Default controller set.
INFO - 2017-08-22 05:27:11 --> Router Class Initialized
INFO - 2017-08-22 05:27:11 --> Output Class Initialized
INFO - 2017-08-22 05:27:11 --> Security Class Initialized
DEBUG - 2017-08-22 05:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:27:11 --> Input Class Initialized
INFO - 2017-08-22 05:27:11 --> Language Class Initialized
INFO - 2017-08-22 05:27:11 --> Loader Class Initialized
INFO - 2017-08-22 05:27:11 --> Helper loaded: url_helper
INFO - 2017-08-22 05:27:11 --> Helper loaded: file_helper
INFO - 2017-08-22 05:27:11 --> Database Driver Class Initialized
INFO - 2017-08-22 05:27:11 --> Email Class Initialized
DEBUG - 2017-08-22 05:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:27:11 --> Table Class Initialized
INFO - 2017-08-22 05:27:11 --> Controller Class Initialized
INFO - 2017-08-22 05:27:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:27:11 --> Final output sent to browser
DEBUG - 2017-08-22 05:27:11 --> Total execution time: 0.1915
INFO - 2017-08-22 05:27:16 --> Config Class Initialized
INFO - 2017-08-22 05:27:16 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:27:16 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:27:16 --> Utf8 Class Initialized
INFO - 2017-08-22 05:27:16 --> URI Class Initialized
DEBUG - 2017-08-22 05:27:16 --> No URI present. Default controller set.
INFO - 2017-08-22 05:27:16 --> Router Class Initialized
INFO - 2017-08-22 05:27:16 --> Output Class Initialized
INFO - 2017-08-22 05:27:16 --> Security Class Initialized
DEBUG - 2017-08-22 05:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:27:16 --> Input Class Initialized
INFO - 2017-08-22 05:27:16 --> Language Class Initialized
INFO - 2017-08-22 05:27:16 --> Loader Class Initialized
INFO - 2017-08-22 05:27:16 --> Helper loaded: url_helper
INFO - 2017-08-22 05:27:16 --> Helper loaded: file_helper
INFO - 2017-08-22 05:27:16 --> Database Driver Class Initialized
INFO - 2017-08-22 05:27:17 --> Email Class Initialized
DEBUG - 2017-08-22 05:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:27:17 --> Table Class Initialized
INFO - 2017-08-22 05:27:17 --> Controller Class Initialized
INFO - 2017-08-22 05:27:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:27:17 --> Final output sent to browser
DEBUG - 2017-08-22 05:27:17 --> Total execution time: 0.1969
INFO - 2017-08-22 05:27:23 --> Config Class Initialized
INFO - 2017-08-22 05:27:23 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:27:23 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:27:24 --> Utf8 Class Initialized
INFO - 2017-08-22 05:27:24 --> URI Class Initialized
DEBUG - 2017-08-22 05:27:24 --> No URI present. Default controller set.
INFO - 2017-08-22 05:27:24 --> Router Class Initialized
INFO - 2017-08-22 05:27:24 --> Output Class Initialized
INFO - 2017-08-22 05:27:24 --> Security Class Initialized
DEBUG - 2017-08-22 05:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:27:24 --> Input Class Initialized
INFO - 2017-08-22 05:27:24 --> Language Class Initialized
INFO - 2017-08-22 05:27:24 --> Loader Class Initialized
INFO - 2017-08-22 05:27:24 --> Helper loaded: url_helper
INFO - 2017-08-22 05:27:24 --> Helper loaded: file_helper
INFO - 2017-08-22 05:27:24 --> Database Driver Class Initialized
INFO - 2017-08-22 05:27:24 --> Email Class Initialized
DEBUG - 2017-08-22 05:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:27:24 --> Table Class Initialized
INFO - 2017-08-22 05:27:24 --> Controller Class Initialized
INFO - 2017-08-22 05:27:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:27:24 --> Final output sent to browser
DEBUG - 2017-08-22 05:27:24 --> Total execution time: 0.1968
INFO - 2017-08-22 05:28:58 --> Config Class Initialized
INFO - 2017-08-22 05:28:58 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:28:58 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:28:58 --> Utf8 Class Initialized
INFO - 2017-08-22 05:28:58 --> URI Class Initialized
DEBUG - 2017-08-22 05:28:58 --> No URI present. Default controller set.
INFO - 2017-08-22 05:28:58 --> Router Class Initialized
INFO - 2017-08-22 05:28:58 --> Output Class Initialized
INFO - 2017-08-22 05:28:58 --> Security Class Initialized
DEBUG - 2017-08-22 05:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:28:58 --> Input Class Initialized
INFO - 2017-08-22 05:28:58 --> Language Class Initialized
INFO - 2017-08-22 05:28:58 --> Loader Class Initialized
INFO - 2017-08-22 05:28:58 --> Helper loaded: url_helper
INFO - 2017-08-22 05:28:58 --> Helper loaded: file_helper
INFO - 2017-08-22 05:28:58 --> Database Driver Class Initialized
INFO - 2017-08-22 05:28:58 --> Email Class Initialized
DEBUG - 2017-08-22 05:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:28:58 --> Table Class Initialized
INFO - 2017-08-22 05:28:58 --> Controller Class Initialized
INFO - 2017-08-22 05:28:58 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:28:58 --> Final output sent to browser
DEBUG - 2017-08-22 05:28:58 --> Total execution time: 0.1943
INFO - 2017-08-22 05:29:02 --> Config Class Initialized
INFO - 2017-08-22 05:29:02 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:29:02 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:29:02 --> Utf8 Class Initialized
INFO - 2017-08-22 05:29:02 --> URI Class Initialized
DEBUG - 2017-08-22 05:29:02 --> No URI present. Default controller set.
INFO - 2017-08-22 05:29:02 --> Router Class Initialized
INFO - 2017-08-22 05:29:02 --> Output Class Initialized
INFO - 2017-08-22 05:29:02 --> Security Class Initialized
DEBUG - 2017-08-22 05:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:29:02 --> Input Class Initialized
INFO - 2017-08-22 05:29:02 --> Language Class Initialized
INFO - 2017-08-22 05:29:02 --> Loader Class Initialized
INFO - 2017-08-22 05:29:02 --> Helper loaded: url_helper
INFO - 2017-08-22 05:29:02 --> Helper loaded: file_helper
INFO - 2017-08-22 05:29:02 --> Database Driver Class Initialized
INFO - 2017-08-22 05:29:02 --> Email Class Initialized
DEBUG - 2017-08-22 05:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:29:02 --> Table Class Initialized
INFO - 2017-08-22 05:29:02 --> Controller Class Initialized
INFO - 2017-08-22 05:29:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:29:02 --> Final output sent to browser
DEBUG - 2017-08-22 05:29:02 --> Total execution time: 0.1935
INFO - 2017-08-22 05:29:12 --> Config Class Initialized
INFO - 2017-08-22 05:29:12 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:29:12 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:29:12 --> Utf8 Class Initialized
INFO - 2017-08-22 05:29:12 --> URI Class Initialized
DEBUG - 2017-08-22 05:29:12 --> No URI present. Default controller set.
INFO - 2017-08-22 05:29:12 --> Router Class Initialized
INFO - 2017-08-22 05:29:12 --> Output Class Initialized
INFO - 2017-08-22 05:29:12 --> Security Class Initialized
DEBUG - 2017-08-22 05:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:29:12 --> Input Class Initialized
INFO - 2017-08-22 05:29:12 --> Language Class Initialized
INFO - 2017-08-22 05:29:12 --> Loader Class Initialized
INFO - 2017-08-22 05:29:12 --> Helper loaded: url_helper
INFO - 2017-08-22 05:29:12 --> Helper loaded: file_helper
INFO - 2017-08-22 05:29:12 --> Database Driver Class Initialized
INFO - 2017-08-22 05:29:12 --> Email Class Initialized
DEBUG - 2017-08-22 05:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:29:12 --> Table Class Initialized
INFO - 2017-08-22 05:29:12 --> Controller Class Initialized
INFO - 2017-08-22 05:29:12 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:29:12 --> Final output sent to browser
DEBUG - 2017-08-22 05:29:12 --> Total execution time: 0.1948
INFO - 2017-08-22 05:29:40 --> Config Class Initialized
INFO - 2017-08-22 05:29:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:29:40 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:29:40 --> Utf8 Class Initialized
INFO - 2017-08-22 05:29:40 --> URI Class Initialized
DEBUG - 2017-08-22 05:29:40 --> No URI present. Default controller set.
INFO - 2017-08-22 05:29:40 --> Router Class Initialized
INFO - 2017-08-22 05:29:40 --> Output Class Initialized
INFO - 2017-08-22 05:29:40 --> Security Class Initialized
DEBUG - 2017-08-22 05:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:29:40 --> Input Class Initialized
INFO - 2017-08-22 05:29:40 --> Language Class Initialized
INFO - 2017-08-22 05:29:40 --> Loader Class Initialized
INFO - 2017-08-22 05:29:40 --> Helper loaded: url_helper
INFO - 2017-08-22 05:29:40 --> Helper loaded: file_helper
INFO - 2017-08-22 05:29:40 --> Database Driver Class Initialized
INFO - 2017-08-22 05:29:40 --> Email Class Initialized
DEBUG - 2017-08-22 05:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:29:40 --> Table Class Initialized
INFO - 2017-08-22 05:29:40 --> Controller Class Initialized
INFO - 2017-08-22 05:29:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:29:40 --> Final output sent to browser
DEBUG - 2017-08-22 05:29:41 --> Total execution time: 0.1998
INFO - 2017-08-22 05:30:18 --> Config Class Initialized
INFO - 2017-08-22 05:30:18 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:30:18 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:30:18 --> Utf8 Class Initialized
INFO - 2017-08-22 05:30:18 --> URI Class Initialized
DEBUG - 2017-08-22 05:30:18 --> No URI present. Default controller set.
INFO - 2017-08-22 05:30:18 --> Router Class Initialized
INFO - 2017-08-22 05:30:18 --> Output Class Initialized
INFO - 2017-08-22 05:30:18 --> Security Class Initialized
DEBUG - 2017-08-22 05:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:30:18 --> Input Class Initialized
INFO - 2017-08-22 05:30:18 --> Language Class Initialized
INFO - 2017-08-22 05:30:18 --> Loader Class Initialized
INFO - 2017-08-22 05:30:18 --> Helper loaded: url_helper
INFO - 2017-08-22 05:30:18 --> Helper loaded: file_helper
INFO - 2017-08-22 05:30:18 --> Database Driver Class Initialized
INFO - 2017-08-22 05:30:18 --> Email Class Initialized
DEBUG - 2017-08-22 05:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:30:18 --> Table Class Initialized
INFO - 2017-08-22 05:30:18 --> Controller Class Initialized
INFO - 2017-08-22 05:30:18 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:30:18 --> Final output sent to browser
DEBUG - 2017-08-22 05:30:18 --> Total execution time: 0.1958
INFO - 2017-08-22 05:30:21 --> Config Class Initialized
INFO - 2017-08-22 05:30:21 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:30:21 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:30:21 --> Utf8 Class Initialized
INFO - 2017-08-22 05:30:21 --> URI Class Initialized
DEBUG - 2017-08-22 05:30:21 --> No URI present. Default controller set.
INFO - 2017-08-22 05:30:21 --> Router Class Initialized
INFO - 2017-08-22 05:30:21 --> Output Class Initialized
INFO - 2017-08-22 05:30:21 --> Security Class Initialized
DEBUG - 2017-08-22 05:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:30:21 --> Input Class Initialized
INFO - 2017-08-22 05:30:21 --> Language Class Initialized
INFO - 2017-08-22 05:30:21 --> Loader Class Initialized
INFO - 2017-08-22 05:30:21 --> Helper loaded: url_helper
INFO - 2017-08-22 05:30:21 --> Helper loaded: file_helper
INFO - 2017-08-22 05:30:21 --> Database Driver Class Initialized
INFO - 2017-08-22 05:30:21 --> Email Class Initialized
DEBUG - 2017-08-22 05:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:30:21 --> Table Class Initialized
INFO - 2017-08-22 05:30:21 --> Controller Class Initialized
INFO - 2017-08-22 05:30:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:30:21 --> Final output sent to browser
DEBUG - 2017-08-22 05:30:21 --> Total execution time: 0.1956
INFO - 2017-08-22 05:30:49 --> Config Class Initialized
INFO - 2017-08-22 05:30:49 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:30:49 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:30:49 --> Utf8 Class Initialized
INFO - 2017-08-22 05:30:49 --> URI Class Initialized
DEBUG - 2017-08-22 05:30:49 --> No URI present. Default controller set.
INFO - 2017-08-22 05:30:49 --> Router Class Initialized
INFO - 2017-08-22 05:30:49 --> Output Class Initialized
INFO - 2017-08-22 05:30:49 --> Security Class Initialized
DEBUG - 2017-08-22 05:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:30:49 --> Input Class Initialized
INFO - 2017-08-22 05:30:49 --> Language Class Initialized
INFO - 2017-08-22 05:30:49 --> Loader Class Initialized
INFO - 2017-08-22 05:30:49 --> Helper loaded: url_helper
INFO - 2017-08-22 05:30:49 --> Helper loaded: file_helper
INFO - 2017-08-22 05:30:49 --> Database Driver Class Initialized
INFO - 2017-08-22 05:30:49 --> Email Class Initialized
DEBUG - 2017-08-22 05:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:30:49 --> Table Class Initialized
INFO - 2017-08-22 05:30:49 --> Controller Class Initialized
INFO - 2017-08-22 05:30:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:30:49 --> Final output sent to browser
DEBUG - 2017-08-22 05:30:49 --> Total execution time: 0.1870
INFO - 2017-08-22 05:32:00 --> Config Class Initialized
INFO - 2017-08-22 05:32:00 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:32:00 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:32:00 --> Utf8 Class Initialized
INFO - 2017-08-22 05:32:00 --> URI Class Initialized
DEBUG - 2017-08-22 05:32:00 --> No URI present. Default controller set.
INFO - 2017-08-22 05:32:00 --> Router Class Initialized
INFO - 2017-08-22 05:32:00 --> Output Class Initialized
INFO - 2017-08-22 05:32:00 --> Security Class Initialized
DEBUG - 2017-08-22 05:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:32:00 --> Input Class Initialized
INFO - 2017-08-22 05:32:00 --> Language Class Initialized
INFO - 2017-08-22 05:32:00 --> Loader Class Initialized
INFO - 2017-08-22 05:32:00 --> Helper loaded: url_helper
INFO - 2017-08-22 05:32:00 --> Helper loaded: file_helper
INFO - 2017-08-22 05:32:00 --> Database Driver Class Initialized
INFO - 2017-08-22 05:32:00 --> Email Class Initialized
DEBUG - 2017-08-22 05:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:32:00 --> Table Class Initialized
INFO - 2017-08-22 05:32:00 --> Controller Class Initialized
INFO - 2017-08-22 05:32:00 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:32:00 --> Final output sent to browser
DEBUG - 2017-08-22 05:32:00 --> Total execution time: 0.1977
INFO - 2017-08-22 05:32:27 --> Config Class Initialized
INFO - 2017-08-22 05:32:27 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:32:27 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:32:27 --> Utf8 Class Initialized
INFO - 2017-08-22 05:32:27 --> URI Class Initialized
DEBUG - 2017-08-22 05:32:27 --> No URI present. Default controller set.
INFO - 2017-08-22 05:32:27 --> Router Class Initialized
INFO - 2017-08-22 05:32:27 --> Output Class Initialized
INFO - 2017-08-22 05:32:27 --> Security Class Initialized
DEBUG - 2017-08-22 05:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:32:27 --> Input Class Initialized
INFO - 2017-08-22 05:32:27 --> Language Class Initialized
INFO - 2017-08-22 05:32:27 --> Loader Class Initialized
INFO - 2017-08-22 05:32:27 --> Helper loaded: url_helper
INFO - 2017-08-22 05:32:27 --> Helper loaded: file_helper
INFO - 2017-08-22 05:32:27 --> Database Driver Class Initialized
INFO - 2017-08-22 05:32:27 --> Email Class Initialized
DEBUG - 2017-08-22 05:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:32:27 --> Table Class Initialized
INFO - 2017-08-22 05:32:27 --> Controller Class Initialized
INFO - 2017-08-22 05:32:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:32:27 --> Final output sent to browser
DEBUG - 2017-08-22 05:32:27 --> Total execution time: 0.1972
INFO - 2017-08-22 05:32:47 --> Config Class Initialized
INFO - 2017-08-22 05:32:47 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:32:47 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:32:47 --> Utf8 Class Initialized
INFO - 2017-08-22 05:32:47 --> URI Class Initialized
DEBUG - 2017-08-22 05:32:47 --> No URI present. Default controller set.
INFO - 2017-08-22 05:32:47 --> Router Class Initialized
INFO - 2017-08-22 05:32:47 --> Output Class Initialized
INFO - 2017-08-22 05:32:47 --> Security Class Initialized
DEBUG - 2017-08-22 05:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:32:47 --> Input Class Initialized
INFO - 2017-08-22 05:32:47 --> Language Class Initialized
INFO - 2017-08-22 05:32:47 --> Loader Class Initialized
INFO - 2017-08-22 05:32:47 --> Helper loaded: url_helper
INFO - 2017-08-22 05:32:47 --> Helper loaded: file_helper
INFO - 2017-08-22 05:32:47 --> Database Driver Class Initialized
INFO - 2017-08-22 05:32:47 --> Email Class Initialized
DEBUG - 2017-08-22 05:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:32:47 --> Table Class Initialized
INFO - 2017-08-22 05:32:47 --> Controller Class Initialized
INFO - 2017-08-22 05:32:47 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:32:47 --> Final output sent to browser
DEBUG - 2017-08-22 05:32:47 --> Total execution time: 0.1992
INFO - 2017-08-22 05:32:58 --> Config Class Initialized
INFO - 2017-08-22 05:32:58 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:32:58 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:32:58 --> Utf8 Class Initialized
INFO - 2017-08-22 05:32:58 --> URI Class Initialized
DEBUG - 2017-08-22 05:32:58 --> No URI present. Default controller set.
INFO - 2017-08-22 05:32:58 --> Router Class Initialized
INFO - 2017-08-22 05:32:58 --> Output Class Initialized
INFO - 2017-08-22 05:32:58 --> Security Class Initialized
DEBUG - 2017-08-22 05:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:32:58 --> Input Class Initialized
INFO - 2017-08-22 05:32:58 --> Language Class Initialized
INFO - 2017-08-22 05:32:58 --> Loader Class Initialized
INFO - 2017-08-22 05:32:58 --> Helper loaded: url_helper
INFO - 2017-08-22 05:32:58 --> Helper loaded: file_helper
INFO - 2017-08-22 05:32:58 --> Database Driver Class Initialized
INFO - 2017-08-22 05:32:58 --> Email Class Initialized
DEBUG - 2017-08-22 05:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:32:58 --> Table Class Initialized
INFO - 2017-08-22 05:32:58 --> Controller Class Initialized
INFO - 2017-08-22 05:32:58 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:32:58 --> Final output sent to browser
DEBUG - 2017-08-22 05:32:58 --> Total execution time: 0.1976
INFO - 2017-08-22 05:33:15 --> Config Class Initialized
INFO - 2017-08-22 05:33:15 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:33:15 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:33:15 --> Utf8 Class Initialized
INFO - 2017-08-22 05:33:15 --> URI Class Initialized
DEBUG - 2017-08-22 05:33:15 --> No URI present. Default controller set.
INFO - 2017-08-22 05:33:15 --> Router Class Initialized
INFO - 2017-08-22 05:33:15 --> Output Class Initialized
INFO - 2017-08-22 05:33:15 --> Security Class Initialized
DEBUG - 2017-08-22 05:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:33:15 --> Input Class Initialized
INFO - 2017-08-22 05:33:15 --> Language Class Initialized
INFO - 2017-08-22 05:33:15 --> Loader Class Initialized
INFO - 2017-08-22 05:33:15 --> Helper loaded: url_helper
INFO - 2017-08-22 05:33:15 --> Helper loaded: file_helper
INFO - 2017-08-22 05:33:15 --> Database Driver Class Initialized
INFO - 2017-08-22 05:33:15 --> Email Class Initialized
DEBUG - 2017-08-22 05:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:33:15 --> Table Class Initialized
INFO - 2017-08-22 05:33:15 --> Controller Class Initialized
INFO - 2017-08-22 05:33:15 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:33:15 --> Final output sent to browser
DEBUG - 2017-08-22 05:33:15 --> Total execution time: 0.1919
INFO - 2017-08-22 05:33:21 --> Config Class Initialized
INFO - 2017-08-22 05:33:21 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:33:21 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:33:21 --> Utf8 Class Initialized
INFO - 2017-08-22 05:33:21 --> URI Class Initialized
DEBUG - 2017-08-22 05:33:21 --> No URI present. Default controller set.
INFO - 2017-08-22 05:33:21 --> Router Class Initialized
INFO - 2017-08-22 05:33:21 --> Output Class Initialized
INFO - 2017-08-22 05:33:21 --> Security Class Initialized
DEBUG - 2017-08-22 05:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:33:21 --> Input Class Initialized
INFO - 2017-08-22 05:33:21 --> Language Class Initialized
INFO - 2017-08-22 05:33:21 --> Loader Class Initialized
INFO - 2017-08-22 05:33:22 --> Helper loaded: url_helper
INFO - 2017-08-22 05:33:22 --> Helper loaded: file_helper
INFO - 2017-08-22 05:33:22 --> Database Driver Class Initialized
INFO - 2017-08-22 05:33:22 --> Email Class Initialized
DEBUG - 2017-08-22 05:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:33:22 --> Table Class Initialized
INFO - 2017-08-22 05:33:22 --> Controller Class Initialized
INFO - 2017-08-22 05:33:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:33:22 --> Final output sent to browser
DEBUG - 2017-08-22 05:33:22 --> Total execution time: 0.2015
INFO - 2017-08-22 05:33:57 --> Config Class Initialized
INFO - 2017-08-22 05:33:57 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:33:57 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:33:57 --> Utf8 Class Initialized
INFO - 2017-08-22 05:33:57 --> URI Class Initialized
DEBUG - 2017-08-22 05:33:57 --> No URI present. Default controller set.
INFO - 2017-08-22 05:33:57 --> Router Class Initialized
INFO - 2017-08-22 05:33:57 --> Output Class Initialized
INFO - 2017-08-22 05:33:57 --> Security Class Initialized
DEBUG - 2017-08-22 05:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:33:57 --> Input Class Initialized
INFO - 2017-08-22 05:33:57 --> Language Class Initialized
INFO - 2017-08-22 05:33:57 --> Loader Class Initialized
INFO - 2017-08-22 05:33:57 --> Helper loaded: url_helper
INFO - 2017-08-22 05:33:57 --> Helper loaded: file_helper
INFO - 2017-08-22 05:33:57 --> Database Driver Class Initialized
INFO - 2017-08-22 05:33:57 --> Email Class Initialized
DEBUG - 2017-08-22 05:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:33:57 --> Table Class Initialized
INFO - 2017-08-22 05:33:57 --> Controller Class Initialized
INFO - 2017-08-22 05:33:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:33:57 --> Final output sent to browser
DEBUG - 2017-08-22 05:33:57 --> Total execution time: 0.2001
INFO - 2017-08-22 05:34:24 --> Config Class Initialized
INFO - 2017-08-22 05:34:24 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:34:24 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:34:24 --> Utf8 Class Initialized
INFO - 2017-08-22 05:34:24 --> URI Class Initialized
DEBUG - 2017-08-22 05:34:24 --> No URI present. Default controller set.
INFO - 2017-08-22 05:34:24 --> Router Class Initialized
INFO - 2017-08-22 05:34:24 --> Output Class Initialized
INFO - 2017-08-22 05:34:24 --> Security Class Initialized
DEBUG - 2017-08-22 05:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:34:24 --> Input Class Initialized
INFO - 2017-08-22 05:34:24 --> Language Class Initialized
INFO - 2017-08-22 05:34:24 --> Loader Class Initialized
INFO - 2017-08-22 05:34:24 --> Helper loaded: url_helper
INFO - 2017-08-22 05:34:24 --> Helper loaded: file_helper
INFO - 2017-08-22 05:34:24 --> Database Driver Class Initialized
INFO - 2017-08-22 05:34:24 --> Email Class Initialized
DEBUG - 2017-08-22 05:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:34:24 --> Table Class Initialized
INFO - 2017-08-22 05:34:24 --> Controller Class Initialized
INFO - 2017-08-22 05:34:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:34:24 --> Final output sent to browser
DEBUG - 2017-08-22 05:34:24 --> Total execution time: 0.1906
INFO - 2017-08-22 05:34:31 --> Config Class Initialized
INFO - 2017-08-22 05:34:31 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:34:31 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:34:31 --> Utf8 Class Initialized
INFO - 2017-08-22 05:34:31 --> URI Class Initialized
DEBUG - 2017-08-22 05:34:31 --> No URI present. Default controller set.
INFO - 2017-08-22 05:34:31 --> Router Class Initialized
INFO - 2017-08-22 05:34:31 --> Output Class Initialized
INFO - 2017-08-22 05:34:31 --> Security Class Initialized
DEBUG - 2017-08-22 05:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:34:31 --> Input Class Initialized
INFO - 2017-08-22 05:34:31 --> Language Class Initialized
INFO - 2017-08-22 05:34:31 --> Loader Class Initialized
INFO - 2017-08-22 05:34:31 --> Helper loaded: url_helper
INFO - 2017-08-22 05:34:31 --> Helper loaded: file_helper
INFO - 2017-08-22 05:34:31 --> Database Driver Class Initialized
INFO - 2017-08-22 05:34:31 --> Email Class Initialized
DEBUG - 2017-08-22 05:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:34:31 --> Table Class Initialized
INFO - 2017-08-22 05:34:31 --> Controller Class Initialized
INFO - 2017-08-22 05:34:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:34:31 --> Final output sent to browser
DEBUG - 2017-08-22 05:34:31 --> Total execution time: 0.2048
INFO - 2017-08-22 05:35:10 --> Config Class Initialized
INFO - 2017-08-22 05:35:10 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:35:10 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:35:10 --> Utf8 Class Initialized
INFO - 2017-08-22 05:35:10 --> URI Class Initialized
DEBUG - 2017-08-22 05:35:10 --> No URI present. Default controller set.
INFO - 2017-08-22 05:35:10 --> Router Class Initialized
INFO - 2017-08-22 05:35:10 --> Output Class Initialized
INFO - 2017-08-22 05:35:10 --> Security Class Initialized
DEBUG - 2017-08-22 05:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:35:10 --> Input Class Initialized
INFO - 2017-08-22 05:35:10 --> Language Class Initialized
INFO - 2017-08-22 05:35:10 --> Loader Class Initialized
INFO - 2017-08-22 05:35:10 --> Helper loaded: url_helper
INFO - 2017-08-22 05:35:10 --> Helper loaded: file_helper
INFO - 2017-08-22 05:35:10 --> Database Driver Class Initialized
INFO - 2017-08-22 05:35:10 --> Email Class Initialized
DEBUG - 2017-08-22 05:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:35:11 --> Table Class Initialized
INFO - 2017-08-22 05:35:11 --> Controller Class Initialized
INFO - 2017-08-22 05:35:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:35:11 --> Final output sent to browser
DEBUG - 2017-08-22 05:35:11 --> Total execution time: 0.2099
INFO - 2017-08-22 05:35:29 --> Config Class Initialized
INFO - 2017-08-22 05:35:29 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:35:29 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:35:29 --> Utf8 Class Initialized
INFO - 2017-08-22 05:35:29 --> URI Class Initialized
DEBUG - 2017-08-22 05:35:29 --> No URI present. Default controller set.
INFO - 2017-08-22 05:35:29 --> Router Class Initialized
INFO - 2017-08-22 05:35:29 --> Output Class Initialized
INFO - 2017-08-22 05:35:29 --> Security Class Initialized
DEBUG - 2017-08-22 05:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:35:29 --> Input Class Initialized
INFO - 2017-08-22 05:35:29 --> Language Class Initialized
INFO - 2017-08-22 05:35:29 --> Loader Class Initialized
INFO - 2017-08-22 05:35:29 --> Helper loaded: url_helper
INFO - 2017-08-22 05:35:29 --> Helper loaded: file_helper
INFO - 2017-08-22 05:35:29 --> Database Driver Class Initialized
INFO - 2017-08-22 05:35:29 --> Email Class Initialized
DEBUG - 2017-08-22 05:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:35:29 --> Table Class Initialized
INFO - 2017-08-22 05:35:29 --> Controller Class Initialized
INFO - 2017-08-22 05:35:29 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:35:29 --> Final output sent to browser
DEBUG - 2017-08-22 05:35:29 --> Total execution time: 0.1946
INFO - 2017-08-22 05:36:03 --> Config Class Initialized
INFO - 2017-08-22 05:36:03 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:36:03 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:36:03 --> Utf8 Class Initialized
INFO - 2017-08-22 05:36:03 --> URI Class Initialized
DEBUG - 2017-08-22 05:36:03 --> No URI present. Default controller set.
INFO - 2017-08-22 05:36:03 --> Router Class Initialized
INFO - 2017-08-22 05:36:03 --> Output Class Initialized
INFO - 2017-08-22 05:36:03 --> Security Class Initialized
DEBUG - 2017-08-22 05:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:36:03 --> Input Class Initialized
INFO - 2017-08-22 05:36:03 --> Language Class Initialized
INFO - 2017-08-22 05:36:03 --> Loader Class Initialized
INFO - 2017-08-22 05:36:04 --> Helper loaded: url_helper
INFO - 2017-08-22 05:36:04 --> Helper loaded: file_helper
INFO - 2017-08-22 05:36:04 --> Database Driver Class Initialized
INFO - 2017-08-22 05:36:04 --> Email Class Initialized
DEBUG - 2017-08-22 05:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:36:04 --> Table Class Initialized
INFO - 2017-08-22 05:36:04 --> Controller Class Initialized
INFO - 2017-08-22 05:36:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:36:04 --> Final output sent to browser
DEBUG - 2017-08-22 05:36:04 --> Total execution time: 0.2032
INFO - 2017-08-22 05:36:21 --> Config Class Initialized
INFO - 2017-08-22 05:36:21 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:36:21 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:36:21 --> Utf8 Class Initialized
INFO - 2017-08-22 05:36:21 --> URI Class Initialized
DEBUG - 2017-08-22 05:36:21 --> No URI present. Default controller set.
INFO - 2017-08-22 05:36:21 --> Router Class Initialized
INFO - 2017-08-22 05:36:21 --> Output Class Initialized
INFO - 2017-08-22 05:36:21 --> Security Class Initialized
DEBUG - 2017-08-22 05:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:36:21 --> Input Class Initialized
INFO - 2017-08-22 05:36:21 --> Language Class Initialized
INFO - 2017-08-22 05:36:21 --> Loader Class Initialized
INFO - 2017-08-22 05:36:21 --> Helper loaded: url_helper
INFO - 2017-08-22 05:36:21 --> Helper loaded: file_helper
INFO - 2017-08-22 05:36:21 --> Database Driver Class Initialized
INFO - 2017-08-22 05:36:21 --> Email Class Initialized
DEBUG - 2017-08-22 05:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:36:21 --> Table Class Initialized
INFO - 2017-08-22 05:36:21 --> Controller Class Initialized
INFO - 2017-08-22 05:36:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:36:21 --> Final output sent to browser
DEBUG - 2017-08-22 05:36:21 --> Total execution time: 0.1924
INFO - 2017-08-22 05:46:48 --> Config Class Initialized
INFO - 2017-08-22 05:46:48 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:46:48 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:46:48 --> Utf8 Class Initialized
INFO - 2017-08-22 05:46:48 --> URI Class Initialized
DEBUG - 2017-08-22 05:46:48 --> No URI present. Default controller set.
INFO - 2017-08-22 05:46:48 --> Router Class Initialized
INFO - 2017-08-22 05:46:48 --> Output Class Initialized
INFO - 2017-08-22 05:46:48 --> Security Class Initialized
DEBUG - 2017-08-22 05:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:46:48 --> Input Class Initialized
INFO - 2017-08-22 05:46:48 --> Language Class Initialized
INFO - 2017-08-22 05:46:48 --> Loader Class Initialized
INFO - 2017-08-22 05:46:48 --> Helper loaded: url_helper
INFO - 2017-08-22 05:46:48 --> Helper loaded: file_helper
INFO - 2017-08-22 05:46:48 --> Database Driver Class Initialized
INFO - 2017-08-22 05:46:48 --> Email Class Initialized
DEBUG - 2017-08-22 05:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:46:48 --> Table Class Initialized
INFO - 2017-08-22 05:46:48 --> Controller Class Initialized
INFO - 2017-08-22 05:46:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:46:48 --> Final output sent to browser
DEBUG - 2017-08-22 05:46:48 --> Total execution time: 0.2000
INFO - 2017-08-22 05:46:57 --> Config Class Initialized
INFO - 2017-08-22 05:46:57 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:46:57 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:46:57 --> Utf8 Class Initialized
INFO - 2017-08-22 05:46:57 --> URI Class Initialized
DEBUG - 2017-08-22 05:46:57 --> No URI present. Default controller set.
INFO - 2017-08-22 05:46:57 --> Router Class Initialized
INFO - 2017-08-22 05:46:57 --> Output Class Initialized
INFO - 2017-08-22 05:46:57 --> Security Class Initialized
DEBUG - 2017-08-22 05:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:46:57 --> Input Class Initialized
INFO - 2017-08-22 05:46:57 --> Language Class Initialized
INFO - 2017-08-22 05:46:57 --> Loader Class Initialized
INFO - 2017-08-22 05:46:57 --> Helper loaded: url_helper
INFO - 2017-08-22 05:46:57 --> Helper loaded: file_helper
INFO - 2017-08-22 05:46:57 --> Database Driver Class Initialized
INFO - 2017-08-22 05:46:57 --> Email Class Initialized
DEBUG - 2017-08-22 05:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:46:57 --> Table Class Initialized
INFO - 2017-08-22 05:46:57 --> Controller Class Initialized
INFO - 2017-08-22 05:46:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:46:57 --> Final output sent to browser
DEBUG - 2017-08-22 05:46:57 --> Total execution time: 0.2076
INFO - 2017-08-22 05:47:06 --> Config Class Initialized
INFO - 2017-08-22 05:47:06 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:47:06 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:47:06 --> Utf8 Class Initialized
INFO - 2017-08-22 05:47:06 --> URI Class Initialized
INFO - 2017-08-22 05:47:06 --> Router Class Initialized
INFO - 2017-08-22 05:47:06 --> Output Class Initialized
INFO - 2017-08-22 05:47:06 --> Security Class Initialized
DEBUG - 2017-08-22 05:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:47:06 --> Input Class Initialized
INFO - 2017-08-22 05:47:06 --> Language Class Initialized
ERROR - 2017-08-22 05:47:06 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:49:30 --> Config Class Initialized
INFO - 2017-08-22 05:49:30 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:49:30 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:49:30 --> Utf8 Class Initialized
INFO - 2017-08-22 05:49:30 --> URI Class Initialized
DEBUG - 2017-08-22 05:49:30 --> No URI present. Default controller set.
INFO - 2017-08-22 05:49:30 --> Router Class Initialized
INFO - 2017-08-22 05:49:31 --> Output Class Initialized
INFO - 2017-08-22 05:49:31 --> Security Class Initialized
DEBUG - 2017-08-22 05:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:49:31 --> Input Class Initialized
INFO - 2017-08-22 05:49:31 --> Language Class Initialized
INFO - 2017-08-22 05:49:31 --> Loader Class Initialized
INFO - 2017-08-22 05:49:31 --> Helper loaded: url_helper
INFO - 2017-08-22 05:49:31 --> Helper loaded: file_helper
INFO - 2017-08-22 05:49:31 --> Database Driver Class Initialized
INFO - 2017-08-22 05:49:31 --> Email Class Initialized
DEBUG - 2017-08-22 05:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:49:31 --> Table Class Initialized
INFO - 2017-08-22 05:49:31 --> Controller Class Initialized
INFO - 2017-08-22 05:49:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:49:31 --> Final output sent to browser
DEBUG - 2017-08-22 05:49:31 --> Total execution time: 0.2202
INFO - 2017-08-22 05:49:31 --> Config Class Initialized
INFO - 2017-08-22 05:49:31 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:49:31 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:49:31 --> Utf8 Class Initialized
INFO - 2017-08-22 05:49:31 --> URI Class Initialized
INFO - 2017-08-22 05:49:31 --> Router Class Initialized
INFO - 2017-08-22 05:49:31 --> Output Class Initialized
INFO - 2017-08-22 05:49:31 --> Security Class Initialized
DEBUG - 2017-08-22 05:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:49:31 --> Input Class Initialized
INFO - 2017-08-22 05:49:31 --> Language Class Initialized
ERROR - 2017-08-22 05:49:31 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:49:31 --> Config Class Initialized
INFO - 2017-08-22 05:49:31 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:49:31 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:49:31 --> Utf8 Class Initialized
INFO - 2017-08-22 05:49:31 --> URI Class Initialized
INFO - 2017-08-22 05:49:31 --> Router Class Initialized
INFO - 2017-08-22 05:49:31 --> Output Class Initialized
INFO - 2017-08-22 05:49:31 --> Security Class Initialized
DEBUG - 2017-08-22 05:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:49:31 --> Input Class Initialized
INFO - 2017-08-22 05:49:31 --> Language Class Initialized
ERROR - 2017-08-22 05:49:31 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:49:41 --> Config Class Initialized
INFO - 2017-08-22 05:49:41 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:49:41 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:49:41 --> Utf8 Class Initialized
INFO - 2017-08-22 05:49:41 --> URI Class Initialized
DEBUG - 2017-08-22 05:49:41 --> No URI present. Default controller set.
INFO - 2017-08-22 05:49:41 --> Router Class Initialized
INFO - 2017-08-22 05:49:41 --> Output Class Initialized
INFO - 2017-08-22 05:49:41 --> Security Class Initialized
DEBUG - 2017-08-22 05:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:49:41 --> Input Class Initialized
INFO - 2017-08-22 05:49:41 --> Language Class Initialized
INFO - 2017-08-22 05:49:41 --> Loader Class Initialized
INFO - 2017-08-22 05:49:41 --> Helper loaded: url_helper
INFO - 2017-08-22 05:49:41 --> Helper loaded: file_helper
INFO - 2017-08-22 05:49:41 --> Database Driver Class Initialized
INFO - 2017-08-22 05:49:41 --> Email Class Initialized
DEBUG - 2017-08-22 05:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:49:41 --> Table Class Initialized
INFO - 2017-08-22 05:49:41 --> Controller Class Initialized
INFO - 2017-08-22 05:49:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:49:41 --> Final output sent to browser
DEBUG - 2017-08-22 05:49:41 --> Total execution time: 0.2278
INFO - 2017-08-22 05:49:42 --> Config Class Initialized
INFO - 2017-08-22 05:49:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:49:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:49:42 --> Utf8 Class Initialized
INFO - 2017-08-22 05:49:42 --> URI Class Initialized
INFO - 2017-08-22 05:49:42 --> Router Class Initialized
INFO - 2017-08-22 05:49:42 --> Output Class Initialized
INFO - 2017-08-22 05:49:42 --> Security Class Initialized
DEBUG - 2017-08-22 05:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:49:42 --> Input Class Initialized
INFO - 2017-08-22 05:49:42 --> Language Class Initialized
ERROR - 2017-08-22 05:49:42 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:49:42 --> Config Class Initialized
INFO - 2017-08-22 05:49:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:49:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:49:42 --> Utf8 Class Initialized
INFO - 2017-08-22 05:49:42 --> URI Class Initialized
INFO - 2017-08-22 05:49:42 --> Router Class Initialized
INFO - 2017-08-22 05:49:42 --> Output Class Initialized
INFO - 2017-08-22 05:49:42 --> Security Class Initialized
DEBUG - 2017-08-22 05:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:49:42 --> Input Class Initialized
INFO - 2017-08-22 05:49:42 --> Language Class Initialized
ERROR - 2017-08-22 05:49:42 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:50:03 --> Config Class Initialized
INFO - 2017-08-22 05:50:03 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:50:03 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:50:03 --> Utf8 Class Initialized
INFO - 2017-08-22 05:50:03 --> URI Class Initialized
DEBUG - 2017-08-22 05:50:03 --> No URI present. Default controller set.
INFO - 2017-08-22 05:50:03 --> Router Class Initialized
INFO - 2017-08-22 05:50:03 --> Output Class Initialized
INFO - 2017-08-22 05:50:03 --> Security Class Initialized
DEBUG - 2017-08-22 05:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:50:03 --> Input Class Initialized
INFO - 2017-08-22 05:50:03 --> Language Class Initialized
INFO - 2017-08-22 05:50:03 --> Loader Class Initialized
INFO - 2017-08-22 05:50:03 --> Helper loaded: url_helper
INFO - 2017-08-22 05:50:03 --> Helper loaded: file_helper
INFO - 2017-08-22 05:50:03 --> Database Driver Class Initialized
INFO - 2017-08-22 05:50:03 --> Email Class Initialized
DEBUG - 2017-08-22 05:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:50:04 --> Table Class Initialized
INFO - 2017-08-22 05:50:04 --> Controller Class Initialized
INFO - 2017-08-22 05:50:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:50:04 --> Final output sent to browser
DEBUG - 2017-08-22 05:50:04 --> Total execution time: 0.2302
INFO - 2017-08-22 05:50:04 --> Config Class Initialized
INFO - 2017-08-22 05:50:04 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:50:04 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:50:04 --> Utf8 Class Initialized
INFO - 2017-08-22 05:50:04 --> URI Class Initialized
INFO - 2017-08-22 05:50:04 --> Router Class Initialized
INFO - 2017-08-22 05:50:04 --> Output Class Initialized
INFO - 2017-08-22 05:50:04 --> Security Class Initialized
DEBUG - 2017-08-22 05:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:50:04 --> Input Class Initialized
INFO - 2017-08-22 05:50:04 --> Language Class Initialized
ERROR - 2017-08-22 05:50:04 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:50:04 --> Config Class Initialized
INFO - 2017-08-22 05:50:04 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:50:04 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:50:04 --> Utf8 Class Initialized
INFO - 2017-08-22 05:50:04 --> URI Class Initialized
INFO - 2017-08-22 05:50:04 --> Router Class Initialized
INFO - 2017-08-22 05:50:04 --> Output Class Initialized
INFO - 2017-08-22 05:50:04 --> Security Class Initialized
DEBUG - 2017-08-22 05:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:50:04 --> Input Class Initialized
INFO - 2017-08-22 05:50:04 --> Language Class Initialized
ERROR - 2017-08-22 05:50:04 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:50:19 --> Config Class Initialized
INFO - 2017-08-22 05:50:19 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:50:19 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:50:19 --> Utf8 Class Initialized
INFO - 2017-08-22 05:50:19 --> URI Class Initialized
DEBUG - 2017-08-22 05:50:19 --> No URI present. Default controller set.
INFO - 2017-08-22 05:50:19 --> Router Class Initialized
INFO - 2017-08-22 05:50:19 --> Output Class Initialized
INFO - 2017-08-22 05:50:19 --> Security Class Initialized
DEBUG - 2017-08-22 05:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:50:19 --> Input Class Initialized
INFO - 2017-08-22 05:50:19 --> Language Class Initialized
INFO - 2017-08-22 05:50:19 --> Loader Class Initialized
INFO - 2017-08-22 05:50:19 --> Helper loaded: url_helper
INFO - 2017-08-22 05:50:19 --> Helper loaded: file_helper
INFO - 2017-08-22 05:50:19 --> Database Driver Class Initialized
INFO - 2017-08-22 05:50:19 --> Email Class Initialized
DEBUG - 2017-08-22 05:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:50:19 --> Table Class Initialized
INFO - 2017-08-22 05:50:19 --> Controller Class Initialized
INFO - 2017-08-22 05:50:19 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:50:19 --> Final output sent to browser
DEBUG - 2017-08-22 05:50:19 --> Total execution time: 0.2142
INFO - 2017-08-22 05:50:19 --> Config Class Initialized
INFO - 2017-08-22 05:50:19 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:50:19 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:50:19 --> Utf8 Class Initialized
INFO - 2017-08-22 05:50:19 --> URI Class Initialized
INFO - 2017-08-22 05:50:19 --> Router Class Initialized
INFO - 2017-08-22 05:50:19 --> Output Class Initialized
INFO - 2017-08-22 05:50:19 --> Security Class Initialized
DEBUG - 2017-08-22 05:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:50:19 --> Input Class Initialized
INFO - 2017-08-22 05:50:19 --> Language Class Initialized
ERROR - 2017-08-22 05:50:19 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:50:20 --> Config Class Initialized
INFO - 2017-08-22 05:50:20 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:50:20 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:50:20 --> Utf8 Class Initialized
INFO - 2017-08-22 05:50:20 --> URI Class Initialized
INFO - 2017-08-22 05:50:20 --> Router Class Initialized
INFO - 2017-08-22 05:50:20 --> Output Class Initialized
INFO - 2017-08-22 05:50:20 --> Security Class Initialized
DEBUG - 2017-08-22 05:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:50:20 --> Input Class Initialized
INFO - 2017-08-22 05:50:20 --> Language Class Initialized
ERROR - 2017-08-22 05:50:20 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:50:45 --> Config Class Initialized
INFO - 2017-08-22 05:50:45 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:50:45 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:50:45 --> Utf8 Class Initialized
INFO - 2017-08-22 05:50:45 --> URI Class Initialized
DEBUG - 2017-08-22 05:50:45 --> No URI present. Default controller set.
INFO - 2017-08-22 05:50:45 --> Router Class Initialized
INFO - 2017-08-22 05:50:45 --> Output Class Initialized
INFO - 2017-08-22 05:50:45 --> Security Class Initialized
DEBUG - 2017-08-22 05:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:50:45 --> Input Class Initialized
INFO - 2017-08-22 05:50:45 --> Language Class Initialized
INFO - 2017-08-22 05:50:45 --> Loader Class Initialized
INFO - 2017-08-22 05:50:45 --> Helper loaded: url_helper
INFO - 2017-08-22 05:50:45 --> Helper loaded: file_helper
INFO - 2017-08-22 05:50:45 --> Database Driver Class Initialized
INFO - 2017-08-22 05:50:45 --> Email Class Initialized
DEBUG - 2017-08-22 05:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:50:45 --> Table Class Initialized
INFO - 2017-08-22 05:50:45 --> Controller Class Initialized
INFO - 2017-08-22 05:50:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:50:45 --> Final output sent to browser
DEBUG - 2017-08-22 05:50:45 --> Total execution time: 0.2175
INFO - 2017-08-22 05:50:45 --> Config Class Initialized
INFO - 2017-08-22 05:50:45 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:50:45 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:50:45 --> Utf8 Class Initialized
INFO - 2017-08-22 05:50:45 --> URI Class Initialized
INFO - 2017-08-22 05:50:45 --> Router Class Initialized
INFO - 2017-08-22 05:50:45 --> Output Class Initialized
INFO - 2017-08-22 05:50:45 --> Security Class Initialized
DEBUG - 2017-08-22 05:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:50:45 --> Input Class Initialized
INFO - 2017-08-22 05:50:45 --> Language Class Initialized
ERROR - 2017-08-22 05:50:45 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:50:45 --> Config Class Initialized
INFO - 2017-08-22 05:50:45 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:50:45 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:50:46 --> Utf8 Class Initialized
INFO - 2017-08-22 05:50:46 --> URI Class Initialized
INFO - 2017-08-22 05:50:46 --> Router Class Initialized
INFO - 2017-08-22 05:50:46 --> Output Class Initialized
INFO - 2017-08-22 05:50:46 --> Security Class Initialized
DEBUG - 2017-08-22 05:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:50:46 --> Input Class Initialized
INFO - 2017-08-22 05:50:46 --> Language Class Initialized
ERROR - 2017-08-22 05:50:46 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:52:34 --> Config Class Initialized
INFO - 2017-08-22 05:52:34 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:52:34 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:52:34 --> Utf8 Class Initialized
INFO - 2017-08-22 05:52:34 --> URI Class Initialized
DEBUG - 2017-08-22 05:52:34 --> No URI present. Default controller set.
INFO - 2017-08-22 05:52:34 --> Router Class Initialized
INFO - 2017-08-22 05:52:34 --> Output Class Initialized
INFO - 2017-08-22 05:52:34 --> Security Class Initialized
DEBUG - 2017-08-22 05:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:52:34 --> Input Class Initialized
INFO - 2017-08-22 05:52:34 --> Language Class Initialized
INFO - 2017-08-22 05:52:34 --> Loader Class Initialized
INFO - 2017-08-22 05:52:34 --> Helper loaded: url_helper
INFO - 2017-08-22 05:52:34 --> Helper loaded: file_helper
INFO - 2017-08-22 05:52:34 --> Database Driver Class Initialized
INFO - 2017-08-22 05:52:34 --> Email Class Initialized
DEBUG - 2017-08-22 05:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:52:34 --> Table Class Initialized
INFO - 2017-08-22 05:52:34 --> Controller Class Initialized
INFO - 2017-08-22 05:52:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:52:34 --> Final output sent to browser
DEBUG - 2017-08-22 05:52:34 --> Total execution time: 0.2172
INFO - 2017-08-22 05:52:34 --> Config Class Initialized
INFO - 2017-08-22 05:52:34 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:52:34 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:52:34 --> Utf8 Class Initialized
INFO - 2017-08-22 05:52:34 --> URI Class Initialized
INFO - 2017-08-22 05:52:34 --> Router Class Initialized
INFO - 2017-08-22 05:52:34 --> Output Class Initialized
INFO - 2017-08-22 05:52:34 --> Security Class Initialized
DEBUG - 2017-08-22 05:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:52:34 --> Input Class Initialized
INFO - 2017-08-22 05:52:34 --> Language Class Initialized
ERROR - 2017-08-22 05:52:34 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:52:35 --> Config Class Initialized
INFO - 2017-08-22 05:52:35 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:52:35 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:52:35 --> Utf8 Class Initialized
INFO - 2017-08-22 05:52:35 --> URI Class Initialized
INFO - 2017-08-22 05:52:35 --> Router Class Initialized
INFO - 2017-08-22 05:52:35 --> Output Class Initialized
INFO - 2017-08-22 05:52:35 --> Security Class Initialized
DEBUG - 2017-08-22 05:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:52:35 --> Input Class Initialized
INFO - 2017-08-22 05:52:35 --> Language Class Initialized
ERROR - 2017-08-22 05:52:35 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:52:47 --> Config Class Initialized
INFO - 2017-08-22 05:52:47 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:52:47 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:52:47 --> Utf8 Class Initialized
INFO - 2017-08-22 05:52:47 --> URI Class Initialized
DEBUG - 2017-08-22 05:52:47 --> No URI present. Default controller set.
INFO - 2017-08-22 05:52:47 --> Router Class Initialized
INFO - 2017-08-22 05:52:47 --> Output Class Initialized
INFO - 2017-08-22 05:52:47 --> Security Class Initialized
DEBUG - 2017-08-22 05:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:52:47 --> Input Class Initialized
INFO - 2017-08-22 05:52:47 --> Language Class Initialized
INFO - 2017-08-22 05:52:47 --> Loader Class Initialized
INFO - 2017-08-22 05:52:47 --> Helper loaded: url_helper
INFO - 2017-08-22 05:52:47 --> Helper loaded: file_helper
INFO - 2017-08-22 05:52:47 --> Database Driver Class Initialized
INFO - 2017-08-22 05:52:47 --> Email Class Initialized
DEBUG - 2017-08-22 05:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:52:47 --> Table Class Initialized
INFO - 2017-08-22 05:52:47 --> Controller Class Initialized
INFO - 2017-08-22 05:52:47 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:52:47 --> Final output sent to browser
DEBUG - 2017-08-22 05:52:47 --> Total execution time: 0.2070
INFO - 2017-08-22 05:52:47 --> Config Class Initialized
INFO - 2017-08-22 05:52:47 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:52:47 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:52:47 --> Utf8 Class Initialized
INFO - 2017-08-22 05:52:47 --> URI Class Initialized
INFO - 2017-08-22 05:52:47 --> Router Class Initialized
INFO - 2017-08-22 05:52:47 --> Output Class Initialized
INFO - 2017-08-22 05:52:47 --> Security Class Initialized
DEBUG - 2017-08-22 05:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:52:47 --> Input Class Initialized
INFO - 2017-08-22 05:52:47 --> Language Class Initialized
ERROR - 2017-08-22 05:52:47 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:52:48 --> Config Class Initialized
INFO - 2017-08-22 05:52:48 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:52:48 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:52:48 --> Utf8 Class Initialized
INFO - 2017-08-22 05:52:48 --> URI Class Initialized
INFO - 2017-08-22 05:52:48 --> Router Class Initialized
INFO - 2017-08-22 05:52:48 --> Output Class Initialized
INFO - 2017-08-22 05:52:48 --> Security Class Initialized
DEBUG - 2017-08-22 05:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:52:48 --> Input Class Initialized
INFO - 2017-08-22 05:52:48 --> Language Class Initialized
ERROR - 2017-08-22 05:52:48 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:52:51 --> Config Class Initialized
INFO - 2017-08-22 05:52:51 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:52:51 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:52:51 --> Utf8 Class Initialized
INFO - 2017-08-22 05:52:51 --> URI Class Initialized
DEBUG - 2017-08-22 05:52:51 --> No URI present. Default controller set.
INFO - 2017-08-22 05:52:51 --> Router Class Initialized
INFO - 2017-08-22 05:52:51 --> Output Class Initialized
INFO - 2017-08-22 05:52:51 --> Security Class Initialized
DEBUG - 2017-08-22 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:52:51 --> Input Class Initialized
INFO - 2017-08-22 05:52:51 --> Language Class Initialized
INFO - 2017-08-22 05:52:51 --> Loader Class Initialized
INFO - 2017-08-22 05:52:51 --> Helper loaded: url_helper
INFO - 2017-08-22 05:52:51 --> Helper loaded: file_helper
INFO - 2017-08-22 05:52:51 --> Database Driver Class Initialized
INFO - 2017-08-22 05:52:51 --> Email Class Initialized
DEBUG - 2017-08-22 05:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:52:51 --> Table Class Initialized
INFO - 2017-08-22 05:52:51 --> Controller Class Initialized
INFO - 2017-08-22 05:52:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:52:52 --> Final output sent to browser
DEBUG - 2017-08-22 05:52:52 --> Total execution time: 0.2138
INFO - 2017-08-22 05:52:52 --> Config Class Initialized
INFO - 2017-08-22 05:52:52 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:52:52 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:52:52 --> Utf8 Class Initialized
INFO - 2017-08-22 05:52:52 --> URI Class Initialized
INFO - 2017-08-22 05:52:52 --> Router Class Initialized
INFO - 2017-08-22 05:52:52 --> Output Class Initialized
INFO - 2017-08-22 05:52:52 --> Security Class Initialized
DEBUG - 2017-08-22 05:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:52:52 --> Input Class Initialized
INFO - 2017-08-22 05:52:52 --> Language Class Initialized
ERROR - 2017-08-22 05:52:52 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:52:52 --> Config Class Initialized
INFO - 2017-08-22 05:52:52 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:52:52 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:52:52 --> Utf8 Class Initialized
INFO - 2017-08-22 05:52:52 --> URI Class Initialized
INFO - 2017-08-22 05:52:52 --> Router Class Initialized
INFO - 2017-08-22 05:52:52 --> Output Class Initialized
INFO - 2017-08-22 05:52:52 --> Security Class Initialized
DEBUG - 2017-08-22 05:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:52:52 --> Input Class Initialized
INFO - 2017-08-22 05:52:52 --> Language Class Initialized
ERROR - 2017-08-22 05:52:52 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:54:45 --> Config Class Initialized
INFO - 2017-08-22 05:54:45 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:54:45 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:54:45 --> Utf8 Class Initialized
INFO - 2017-08-22 05:54:45 --> URI Class Initialized
DEBUG - 2017-08-22 05:54:45 --> No URI present. Default controller set.
INFO - 2017-08-22 05:54:45 --> Router Class Initialized
INFO - 2017-08-22 05:54:45 --> Output Class Initialized
INFO - 2017-08-22 05:54:45 --> Security Class Initialized
DEBUG - 2017-08-22 05:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:54:45 --> Input Class Initialized
INFO - 2017-08-22 05:54:45 --> Language Class Initialized
INFO - 2017-08-22 05:54:45 --> Loader Class Initialized
INFO - 2017-08-22 05:54:45 --> Helper loaded: url_helper
INFO - 2017-08-22 05:54:45 --> Helper loaded: file_helper
INFO - 2017-08-22 05:54:45 --> Database Driver Class Initialized
INFO - 2017-08-22 05:54:45 --> Email Class Initialized
DEBUG - 2017-08-22 05:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:54:45 --> Table Class Initialized
INFO - 2017-08-22 05:54:45 --> Controller Class Initialized
INFO - 2017-08-22 05:54:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:54:45 --> Final output sent to browser
DEBUG - 2017-08-22 05:54:45 --> Total execution time: 0.2033
INFO - 2017-08-22 05:54:46 --> Config Class Initialized
INFO - 2017-08-22 05:54:46 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:54:46 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:54:46 --> Utf8 Class Initialized
INFO - 2017-08-22 05:54:46 --> URI Class Initialized
INFO - 2017-08-22 05:54:46 --> Router Class Initialized
INFO - 2017-08-22 05:54:46 --> Output Class Initialized
INFO - 2017-08-22 05:54:46 --> Security Class Initialized
DEBUG - 2017-08-22 05:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:54:46 --> Input Class Initialized
INFO - 2017-08-22 05:54:46 --> Language Class Initialized
ERROR - 2017-08-22 05:54:46 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:54:46 --> Config Class Initialized
INFO - 2017-08-22 05:54:46 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:54:46 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:54:46 --> Utf8 Class Initialized
INFO - 2017-08-22 05:54:46 --> URI Class Initialized
INFO - 2017-08-22 05:54:46 --> Router Class Initialized
INFO - 2017-08-22 05:54:46 --> Output Class Initialized
INFO - 2017-08-22 05:54:46 --> Security Class Initialized
DEBUG - 2017-08-22 05:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:54:46 --> Input Class Initialized
INFO - 2017-08-22 05:54:46 --> Language Class Initialized
ERROR - 2017-08-22 05:54:46 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:55:00 --> Config Class Initialized
INFO - 2017-08-22 05:55:00 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:55:00 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:55:00 --> Utf8 Class Initialized
INFO - 2017-08-22 05:55:00 --> URI Class Initialized
DEBUG - 2017-08-22 05:55:00 --> No URI present. Default controller set.
INFO - 2017-08-22 05:55:00 --> Router Class Initialized
INFO - 2017-08-22 05:55:00 --> Output Class Initialized
INFO - 2017-08-22 05:55:00 --> Security Class Initialized
DEBUG - 2017-08-22 05:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:55:00 --> Input Class Initialized
INFO - 2017-08-22 05:55:00 --> Language Class Initialized
INFO - 2017-08-22 05:55:00 --> Loader Class Initialized
INFO - 2017-08-22 05:55:01 --> Helper loaded: url_helper
INFO - 2017-08-22 05:55:01 --> Helper loaded: file_helper
INFO - 2017-08-22 05:55:01 --> Database Driver Class Initialized
INFO - 2017-08-22 05:55:01 --> Email Class Initialized
DEBUG - 2017-08-22 05:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:55:01 --> Table Class Initialized
INFO - 2017-08-22 05:55:01 --> Controller Class Initialized
INFO - 2017-08-22 05:55:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:55:01 --> Final output sent to browser
DEBUG - 2017-08-22 05:55:01 --> Total execution time: 0.2224
INFO - 2017-08-22 05:55:01 --> Config Class Initialized
INFO - 2017-08-22 05:55:01 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:55:01 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:55:01 --> Utf8 Class Initialized
INFO - 2017-08-22 05:55:01 --> URI Class Initialized
INFO - 2017-08-22 05:55:01 --> Router Class Initialized
INFO - 2017-08-22 05:55:01 --> Output Class Initialized
INFO - 2017-08-22 05:55:01 --> Security Class Initialized
DEBUG - 2017-08-22 05:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:55:01 --> Input Class Initialized
INFO - 2017-08-22 05:55:01 --> Language Class Initialized
ERROR - 2017-08-22 05:55:01 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:55:01 --> Config Class Initialized
INFO - 2017-08-22 05:55:01 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:55:01 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:55:01 --> Utf8 Class Initialized
INFO - 2017-08-22 05:55:01 --> URI Class Initialized
INFO - 2017-08-22 05:55:01 --> Router Class Initialized
INFO - 2017-08-22 05:55:01 --> Output Class Initialized
INFO - 2017-08-22 05:55:01 --> Security Class Initialized
DEBUG - 2017-08-22 05:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:55:01 --> Input Class Initialized
INFO - 2017-08-22 05:55:01 --> Language Class Initialized
ERROR - 2017-08-22 05:55:01 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:55:42 --> Config Class Initialized
INFO - 2017-08-22 05:55:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:55:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:55:42 --> Utf8 Class Initialized
INFO - 2017-08-22 05:55:42 --> URI Class Initialized
DEBUG - 2017-08-22 05:55:42 --> No URI present. Default controller set.
INFO - 2017-08-22 05:55:42 --> Router Class Initialized
INFO - 2017-08-22 05:55:42 --> Output Class Initialized
INFO - 2017-08-22 05:55:42 --> Security Class Initialized
DEBUG - 2017-08-22 05:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:55:42 --> Input Class Initialized
INFO - 2017-08-22 05:55:42 --> Language Class Initialized
INFO - 2017-08-22 05:55:42 --> Loader Class Initialized
INFO - 2017-08-22 05:55:42 --> Helper loaded: url_helper
INFO - 2017-08-22 05:55:42 --> Helper loaded: file_helper
INFO - 2017-08-22 05:55:42 --> Database Driver Class Initialized
INFO - 2017-08-22 05:55:42 --> Email Class Initialized
DEBUG - 2017-08-22 05:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:55:42 --> Table Class Initialized
INFO - 2017-08-22 05:55:42 --> Controller Class Initialized
INFO - 2017-08-22 05:55:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:55:42 --> Final output sent to browser
DEBUG - 2017-08-22 05:55:42 --> Total execution time: 0.2259
INFO - 2017-08-22 05:55:42 --> Config Class Initialized
INFO - 2017-08-22 05:55:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:55:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:55:42 --> Utf8 Class Initialized
INFO - 2017-08-22 05:55:42 --> URI Class Initialized
INFO - 2017-08-22 05:55:42 --> Router Class Initialized
INFO - 2017-08-22 05:55:42 --> Output Class Initialized
INFO - 2017-08-22 05:55:42 --> Security Class Initialized
DEBUG - 2017-08-22 05:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:55:42 --> Input Class Initialized
INFO - 2017-08-22 05:55:42 --> Language Class Initialized
ERROR - 2017-08-22 05:55:42 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:55:43 --> Config Class Initialized
INFO - 2017-08-22 05:55:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:55:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:55:43 --> Utf8 Class Initialized
INFO - 2017-08-22 05:55:43 --> URI Class Initialized
INFO - 2017-08-22 05:55:43 --> Router Class Initialized
INFO - 2017-08-22 05:55:43 --> Output Class Initialized
INFO - 2017-08-22 05:55:43 --> Security Class Initialized
DEBUG - 2017-08-22 05:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:55:43 --> Input Class Initialized
INFO - 2017-08-22 05:55:43 --> Language Class Initialized
ERROR - 2017-08-22 05:55:43 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:55:52 --> Config Class Initialized
INFO - 2017-08-22 05:55:52 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:55:52 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:55:52 --> Utf8 Class Initialized
INFO - 2017-08-22 05:55:52 --> URI Class Initialized
DEBUG - 2017-08-22 05:55:52 --> No URI present. Default controller set.
INFO - 2017-08-22 05:55:52 --> Router Class Initialized
INFO - 2017-08-22 05:55:53 --> Output Class Initialized
INFO - 2017-08-22 05:55:53 --> Security Class Initialized
DEBUG - 2017-08-22 05:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:55:53 --> Input Class Initialized
INFO - 2017-08-22 05:55:53 --> Language Class Initialized
INFO - 2017-08-22 05:55:53 --> Loader Class Initialized
INFO - 2017-08-22 05:55:53 --> Helper loaded: url_helper
INFO - 2017-08-22 05:55:53 --> Helper loaded: file_helper
INFO - 2017-08-22 05:55:53 --> Database Driver Class Initialized
INFO - 2017-08-22 05:55:53 --> Email Class Initialized
DEBUG - 2017-08-22 05:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:55:53 --> Table Class Initialized
INFO - 2017-08-22 05:55:53 --> Controller Class Initialized
INFO - 2017-08-22 05:55:53 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:55:53 --> Final output sent to browser
DEBUG - 2017-08-22 05:55:53 --> Total execution time: 0.2277
INFO - 2017-08-22 05:55:53 --> Config Class Initialized
INFO - 2017-08-22 05:55:53 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:55:53 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:55:53 --> Utf8 Class Initialized
INFO - 2017-08-22 05:55:53 --> URI Class Initialized
INFO - 2017-08-22 05:55:53 --> Router Class Initialized
INFO - 2017-08-22 05:55:53 --> Output Class Initialized
INFO - 2017-08-22 05:55:53 --> Security Class Initialized
DEBUG - 2017-08-22 05:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:55:53 --> Input Class Initialized
INFO - 2017-08-22 05:55:53 --> Language Class Initialized
ERROR - 2017-08-22 05:55:53 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:55:53 --> Config Class Initialized
INFO - 2017-08-22 05:55:53 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:55:54 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:55:54 --> Utf8 Class Initialized
INFO - 2017-08-22 05:55:54 --> URI Class Initialized
INFO - 2017-08-22 05:55:54 --> Router Class Initialized
INFO - 2017-08-22 05:55:54 --> Output Class Initialized
INFO - 2017-08-22 05:55:54 --> Security Class Initialized
DEBUG - 2017-08-22 05:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:55:54 --> Input Class Initialized
INFO - 2017-08-22 05:55:54 --> Language Class Initialized
ERROR - 2017-08-22 05:55:54 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:56:01 --> Config Class Initialized
INFO - 2017-08-22 05:56:01 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:56:01 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:56:01 --> Utf8 Class Initialized
INFO - 2017-08-22 05:56:01 --> URI Class Initialized
DEBUG - 2017-08-22 05:56:01 --> No URI present. Default controller set.
INFO - 2017-08-22 05:56:01 --> Router Class Initialized
INFO - 2017-08-22 05:56:01 --> Output Class Initialized
INFO - 2017-08-22 05:56:01 --> Security Class Initialized
DEBUG - 2017-08-22 05:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:56:01 --> Input Class Initialized
INFO - 2017-08-22 05:56:01 --> Language Class Initialized
INFO - 2017-08-22 05:56:01 --> Loader Class Initialized
INFO - 2017-08-22 05:56:01 --> Helper loaded: url_helper
INFO - 2017-08-22 05:56:01 --> Helper loaded: file_helper
INFO - 2017-08-22 05:56:01 --> Database Driver Class Initialized
INFO - 2017-08-22 05:56:01 --> Email Class Initialized
DEBUG - 2017-08-22 05:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:56:01 --> Table Class Initialized
INFO - 2017-08-22 05:56:01 --> Controller Class Initialized
INFO - 2017-08-22 05:56:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:56:01 --> Final output sent to browser
DEBUG - 2017-08-22 05:56:01 --> Total execution time: 0.2208
INFO - 2017-08-22 05:56:01 --> Config Class Initialized
INFO - 2017-08-22 05:56:01 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:56:01 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:56:01 --> Utf8 Class Initialized
INFO - 2017-08-22 05:56:01 --> URI Class Initialized
INFO - 2017-08-22 05:56:01 --> Router Class Initialized
INFO - 2017-08-22 05:56:01 --> Output Class Initialized
INFO - 2017-08-22 05:56:01 --> Security Class Initialized
DEBUG - 2017-08-22 05:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:56:01 --> Input Class Initialized
INFO - 2017-08-22 05:56:01 --> Language Class Initialized
ERROR - 2017-08-22 05:56:01 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:56:02 --> Config Class Initialized
INFO - 2017-08-22 05:56:02 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:56:02 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:56:02 --> Utf8 Class Initialized
INFO - 2017-08-22 05:56:02 --> URI Class Initialized
INFO - 2017-08-22 05:56:02 --> Router Class Initialized
INFO - 2017-08-22 05:56:02 --> Output Class Initialized
INFO - 2017-08-22 05:56:02 --> Security Class Initialized
DEBUG - 2017-08-22 05:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:56:02 --> Input Class Initialized
INFO - 2017-08-22 05:56:02 --> Language Class Initialized
ERROR - 2017-08-22 05:56:02 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:56:22 --> Config Class Initialized
INFO - 2017-08-22 05:56:22 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:56:22 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:56:22 --> Utf8 Class Initialized
INFO - 2017-08-22 05:56:22 --> URI Class Initialized
DEBUG - 2017-08-22 05:56:22 --> No URI present. Default controller set.
INFO - 2017-08-22 05:56:22 --> Router Class Initialized
INFO - 2017-08-22 05:56:22 --> Output Class Initialized
INFO - 2017-08-22 05:56:22 --> Security Class Initialized
DEBUG - 2017-08-22 05:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:56:22 --> Input Class Initialized
INFO - 2017-08-22 05:56:22 --> Language Class Initialized
INFO - 2017-08-22 05:56:22 --> Loader Class Initialized
INFO - 2017-08-22 05:56:22 --> Helper loaded: url_helper
INFO - 2017-08-22 05:56:22 --> Helper loaded: file_helper
INFO - 2017-08-22 05:56:22 --> Database Driver Class Initialized
INFO - 2017-08-22 05:56:22 --> Email Class Initialized
DEBUG - 2017-08-22 05:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:56:22 --> Table Class Initialized
INFO - 2017-08-22 05:56:22 --> Controller Class Initialized
INFO - 2017-08-22 05:56:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:56:22 --> Final output sent to browser
DEBUG - 2017-08-22 05:56:22 --> Total execution time: 0.2214
INFO - 2017-08-22 05:56:23 --> Config Class Initialized
INFO - 2017-08-22 05:56:23 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:56:23 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:56:23 --> Utf8 Class Initialized
INFO - 2017-08-22 05:56:23 --> URI Class Initialized
INFO - 2017-08-22 05:56:23 --> Router Class Initialized
INFO - 2017-08-22 05:56:23 --> Output Class Initialized
INFO - 2017-08-22 05:56:23 --> Security Class Initialized
DEBUG - 2017-08-22 05:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:56:23 --> Input Class Initialized
INFO - 2017-08-22 05:56:23 --> Language Class Initialized
ERROR - 2017-08-22 05:56:23 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:56:23 --> Config Class Initialized
INFO - 2017-08-22 05:56:23 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:56:23 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:56:23 --> Utf8 Class Initialized
INFO - 2017-08-22 05:56:23 --> URI Class Initialized
INFO - 2017-08-22 05:56:23 --> Router Class Initialized
INFO - 2017-08-22 05:56:23 --> Output Class Initialized
INFO - 2017-08-22 05:56:23 --> Security Class Initialized
DEBUG - 2017-08-22 05:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:56:23 --> Input Class Initialized
INFO - 2017-08-22 05:56:23 --> Language Class Initialized
ERROR - 2017-08-22 05:56:23 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:57:25 --> Config Class Initialized
INFO - 2017-08-22 05:57:25 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:57:25 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:57:25 --> Utf8 Class Initialized
INFO - 2017-08-22 05:57:25 --> URI Class Initialized
DEBUG - 2017-08-22 05:57:25 --> No URI present. Default controller set.
INFO - 2017-08-22 05:57:25 --> Router Class Initialized
INFO - 2017-08-22 05:57:25 --> Output Class Initialized
INFO - 2017-08-22 05:57:25 --> Security Class Initialized
DEBUG - 2017-08-22 05:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:57:25 --> Input Class Initialized
INFO - 2017-08-22 05:57:25 --> Language Class Initialized
INFO - 2017-08-22 05:57:25 --> Loader Class Initialized
INFO - 2017-08-22 05:57:25 --> Helper loaded: url_helper
INFO - 2017-08-22 05:57:25 --> Helper loaded: file_helper
INFO - 2017-08-22 05:57:25 --> Database Driver Class Initialized
INFO - 2017-08-22 05:57:25 --> Email Class Initialized
DEBUG - 2017-08-22 05:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:57:25 --> Table Class Initialized
INFO - 2017-08-22 05:57:25 --> Controller Class Initialized
INFO - 2017-08-22 05:57:25 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:57:25 --> Final output sent to browser
DEBUG - 2017-08-22 05:57:25 --> Total execution time: 0.2121
INFO - 2017-08-22 05:57:25 --> Config Class Initialized
INFO - 2017-08-22 05:57:25 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:57:25 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:57:25 --> Utf8 Class Initialized
INFO - 2017-08-22 05:57:25 --> URI Class Initialized
INFO - 2017-08-22 05:57:25 --> Router Class Initialized
INFO - 2017-08-22 05:57:25 --> Output Class Initialized
INFO - 2017-08-22 05:57:25 --> Security Class Initialized
DEBUG - 2017-08-22 05:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:57:25 --> Input Class Initialized
INFO - 2017-08-22 05:57:25 --> Language Class Initialized
ERROR - 2017-08-22 05:57:25 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:57:26 --> Config Class Initialized
INFO - 2017-08-22 05:57:26 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:57:26 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:57:26 --> Utf8 Class Initialized
INFO - 2017-08-22 05:57:26 --> URI Class Initialized
INFO - 2017-08-22 05:57:26 --> Router Class Initialized
INFO - 2017-08-22 05:57:26 --> Output Class Initialized
INFO - 2017-08-22 05:57:26 --> Security Class Initialized
DEBUG - 2017-08-22 05:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:57:26 --> Input Class Initialized
INFO - 2017-08-22 05:57:26 --> Language Class Initialized
ERROR - 2017-08-22 05:57:26 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:57:54 --> Config Class Initialized
INFO - 2017-08-22 05:57:54 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:57:54 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:57:54 --> Utf8 Class Initialized
INFO - 2017-08-22 05:57:54 --> URI Class Initialized
DEBUG - 2017-08-22 05:57:54 --> No URI present. Default controller set.
INFO - 2017-08-22 05:57:54 --> Router Class Initialized
INFO - 2017-08-22 05:57:54 --> Output Class Initialized
INFO - 2017-08-22 05:57:54 --> Security Class Initialized
DEBUG - 2017-08-22 05:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:57:54 --> Input Class Initialized
INFO - 2017-08-22 05:57:54 --> Language Class Initialized
INFO - 2017-08-22 05:57:54 --> Loader Class Initialized
INFO - 2017-08-22 05:57:54 --> Helper loaded: url_helper
INFO - 2017-08-22 05:57:54 --> Helper loaded: file_helper
INFO - 2017-08-22 05:57:54 --> Database Driver Class Initialized
INFO - 2017-08-22 05:57:54 --> Email Class Initialized
DEBUG - 2017-08-22 05:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:57:54 --> Table Class Initialized
INFO - 2017-08-22 05:57:54 --> Controller Class Initialized
INFO - 2017-08-22 05:57:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:57:54 --> Final output sent to browser
DEBUG - 2017-08-22 05:57:54 --> Total execution time: 0.2285
INFO - 2017-08-22 05:57:55 --> Config Class Initialized
INFO - 2017-08-22 05:57:55 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:57:55 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:57:55 --> Utf8 Class Initialized
INFO - 2017-08-22 05:57:55 --> URI Class Initialized
INFO - 2017-08-22 05:57:55 --> Router Class Initialized
INFO - 2017-08-22 05:57:55 --> Output Class Initialized
INFO - 2017-08-22 05:57:55 --> Security Class Initialized
DEBUG - 2017-08-22 05:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:57:55 --> Input Class Initialized
INFO - 2017-08-22 05:57:55 --> Language Class Initialized
ERROR - 2017-08-22 05:57:55 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:57:55 --> Config Class Initialized
INFO - 2017-08-22 05:57:55 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:57:55 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:57:55 --> Utf8 Class Initialized
INFO - 2017-08-22 05:57:55 --> URI Class Initialized
INFO - 2017-08-22 05:57:55 --> Router Class Initialized
INFO - 2017-08-22 05:57:55 --> Output Class Initialized
INFO - 2017-08-22 05:57:55 --> Security Class Initialized
DEBUG - 2017-08-22 05:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:57:55 --> Input Class Initialized
INFO - 2017-08-22 05:57:55 --> Language Class Initialized
ERROR - 2017-08-22 05:57:55 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:58:18 --> Config Class Initialized
INFO - 2017-08-22 05:58:18 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:58:18 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:58:18 --> Utf8 Class Initialized
INFO - 2017-08-22 05:58:18 --> URI Class Initialized
DEBUG - 2017-08-22 05:58:18 --> No URI present. Default controller set.
INFO - 2017-08-22 05:58:18 --> Router Class Initialized
INFO - 2017-08-22 05:58:18 --> Output Class Initialized
INFO - 2017-08-22 05:58:18 --> Security Class Initialized
DEBUG - 2017-08-22 05:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:58:18 --> Input Class Initialized
INFO - 2017-08-22 05:58:18 --> Language Class Initialized
INFO - 2017-08-22 05:58:18 --> Loader Class Initialized
INFO - 2017-08-22 05:58:18 --> Helper loaded: url_helper
INFO - 2017-08-22 05:58:18 --> Helper loaded: file_helper
INFO - 2017-08-22 05:58:18 --> Database Driver Class Initialized
INFO - 2017-08-22 05:58:18 --> Email Class Initialized
DEBUG - 2017-08-22 05:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:58:18 --> Table Class Initialized
INFO - 2017-08-22 05:58:18 --> Controller Class Initialized
INFO - 2017-08-22 05:58:18 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:58:18 --> Final output sent to browser
DEBUG - 2017-08-22 05:58:18 --> Total execution time: 0.2263
INFO - 2017-08-22 05:58:18 --> Config Class Initialized
INFO - 2017-08-22 05:58:18 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:58:18 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:58:18 --> Utf8 Class Initialized
INFO - 2017-08-22 05:58:18 --> URI Class Initialized
INFO - 2017-08-22 05:58:18 --> Router Class Initialized
INFO - 2017-08-22 05:58:18 --> Output Class Initialized
INFO - 2017-08-22 05:58:18 --> Security Class Initialized
DEBUG - 2017-08-22 05:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:58:18 --> Input Class Initialized
INFO - 2017-08-22 05:58:18 --> Language Class Initialized
ERROR - 2017-08-22 05:58:18 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:58:19 --> Config Class Initialized
INFO - 2017-08-22 05:58:19 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:58:19 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:58:19 --> Utf8 Class Initialized
INFO - 2017-08-22 05:58:19 --> URI Class Initialized
INFO - 2017-08-22 05:58:19 --> Router Class Initialized
INFO - 2017-08-22 05:58:19 --> Output Class Initialized
INFO - 2017-08-22 05:58:19 --> Security Class Initialized
DEBUG - 2017-08-22 05:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:58:19 --> Input Class Initialized
INFO - 2017-08-22 05:58:19 --> Language Class Initialized
ERROR - 2017-08-22 05:58:19 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:58:27 --> Config Class Initialized
INFO - 2017-08-22 05:58:27 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:58:27 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:58:28 --> Utf8 Class Initialized
INFO - 2017-08-22 05:58:28 --> URI Class Initialized
DEBUG - 2017-08-22 05:58:28 --> No URI present. Default controller set.
INFO - 2017-08-22 05:58:28 --> Router Class Initialized
INFO - 2017-08-22 05:58:28 --> Output Class Initialized
INFO - 2017-08-22 05:58:28 --> Security Class Initialized
DEBUG - 2017-08-22 05:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:58:28 --> Input Class Initialized
INFO - 2017-08-22 05:58:28 --> Language Class Initialized
INFO - 2017-08-22 05:58:28 --> Loader Class Initialized
INFO - 2017-08-22 05:58:28 --> Helper loaded: url_helper
INFO - 2017-08-22 05:58:28 --> Helper loaded: file_helper
INFO - 2017-08-22 05:58:28 --> Database Driver Class Initialized
INFO - 2017-08-22 05:58:28 --> Email Class Initialized
DEBUG - 2017-08-22 05:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:58:28 --> Table Class Initialized
INFO - 2017-08-22 05:58:28 --> Controller Class Initialized
INFO - 2017-08-22 05:58:28 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:58:28 --> Final output sent to browser
DEBUG - 2017-08-22 05:58:28 --> Total execution time: 0.2227
INFO - 2017-08-22 05:58:28 --> Config Class Initialized
INFO - 2017-08-22 05:58:28 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:58:28 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:58:28 --> Utf8 Class Initialized
INFO - 2017-08-22 05:58:28 --> URI Class Initialized
INFO - 2017-08-22 05:58:28 --> Router Class Initialized
INFO - 2017-08-22 05:58:28 --> Output Class Initialized
INFO - 2017-08-22 05:58:28 --> Security Class Initialized
DEBUG - 2017-08-22 05:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:58:28 --> Input Class Initialized
INFO - 2017-08-22 05:58:28 --> Language Class Initialized
ERROR - 2017-08-22 05:58:28 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:58:29 --> Config Class Initialized
INFO - 2017-08-22 05:58:29 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:58:29 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:58:29 --> Utf8 Class Initialized
INFO - 2017-08-22 05:58:29 --> URI Class Initialized
INFO - 2017-08-22 05:58:29 --> Router Class Initialized
INFO - 2017-08-22 05:58:29 --> Output Class Initialized
INFO - 2017-08-22 05:58:29 --> Security Class Initialized
DEBUG - 2017-08-22 05:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:58:29 --> Input Class Initialized
INFO - 2017-08-22 05:58:29 --> Language Class Initialized
ERROR - 2017-08-22 05:58:29 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:58:30 --> Config Class Initialized
INFO - 2017-08-22 05:58:30 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:58:30 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:58:30 --> Utf8 Class Initialized
INFO - 2017-08-22 05:58:31 --> URI Class Initialized
DEBUG - 2017-08-22 05:58:31 --> No URI present. Default controller set.
INFO - 2017-08-22 05:58:31 --> Router Class Initialized
INFO - 2017-08-22 05:58:31 --> Output Class Initialized
INFO - 2017-08-22 05:58:31 --> Security Class Initialized
DEBUG - 2017-08-22 05:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:58:31 --> Input Class Initialized
INFO - 2017-08-22 05:58:31 --> Language Class Initialized
INFO - 2017-08-22 05:58:31 --> Loader Class Initialized
INFO - 2017-08-22 05:58:31 --> Helper loaded: url_helper
INFO - 2017-08-22 05:58:31 --> Helper loaded: file_helper
INFO - 2017-08-22 05:58:31 --> Database Driver Class Initialized
INFO - 2017-08-22 05:58:31 --> Email Class Initialized
DEBUG - 2017-08-22 05:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:58:31 --> Table Class Initialized
INFO - 2017-08-22 05:58:31 --> Controller Class Initialized
INFO - 2017-08-22 05:58:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:58:31 --> Final output sent to browser
DEBUG - 2017-08-22 05:58:31 --> Total execution time: 0.2227
INFO - 2017-08-22 05:58:31 --> Config Class Initialized
INFO - 2017-08-22 05:58:31 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:58:31 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:58:31 --> Utf8 Class Initialized
INFO - 2017-08-22 05:58:31 --> URI Class Initialized
INFO - 2017-08-22 05:58:31 --> Router Class Initialized
INFO - 2017-08-22 05:58:31 --> Output Class Initialized
INFO - 2017-08-22 05:58:31 --> Security Class Initialized
DEBUG - 2017-08-22 05:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:58:31 --> Input Class Initialized
INFO - 2017-08-22 05:58:31 --> Language Class Initialized
ERROR - 2017-08-22 05:58:31 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:58:31 --> Config Class Initialized
INFO - 2017-08-22 05:58:31 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:58:31 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:58:31 --> Utf8 Class Initialized
INFO - 2017-08-22 05:58:31 --> URI Class Initialized
INFO - 2017-08-22 05:58:31 --> Router Class Initialized
INFO - 2017-08-22 05:58:31 --> Output Class Initialized
INFO - 2017-08-22 05:58:31 --> Security Class Initialized
DEBUG - 2017-08-22 05:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:58:31 --> Input Class Initialized
INFO - 2017-08-22 05:58:31 --> Language Class Initialized
ERROR - 2017-08-22 05:58:31 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:59:31 --> Config Class Initialized
INFO - 2017-08-22 05:59:31 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:59:31 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:59:31 --> Utf8 Class Initialized
INFO - 2017-08-22 05:59:31 --> URI Class Initialized
DEBUG - 2017-08-22 05:59:31 --> No URI present. Default controller set.
INFO - 2017-08-22 05:59:31 --> Router Class Initialized
INFO - 2017-08-22 05:59:31 --> Output Class Initialized
INFO - 2017-08-22 05:59:31 --> Security Class Initialized
DEBUG - 2017-08-22 05:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:59:31 --> Input Class Initialized
INFO - 2017-08-22 05:59:31 --> Language Class Initialized
INFO - 2017-08-22 05:59:31 --> Loader Class Initialized
INFO - 2017-08-22 05:59:31 --> Helper loaded: url_helper
INFO - 2017-08-22 05:59:31 --> Helper loaded: file_helper
INFO - 2017-08-22 05:59:31 --> Database Driver Class Initialized
INFO - 2017-08-22 05:59:31 --> Email Class Initialized
DEBUG - 2017-08-22 05:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 05:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 05:59:31 --> Table Class Initialized
INFO - 2017-08-22 05:59:31 --> Controller Class Initialized
INFO - 2017-08-22 05:59:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 05:59:31 --> Final output sent to browser
DEBUG - 2017-08-22 05:59:31 --> Total execution time: 0.2317
INFO - 2017-08-22 05:59:32 --> Config Class Initialized
INFO - 2017-08-22 05:59:32 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:59:32 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:59:32 --> Utf8 Class Initialized
INFO - 2017-08-22 05:59:32 --> URI Class Initialized
INFO - 2017-08-22 05:59:32 --> Router Class Initialized
INFO - 2017-08-22 05:59:32 --> Output Class Initialized
INFO - 2017-08-22 05:59:32 --> Security Class Initialized
DEBUG - 2017-08-22 05:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:59:32 --> Input Class Initialized
INFO - 2017-08-22 05:59:32 --> Language Class Initialized
ERROR - 2017-08-22 05:59:32 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 05:59:32 --> Config Class Initialized
INFO - 2017-08-22 05:59:32 --> Hooks Class Initialized
DEBUG - 2017-08-22 05:59:32 --> UTF-8 Support Enabled
INFO - 2017-08-22 05:59:32 --> Utf8 Class Initialized
INFO - 2017-08-22 05:59:32 --> URI Class Initialized
INFO - 2017-08-22 05:59:32 --> Router Class Initialized
INFO - 2017-08-22 05:59:32 --> Output Class Initialized
INFO - 2017-08-22 05:59:32 --> Security Class Initialized
DEBUG - 2017-08-22 05:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 05:59:32 --> Input Class Initialized
INFO - 2017-08-22 05:59:32 --> Language Class Initialized
ERROR - 2017-08-22 05:59:32 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:00:42 --> Config Class Initialized
INFO - 2017-08-22 06:00:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:00:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:00:42 --> Utf8 Class Initialized
INFO - 2017-08-22 06:00:42 --> URI Class Initialized
DEBUG - 2017-08-22 06:00:42 --> No URI present. Default controller set.
INFO - 2017-08-22 06:00:42 --> Router Class Initialized
INFO - 2017-08-22 06:00:42 --> Output Class Initialized
INFO - 2017-08-22 06:00:42 --> Security Class Initialized
DEBUG - 2017-08-22 06:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:00:42 --> Input Class Initialized
INFO - 2017-08-22 06:00:42 --> Language Class Initialized
INFO - 2017-08-22 06:00:42 --> Loader Class Initialized
INFO - 2017-08-22 06:00:42 --> Helper loaded: url_helper
INFO - 2017-08-22 06:00:42 --> Helper loaded: file_helper
INFO - 2017-08-22 06:00:42 --> Database Driver Class Initialized
INFO - 2017-08-22 06:00:42 --> Email Class Initialized
DEBUG - 2017-08-22 06:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:00:42 --> Table Class Initialized
INFO - 2017-08-22 06:00:42 --> Controller Class Initialized
INFO - 2017-08-22 06:00:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:00:42 --> Final output sent to browser
DEBUG - 2017-08-22 06:00:42 --> Total execution time: 0.2294
INFO - 2017-08-22 06:00:42 --> Config Class Initialized
INFO - 2017-08-22 06:00:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:00:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:00:43 --> Utf8 Class Initialized
INFO - 2017-08-22 06:00:43 --> URI Class Initialized
INFO - 2017-08-22 06:00:43 --> Router Class Initialized
INFO - 2017-08-22 06:00:43 --> Output Class Initialized
INFO - 2017-08-22 06:00:43 --> Security Class Initialized
DEBUG - 2017-08-22 06:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:00:43 --> Input Class Initialized
INFO - 2017-08-22 06:00:43 --> Language Class Initialized
ERROR - 2017-08-22 06:00:43 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:00:43 --> Config Class Initialized
INFO - 2017-08-22 06:00:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:00:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:00:43 --> Utf8 Class Initialized
INFO - 2017-08-22 06:00:43 --> URI Class Initialized
INFO - 2017-08-22 06:00:43 --> Router Class Initialized
INFO - 2017-08-22 06:00:43 --> Output Class Initialized
INFO - 2017-08-22 06:00:43 --> Security Class Initialized
DEBUG - 2017-08-22 06:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:00:43 --> Input Class Initialized
INFO - 2017-08-22 06:00:43 --> Language Class Initialized
ERROR - 2017-08-22 06:00:43 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:01:02 --> Config Class Initialized
INFO - 2017-08-22 06:01:02 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:01:02 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:01:02 --> Utf8 Class Initialized
INFO - 2017-08-22 06:01:02 --> URI Class Initialized
DEBUG - 2017-08-22 06:01:02 --> No URI present. Default controller set.
INFO - 2017-08-22 06:01:02 --> Router Class Initialized
INFO - 2017-08-22 06:01:02 --> Output Class Initialized
INFO - 2017-08-22 06:01:02 --> Security Class Initialized
DEBUG - 2017-08-22 06:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:01:02 --> Input Class Initialized
INFO - 2017-08-22 06:01:02 --> Language Class Initialized
INFO - 2017-08-22 06:01:02 --> Loader Class Initialized
INFO - 2017-08-22 06:01:02 --> Helper loaded: url_helper
INFO - 2017-08-22 06:01:02 --> Helper loaded: file_helper
INFO - 2017-08-22 06:01:02 --> Database Driver Class Initialized
INFO - 2017-08-22 06:01:02 --> Email Class Initialized
DEBUG - 2017-08-22 06:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:01:02 --> Table Class Initialized
INFO - 2017-08-22 06:01:02 --> Controller Class Initialized
INFO - 2017-08-22 06:01:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:01:02 --> Final output sent to browser
DEBUG - 2017-08-22 06:01:02 --> Total execution time: 0.2336
INFO - 2017-08-22 06:01:03 --> Config Class Initialized
INFO - 2017-08-22 06:01:03 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:01:03 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:01:03 --> Utf8 Class Initialized
INFO - 2017-08-22 06:01:03 --> URI Class Initialized
INFO - 2017-08-22 06:01:03 --> Router Class Initialized
INFO - 2017-08-22 06:01:03 --> Output Class Initialized
INFO - 2017-08-22 06:01:03 --> Security Class Initialized
DEBUG - 2017-08-22 06:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:01:03 --> Input Class Initialized
INFO - 2017-08-22 06:01:03 --> Language Class Initialized
ERROR - 2017-08-22 06:01:03 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:01:03 --> Config Class Initialized
INFO - 2017-08-22 06:01:03 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:01:03 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:01:03 --> Utf8 Class Initialized
INFO - 2017-08-22 06:01:03 --> URI Class Initialized
INFO - 2017-08-22 06:01:03 --> Router Class Initialized
INFO - 2017-08-22 06:01:03 --> Output Class Initialized
INFO - 2017-08-22 06:01:03 --> Security Class Initialized
DEBUG - 2017-08-22 06:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:01:03 --> Input Class Initialized
INFO - 2017-08-22 06:01:03 --> Language Class Initialized
ERROR - 2017-08-22 06:01:03 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:01:42 --> Config Class Initialized
INFO - 2017-08-22 06:01:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:01:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:01:42 --> Utf8 Class Initialized
INFO - 2017-08-22 06:01:42 --> URI Class Initialized
DEBUG - 2017-08-22 06:01:42 --> No URI present. Default controller set.
INFO - 2017-08-22 06:01:42 --> Router Class Initialized
INFO - 2017-08-22 06:01:42 --> Output Class Initialized
INFO - 2017-08-22 06:01:42 --> Security Class Initialized
DEBUG - 2017-08-22 06:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:01:42 --> Input Class Initialized
INFO - 2017-08-22 06:01:42 --> Language Class Initialized
INFO - 2017-08-22 06:01:42 --> Loader Class Initialized
INFO - 2017-08-22 06:01:42 --> Helper loaded: url_helper
INFO - 2017-08-22 06:01:42 --> Helper loaded: file_helper
INFO - 2017-08-22 06:01:42 --> Database Driver Class Initialized
INFO - 2017-08-22 06:01:42 --> Email Class Initialized
DEBUG - 2017-08-22 06:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:01:42 --> Table Class Initialized
INFO - 2017-08-22 06:01:42 --> Controller Class Initialized
INFO - 2017-08-22 06:01:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:01:42 --> Final output sent to browser
DEBUG - 2017-08-22 06:01:42 --> Total execution time: 0.2224
INFO - 2017-08-22 06:01:42 --> Config Class Initialized
INFO - 2017-08-22 06:01:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:01:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:01:42 --> Utf8 Class Initialized
INFO - 2017-08-22 06:01:42 --> URI Class Initialized
INFO - 2017-08-22 06:01:42 --> Router Class Initialized
INFO - 2017-08-22 06:01:42 --> Output Class Initialized
INFO - 2017-08-22 06:01:42 --> Security Class Initialized
DEBUG - 2017-08-22 06:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:01:42 --> Input Class Initialized
INFO - 2017-08-22 06:01:42 --> Language Class Initialized
ERROR - 2017-08-22 06:01:42 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:01:42 --> Config Class Initialized
INFO - 2017-08-22 06:01:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:01:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:01:42 --> Utf8 Class Initialized
INFO - 2017-08-22 06:01:42 --> URI Class Initialized
INFO - 2017-08-22 06:01:42 --> Router Class Initialized
INFO - 2017-08-22 06:01:42 --> Output Class Initialized
INFO - 2017-08-22 06:01:42 --> Security Class Initialized
DEBUG - 2017-08-22 06:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:01:42 --> Input Class Initialized
INFO - 2017-08-22 06:01:42 --> Language Class Initialized
ERROR - 2017-08-22 06:01:42 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:01:54 --> Config Class Initialized
INFO - 2017-08-22 06:01:54 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:01:54 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:01:54 --> Utf8 Class Initialized
INFO - 2017-08-22 06:01:54 --> URI Class Initialized
DEBUG - 2017-08-22 06:01:54 --> No URI present. Default controller set.
INFO - 2017-08-22 06:01:54 --> Router Class Initialized
INFO - 2017-08-22 06:01:54 --> Output Class Initialized
INFO - 2017-08-22 06:01:54 --> Security Class Initialized
DEBUG - 2017-08-22 06:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:01:54 --> Input Class Initialized
INFO - 2017-08-22 06:01:54 --> Language Class Initialized
INFO - 2017-08-22 06:01:54 --> Loader Class Initialized
INFO - 2017-08-22 06:01:54 --> Helper loaded: url_helper
INFO - 2017-08-22 06:01:54 --> Helper loaded: file_helper
INFO - 2017-08-22 06:01:54 --> Database Driver Class Initialized
INFO - 2017-08-22 06:01:54 --> Email Class Initialized
DEBUG - 2017-08-22 06:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:01:54 --> Table Class Initialized
INFO - 2017-08-22 06:01:54 --> Controller Class Initialized
INFO - 2017-08-22 06:01:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:01:54 --> Final output sent to browser
DEBUG - 2017-08-22 06:01:54 --> Total execution time: 0.2449
INFO - 2017-08-22 06:01:54 --> Config Class Initialized
INFO - 2017-08-22 06:01:54 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:01:54 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:01:54 --> Utf8 Class Initialized
INFO - 2017-08-22 06:01:54 --> URI Class Initialized
INFO - 2017-08-22 06:01:54 --> Router Class Initialized
INFO - 2017-08-22 06:01:54 --> Output Class Initialized
INFO - 2017-08-22 06:01:54 --> Security Class Initialized
DEBUG - 2017-08-22 06:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:01:54 --> Input Class Initialized
INFO - 2017-08-22 06:01:54 --> Language Class Initialized
ERROR - 2017-08-22 06:01:54 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:01:54 --> Config Class Initialized
INFO - 2017-08-22 06:01:54 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:01:54 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:01:54 --> Utf8 Class Initialized
INFO - 2017-08-22 06:01:54 --> URI Class Initialized
INFO - 2017-08-22 06:01:54 --> Router Class Initialized
INFO - 2017-08-22 06:01:54 --> Output Class Initialized
INFO - 2017-08-22 06:01:54 --> Security Class Initialized
DEBUG - 2017-08-22 06:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:01:54 --> Input Class Initialized
INFO - 2017-08-22 06:01:54 --> Language Class Initialized
ERROR - 2017-08-22 06:01:54 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:02:06 --> Config Class Initialized
INFO - 2017-08-22 06:02:06 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:02:06 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:02:06 --> Utf8 Class Initialized
INFO - 2017-08-22 06:02:06 --> URI Class Initialized
DEBUG - 2017-08-22 06:02:06 --> No URI present. Default controller set.
INFO - 2017-08-22 06:02:06 --> Router Class Initialized
INFO - 2017-08-22 06:02:06 --> Output Class Initialized
INFO - 2017-08-22 06:02:06 --> Security Class Initialized
DEBUG - 2017-08-22 06:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:02:06 --> Input Class Initialized
INFO - 2017-08-22 06:02:06 --> Language Class Initialized
INFO - 2017-08-22 06:02:06 --> Loader Class Initialized
INFO - 2017-08-22 06:02:06 --> Helper loaded: url_helper
INFO - 2017-08-22 06:02:06 --> Helper loaded: file_helper
INFO - 2017-08-22 06:02:06 --> Database Driver Class Initialized
INFO - 2017-08-22 06:02:06 --> Email Class Initialized
DEBUG - 2017-08-22 06:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:02:06 --> Table Class Initialized
INFO - 2017-08-22 06:02:06 --> Controller Class Initialized
INFO - 2017-08-22 06:02:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:02:06 --> Final output sent to browser
DEBUG - 2017-08-22 06:02:06 --> Total execution time: 0.2265
INFO - 2017-08-22 06:02:06 --> Config Class Initialized
INFO - 2017-08-22 06:02:06 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:02:06 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:02:06 --> Utf8 Class Initialized
INFO - 2017-08-22 06:02:06 --> URI Class Initialized
INFO - 2017-08-22 06:02:06 --> Router Class Initialized
INFO - 2017-08-22 06:02:06 --> Output Class Initialized
INFO - 2017-08-22 06:02:06 --> Security Class Initialized
DEBUG - 2017-08-22 06:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:02:06 --> Input Class Initialized
INFO - 2017-08-22 06:02:06 --> Language Class Initialized
ERROR - 2017-08-22 06:02:06 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:02:07 --> Config Class Initialized
INFO - 2017-08-22 06:02:07 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:02:07 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:02:07 --> Utf8 Class Initialized
INFO - 2017-08-22 06:02:07 --> URI Class Initialized
INFO - 2017-08-22 06:02:07 --> Router Class Initialized
INFO - 2017-08-22 06:02:07 --> Output Class Initialized
INFO - 2017-08-22 06:02:07 --> Security Class Initialized
DEBUG - 2017-08-22 06:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:02:07 --> Input Class Initialized
INFO - 2017-08-22 06:02:07 --> Language Class Initialized
ERROR - 2017-08-22 06:02:07 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:03:16 --> Config Class Initialized
INFO - 2017-08-22 06:03:16 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:03:16 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:03:16 --> Utf8 Class Initialized
INFO - 2017-08-22 06:03:16 --> URI Class Initialized
DEBUG - 2017-08-22 06:03:16 --> No URI present. Default controller set.
INFO - 2017-08-22 06:03:16 --> Router Class Initialized
INFO - 2017-08-22 06:03:16 --> Output Class Initialized
INFO - 2017-08-22 06:03:16 --> Security Class Initialized
DEBUG - 2017-08-22 06:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:03:16 --> Input Class Initialized
INFO - 2017-08-22 06:03:16 --> Language Class Initialized
INFO - 2017-08-22 06:03:16 --> Loader Class Initialized
INFO - 2017-08-22 06:03:16 --> Helper loaded: url_helper
INFO - 2017-08-22 06:03:16 --> Helper loaded: file_helper
INFO - 2017-08-22 06:03:16 --> Database Driver Class Initialized
INFO - 2017-08-22 06:03:16 --> Email Class Initialized
DEBUG - 2017-08-22 06:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:03:16 --> Table Class Initialized
INFO - 2017-08-22 06:03:16 --> Controller Class Initialized
INFO - 2017-08-22 06:03:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:03:16 --> Final output sent to browser
DEBUG - 2017-08-22 06:03:16 --> Total execution time: 0.2159
INFO - 2017-08-22 06:03:16 --> Config Class Initialized
INFO - 2017-08-22 06:03:16 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:03:16 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:03:16 --> Utf8 Class Initialized
INFO - 2017-08-22 06:03:16 --> URI Class Initialized
INFO - 2017-08-22 06:03:16 --> Router Class Initialized
INFO - 2017-08-22 06:03:16 --> Output Class Initialized
INFO - 2017-08-22 06:03:16 --> Security Class Initialized
DEBUG - 2017-08-22 06:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:03:16 --> Input Class Initialized
INFO - 2017-08-22 06:03:16 --> Language Class Initialized
ERROR - 2017-08-22 06:03:16 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:03:16 --> Config Class Initialized
INFO - 2017-08-22 06:03:16 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:03:16 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:03:16 --> Utf8 Class Initialized
INFO - 2017-08-22 06:03:16 --> URI Class Initialized
INFO - 2017-08-22 06:03:16 --> Router Class Initialized
INFO - 2017-08-22 06:03:16 --> Output Class Initialized
INFO - 2017-08-22 06:03:16 --> Security Class Initialized
DEBUG - 2017-08-22 06:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:03:17 --> Input Class Initialized
INFO - 2017-08-22 06:03:17 --> Language Class Initialized
ERROR - 2017-08-22 06:03:17 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:03:30 --> Config Class Initialized
INFO - 2017-08-22 06:03:30 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:03:30 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:03:30 --> Utf8 Class Initialized
INFO - 2017-08-22 06:03:30 --> URI Class Initialized
DEBUG - 2017-08-22 06:03:30 --> No URI present. Default controller set.
INFO - 2017-08-22 06:03:30 --> Router Class Initialized
INFO - 2017-08-22 06:03:30 --> Output Class Initialized
INFO - 2017-08-22 06:03:30 --> Security Class Initialized
DEBUG - 2017-08-22 06:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:03:30 --> Input Class Initialized
INFO - 2017-08-22 06:03:30 --> Language Class Initialized
INFO - 2017-08-22 06:03:30 --> Loader Class Initialized
INFO - 2017-08-22 06:03:30 --> Helper loaded: url_helper
INFO - 2017-08-22 06:03:30 --> Helper loaded: file_helper
INFO - 2017-08-22 06:03:30 --> Database Driver Class Initialized
INFO - 2017-08-22 06:03:30 --> Email Class Initialized
DEBUG - 2017-08-22 06:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:03:30 --> Table Class Initialized
INFO - 2017-08-22 06:03:30 --> Controller Class Initialized
INFO - 2017-08-22 06:03:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:03:30 --> Final output sent to browser
DEBUG - 2017-08-22 06:03:30 --> Total execution time: 0.2267
INFO - 2017-08-22 06:03:30 --> Config Class Initialized
INFO - 2017-08-22 06:03:30 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:03:30 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:03:30 --> Utf8 Class Initialized
INFO - 2017-08-22 06:03:30 --> URI Class Initialized
INFO - 2017-08-22 06:03:30 --> Router Class Initialized
INFO - 2017-08-22 06:03:30 --> Output Class Initialized
INFO - 2017-08-22 06:03:30 --> Security Class Initialized
DEBUG - 2017-08-22 06:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:03:30 --> Input Class Initialized
INFO - 2017-08-22 06:03:30 --> Language Class Initialized
ERROR - 2017-08-22 06:03:30 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:03:31 --> Config Class Initialized
INFO - 2017-08-22 06:03:31 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:03:31 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:03:31 --> Utf8 Class Initialized
INFO - 2017-08-22 06:03:31 --> URI Class Initialized
INFO - 2017-08-22 06:03:31 --> Router Class Initialized
INFO - 2017-08-22 06:03:31 --> Output Class Initialized
INFO - 2017-08-22 06:03:31 --> Security Class Initialized
DEBUG - 2017-08-22 06:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:03:31 --> Input Class Initialized
INFO - 2017-08-22 06:03:31 --> Language Class Initialized
ERROR - 2017-08-22 06:03:31 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:03:52 --> Config Class Initialized
INFO - 2017-08-22 06:03:52 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:03:52 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:03:52 --> Utf8 Class Initialized
INFO - 2017-08-22 06:03:52 --> URI Class Initialized
DEBUG - 2017-08-22 06:03:52 --> No URI present. Default controller set.
INFO - 2017-08-22 06:03:52 --> Router Class Initialized
INFO - 2017-08-22 06:03:52 --> Output Class Initialized
INFO - 2017-08-22 06:03:52 --> Security Class Initialized
DEBUG - 2017-08-22 06:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:03:52 --> Input Class Initialized
INFO - 2017-08-22 06:03:53 --> Language Class Initialized
INFO - 2017-08-22 06:03:53 --> Loader Class Initialized
INFO - 2017-08-22 06:03:53 --> Helper loaded: url_helper
INFO - 2017-08-22 06:03:53 --> Helper loaded: file_helper
INFO - 2017-08-22 06:03:53 --> Database Driver Class Initialized
INFO - 2017-08-22 06:03:53 --> Email Class Initialized
DEBUG - 2017-08-22 06:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:03:53 --> Table Class Initialized
INFO - 2017-08-22 06:03:53 --> Controller Class Initialized
INFO - 2017-08-22 06:03:53 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:03:53 --> Final output sent to browser
DEBUG - 2017-08-22 06:03:53 --> Total execution time: 0.2270
INFO - 2017-08-22 06:03:53 --> Config Class Initialized
INFO - 2017-08-22 06:03:53 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:03:53 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:03:53 --> Utf8 Class Initialized
INFO - 2017-08-22 06:03:53 --> URI Class Initialized
INFO - 2017-08-22 06:03:53 --> Router Class Initialized
INFO - 2017-08-22 06:03:53 --> Output Class Initialized
INFO - 2017-08-22 06:03:53 --> Security Class Initialized
DEBUG - 2017-08-22 06:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:03:53 --> Input Class Initialized
INFO - 2017-08-22 06:03:53 --> Language Class Initialized
ERROR - 2017-08-22 06:03:53 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:03:53 --> Config Class Initialized
INFO - 2017-08-22 06:03:53 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:03:53 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:03:53 --> Utf8 Class Initialized
INFO - 2017-08-22 06:03:53 --> URI Class Initialized
INFO - 2017-08-22 06:03:53 --> Router Class Initialized
INFO - 2017-08-22 06:03:53 --> Output Class Initialized
INFO - 2017-08-22 06:03:53 --> Security Class Initialized
DEBUG - 2017-08-22 06:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:03:53 --> Input Class Initialized
INFO - 2017-08-22 06:03:53 --> Language Class Initialized
ERROR - 2017-08-22 06:03:53 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:04:02 --> Config Class Initialized
INFO - 2017-08-22 06:04:02 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:04:02 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:04:02 --> Utf8 Class Initialized
INFO - 2017-08-22 06:04:02 --> URI Class Initialized
DEBUG - 2017-08-22 06:04:02 --> No URI present. Default controller set.
INFO - 2017-08-22 06:04:02 --> Router Class Initialized
INFO - 2017-08-22 06:04:02 --> Output Class Initialized
INFO - 2017-08-22 06:04:02 --> Security Class Initialized
DEBUG - 2017-08-22 06:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:04:02 --> Input Class Initialized
INFO - 2017-08-22 06:04:02 --> Language Class Initialized
INFO - 2017-08-22 06:04:02 --> Loader Class Initialized
INFO - 2017-08-22 06:04:02 --> Helper loaded: url_helper
INFO - 2017-08-22 06:04:02 --> Helper loaded: file_helper
INFO - 2017-08-22 06:04:02 --> Database Driver Class Initialized
INFO - 2017-08-22 06:04:02 --> Email Class Initialized
DEBUG - 2017-08-22 06:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:04:02 --> Table Class Initialized
INFO - 2017-08-22 06:04:02 --> Controller Class Initialized
INFO - 2017-08-22 06:04:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:04:02 --> Final output sent to browser
DEBUG - 2017-08-22 06:04:02 --> Total execution time: 0.2355
INFO - 2017-08-22 06:04:02 --> Config Class Initialized
INFO - 2017-08-22 06:04:02 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:04:02 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:04:02 --> Utf8 Class Initialized
INFO - 2017-08-22 06:04:02 --> URI Class Initialized
INFO - 2017-08-22 06:04:02 --> Router Class Initialized
INFO - 2017-08-22 06:04:02 --> Output Class Initialized
INFO - 2017-08-22 06:04:02 --> Security Class Initialized
DEBUG - 2017-08-22 06:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:04:02 --> Input Class Initialized
INFO - 2017-08-22 06:04:02 --> Language Class Initialized
ERROR - 2017-08-22 06:04:02 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:04:02 --> Config Class Initialized
INFO - 2017-08-22 06:04:02 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:04:02 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:04:02 --> Utf8 Class Initialized
INFO - 2017-08-22 06:04:02 --> URI Class Initialized
INFO - 2017-08-22 06:04:02 --> Router Class Initialized
INFO - 2017-08-22 06:04:02 --> Output Class Initialized
INFO - 2017-08-22 06:04:02 --> Security Class Initialized
DEBUG - 2017-08-22 06:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:04:02 --> Input Class Initialized
INFO - 2017-08-22 06:04:02 --> Language Class Initialized
ERROR - 2017-08-22 06:04:03 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:04:50 --> Config Class Initialized
INFO - 2017-08-22 06:04:50 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:04:50 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:04:50 --> Utf8 Class Initialized
INFO - 2017-08-22 06:04:50 --> URI Class Initialized
DEBUG - 2017-08-22 06:04:50 --> No URI present. Default controller set.
INFO - 2017-08-22 06:04:50 --> Router Class Initialized
INFO - 2017-08-22 06:04:50 --> Output Class Initialized
INFO - 2017-08-22 06:04:50 --> Security Class Initialized
DEBUG - 2017-08-22 06:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:04:50 --> Input Class Initialized
INFO - 2017-08-22 06:04:50 --> Language Class Initialized
INFO - 2017-08-22 06:04:50 --> Loader Class Initialized
INFO - 2017-08-22 06:04:50 --> Helper loaded: url_helper
INFO - 2017-08-22 06:04:50 --> Helper loaded: file_helper
INFO - 2017-08-22 06:04:50 --> Database Driver Class Initialized
INFO - 2017-08-22 06:04:50 --> Email Class Initialized
DEBUG - 2017-08-22 06:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:04:50 --> Table Class Initialized
INFO - 2017-08-22 06:04:50 --> Controller Class Initialized
INFO - 2017-08-22 06:04:50 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:04:50 --> Final output sent to browser
DEBUG - 2017-08-22 06:04:50 --> Total execution time: 0.2346
INFO - 2017-08-22 06:04:51 --> Config Class Initialized
INFO - 2017-08-22 06:04:51 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:04:51 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:04:51 --> Utf8 Class Initialized
INFO - 2017-08-22 06:04:51 --> URI Class Initialized
INFO - 2017-08-22 06:04:51 --> Router Class Initialized
INFO - 2017-08-22 06:04:51 --> Output Class Initialized
INFO - 2017-08-22 06:04:51 --> Security Class Initialized
DEBUG - 2017-08-22 06:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:04:51 --> Input Class Initialized
INFO - 2017-08-22 06:04:51 --> Language Class Initialized
ERROR - 2017-08-22 06:04:51 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:04:51 --> Config Class Initialized
INFO - 2017-08-22 06:04:51 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:04:51 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:04:51 --> Utf8 Class Initialized
INFO - 2017-08-22 06:04:51 --> URI Class Initialized
INFO - 2017-08-22 06:04:51 --> Router Class Initialized
INFO - 2017-08-22 06:04:51 --> Output Class Initialized
INFO - 2017-08-22 06:04:51 --> Security Class Initialized
DEBUG - 2017-08-22 06:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:04:51 --> Input Class Initialized
INFO - 2017-08-22 06:04:51 --> Language Class Initialized
ERROR - 2017-08-22 06:04:51 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:05:00 --> Config Class Initialized
INFO - 2017-08-22 06:05:00 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:00 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:00 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:00 --> URI Class Initialized
DEBUG - 2017-08-22 06:05:00 --> No URI present. Default controller set.
INFO - 2017-08-22 06:05:00 --> Router Class Initialized
INFO - 2017-08-22 06:05:00 --> Output Class Initialized
INFO - 2017-08-22 06:05:00 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:00 --> Input Class Initialized
INFO - 2017-08-22 06:05:00 --> Language Class Initialized
INFO - 2017-08-22 06:05:00 --> Loader Class Initialized
INFO - 2017-08-22 06:05:00 --> Helper loaded: url_helper
INFO - 2017-08-22 06:05:00 --> Helper loaded: file_helper
INFO - 2017-08-22 06:05:00 --> Database Driver Class Initialized
INFO - 2017-08-22 06:05:00 --> Email Class Initialized
DEBUG - 2017-08-22 06:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:05:00 --> Table Class Initialized
INFO - 2017-08-22 06:05:00 --> Controller Class Initialized
INFO - 2017-08-22 06:05:00 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:05:00 --> Final output sent to browser
DEBUG - 2017-08-22 06:05:00 --> Total execution time: 0.2356
INFO - 2017-08-22 06:05:00 --> Config Class Initialized
INFO - 2017-08-22 06:05:00 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:00 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:00 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:00 --> URI Class Initialized
INFO - 2017-08-22 06:05:00 --> Router Class Initialized
INFO - 2017-08-22 06:05:00 --> Output Class Initialized
INFO - 2017-08-22 06:05:00 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:00 --> Input Class Initialized
INFO - 2017-08-22 06:05:00 --> Language Class Initialized
ERROR - 2017-08-22 06:05:00 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:05:01 --> Config Class Initialized
INFO - 2017-08-22 06:05:01 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:01 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:01 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:01 --> URI Class Initialized
INFO - 2017-08-22 06:05:01 --> Router Class Initialized
INFO - 2017-08-22 06:05:01 --> Output Class Initialized
INFO - 2017-08-22 06:05:01 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:01 --> Input Class Initialized
INFO - 2017-08-22 06:05:01 --> Language Class Initialized
ERROR - 2017-08-22 06:05:01 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:05:03 --> Config Class Initialized
INFO - 2017-08-22 06:05:03 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:03 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:04 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:04 --> URI Class Initialized
DEBUG - 2017-08-22 06:05:04 --> No URI present. Default controller set.
INFO - 2017-08-22 06:05:04 --> Router Class Initialized
INFO - 2017-08-22 06:05:04 --> Output Class Initialized
INFO - 2017-08-22 06:05:04 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:04 --> Input Class Initialized
INFO - 2017-08-22 06:05:04 --> Language Class Initialized
INFO - 2017-08-22 06:05:04 --> Loader Class Initialized
INFO - 2017-08-22 06:05:04 --> Helper loaded: url_helper
INFO - 2017-08-22 06:05:04 --> Helper loaded: file_helper
INFO - 2017-08-22 06:05:04 --> Database Driver Class Initialized
INFO - 2017-08-22 06:05:04 --> Email Class Initialized
DEBUG - 2017-08-22 06:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:05:04 --> Table Class Initialized
INFO - 2017-08-22 06:05:04 --> Controller Class Initialized
INFO - 2017-08-22 06:05:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:05:04 --> Final output sent to browser
DEBUG - 2017-08-22 06:05:04 --> Total execution time: 0.2406
INFO - 2017-08-22 06:05:04 --> Config Class Initialized
INFO - 2017-08-22 06:05:04 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:04 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:04 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:04 --> URI Class Initialized
INFO - 2017-08-22 06:05:04 --> Router Class Initialized
INFO - 2017-08-22 06:05:04 --> Output Class Initialized
INFO - 2017-08-22 06:05:04 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:04 --> Input Class Initialized
INFO - 2017-08-22 06:05:04 --> Language Class Initialized
ERROR - 2017-08-22 06:05:04 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:05:04 --> Config Class Initialized
INFO - 2017-08-22 06:05:04 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:04 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:04 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:04 --> URI Class Initialized
INFO - 2017-08-22 06:05:04 --> Router Class Initialized
INFO - 2017-08-22 06:05:04 --> Output Class Initialized
INFO - 2017-08-22 06:05:04 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:04 --> Input Class Initialized
INFO - 2017-08-22 06:05:04 --> Language Class Initialized
ERROR - 2017-08-22 06:05:04 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:05:15 --> Config Class Initialized
INFO - 2017-08-22 06:05:15 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:15 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:15 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:15 --> URI Class Initialized
DEBUG - 2017-08-22 06:05:15 --> No URI present. Default controller set.
INFO - 2017-08-22 06:05:15 --> Router Class Initialized
INFO - 2017-08-22 06:05:15 --> Output Class Initialized
INFO - 2017-08-22 06:05:15 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:15 --> Input Class Initialized
INFO - 2017-08-22 06:05:15 --> Language Class Initialized
INFO - 2017-08-22 06:05:15 --> Loader Class Initialized
INFO - 2017-08-22 06:05:15 --> Helper loaded: url_helper
INFO - 2017-08-22 06:05:15 --> Helper loaded: file_helper
INFO - 2017-08-22 06:05:16 --> Database Driver Class Initialized
INFO - 2017-08-22 06:05:16 --> Email Class Initialized
DEBUG - 2017-08-22 06:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:05:16 --> Table Class Initialized
INFO - 2017-08-22 06:05:16 --> Controller Class Initialized
INFO - 2017-08-22 06:05:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:05:16 --> Final output sent to browser
DEBUG - 2017-08-22 06:05:16 --> Total execution time: 0.2424
INFO - 2017-08-22 06:05:16 --> Config Class Initialized
INFO - 2017-08-22 06:05:16 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:16 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:16 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:16 --> URI Class Initialized
INFO - 2017-08-22 06:05:16 --> Router Class Initialized
INFO - 2017-08-22 06:05:16 --> Output Class Initialized
INFO - 2017-08-22 06:05:16 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:16 --> Input Class Initialized
INFO - 2017-08-22 06:05:16 --> Language Class Initialized
ERROR - 2017-08-22 06:05:16 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:05:16 --> Config Class Initialized
INFO - 2017-08-22 06:05:16 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:16 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:16 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:16 --> URI Class Initialized
INFO - 2017-08-22 06:05:16 --> Router Class Initialized
INFO - 2017-08-22 06:05:16 --> Output Class Initialized
INFO - 2017-08-22 06:05:16 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:16 --> Input Class Initialized
INFO - 2017-08-22 06:05:16 --> Language Class Initialized
ERROR - 2017-08-22 06:05:16 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:05:28 --> Config Class Initialized
INFO - 2017-08-22 06:05:28 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:28 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:28 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:28 --> URI Class Initialized
DEBUG - 2017-08-22 06:05:28 --> No URI present. Default controller set.
INFO - 2017-08-22 06:05:28 --> Router Class Initialized
INFO - 2017-08-22 06:05:28 --> Output Class Initialized
INFO - 2017-08-22 06:05:28 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:28 --> Input Class Initialized
INFO - 2017-08-22 06:05:28 --> Language Class Initialized
INFO - 2017-08-22 06:05:28 --> Loader Class Initialized
INFO - 2017-08-22 06:05:28 --> Helper loaded: url_helper
INFO - 2017-08-22 06:05:28 --> Helper loaded: file_helper
INFO - 2017-08-22 06:05:28 --> Database Driver Class Initialized
INFO - 2017-08-22 06:05:28 --> Email Class Initialized
DEBUG - 2017-08-22 06:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:05:28 --> Table Class Initialized
INFO - 2017-08-22 06:05:28 --> Controller Class Initialized
INFO - 2017-08-22 06:05:28 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:05:28 --> Final output sent to browser
DEBUG - 2017-08-22 06:05:28 --> Total execution time: 0.2424
INFO - 2017-08-22 06:05:29 --> Config Class Initialized
INFO - 2017-08-22 06:05:29 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:29 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:29 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:29 --> URI Class Initialized
INFO - 2017-08-22 06:05:29 --> Router Class Initialized
INFO - 2017-08-22 06:05:29 --> Output Class Initialized
INFO - 2017-08-22 06:05:29 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:29 --> Input Class Initialized
INFO - 2017-08-22 06:05:29 --> Language Class Initialized
ERROR - 2017-08-22 06:05:29 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:05:29 --> Config Class Initialized
INFO - 2017-08-22 06:05:29 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:29 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:29 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:29 --> URI Class Initialized
INFO - 2017-08-22 06:05:29 --> Router Class Initialized
INFO - 2017-08-22 06:05:29 --> Output Class Initialized
INFO - 2017-08-22 06:05:29 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:29 --> Input Class Initialized
INFO - 2017-08-22 06:05:29 --> Language Class Initialized
ERROR - 2017-08-22 06:05:29 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:05:35 --> Config Class Initialized
INFO - 2017-08-22 06:05:35 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:35 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:35 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:35 --> URI Class Initialized
DEBUG - 2017-08-22 06:05:35 --> No URI present. Default controller set.
INFO - 2017-08-22 06:05:35 --> Router Class Initialized
INFO - 2017-08-22 06:05:35 --> Output Class Initialized
INFO - 2017-08-22 06:05:35 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:35 --> Input Class Initialized
INFO - 2017-08-22 06:05:35 --> Language Class Initialized
INFO - 2017-08-22 06:05:35 --> Loader Class Initialized
INFO - 2017-08-22 06:05:35 --> Helper loaded: url_helper
INFO - 2017-08-22 06:05:35 --> Helper loaded: file_helper
INFO - 2017-08-22 06:05:35 --> Database Driver Class Initialized
INFO - 2017-08-22 06:05:35 --> Email Class Initialized
DEBUG - 2017-08-22 06:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:05:35 --> Table Class Initialized
INFO - 2017-08-22 06:05:35 --> Controller Class Initialized
INFO - 2017-08-22 06:05:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:05:35 --> Final output sent to browser
DEBUG - 2017-08-22 06:05:35 --> Total execution time: 0.2443
INFO - 2017-08-22 06:05:36 --> Config Class Initialized
INFO - 2017-08-22 06:05:36 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:36 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:36 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:36 --> URI Class Initialized
INFO - 2017-08-22 06:05:36 --> Router Class Initialized
INFO - 2017-08-22 06:05:36 --> Output Class Initialized
INFO - 2017-08-22 06:05:36 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:36 --> Input Class Initialized
INFO - 2017-08-22 06:05:36 --> Language Class Initialized
ERROR - 2017-08-22 06:05:36 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:05:36 --> Config Class Initialized
INFO - 2017-08-22 06:05:36 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:36 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:36 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:36 --> URI Class Initialized
INFO - 2017-08-22 06:05:36 --> Router Class Initialized
INFO - 2017-08-22 06:05:36 --> Output Class Initialized
INFO - 2017-08-22 06:05:36 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:36 --> Input Class Initialized
INFO - 2017-08-22 06:05:36 --> Language Class Initialized
ERROR - 2017-08-22 06:05:36 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:05:40 --> Config Class Initialized
INFO - 2017-08-22 06:05:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:40 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:40 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:40 --> URI Class Initialized
DEBUG - 2017-08-22 06:05:40 --> No URI present. Default controller set.
INFO - 2017-08-22 06:05:40 --> Router Class Initialized
INFO - 2017-08-22 06:05:40 --> Output Class Initialized
INFO - 2017-08-22 06:05:40 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:40 --> Input Class Initialized
INFO - 2017-08-22 06:05:40 --> Language Class Initialized
INFO - 2017-08-22 06:05:40 --> Loader Class Initialized
INFO - 2017-08-22 06:05:40 --> Helper loaded: url_helper
INFO - 2017-08-22 06:05:40 --> Helper loaded: file_helper
INFO - 2017-08-22 06:05:40 --> Database Driver Class Initialized
INFO - 2017-08-22 06:05:40 --> Email Class Initialized
DEBUG - 2017-08-22 06:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:05:40 --> Table Class Initialized
INFO - 2017-08-22 06:05:40 --> Controller Class Initialized
INFO - 2017-08-22 06:05:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:05:40 --> Final output sent to browser
DEBUG - 2017-08-22 06:05:40 --> Total execution time: 0.2503
INFO - 2017-08-22 06:05:40 --> Config Class Initialized
INFO - 2017-08-22 06:05:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:40 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:40 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:40 --> URI Class Initialized
INFO - 2017-08-22 06:05:40 --> Router Class Initialized
INFO - 2017-08-22 06:05:40 --> Output Class Initialized
INFO - 2017-08-22 06:05:40 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:40 --> Input Class Initialized
INFO - 2017-08-22 06:05:40 --> Language Class Initialized
ERROR - 2017-08-22 06:05:40 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:05:41 --> Config Class Initialized
INFO - 2017-08-22 06:05:41 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:05:41 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:05:41 --> Utf8 Class Initialized
INFO - 2017-08-22 06:05:41 --> URI Class Initialized
INFO - 2017-08-22 06:05:41 --> Router Class Initialized
INFO - 2017-08-22 06:05:41 --> Output Class Initialized
INFO - 2017-08-22 06:05:41 --> Security Class Initialized
DEBUG - 2017-08-22 06:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:05:41 --> Input Class Initialized
INFO - 2017-08-22 06:05:41 --> Language Class Initialized
ERROR - 2017-08-22 06:05:41 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:07:36 --> Config Class Initialized
INFO - 2017-08-22 06:07:36 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:07:36 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:07:36 --> Utf8 Class Initialized
INFO - 2017-08-22 06:07:36 --> URI Class Initialized
DEBUG - 2017-08-22 06:07:36 --> No URI present. Default controller set.
INFO - 2017-08-22 06:07:36 --> Router Class Initialized
INFO - 2017-08-22 06:07:36 --> Output Class Initialized
INFO - 2017-08-22 06:07:36 --> Security Class Initialized
DEBUG - 2017-08-22 06:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:07:36 --> Input Class Initialized
INFO - 2017-08-22 06:07:36 --> Language Class Initialized
INFO - 2017-08-22 06:07:36 --> Loader Class Initialized
INFO - 2017-08-22 06:07:36 --> Helper loaded: url_helper
INFO - 2017-08-22 06:07:36 --> Helper loaded: file_helper
INFO - 2017-08-22 06:07:36 --> Database Driver Class Initialized
INFO - 2017-08-22 06:07:36 --> Email Class Initialized
DEBUG - 2017-08-22 06:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:07:36 --> Table Class Initialized
INFO - 2017-08-22 06:07:36 --> Controller Class Initialized
INFO - 2017-08-22 06:07:36 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:07:36 --> Final output sent to browser
DEBUG - 2017-08-22 06:07:36 --> Total execution time: 0.2781
INFO - 2017-08-22 06:07:36 --> Config Class Initialized
INFO - 2017-08-22 06:07:36 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:07:36 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:07:36 --> Utf8 Class Initialized
INFO - 2017-08-22 06:07:36 --> URI Class Initialized
INFO - 2017-08-22 06:07:36 --> Router Class Initialized
INFO - 2017-08-22 06:07:36 --> Output Class Initialized
INFO - 2017-08-22 06:07:36 --> Security Class Initialized
DEBUG - 2017-08-22 06:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:07:36 --> Input Class Initialized
INFO - 2017-08-22 06:07:36 --> Language Class Initialized
ERROR - 2017-08-22 06:07:36 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:07:37 --> Config Class Initialized
INFO - 2017-08-22 06:07:37 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:07:37 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:07:37 --> Utf8 Class Initialized
INFO - 2017-08-22 06:07:37 --> URI Class Initialized
INFO - 2017-08-22 06:07:37 --> Router Class Initialized
INFO - 2017-08-22 06:07:37 --> Output Class Initialized
INFO - 2017-08-22 06:07:37 --> Security Class Initialized
DEBUG - 2017-08-22 06:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:07:37 --> Input Class Initialized
INFO - 2017-08-22 06:07:37 --> Language Class Initialized
ERROR - 2017-08-22 06:07:37 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:08:00 --> Config Class Initialized
INFO - 2017-08-22 06:08:00 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:08:00 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:08:00 --> Utf8 Class Initialized
INFO - 2017-08-22 06:08:00 --> URI Class Initialized
DEBUG - 2017-08-22 06:08:00 --> No URI present. Default controller set.
INFO - 2017-08-22 06:08:00 --> Router Class Initialized
INFO - 2017-08-22 06:08:00 --> Output Class Initialized
INFO - 2017-08-22 06:08:00 --> Security Class Initialized
DEBUG - 2017-08-22 06:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:08:00 --> Input Class Initialized
INFO - 2017-08-22 06:08:00 --> Language Class Initialized
INFO - 2017-08-22 06:08:00 --> Loader Class Initialized
INFO - 2017-08-22 06:08:01 --> Helper loaded: url_helper
INFO - 2017-08-22 06:08:01 --> Helper loaded: file_helper
INFO - 2017-08-22 06:08:01 --> Database Driver Class Initialized
INFO - 2017-08-22 06:08:01 --> Email Class Initialized
DEBUG - 2017-08-22 06:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:08:01 --> Table Class Initialized
INFO - 2017-08-22 06:08:01 --> Controller Class Initialized
INFO - 2017-08-22 06:08:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:08:01 --> Final output sent to browser
DEBUG - 2017-08-22 06:08:01 --> Total execution time: 0.2405
INFO - 2017-08-22 06:08:01 --> Config Class Initialized
INFO - 2017-08-22 06:08:01 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:08:01 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:08:01 --> Utf8 Class Initialized
INFO - 2017-08-22 06:08:01 --> URI Class Initialized
INFO - 2017-08-22 06:08:01 --> Router Class Initialized
INFO - 2017-08-22 06:08:01 --> Output Class Initialized
INFO - 2017-08-22 06:08:01 --> Security Class Initialized
DEBUG - 2017-08-22 06:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:08:01 --> Input Class Initialized
INFO - 2017-08-22 06:08:01 --> Language Class Initialized
ERROR - 2017-08-22 06:08:01 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:08:01 --> Config Class Initialized
INFO - 2017-08-22 06:08:01 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:08:01 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:08:01 --> Utf8 Class Initialized
INFO - 2017-08-22 06:08:01 --> URI Class Initialized
INFO - 2017-08-22 06:08:01 --> Router Class Initialized
INFO - 2017-08-22 06:08:01 --> Output Class Initialized
INFO - 2017-08-22 06:08:01 --> Security Class Initialized
DEBUG - 2017-08-22 06:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:08:01 --> Input Class Initialized
INFO - 2017-08-22 06:08:01 --> Language Class Initialized
ERROR - 2017-08-22 06:08:01 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:10:24 --> Config Class Initialized
INFO - 2017-08-22 06:10:24 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:10:24 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:10:24 --> Utf8 Class Initialized
INFO - 2017-08-22 06:10:24 --> URI Class Initialized
DEBUG - 2017-08-22 06:10:24 --> No URI present. Default controller set.
INFO - 2017-08-22 06:10:24 --> Router Class Initialized
INFO - 2017-08-22 06:10:24 --> Output Class Initialized
INFO - 2017-08-22 06:10:24 --> Security Class Initialized
DEBUG - 2017-08-22 06:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:10:24 --> Input Class Initialized
INFO - 2017-08-22 06:10:24 --> Language Class Initialized
INFO - 2017-08-22 06:10:24 --> Loader Class Initialized
INFO - 2017-08-22 06:10:24 --> Helper loaded: url_helper
INFO - 2017-08-22 06:10:24 --> Helper loaded: file_helper
INFO - 2017-08-22 06:10:24 --> Database Driver Class Initialized
INFO - 2017-08-22 06:10:24 --> Email Class Initialized
DEBUG - 2017-08-22 06:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:10:24 --> Table Class Initialized
INFO - 2017-08-22 06:10:24 --> Controller Class Initialized
INFO - 2017-08-22 06:10:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:10:24 --> Final output sent to browser
DEBUG - 2017-08-22 06:10:24 --> Total execution time: 0.2565
INFO - 2017-08-22 06:10:24 --> Config Class Initialized
INFO - 2017-08-22 06:10:24 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:10:24 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:10:24 --> Utf8 Class Initialized
INFO - 2017-08-22 06:10:24 --> URI Class Initialized
INFO - 2017-08-22 06:10:24 --> Router Class Initialized
INFO - 2017-08-22 06:10:24 --> Output Class Initialized
INFO - 2017-08-22 06:10:24 --> Security Class Initialized
DEBUG - 2017-08-22 06:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:10:24 --> Input Class Initialized
INFO - 2017-08-22 06:10:24 --> Language Class Initialized
ERROR - 2017-08-22 06:10:24 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:10:25 --> Config Class Initialized
INFO - 2017-08-22 06:10:25 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:10:25 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:10:25 --> Utf8 Class Initialized
INFO - 2017-08-22 06:10:25 --> URI Class Initialized
INFO - 2017-08-22 06:10:25 --> Router Class Initialized
INFO - 2017-08-22 06:10:25 --> Output Class Initialized
INFO - 2017-08-22 06:10:25 --> Security Class Initialized
DEBUG - 2017-08-22 06:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:10:25 --> Input Class Initialized
INFO - 2017-08-22 06:10:25 --> Language Class Initialized
ERROR - 2017-08-22 06:10:25 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:11:23 --> Config Class Initialized
INFO - 2017-08-22 06:11:23 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:11:23 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:11:23 --> Utf8 Class Initialized
INFO - 2017-08-22 06:11:23 --> URI Class Initialized
DEBUG - 2017-08-22 06:11:23 --> No URI present. Default controller set.
INFO - 2017-08-22 06:11:23 --> Router Class Initialized
INFO - 2017-08-22 06:11:23 --> Output Class Initialized
INFO - 2017-08-22 06:11:23 --> Security Class Initialized
DEBUG - 2017-08-22 06:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:11:23 --> Input Class Initialized
INFO - 2017-08-22 06:11:23 --> Language Class Initialized
INFO - 2017-08-22 06:11:23 --> Loader Class Initialized
INFO - 2017-08-22 06:11:23 --> Helper loaded: url_helper
INFO - 2017-08-22 06:11:23 --> Helper loaded: file_helper
INFO - 2017-08-22 06:11:23 --> Database Driver Class Initialized
INFO - 2017-08-22 06:11:23 --> Email Class Initialized
DEBUG - 2017-08-22 06:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:11:23 --> Table Class Initialized
INFO - 2017-08-22 06:11:23 --> Controller Class Initialized
INFO - 2017-08-22 06:11:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:11:23 --> Final output sent to browser
DEBUG - 2017-08-22 06:11:23 --> Total execution time: 0.2567
INFO - 2017-08-22 06:11:23 --> Config Class Initialized
INFO - 2017-08-22 06:11:23 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:11:23 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:11:23 --> Utf8 Class Initialized
INFO - 2017-08-22 06:11:23 --> URI Class Initialized
INFO - 2017-08-22 06:11:23 --> Router Class Initialized
INFO - 2017-08-22 06:11:23 --> Output Class Initialized
INFO - 2017-08-22 06:11:23 --> Security Class Initialized
DEBUG - 2017-08-22 06:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:11:23 --> Input Class Initialized
INFO - 2017-08-22 06:11:23 --> Language Class Initialized
ERROR - 2017-08-22 06:11:23 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:11:24 --> Config Class Initialized
INFO - 2017-08-22 06:11:24 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:11:24 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:11:24 --> Utf8 Class Initialized
INFO - 2017-08-22 06:11:24 --> URI Class Initialized
INFO - 2017-08-22 06:11:24 --> Router Class Initialized
INFO - 2017-08-22 06:11:24 --> Output Class Initialized
INFO - 2017-08-22 06:11:24 --> Security Class Initialized
DEBUG - 2017-08-22 06:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:11:24 --> Input Class Initialized
INFO - 2017-08-22 06:11:24 --> Language Class Initialized
ERROR - 2017-08-22 06:11:24 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:11:32 --> Config Class Initialized
INFO - 2017-08-22 06:11:32 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:11:32 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:11:32 --> Utf8 Class Initialized
INFO - 2017-08-22 06:11:32 --> URI Class Initialized
DEBUG - 2017-08-22 06:11:32 --> No URI present. Default controller set.
INFO - 2017-08-22 06:11:32 --> Router Class Initialized
INFO - 2017-08-22 06:11:32 --> Output Class Initialized
INFO - 2017-08-22 06:11:32 --> Security Class Initialized
DEBUG - 2017-08-22 06:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:11:32 --> Input Class Initialized
INFO - 2017-08-22 06:11:32 --> Language Class Initialized
INFO - 2017-08-22 06:11:32 --> Loader Class Initialized
INFO - 2017-08-22 06:11:32 --> Helper loaded: url_helper
INFO - 2017-08-22 06:11:32 --> Helper loaded: file_helper
INFO - 2017-08-22 06:11:32 --> Database Driver Class Initialized
INFO - 2017-08-22 06:11:32 --> Email Class Initialized
DEBUG - 2017-08-22 06:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:11:32 --> Table Class Initialized
INFO - 2017-08-22 06:11:32 --> Controller Class Initialized
INFO - 2017-08-22 06:11:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:11:32 --> Final output sent to browser
DEBUG - 2017-08-22 06:11:32 --> Total execution time: 0.2454
INFO - 2017-08-22 06:11:32 --> Config Class Initialized
INFO - 2017-08-22 06:11:32 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:11:32 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:11:32 --> Utf8 Class Initialized
INFO - 2017-08-22 06:11:32 --> URI Class Initialized
INFO - 2017-08-22 06:11:32 --> Router Class Initialized
INFO - 2017-08-22 06:11:32 --> Output Class Initialized
INFO - 2017-08-22 06:11:32 --> Security Class Initialized
DEBUG - 2017-08-22 06:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:11:32 --> Input Class Initialized
INFO - 2017-08-22 06:11:33 --> Language Class Initialized
ERROR - 2017-08-22 06:11:33 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:11:33 --> Config Class Initialized
INFO - 2017-08-22 06:11:33 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:11:33 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:11:33 --> Utf8 Class Initialized
INFO - 2017-08-22 06:11:33 --> URI Class Initialized
INFO - 2017-08-22 06:11:33 --> Router Class Initialized
INFO - 2017-08-22 06:11:33 --> Output Class Initialized
INFO - 2017-08-22 06:11:33 --> Security Class Initialized
DEBUG - 2017-08-22 06:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:11:33 --> Input Class Initialized
INFO - 2017-08-22 06:11:33 --> Language Class Initialized
ERROR - 2017-08-22 06:11:33 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:11:35 --> Config Class Initialized
INFO - 2017-08-22 06:11:35 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:11:35 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:11:35 --> Utf8 Class Initialized
INFO - 2017-08-22 06:11:35 --> URI Class Initialized
DEBUG - 2017-08-22 06:11:35 --> No URI present. Default controller set.
INFO - 2017-08-22 06:11:35 --> Router Class Initialized
INFO - 2017-08-22 06:11:35 --> Output Class Initialized
INFO - 2017-08-22 06:11:35 --> Security Class Initialized
DEBUG - 2017-08-22 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:11:35 --> Input Class Initialized
INFO - 2017-08-22 06:11:35 --> Language Class Initialized
INFO - 2017-08-22 06:11:35 --> Loader Class Initialized
INFO - 2017-08-22 06:11:35 --> Helper loaded: url_helper
INFO - 2017-08-22 06:11:35 --> Helper loaded: file_helper
INFO - 2017-08-22 06:11:35 --> Database Driver Class Initialized
INFO - 2017-08-22 06:11:35 --> Email Class Initialized
DEBUG - 2017-08-22 06:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:11:35 --> Table Class Initialized
INFO - 2017-08-22 06:11:35 --> Controller Class Initialized
INFO - 2017-08-22 06:11:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:11:35 --> Final output sent to browser
DEBUG - 2017-08-22 06:11:35 --> Total execution time: 0.2501
INFO - 2017-08-22 06:11:36 --> Config Class Initialized
INFO - 2017-08-22 06:11:36 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:11:36 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:11:36 --> Utf8 Class Initialized
INFO - 2017-08-22 06:11:36 --> URI Class Initialized
INFO - 2017-08-22 06:11:36 --> Router Class Initialized
INFO - 2017-08-22 06:11:36 --> Output Class Initialized
INFO - 2017-08-22 06:11:36 --> Security Class Initialized
DEBUG - 2017-08-22 06:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:11:36 --> Input Class Initialized
INFO - 2017-08-22 06:11:36 --> Language Class Initialized
ERROR - 2017-08-22 06:11:36 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:11:36 --> Config Class Initialized
INFO - 2017-08-22 06:11:36 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:11:36 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:11:36 --> Utf8 Class Initialized
INFO - 2017-08-22 06:11:36 --> URI Class Initialized
INFO - 2017-08-22 06:11:36 --> Router Class Initialized
INFO - 2017-08-22 06:11:36 --> Output Class Initialized
INFO - 2017-08-22 06:11:36 --> Security Class Initialized
DEBUG - 2017-08-22 06:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:11:36 --> Input Class Initialized
INFO - 2017-08-22 06:11:36 --> Language Class Initialized
ERROR - 2017-08-22 06:11:36 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:12:07 --> Config Class Initialized
INFO - 2017-08-22 06:12:07 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:12:07 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:12:07 --> Utf8 Class Initialized
INFO - 2017-08-22 06:12:07 --> URI Class Initialized
DEBUG - 2017-08-22 06:12:07 --> No URI present. Default controller set.
INFO - 2017-08-22 06:12:07 --> Router Class Initialized
INFO - 2017-08-22 06:12:07 --> Output Class Initialized
INFO - 2017-08-22 06:12:07 --> Security Class Initialized
DEBUG - 2017-08-22 06:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:12:07 --> Input Class Initialized
INFO - 2017-08-22 06:12:07 --> Language Class Initialized
INFO - 2017-08-22 06:12:07 --> Loader Class Initialized
INFO - 2017-08-22 06:12:07 --> Helper loaded: url_helper
INFO - 2017-08-22 06:12:07 --> Helper loaded: file_helper
INFO - 2017-08-22 06:12:07 --> Database Driver Class Initialized
INFO - 2017-08-22 06:12:08 --> Email Class Initialized
DEBUG - 2017-08-22 06:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:12:08 --> Table Class Initialized
INFO - 2017-08-22 06:12:08 --> Controller Class Initialized
INFO - 2017-08-22 06:12:08 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:12:08 --> Final output sent to browser
DEBUG - 2017-08-22 06:12:08 --> Total execution time: 0.2499
INFO - 2017-08-22 06:12:08 --> Config Class Initialized
INFO - 2017-08-22 06:12:08 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:12:08 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:12:08 --> Utf8 Class Initialized
INFO - 2017-08-22 06:12:08 --> URI Class Initialized
INFO - 2017-08-22 06:12:08 --> Router Class Initialized
INFO - 2017-08-22 06:12:08 --> Output Class Initialized
INFO - 2017-08-22 06:12:08 --> Security Class Initialized
DEBUG - 2017-08-22 06:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:12:08 --> Input Class Initialized
INFO - 2017-08-22 06:12:08 --> Language Class Initialized
ERROR - 2017-08-22 06:12:08 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:12:08 --> Config Class Initialized
INFO - 2017-08-22 06:12:08 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:12:08 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:12:08 --> Utf8 Class Initialized
INFO - 2017-08-22 06:12:08 --> URI Class Initialized
INFO - 2017-08-22 06:12:08 --> Router Class Initialized
INFO - 2017-08-22 06:12:08 --> Output Class Initialized
INFO - 2017-08-22 06:12:08 --> Security Class Initialized
DEBUG - 2017-08-22 06:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:12:08 --> Input Class Initialized
INFO - 2017-08-22 06:12:08 --> Language Class Initialized
ERROR - 2017-08-22 06:12:08 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:12:16 --> Config Class Initialized
INFO - 2017-08-22 06:12:16 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:12:16 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:12:16 --> Utf8 Class Initialized
INFO - 2017-08-22 06:12:16 --> URI Class Initialized
DEBUG - 2017-08-22 06:12:16 --> No URI present. Default controller set.
INFO - 2017-08-22 06:12:16 --> Router Class Initialized
INFO - 2017-08-22 06:12:16 --> Output Class Initialized
INFO - 2017-08-22 06:12:16 --> Security Class Initialized
DEBUG - 2017-08-22 06:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:12:16 --> Input Class Initialized
INFO - 2017-08-22 06:12:16 --> Language Class Initialized
INFO - 2017-08-22 06:12:16 --> Loader Class Initialized
INFO - 2017-08-22 06:12:16 --> Helper loaded: url_helper
INFO - 2017-08-22 06:12:16 --> Helper loaded: file_helper
INFO - 2017-08-22 06:12:16 --> Database Driver Class Initialized
INFO - 2017-08-22 06:12:16 --> Email Class Initialized
DEBUG - 2017-08-22 06:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:12:16 --> Table Class Initialized
INFO - 2017-08-22 06:12:16 --> Controller Class Initialized
INFO - 2017-08-22 06:12:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:12:16 --> Final output sent to browser
DEBUG - 2017-08-22 06:12:16 --> Total execution time: 0.2521
INFO - 2017-08-22 06:12:16 --> Config Class Initialized
INFO - 2017-08-22 06:12:16 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:12:16 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:12:16 --> Utf8 Class Initialized
INFO - 2017-08-22 06:12:16 --> URI Class Initialized
INFO - 2017-08-22 06:12:17 --> Router Class Initialized
INFO - 2017-08-22 06:12:17 --> Output Class Initialized
INFO - 2017-08-22 06:12:17 --> Security Class Initialized
DEBUG - 2017-08-22 06:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:12:17 --> Input Class Initialized
INFO - 2017-08-22 06:12:17 --> Language Class Initialized
ERROR - 2017-08-22 06:12:17 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:12:17 --> Config Class Initialized
INFO - 2017-08-22 06:12:17 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:12:17 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:12:17 --> Utf8 Class Initialized
INFO - 2017-08-22 06:12:17 --> URI Class Initialized
INFO - 2017-08-22 06:12:17 --> Router Class Initialized
INFO - 2017-08-22 06:12:17 --> Output Class Initialized
INFO - 2017-08-22 06:12:17 --> Security Class Initialized
DEBUG - 2017-08-22 06:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:12:17 --> Input Class Initialized
INFO - 2017-08-22 06:12:17 --> Language Class Initialized
ERROR - 2017-08-22 06:12:17 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:12:42 --> Config Class Initialized
INFO - 2017-08-22 06:12:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:12:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:12:42 --> Utf8 Class Initialized
INFO - 2017-08-22 06:12:42 --> URI Class Initialized
DEBUG - 2017-08-22 06:12:42 --> No URI present. Default controller set.
INFO - 2017-08-22 06:12:42 --> Router Class Initialized
INFO - 2017-08-22 06:12:42 --> Output Class Initialized
INFO - 2017-08-22 06:12:42 --> Security Class Initialized
DEBUG - 2017-08-22 06:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:12:42 --> Input Class Initialized
INFO - 2017-08-22 06:12:42 --> Language Class Initialized
INFO - 2017-08-22 06:12:42 --> Loader Class Initialized
INFO - 2017-08-22 06:12:42 --> Helper loaded: url_helper
INFO - 2017-08-22 06:12:42 --> Helper loaded: file_helper
INFO - 2017-08-22 06:12:42 --> Database Driver Class Initialized
INFO - 2017-08-22 06:12:43 --> Email Class Initialized
DEBUG - 2017-08-22 06:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:12:43 --> Table Class Initialized
INFO - 2017-08-22 06:12:43 --> Controller Class Initialized
INFO - 2017-08-22 06:12:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:12:43 --> Final output sent to browser
DEBUG - 2017-08-22 06:12:43 --> Total execution time: 0.2517
INFO - 2017-08-22 06:12:43 --> Config Class Initialized
INFO - 2017-08-22 06:12:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:12:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:12:43 --> Utf8 Class Initialized
INFO - 2017-08-22 06:12:43 --> URI Class Initialized
INFO - 2017-08-22 06:12:43 --> Router Class Initialized
INFO - 2017-08-22 06:12:43 --> Output Class Initialized
INFO - 2017-08-22 06:12:43 --> Security Class Initialized
DEBUG - 2017-08-22 06:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:12:43 --> Input Class Initialized
INFO - 2017-08-22 06:12:43 --> Language Class Initialized
ERROR - 2017-08-22 06:12:43 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:12:43 --> Config Class Initialized
INFO - 2017-08-22 06:12:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:12:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:12:43 --> Utf8 Class Initialized
INFO - 2017-08-22 06:12:43 --> URI Class Initialized
INFO - 2017-08-22 06:12:43 --> Router Class Initialized
INFO - 2017-08-22 06:12:43 --> Output Class Initialized
INFO - 2017-08-22 06:12:43 --> Security Class Initialized
DEBUG - 2017-08-22 06:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:12:43 --> Input Class Initialized
INFO - 2017-08-22 06:12:43 --> Language Class Initialized
ERROR - 2017-08-22 06:12:43 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:16:55 --> Config Class Initialized
INFO - 2017-08-22 06:16:55 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:16:55 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:16:55 --> Utf8 Class Initialized
INFO - 2017-08-22 06:16:55 --> URI Class Initialized
DEBUG - 2017-08-22 06:16:55 --> No URI present. Default controller set.
INFO - 2017-08-22 06:16:55 --> Router Class Initialized
INFO - 2017-08-22 06:16:55 --> Output Class Initialized
INFO - 2017-08-22 06:16:55 --> Security Class Initialized
DEBUG - 2017-08-22 06:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:16:55 --> Input Class Initialized
INFO - 2017-08-22 06:16:55 --> Language Class Initialized
INFO - 2017-08-22 06:16:55 --> Loader Class Initialized
INFO - 2017-08-22 06:16:55 --> Helper loaded: url_helper
INFO - 2017-08-22 06:16:55 --> Helper loaded: file_helper
INFO - 2017-08-22 06:16:55 --> Database Driver Class Initialized
INFO - 2017-08-22 06:16:55 --> Email Class Initialized
DEBUG - 2017-08-22 06:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:16:55 --> Table Class Initialized
INFO - 2017-08-22 06:16:55 --> Controller Class Initialized
INFO - 2017-08-22 06:16:55 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:16:55 --> Final output sent to browser
DEBUG - 2017-08-22 06:16:55 --> Total execution time: 0.2531
INFO - 2017-08-22 06:16:55 --> Config Class Initialized
INFO - 2017-08-22 06:16:55 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:16:55 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:16:55 --> Utf8 Class Initialized
INFO - 2017-08-22 06:16:55 --> URI Class Initialized
INFO - 2017-08-22 06:16:55 --> Router Class Initialized
INFO - 2017-08-22 06:16:55 --> Output Class Initialized
INFO - 2017-08-22 06:16:55 --> Security Class Initialized
DEBUG - 2017-08-22 06:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:16:55 --> Input Class Initialized
INFO - 2017-08-22 06:16:55 --> Language Class Initialized
ERROR - 2017-08-22 06:16:55 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:16:56 --> Config Class Initialized
INFO - 2017-08-22 06:16:56 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:16:56 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:16:56 --> Utf8 Class Initialized
INFO - 2017-08-22 06:16:56 --> URI Class Initialized
INFO - 2017-08-22 06:16:56 --> Router Class Initialized
INFO - 2017-08-22 06:16:56 --> Output Class Initialized
INFO - 2017-08-22 06:16:56 --> Security Class Initialized
DEBUG - 2017-08-22 06:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:16:56 --> Input Class Initialized
INFO - 2017-08-22 06:16:56 --> Language Class Initialized
ERROR - 2017-08-22 06:16:56 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:17:28 --> Config Class Initialized
INFO - 2017-08-22 06:17:28 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:17:28 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:17:28 --> Utf8 Class Initialized
INFO - 2017-08-22 06:17:28 --> URI Class Initialized
INFO - 2017-08-22 06:17:28 --> Router Class Initialized
INFO - 2017-08-22 06:17:28 --> Output Class Initialized
INFO - 2017-08-22 06:17:28 --> Security Class Initialized
DEBUG - 2017-08-22 06:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:17:28 --> Input Class Initialized
INFO - 2017-08-22 06:17:28 --> Language Class Initialized
ERROR - 2017-08-22 06:17:28 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:18:54 --> Config Class Initialized
INFO - 2017-08-22 06:18:54 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:18:54 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:18:54 --> Utf8 Class Initialized
INFO - 2017-08-22 06:18:54 --> URI Class Initialized
DEBUG - 2017-08-22 06:18:54 --> No URI present. Default controller set.
INFO - 2017-08-22 06:18:54 --> Router Class Initialized
INFO - 2017-08-22 06:18:55 --> Output Class Initialized
INFO - 2017-08-22 06:18:55 --> Security Class Initialized
DEBUG - 2017-08-22 06:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:18:55 --> Input Class Initialized
INFO - 2017-08-22 06:18:55 --> Language Class Initialized
INFO - 2017-08-22 06:18:55 --> Loader Class Initialized
INFO - 2017-08-22 06:18:55 --> Helper loaded: url_helper
INFO - 2017-08-22 06:18:55 --> Helper loaded: file_helper
INFO - 2017-08-22 06:18:55 --> Database Driver Class Initialized
INFO - 2017-08-22 06:18:55 --> Email Class Initialized
DEBUG - 2017-08-22 06:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:18:55 --> Table Class Initialized
INFO - 2017-08-22 06:18:55 --> Controller Class Initialized
INFO - 2017-08-22 06:18:55 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:18:55 --> Final output sent to browser
DEBUG - 2017-08-22 06:18:55 --> Total execution time: 0.2584
INFO - 2017-08-22 06:18:55 --> Config Class Initialized
INFO - 2017-08-22 06:18:55 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:18:55 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:18:55 --> Utf8 Class Initialized
INFO - 2017-08-22 06:18:55 --> URI Class Initialized
INFO - 2017-08-22 06:18:55 --> Router Class Initialized
INFO - 2017-08-22 06:18:55 --> Output Class Initialized
INFO - 2017-08-22 06:18:55 --> Security Class Initialized
DEBUG - 2017-08-22 06:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:18:55 --> Input Class Initialized
INFO - 2017-08-22 06:18:55 --> Language Class Initialized
ERROR - 2017-08-22 06:18:55 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:18:55 --> Config Class Initialized
INFO - 2017-08-22 06:18:55 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:18:55 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:18:55 --> Utf8 Class Initialized
INFO - 2017-08-22 06:18:55 --> URI Class Initialized
INFO - 2017-08-22 06:18:55 --> Router Class Initialized
INFO - 2017-08-22 06:18:55 --> Output Class Initialized
INFO - 2017-08-22 06:18:55 --> Security Class Initialized
DEBUG - 2017-08-22 06:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:18:55 --> Input Class Initialized
INFO - 2017-08-22 06:18:55 --> Language Class Initialized
ERROR - 2017-08-22 06:18:55 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:20:40 --> Config Class Initialized
INFO - 2017-08-22 06:20:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:20:41 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:20:41 --> Utf8 Class Initialized
INFO - 2017-08-22 06:20:41 --> URI Class Initialized
DEBUG - 2017-08-22 06:20:41 --> No URI present. Default controller set.
INFO - 2017-08-22 06:20:41 --> Router Class Initialized
INFO - 2017-08-22 06:20:41 --> Output Class Initialized
INFO - 2017-08-22 06:20:41 --> Security Class Initialized
DEBUG - 2017-08-22 06:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:20:41 --> Input Class Initialized
INFO - 2017-08-22 06:20:41 --> Language Class Initialized
INFO - 2017-08-22 06:20:41 --> Loader Class Initialized
INFO - 2017-08-22 06:20:41 --> Helper loaded: url_helper
INFO - 2017-08-22 06:20:41 --> Helper loaded: file_helper
INFO - 2017-08-22 06:20:41 --> Database Driver Class Initialized
INFO - 2017-08-22 06:20:41 --> Email Class Initialized
DEBUG - 2017-08-22 06:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:20:41 --> Table Class Initialized
INFO - 2017-08-22 06:20:41 --> Controller Class Initialized
INFO - 2017-08-22 06:20:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:20:41 --> Final output sent to browser
DEBUG - 2017-08-22 06:20:41 --> Total execution time: 0.2527
INFO - 2017-08-22 06:20:41 --> Config Class Initialized
INFO - 2017-08-22 06:20:41 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:20:41 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:20:41 --> Utf8 Class Initialized
INFO - 2017-08-22 06:20:41 --> URI Class Initialized
INFO - 2017-08-22 06:20:41 --> Router Class Initialized
INFO - 2017-08-22 06:20:41 --> Output Class Initialized
INFO - 2017-08-22 06:20:41 --> Security Class Initialized
DEBUG - 2017-08-22 06:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:20:41 --> Input Class Initialized
INFO - 2017-08-22 06:20:41 --> Language Class Initialized
ERROR - 2017-08-22 06:20:41 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:20:41 --> Config Class Initialized
INFO - 2017-08-22 06:20:41 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:20:41 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:20:41 --> Utf8 Class Initialized
INFO - 2017-08-22 06:20:41 --> URI Class Initialized
INFO - 2017-08-22 06:20:41 --> Router Class Initialized
INFO - 2017-08-22 06:20:41 --> Output Class Initialized
INFO - 2017-08-22 06:20:41 --> Security Class Initialized
DEBUG - 2017-08-22 06:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:20:41 --> Input Class Initialized
INFO - 2017-08-22 06:20:41 --> Language Class Initialized
ERROR - 2017-08-22 06:20:41 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 06:21:04 --> Config Class Initialized
INFO - 2017-08-22 06:21:04 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:21:04 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:21:04 --> Utf8 Class Initialized
INFO - 2017-08-22 06:21:04 --> URI Class Initialized
DEBUG - 2017-08-22 06:21:04 --> No URI present. Default controller set.
INFO - 2017-08-22 06:21:04 --> Router Class Initialized
INFO - 2017-08-22 06:21:04 --> Output Class Initialized
INFO - 2017-08-22 06:21:04 --> Security Class Initialized
DEBUG - 2017-08-22 06:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:21:04 --> Input Class Initialized
INFO - 2017-08-22 06:21:04 --> Language Class Initialized
INFO - 2017-08-22 06:21:04 --> Loader Class Initialized
INFO - 2017-08-22 06:21:04 --> Helper loaded: url_helper
INFO - 2017-08-22 06:21:04 --> Helper loaded: file_helper
INFO - 2017-08-22 06:21:04 --> Database Driver Class Initialized
INFO - 2017-08-22 06:21:04 --> Email Class Initialized
DEBUG - 2017-08-22 06:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:21:04 --> Table Class Initialized
INFO - 2017-08-22 06:21:04 --> Controller Class Initialized
INFO - 2017-08-22 06:21:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:21:04 --> Final output sent to browser
DEBUG - 2017-08-22 06:21:04 --> Total execution time: 0.2636
INFO - 2017-08-22 06:21:14 --> Config Class Initialized
INFO - 2017-08-22 06:21:14 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:21:14 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:21:14 --> Utf8 Class Initialized
INFO - 2017-08-22 06:21:14 --> URI Class Initialized
DEBUG - 2017-08-22 06:21:14 --> No URI present. Default controller set.
INFO - 2017-08-22 06:21:14 --> Router Class Initialized
INFO - 2017-08-22 06:21:15 --> Output Class Initialized
INFO - 2017-08-22 06:21:15 --> Security Class Initialized
DEBUG - 2017-08-22 06:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:21:15 --> Input Class Initialized
INFO - 2017-08-22 06:21:15 --> Language Class Initialized
INFO - 2017-08-22 06:21:15 --> Loader Class Initialized
INFO - 2017-08-22 06:21:15 --> Helper loaded: url_helper
INFO - 2017-08-22 06:21:15 --> Helper loaded: file_helper
INFO - 2017-08-22 06:21:15 --> Database Driver Class Initialized
INFO - 2017-08-22 06:21:15 --> Email Class Initialized
DEBUG - 2017-08-22 06:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:21:15 --> Table Class Initialized
INFO - 2017-08-22 06:21:15 --> Controller Class Initialized
INFO - 2017-08-22 06:21:15 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:21:15 --> Final output sent to browser
DEBUG - 2017-08-22 06:21:15 --> Total execution time: 0.2498
INFO - 2017-08-22 06:21:22 --> Config Class Initialized
INFO - 2017-08-22 06:21:22 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:21:22 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:21:22 --> Utf8 Class Initialized
INFO - 2017-08-22 06:21:22 --> URI Class Initialized
DEBUG - 2017-08-22 06:21:22 --> No URI present. Default controller set.
INFO - 2017-08-22 06:21:22 --> Router Class Initialized
INFO - 2017-08-22 06:21:22 --> Output Class Initialized
INFO - 2017-08-22 06:21:22 --> Security Class Initialized
DEBUG - 2017-08-22 06:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:21:22 --> Input Class Initialized
INFO - 2017-08-22 06:21:22 --> Language Class Initialized
INFO - 2017-08-22 06:21:22 --> Loader Class Initialized
INFO - 2017-08-22 06:21:22 --> Helper loaded: url_helper
INFO - 2017-08-22 06:21:22 --> Helper loaded: file_helper
INFO - 2017-08-22 06:21:22 --> Database Driver Class Initialized
INFO - 2017-08-22 06:21:22 --> Email Class Initialized
DEBUG - 2017-08-22 06:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:21:22 --> Table Class Initialized
INFO - 2017-08-22 06:21:22 --> Controller Class Initialized
INFO - 2017-08-22 06:21:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:21:22 --> Final output sent to browser
DEBUG - 2017-08-22 06:21:22 --> Total execution time: 0.2549
INFO - 2017-08-22 06:21:38 --> Config Class Initialized
INFO - 2017-08-22 06:21:38 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:21:38 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:21:38 --> Utf8 Class Initialized
INFO - 2017-08-22 06:21:38 --> URI Class Initialized
DEBUG - 2017-08-22 06:21:38 --> No URI present. Default controller set.
INFO - 2017-08-22 06:21:38 --> Router Class Initialized
INFO - 2017-08-22 06:21:38 --> Output Class Initialized
INFO - 2017-08-22 06:21:38 --> Security Class Initialized
DEBUG - 2017-08-22 06:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:21:38 --> Input Class Initialized
INFO - 2017-08-22 06:21:38 --> Language Class Initialized
INFO - 2017-08-22 06:21:38 --> Loader Class Initialized
INFO - 2017-08-22 06:21:38 --> Helper loaded: url_helper
INFO - 2017-08-22 06:21:38 --> Helper loaded: file_helper
INFO - 2017-08-22 06:21:38 --> Database Driver Class Initialized
INFO - 2017-08-22 06:21:38 --> Email Class Initialized
DEBUG - 2017-08-22 06:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:21:38 --> Table Class Initialized
INFO - 2017-08-22 06:21:38 --> Controller Class Initialized
INFO - 2017-08-22 06:21:38 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:21:38 --> Final output sent to browser
DEBUG - 2017-08-22 06:21:38 --> Total execution time: 0.2465
INFO - 2017-08-22 06:21:40 --> Config Class Initialized
INFO - 2017-08-22 06:21:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:21:40 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:21:40 --> Utf8 Class Initialized
INFO - 2017-08-22 06:21:40 --> URI Class Initialized
DEBUG - 2017-08-22 06:21:40 --> No URI present. Default controller set.
INFO - 2017-08-22 06:21:40 --> Router Class Initialized
INFO - 2017-08-22 06:21:40 --> Output Class Initialized
INFO - 2017-08-22 06:21:40 --> Security Class Initialized
DEBUG - 2017-08-22 06:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:21:40 --> Input Class Initialized
INFO - 2017-08-22 06:21:40 --> Language Class Initialized
INFO - 2017-08-22 06:21:40 --> Loader Class Initialized
INFO - 2017-08-22 06:21:40 --> Helper loaded: url_helper
INFO - 2017-08-22 06:21:40 --> Helper loaded: file_helper
INFO - 2017-08-22 06:21:40 --> Database Driver Class Initialized
INFO - 2017-08-22 06:21:40 --> Email Class Initialized
DEBUG - 2017-08-22 06:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:21:40 --> Table Class Initialized
INFO - 2017-08-22 06:21:40 --> Controller Class Initialized
INFO - 2017-08-22 06:21:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:21:40 --> Final output sent to browser
DEBUG - 2017-08-22 06:21:40 --> Total execution time: 0.2553
INFO - 2017-08-22 06:21:41 --> Config Class Initialized
INFO - 2017-08-22 06:21:41 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:21:41 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:21:41 --> Utf8 Class Initialized
INFO - 2017-08-22 06:21:41 --> URI Class Initialized
DEBUG - 2017-08-22 06:21:41 --> No URI present. Default controller set.
INFO - 2017-08-22 06:21:41 --> Router Class Initialized
INFO - 2017-08-22 06:21:41 --> Output Class Initialized
INFO - 2017-08-22 06:21:41 --> Security Class Initialized
DEBUG - 2017-08-22 06:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:21:41 --> Input Class Initialized
INFO - 2017-08-22 06:21:41 --> Language Class Initialized
INFO - 2017-08-22 06:21:41 --> Loader Class Initialized
INFO - 2017-08-22 06:21:41 --> Helper loaded: url_helper
INFO - 2017-08-22 06:21:41 --> Helper loaded: file_helper
INFO - 2017-08-22 06:21:41 --> Database Driver Class Initialized
INFO - 2017-08-22 06:21:41 --> Email Class Initialized
DEBUG - 2017-08-22 06:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:21:41 --> Table Class Initialized
INFO - 2017-08-22 06:21:41 --> Controller Class Initialized
INFO - 2017-08-22 06:21:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:21:41 --> Final output sent to browser
DEBUG - 2017-08-22 06:21:41 --> Total execution time: 0.2418
INFO - 2017-08-22 06:23:12 --> Config Class Initialized
INFO - 2017-08-22 06:23:12 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:23:12 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:23:12 --> Utf8 Class Initialized
INFO - 2017-08-22 06:23:12 --> URI Class Initialized
DEBUG - 2017-08-22 06:23:12 --> No URI present. Default controller set.
INFO - 2017-08-22 06:23:12 --> Router Class Initialized
INFO - 2017-08-22 06:23:12 --> Output Class Initialized
INFO - 2017-08-22 06:23:12 --> Security Class Initialized
DEBUG - 2017-08-22 06:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:23:12 --> Input Class Initialized
INFO - 2017-08-22 06:23:12 --> Language Class Initialized
INFO - 2017-08-22 06:23:12 --> Loader Class Initialized
INFO - 2017-08-22 06:23:12 --> Helper loaded: url_helper
INFO - 2017-08-22 06:23:12 --> Helper loaded: file_helper
INFO - 2017-08-22 06:23:12 --> Database Driver Class Initialized
INFO - 2017-08-22 06:23:12 --> Email Class Initialized
DEBUG - 2017-08-22 06:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:23:12 --> Table Class Initialized
INFO - 2017-08-22 06:23:12 --> Controller Class Initialized
INFO - 2017-08-22 06:23:12 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:23:12 --> Final output sent to browser
DEBUG - 2017-08-22 06:23:12 --> Total execution time: 0.2587
INFO - 2017-08-22 06:23:26 --> Config Class Initialized
INFO - 2017-08-22 06:23:26 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:23:26 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:23:26 --> Utf8 Class Initialized
INFO - 2017-08-22 06:23:26 --> URI Class Initialized
DEBUG - 2017-08-22 06:23:26 --> No URI present. Default controller set.
INFO - 2017-08-22 06:23:26 --> Router Class Initialized
INFO - 2017-08-22 06:23:26 --> Output Class Initialized
INFO - 2017-08-22 06:23:26 --> Security Class Initialized
DEBUG - 2017-08-22 06:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:23:26 --> Input Class Initialized
INFO - 2017-08-22 06:23:26 --> Language Class Initialized
INFO - 2017-08-22 06:23:26 --> Loader Class Initialized
INFO - 2017-08-22 06:23:26 --> Helper loaded: url_helper
INFO - 2017-08-22 06:23:26 --> Helper loaded: file_helper
INFO - 2017-08-22 06:23:26 --> Database Driver Class Initialized
INFO - 2017-08-22 06:23:26 --> Email Class Initialized
DEBUG - 2017-08-22 06:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:23:26 --> Table Class Initialized
INFO - 2017-08-22 06:23:26 --> Controller Class Initialized
INFO - 2017-08-22 06:23:26 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:23:26 --> Final output sent to browser
DEBUG - 2017-08-22 06:23:26 --> Total execution time: 0.2621
INFO - 2017-08-22 06:23:40 --> Config Class Initialized
INFO - 2017-08-22 06:23:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:23:40 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:23:40 --> Utf8 Class Initialized
INFO - 2017-08-22 06:23:40 --> URI Class Initialized
DEBUG - 2017-08-22 06:23:40 --> No URI present. Default controller set.
INFO - 2017-08-22 06:23:40 --> Router Class Initialized
INFO - 2017-08-22 06:23:40 --> Output Class Initialized
INFO - 2017-08-22 06:23:40 --> Security Class Initialized
DEBUG - 2017-08-22 06:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:23:40 --> Input Class Initialized
INFO - 2017-08-22 06:23:40 --> Language Class Initialized
INFO - 2017-08-22 06:23:40 --> Loader Class Initialized
INFO - 2017-08-22 06:23:40 --> Helper loaded: url_helper
INFO - 2017-08-22 06:23:40 --> Helper loaded: file_helper
INFO - 2017-08-22 06:23:40 --> Database Driver Class Initialized
INFO - 2017-08-22 06:23:40 --> Email Class Initialized
DEBUG - 2017-08-22 06:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:23:40 --> Table Class Initialized
INFO - 2017-08-22 06:23:41 --> Controller Class Initialized
INFO - 2017-08-22 06:23:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:23:41 --> Final output sent to browser
DEBUG - 2017-08-22 06:23:41 --> Total execution time: 0.2495
INFO - 2017-08-22 06:23:42 --> Config Class Initialized
INFO - 2017-08-22 06:23:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:23:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:23:42 --> Utf8 Class Initialized
INFO - 2017-08-22 06:23:42 --> URI Class Initialized
DEBUG - 2017-08-22 06:23:42 --> No URI present. Default controller set.
INFO - 2017-08-22 06:23:42 --> Router Class Initialized
INFO - 2017-08-22 06:23:42 --> Output Class Initialized
INFO - 2017-08-22 06:23:42 --> Security Class Initialized
DEBUG - 2017-08-22 06:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:23:42 --> Input Class Initialized
INFO - 2017-08-22 06:23:42 --> Language Class Initialized
INFO - 2017-08-22 06:23:42 --> Loader Class Initialized
INFO - 2017-08-22 06:23:42 --> Helper loaded: url_helper
INFO - 2017-08-22 06:23:42 --> Helper loaded: file_helper
INFO - 2017-08-22 06:23:42 --> Database Driver Class Initialized
INFO - 2017-08-22 06:23:42 --> Email Class Initialized
DEBUG - 2017-08-22 06:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:23:42 --> Table Class Initialized
INFO - 2017-08-22 06:23:42 --> Controller Class Initialized
INFO - 2017-08-22 06:23:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:23:42 --> Final output sent to browser
DEBUG - 2017-08-22 06:23:42 --> Total execution time: 0.2427
INFO - 2017-08-22 06:24:33 --> Config Class Initialized
INFO - 2017-08-22 06:24:33 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:24:33 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:24:33 --> Utf8 Class Initialized
INFO - 2017-08-22 06:24:33 --> URI Class Initialized
DEBUG - 2017-08-22 06:24:33 --> No URI present. Default controller set.
INFO - 2017-08-22 06:24:33 --> Router Class Initialized
INFO - 2017-08-22 06:24:33 --> Output Class Initialized
INFO - 2017-08-22 06:24:33 --> Security Class Initialized
DEBUG - 2017-08-22 06:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:24:33 --> Input Class Initialized
INFO - 2017-08-22 06:24:33 --> Language Class Initialized
INFO - 2017-08-22 06:24:33 --> Loader Class Initialized
INFO - 2017-08-22 06:24:33 --> Helper loaded: url_helper
INFO - 2017-08-22 06:24:33 --> Helper loaded: file_helper
INFO - 2017-08-22 06:24:33 --> Database Driver Class Initialized
INFO - 2017-08-22 06:24:33 --> Email Class Initialized
DEBUG - 2017-08-22 06:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:24:33 --> Table Class Initialized
INFO - 2017-08-22 06:24:33 --> Controller Class Initialized
INFO - 2017-08-22 06:24:33 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:24:33 --> Final output sent to browser
DEBUG - 2017-08-22 06:24:33 --> Total execution time: 0.2547
INFO - 2017-08-22 06:24:45 --> Config Class Initialized
INFO - 2017-08-22 06:24:45 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:24:45 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:24:45 --> Utf8 Class Initialized
INFO - 2017-08-22 06:24:45 --> URI Class Initialized
DEBUG - 2017-08-22 06:24:45 --> No URI present. Default controller set.
INFO - 2017-08-22 06:24:45 --> Router Class Initialized
INFO - 2017-08-22 06:24:45 --> Output Class Initialized
INFO - 2017-08-22 06:24:45 --> Security Class Initialized
DEBUG - 2017-08-22 06:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:24:45 --> Input Class Initialized
INFO - 2017-08-22 06:24:45 --> Language Class Initialized
INFO - 2017-08-22 06:24:45 --> Loader Class Initialized
INFO - 2017-08-22 06:24:45 --> Helper loaded: url_helper
INFO - 2017-08-22 06:24:45 --> Helper loaded: file_helper
INFO - 2017-08-22 06:24:45 --> Database Driver Class Initialized
INFO - 2017-08-22 06:24:45 --> Email Class Initialized
DEBUG - 2017-08-22 06:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:24:45 --> Table Class Initialized
INFO - 2017-08-22 06:24:45 --> Controller Class Initialized
INFO - 2017-08-22 06:24:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:24:45 --> Final output sent to browser
DEBUG - 2017-08-22 06:24:46 --> Total execution time: 0.2550
INFO - 2017-08-22 06:24:49 --> Config Class Initialized
INFO - 2017-08-22 06:24:49 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:24:49 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:24:49 --> Utf8 Class Initialized
INFO - 2017-08-22 06:24:49 --> URI Class Initialized
DEBUG - 2017-08-22 06:24:49 --> No URI present. Default controller set.
INFO - 2017-08-22 06:24:49 --> Router Class Initialized
INFO - 2017-08-22 06:24:49 --> Output Class Initialized
INFO - 2017-08-22 06:24:49 --> Security Class Initialized
DEBUG - 2017-08-22 06:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:24:49 --> Input Class Initialized
INFO - 2017-08-22 06:24:49 --> Language Class Initialized
INFO - 2017-08-22 06:24:49 --> Loader Class Initialized
INFO - 2017-08-22 06:24:49 --> Helper loaded: url_helper
INFO - 2017-08-22 06:24:49 --> Helper loaded: file_helper
INFO - 2017-08-22 06:24:49 --> Database Driver Class Initialized
INFO - 2017-08-22 06:24:49 --> Email Class Initialized
DEBUG - 2017-08-22 06:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:24:49 --> Table Class Initialized
INFO - 2017-08-22 06:24:49 --> Controller Class Initialized
INFO - 2017-08-22 06:24:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:24:49 --> Final output sent to browser
DEBUG - 2017-08-22 06:24:49 --> Total execution time: 0.2591
INFO - 2017-08-22 06:24:52 --> Config Class Initialized
INFO - 2017-08-22 06:24:52 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:24:52 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:24:52 --> Utf8 Class Initialized
INFO - 2017-08-22 06:24:52 --> URI Class Initialized
DEBUG - 2017-08-22 06:24:52 --> No URI present. Default controller set.
INFO - 2017-08-22 06:24:52 --> Router Class Initialized
INFO - 2017-08-22 06:24:52 --> Output Class Initialized
INFO - 2017-08-22 06:24:52 --> Security Class Initialized
DEBUG - 2017-08-22 06:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:24:52 --> Input Class Initialized
INFO - 2017-08-22 06:24:52 --> Language Class Initialized
INFO - 2017-08-22 06:24:53 --> Loader Class Initialized
INFO - 2017-08-22 06:24:53 --> Helper loaded: url_helper
INFO - 2017-08-22 06:24:53 --> Helper loaded: file_helper
INFO - 2017-08-22 06:24:53 --> Database Driver Class Initialized
INFO - 2017-08-22 06:24:53 --> Email Class Initialized
DEBUG - 2017-08-22 06:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:24:53 --> Table Class Initialized
INFO - 2017-08-22 06:24:53 --> Controller Class Initialized
INFO - 2017-08-22 06:24:53 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:24:53 --> Final output sent to browser
DEBUG - 2017-08-22 06:24:53 --> Total execution time: 0.2620
INFO - 2017-08-22 06:25:01 --> Config Class Initialized
INFO - 2017-08-22 06:25:01 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:25:01 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:25:01 --> Utf8 Class Initialized
INFO - 2017-08-22 06:25:01 --> URI Class Initialized
DEBUG - 2017-08-22 06:25:01 --> No URI present. Default controller set.
INFO - 2017-08-22 06:25:01 --> Router Class Initialized
INFO - 2017-08-22 06:25:01 --> Output Class Initialized
INFO - 2017-08-22 06:25:01 --> Security Class Initialized
DEBUG - 2017-08-22 06:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:25:01 --> Input Class Initialized
INFO - 2017-08-22 06:25:01 --> Language Class Initialized
INFO - 2017-08-22 06:25:01 --> Loader Class Initialized
INFO - 2017-08-22 06:25:01 --> Helper loaded: url_helper
INFO - 2017-08-22 06:25:01 --> Helper loaded: file_helper
INFO - 2017-08-22 06:25:01 --> Database Driver Class Initialized
INFO - 2017-08-22 06:25:02 --> Email Class Initialized
DEBUG - 2017-08-22 06:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:25:02 --> Table Class Initialized
INFO - 2017-08-22 06:25:02 --> Controller Class Initialized
INFO - 2017-08-22 06:25:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:25:02 --> Final output sent to browser
DEBUG - 2017-08-22 06:25:02 --> Total execution time: 0.2603
INFO - 2017-08-22 06:25:05 --> Config Class Initialized
INFO - 2017-08-22 06:25:05 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:25:06 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:25:06 --> Utf8 Class Initialized
INFO - 2017-08-22 06:25:06 --> URI Class Initialized
DEBUG - 2017-08-22 06:25:06 --> No URI present. Default controller set.
INFO - 2017-08-22 06:25:06 --> Router Class Initialized
INFO - 2017-08-22 06:25:06 --> Output Class Initialized
INFO - 2017-08-22 06:25:06 --> Security Class Initialized
DEBUG - 2017-08-22 06:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:25:06 --> Input Class Initialized
INFO - 2017-08-22 06:25:06 --> Language Class Initialized
INFO - 2017-08-22 06:25:06 --> Loader Class Initialized
INFO - 2017-08-22 06:25:06 --> Helper loaded: url_helper
INFO - 2017-08-22 06:25:06 --> Helper loaded: file_helper
INFO - 2017-08-22 06:25:06 --> Database Driver Class Initialized
INFO - 2017-08-22 06:25:06 --> Email Class Initialized
DEBUG - 2017-08-22 06:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:25:06 --> Table Class Initialized
INFO - 2017-08-22 06:25:06 --> Controller Class Initialized
INFO - 2017-08-22 06:25:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:25:06 --> Final output sent to browser
DEBUG - 2017-08-22 06:25:06 --> Total execution time: 0.2630
INFO - 2017-08-22 06:25:17 --> Config Class Initialized
INFO - 2017-08-22 06:25:17 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:25:17 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:25:17 --> Utf8 Class Initialized
INFO - 2017-08-22 06:25:17 --> URI Class Initialized
DEBUG - 2017-08-22 06:25:17 --> No URI present. Default controller set.
INFO - 2017-08-22 06:25:17 --> Router Class Initialized
INFO - 2017-08-22 06:25:17 --> Output Class Initialized
INFO - 2017-08-22 06:25:17 --> Security Class Initialized
DEBUG - 2017-08-22 06:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:25:17 --> Input Class Initialized
INFO - 2017-08-22 06:25:17 --> Language Class Initialized
INFO - 2017-08-22 06:25:17 --> Loader Class Initialized
INFO - 2017-08-22 06:25:17 --> Helper loaded: url_helper
INFO - 2017-08-22 06:25:17 --> Helper loaded: file_helper
INFO - 2017-08-22 06:25:17 --> Database Driver Class Initialized
INFO - 2017-08-22 06:25:17 --> Email Class Initialized
DEBUG - 2017-08-22 06:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:25:17 --> Table Class Initialized
INFO - 2017-08-22 06:25:17 --> Controller Class Initialized
INFO - 2017-08-22 06:25:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:25:17 --> Final output sent to browser
DEBUG - 2017-08-22 06:25:17 --> Total execution time: 0.2586
INFO - 2017-08-22 06:25:27 --> Config Class Initialized
INFO - 2017-08-22 06:25:27 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:25:27 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:25:27 --> Utf8 Class Initialized
INFO - 2017-08-22 06:25:27 --> URI Class Initialized
DEBUG - 2017-08-22 06:25:27 --> No URI present. Default controller set.
INFO - 2017-08-22 06:25:27 --> Router Class Initialized
INFO - 2017-08-22 06:25:27 --> Output Class Initialized
INFO - 2017-08-22 06:25:27 --> Security Class Initialized
DEBUG - 2017-08-22 06:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:25:27 --> Input Class Initialized
INFO - 2017-08-22 06:25:27 --> Language Class Initialized
INFO - 2017-08-22 06:25:27 --> Loader Class Initialized
INFO - 2017-08-22 06:25:27 --> Helper loaded: url_helper
INFO - 2017-08-22 06:25:27 --> Helper loaded: file_helper
INFO - 2017-08-22 06:25:27 --> Database Driver Class Initialized
INFO - 2017-08-22 06:25:27 --> Email Class Initialized
DEBUG - 2017-08-22 06:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:25:27 --> Table Class Initialized
INFO - 2017-08-22 06:25:27 --> Controller Class Initialized
INFO - 2017-08-22 06:25:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:25:27 --> Final output sent to browser
DEBUG - 2017-08-22 06:25:27 --> Total execution time: 0.2468
INFO - 2017-08-22 06:25:31 --> Config Class Initialized
INFO - 2017-08-22 06:25:31 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:25:31 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:25:31 --> Utf8 Class Initialized
INFO - 2017-08-22 06:25:32 --> URI Class Initialized
DEBUG - 2017-08-22 06:25:32 --> No URI present. Default controller set.
INFO - 2017-08-22 06:25:32 --> Router Class Initialized
INFO - 2017-08-22 06:25:32 --> Output Class Initialized
INFO - 2017-08-22 06:25:32 --> Security Class Initialized
DEBUG - 2017-08-22 06:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:25:32 --> Input Class Initialized
INFO - 2017-08-22 06:25:32 --> Language Class Initialized
INFO - 2017-08-22 06:25:32 --> Loader Class Initialized
INFO - 2017-08-22 06:25:32 --> Helper loaded: url_helper
INFO - 2017-08-22 06:25:32 --> Helper loaded: file_helper
INFO - 2017-08-22 06:25:32 --> Database Driver Class Initialized
INFO - 2017-08-22 06:25:32 --> Email Class Initialized
DEBUG - 2017-08-22 06:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:25:32 --> Table Class Initialized
INFO - 2017-08-22 06:25:32 --> Controller Class Initialized
INFO - 2017-08-22 06:25:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:25:32 --> Final output sent to browser
DEBUG - 2017-08-22 06:25:32 --> Total execution time: 0.2610
INFO - 2017-08-22 06:25:35 --> Config Class Initialized
INFO - 2017-08-22 06:25:35 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:25:35 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:25:35 --> Utf8 Class Initialized
INFO - 2017-08-22 06:25:35 --> URI Class Initialized
DEBUG - 2017-08-22 06:25:35 --> No URI present. Default controller set.
INFO - 2017-08-22 06:25:35 --> Router Class Initialized
INFO - 2017-08-22 06:25:35 --> Output Class Initialized
INFO - 2017-08-22 06:25:35 --> Security Class Initialized
DEBUG - 2017-08-22 06:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:25:35 --> Input Class Initialized
INFO - 2017-08-22 06:25:35 --> Language Class Initialized
INFO - 2017-08-22 06:25:35 --> Loader Class Initialized
INFO - 2017-08-22 06:25:35 --> Helper loaded: url_helper
INFO - 2017-08-22 06:25:35 --> Helper loaded: file_helper
INFO - 2017-08-22 06:25:35 --> Database Driver Class Initialized
INFO - 2017-08-22 06:25:35 --> Email Class Initialized
DEBUG - 2017-08-22 06:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:25:35 --> Table Class Initialized
INFO - 2017-08-22 06:25:35 --> Controller Class Initialized
INFO - 2017-08-22 06:25:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:25:35 --> Final output sent to browser
DEBUG - 2017-08-22 06:25:35 --> Total execution time: 0.2536
INFO - 2017-08-22 06:26:17 --> Config Class Initialized
INFO - 2017-08-22 06:26:17 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:26:17 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:26:17 --> Utf8 Class Initialized
INFO - 2017-08-22 06:26:17 --> URI Class Initialized
DEBUG - 2017-08-22 06:26:17 --> No URI present. Default controller set.
INFO - 2017-08-22 06:26:17 --> Router Class Initialized
INFO - 2017-08-22 06:26:17 --> Output Class Initialized
INFO - 2017-08-22 06:26:17 --> Security Class Initialized
DEBUG - 2017-08-22 06:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:26:17 --> Input Class Initialized
INFO - 2017-08-22 06:26:17 --> Language Class Initialized
INFO - 2017-08-22 06:26:17 --> Loader Class Initialized
INFO - 2017-08-22 06:26:17 --> Helper loaded: url_helper
INFO - 2017-08-22 06:26:17 --> Helper loaded: file_helper
INFO - 2017-08-22 06:26:17 --> Database Driver Class Initialized
INFO - 2017-08-22 06:26:17 --> Email Class Initialized
DEBUG - 2017-08-22 06:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:26:17 --> Table Class Initialized
INFO - 2017-08-22 06:26:17 --> Controller Class Initialized
INFO - 2017-08-22 06:26:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:26:17 --> Final output sent to browser
DEBUG - 2017-08-22 06:26:17 --> Total execution time: 0.2526
INFO - 2017-08-22 06:26:22 --> Config Class Initialized
INFO - 2017-08-22 06:26:22 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:26:22 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:26:22 --> Utf8 Class Initialized
INFO - 2017-08-22 06:26:22 --> URI Class Initialized
DEBUG - 2017-08-22 06:26:22 --> No URI present. Default controller set.
INFO - 2017-08-22 06:26:22 --> Router Class Initialized
INFO - 2017-08-22 06:26:22 --> Output Class Initialized
INFO - 2017-08-22 06:26:22 --> Security Class Initialized
DEBUG - 2017-08-22 06:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:26:22 --> Input Class Initialized
INFO - 2017-08-22 06:26:22 --> Language Class Initialized
INFO - 2017-08-22 06:26:22 --> Loader Class Initialized
INFO - 2017-08-22 06:26:22 --> Helper loaded: url_helper
INFO - 2017-08-22 06:26:22 --> Helper loaded: file_helper
INFO - 2017-08-22 06:26:22 --> Database Driver Class Initialized
INFO - 2017-08-22 06:26:22 --> Email Class Initialized
DEBUG - 2017-08-22 06:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:26:22 --> Table Class Initialized
INFO - 2017-08-22 06:26:22 --> Controller Class Initialized
INFO - 2017-08-22 06:26:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:26:22 --> Final output sent to browser
DEBUG - 2017-08-22 06:26:22 --> Total execution time: 0.2612
INFO - 2017-08-22 06:26:28 --> Config Class Initialized
INFO - 2017-08-22 06:26:28 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:26:28 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:26:28 --> Utf8 Class Initialized
INFO - 2017-08-22 06:26:28 --> URI Class Initialized
DEBUG - 2017-08-22 06:26:28 --> No URI present. Default controller set.
INFO - 2017-08-22 06:26:28 --> Router Class Initialized
INFO - 2017-08-22 06:26:28 --> Output Class Initialized
INFO - 2017-08-22 06:26:28 --> Security Class Initialized
DEBUG - 2017-08-22 06:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:26:28 --> Input Class Initialized
INFO - 2017-08-22 06:26:28 --> Language Class Initialized
INFO - 2017-08-22 06:26:28 --> Loader Class Initialized
INFO - 2017-08-22 06:26:28 --> Helper loaded: url_helper
INFO - 2017-08-22 06:26:28 --> Helper loaded: file_helper
INFO - 2017-08-22 06:26:28 --> Database Driver Class Initialized
INFO - 2017-08-22 06:26:28 --> Email Class Initialized
DEBUG - 2017-08-22 06:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:26:28 --> Table Class Initialized
INFO - 2017-08-22 06:26:28 --> Controller Class Initialized
INFO - 2017-08-22 06:26:28 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:26:28 --> Final output sent to browser
DEBUG - 2017-08-22 06:26:28 --> Total execution time: 0.2511
INFO - 2017-08-22 06:26:48 --> Config Class Initialized
INFO - 2017-08-22 06:26:48 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:26:48 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:26:48 --> Utf8 Class Initialized
INFO - 2017-08-22 06:26:48 --> URI Class Initialized
DEBUG - 2017-08-22 06:26:48 --> No URI present. Default controller set.
INFO - 2017-08-22 06:26:48 --> Router Class Initialized
INFO - 2017-08-22 06:26:48 --> Output Class Initialized
INFO - 2017-08-22 06:26:48 --> Security Class Initialized
DEBUG - 2017-08-22 06:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:26:48 --> Input Class Initialized
INFO - 2017-08-22 06:26:48 --> Language Class Initialized
INFO - 2017-08-22 06:26:48 --> Loader Class Initialized
INFO - 2017-08-22 06:26:48 --> Helper loaded: url_helper
INFO - 2017-08-22 06:26:48 --> Helper loaded: file_helper
INFO - 2017-08-22 06:26:48 --> Database Driver Class Initialized
INFO - 2017-08-22 06:26:48 --> Email Class Initialized
DEBUG - 2017-08-22 06:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:26:48 --> Table Class Initialized
INFO - 2017-08-22 06:26:48 --> Controller Class Initialized
INFO - 2017-08-22 06:26:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:26:48 --> Final output sent to browser
DEBUG - 2017-08-22 06:26:48 --> Total execution time: 0.2597
INFO - 2017-08-22 06:31:43 --> Config Class Initialized
INFO - 2017-08-22 06:31:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:31:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:31:43 --> Utf8 Class Initialized
INFO - 2017-08-22 06:31:44 --> URI Class Initialized
DEBUG - 2017-08-22 06:31:44 --> No URI present. Default controller set.
INFO - 2017-08-22 06:31:44 --> Router Class Initialized
INFO - 2017-08-22 06:31:44 --> Output Class Initialized
INFO - 2017-08-22 06:31:44 --> Security Class Initialized
DEBUG - 2017-08-22 06:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:31:44 --> Input Class Initialized
INFO - 2017-08-22 06:31:44 --> Language Class Initialized
INFO - 2017-08-22 06:31:44 --> Loader Class Initialized
INFO - 2017-08-22 06:31:44 --> Helper loaded: url_helper
INFO - 2017-08-22 06:31:44 --> Helper loaded: file_helper
INFO - 2017-08-22 06:31:44 --> Database Driver Class Initialized
INFO - 2017-08-22 06:31:44 --> Email Class Initialized
DEBUG - 2017-08-22 06:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 06:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 06:31:44 --> Table Class Initialized
INFO - 2017-08-22 06:31:44 --> Controller Class Initialized
INFO - 2017-08-22 06:31:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 06:31:44 --> Final output sent to browser
DEBUG - 2017-08-22 06:31:44 --> Total execution time: 0.2624
INFO - 2017-08-22 06:31:50 --> Config Class Initialized
INFO - 2017-08-22 06:31:50 --> Hooks Class Initialized
DEBUG - 2017-08-22 06:31:50 --> UTF-8 Support Enabled
INFO - 2017-08-22 06:31:50 --> Utf8 Class Initialized
INFO - 2017-08-22 06:31:50 --> URI Class Initialized
INFO - 2017-08-22 06:31:50 --> Router Class Initialized
INFO - 2017-08-22 06:31:50 --> Output Class Initialized
INFO - 2017-08-22 06:31:50 --> Security Class Initialized
DEBUG - 2017-08-22 06:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 06:31:50 --> Input Class Initialized
INFO - 2017-08-22 06:31:50 --> Language Class Initialized
ERROR - 2017-08-22 06:31:50 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:35:55 --> Config Class Initialized
INFO - 2017-08-22 07:35:55 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:35:55 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:35:55 --> Utf8 Class Initialized
INFO - 2017-08-22 07:35:55 --> URI Class Initialized
DEBUG - 2017-08-22 07:35:55 --> No URI present. Default controller set.
INFO - 2017-08-22 07:35:55 --> Router Class Initialized
INFO - 2017-08-22 07:35:55 --> Output Class Initialized
INFO - 2017-08-22 07:35:55 --> Security Class Initialized
DEBUG - 2017-08-22 07:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:35:55 --> Input Class Initialized
INFO - 2017-08-22 07:35:55 --> Language Class Initialized
INFO - 2017-08-22 07:35:55 --> Loader Class Initialized
INFO - 2017-08-22 07:35:55 --> Helper loaded: url_helper
INFO - 2017-08-22 07:35:55 --> Helper loaded: file_helper
INFO - 2017-08-22 07:35:56 --> Database Driver Class Initialized
INFO - 2017-08-22 07:35:56 --> Email Class Initialized
DEBUG - 2017-08-22 07:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:35:56 --> Table Class Initialized
INFO - 2017-08-22 07:35:56 --> Controller Class Initialized
INFO - 2017-08-22 07:35:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:35:56 --> Final output sent to browser
DEBUG - 2017-08-22 07:35:56 --> Total execution time: 1.0295
INFO - 2017-08-22 07:35:56 --> Config Class Initialized
INFO - 2017-08-22 07:35:56 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:35:56 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:35:56 --> Utf8 Class Initialized
INFO - 2017-08-22 07:35:56 --> URI Class Initialized
INFO - 2017-08-22 07:35:56 --> Router Class Initialized
INFO - 2017-08-22 07:35:56 --> Output Class Initialized
INFO - 2017-08-22 07:35:56 --> Security Class Initialized
DEBUG - 2017-08-22 07:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:35:56 --> Input Class Initialized
INFO - 2017-08-22 07:35:56 --> Language Class Initialized
ERROR - 2017-08-22 07:35:56 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:35:57 --> Config Class Initialized
INFO - 2017-08-22 07:35:57 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:35:57 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:35:57 --> Utf8 Class Initialized
INFO - 2017-08-22 07:35:57 --> URI Class Initialized
INFO - 2017-08-22 07:35:57 --> Router Class Initialized
INFO - 2017-08-22 07:35:57 --> Output Class Initialized
INFO - 2017-08-22 07:35:57 --> Security Class Initialized
DEBUG - 2017-08-22 07:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:35:57 --> Input Class Initialized
INFO - 2017-08-22 07:35:57 --> Language Class Initialized
ERROR - 2017-08-22 07:35:57 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:36:21 --> Config Class Initialized
INFO - 2017-08-22 07:36:21 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:36:21 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:36:21 --> Utf8 Class Initialized
INFO - 2017-08-22 07:36:21 --> URI Class Initialized
DEBUG - 2017-08-22 07:36:21 --> No URI present. Default controller set.
INFO - 2017-08-22 07:36:21 --> Router Class Initialized
INFO - 2017-08-22 07:36:21 --> Output Class Initialized
INFO - 2017-08-22 07:36:21 --> Security Class Initialized
DEBUG - 2017-08-22 07:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:36:21 --> Input Class Initialized
INFO - 2017-08-22 07:36:21 --> Language Class Initialized
INFO - 2017-08-22 07:36:21 --> Loader Class Initialized
INFO - 2017-08-22 07:36:21 --> Helper loaded: url_helper
INFO - 2017-08-22 07:36:21 --> Helper loaded: file_helper
INFO - 2017-08-22 07:36:21 --> Database Driver Class Initialized
INFO - 2017-08-22 07:36:21 --> Email Class Initialized
DEBUG - 2017-08-22 07:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:36:21 --> Table Class Initialized
INFO - 2017-08-22 07:36:21 --> Controller Class Initialized
INFO - 2017-08-22 07:36:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:36:21 --> Final output sent to browser
DEBUG - 2017-08-22 07:36:21 --> Total execution time: 0.2782
INFO - 2017-08-22 07:36:22 --> Config Class Initialized
INFO - 2017-08-22 07:36:22 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:36:22 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:36:22 --> Utf8 Class Initialized
INFO - 2017-08-22 07:36:22 --> URI Class Initialized
INFO - 2017-08-22 07:36:22 --> Router Class Initialized
INFO - 2017-08-22 07:36:22 --> Output Class Initialized
INFO - 2017-08-22 07:36:22 --> Security Class Initialized
DEBUG - 2017-08-22 07:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:36:22 --> Input Class Initialized
INFO - 2017-08-22 07:36:22 --> Language Class Initialized
ERROR - 2017-08-22 07:36:22 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:36:22 --> Config Class Initialized
INFO - 2017-08-22 07:36:22 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:36:22 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:36:22 --> Utf8 Class Initialized
INFO - 2017-08-22 07:36:22 --> URI Class Initialized
INFO - 2017-08-22 07:36:22 --> Router Class Initialized
INFO - 2017-08-22 07:36:22 --> Output Class Initialized
INFO - 2017-08-22 07:36:22 --> Security Class Initialized
DEBUG - 2017-08-22 07:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:36:22 --> Input Class Initialized
INFO - 2017-08-22 07:36:22 --> Language Class Initialized
ERROR - 2017-08-22 07:36:22 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:37:49 --> Config Class Initialized
INFO - 2017-08-22 07:37:49 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:37:49 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:37:49 --> Utf8 Class Initialized
INFO - 2017-08-22 07:37:49 --> URI Class Initialized
DEBUG - 2017-08-22 07:37:49 --> No URI present. Default controller set.
INFO - 2017-08-22 07:37:49 --> Router Class Initialized
INFO - 2017-08-22 07:37:49 --> Output Class Initialized
INFO - 2017-08-22 07:37:49 --> Security Class Initialized
DEBUG - 2017-08-22 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:37:49 --> Input Class Initialized
INFO - 2017-08-22 07:37:49 --> Language Class Initialized
INFO - 2017-08-22 07:37:49 --> Loader Class Initialized
INFO - 2017-08-22 07:37:49 --> Helper loaded: url_helper
INFO - 2017-08-22 07:37:49 --> Helper loaded: file_helper
INFO - 2017-08-22 07:37:49 --> Database Driver Class Initialized
INFO - 2017-08-22 07:37:49 --> Email Class Initialized
DEBUG - 2017-08-22 07:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:37:49 --> Table Class Initialized
INFO - 2017-08-22 07:37:49 --> Controller Class Initialized
INFO - 2017-08-22 07:37:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:37:49 --> Final output sent to browser
DEBUG - 2017-08-22 07:37:49 --> Total execution time: 0.2939
INFO - 2017-08-22 07:37:49 --> Config Class Initialized
INFO - 2017-08-22 07:37:49 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:37:49 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:37:49 --> Utf8 Class Initialized
INFO - 2017-08-22 07:37:49 --> URI Class Initialized
INFO - 2017-08-22 07:37:49 --> Router Class Initialized
INFO - 2017-08-22 07:37:49 --> Output Class Initialized
INFO - 2017-08-22 07:37:49 --> Security Class Initialized
DEBUG - 2017-08-22 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:37:49 --> Input Class Initialized
INFO - 2017-08-22 07:37:49 --> Language Class Initialized
ERROR - 2017-08-22 07:37:49 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:37:50 --> Config Class Initialized
INFO - 2017-08-22 07:37:50 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:37:50 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:37:50 --> Utf8 Class Initialized
INFO - 2017-08-22 07:37:50 --> URI Class Initialized
INFO - 2017-08-22 07:37:50 --> Router Class Initialized
INFO - 2017-08-22 07:37:50 --> Output Class Initialized
INFO - 2017-08-22 07:37:50 --> Security Class Initialized
DEBUG - 2017-08-22 07:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:37:50 --> Input Class Initialized
INFO - 2017-08-22 07:37:50 --> Language Class Initialized
ERROR - 2017-08-22 07:37:50 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:41:05 --> Config Class Initialized
INFO - 2017-08-22 07:41:05 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:41:05 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:41:05 --> Utf8 Class Initialized
INFO - 2017-08-22 07:41:05 --> URI Class Initialized
DEBUG - 2017-08-22 07:41:05 --> No URI present. Default controller set.
INFO - 2017-08-22 07:41:05 --> Router Class Initialized
INFO - 2017-08-22 07:41:05 --> Output Class Initialized
INFO - 2017-08-22 07:41:05 --> Security Class Initialized
DEBUG - 2017-08-22 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:41:05 --> Input Class Initialized
INFO - 2017-08-22 07:41:05 --> Language Class Initialized
INFO - 2017-08-22 07:41:05 --> Loader Class Initialized
INFO - 2017-08-22 07:41:05 --> Helper loaded: url_helper
INFO - 2017-08-22 07:41:05 --> Helper loaded: file_helper
INFO - 2017-08-22 07:41:05 --> Database Driver Class Initialized
INFO - 2017-08-22 07:41:05 --> Email Class Initialized
DEBUG - 2017-08-22 07:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:41:05 --> Table Class Initialized
INFO - 2017-08-22 07:41:05 --> Controller Class Initialized
INFO - 2017-08-22 07:41:05 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:41:05 --> Final output sent to browser
DEBUG - 2017-08-22 07:41:05 --> Total execution time: 0.2871
INFO - 2017-08-22 07:41:06 --> Config Class Initialized
INFO - 2017-08-22 07:41:06 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:41:06 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:41:06 --> Utf8 Class Initialized
INFO - 2017-08-22 07:41:06 --> URI Class Initialized
INFO - 2017-08-22 07:41:06 --> Router Class Initialized
INFO - 2017-08-22 07:41:06 --> Output Class Initialized
INFO - 2017-08-22 07:41:06 --> Security Class Initialized
DEBUG - 2017-08-22 07:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:41:06 --> Input Class Initialized
INFO - 2017-08-22 07:41:06 --> Language Class Initialized
ERROR - 2017-08-22 07:41:06 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:41:06 --> Config Class Initialized
INFO - 2017-08-22 07:41:06 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:41:06 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:41:06 --> Utf8 Class Initialized
INFO - 2017-08-22 07:41:06 --> URI Class Initialized
INFO - 2017-08-22 07:41:06 --> Router Class Initialized
INFO - 2017-08-22 07:41:06 --> Output Class Initialized
INFO - 2017-08-22 07:41:06 --> Security Class Initialized
DEBUG - 2017-08-22 07:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:41:06 --> Input Class Initialized
INFO - 2017-08-22 07:41:06 --> Config Class Initialized
INFO - 2017-08-22 07:41:06 --> Language Class Initialized
INFO - 2017-08-22 07:41:06 --> Hooks Class Initialized
ERROR - 2017-08-22 07:41:06 --> 404 Page Not Found: Ext/vendor
DEBUG - 2017-08-22 07:41:06 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:41:06 --> Utf8 Class Initialized
INFO - 2017-08-22 07:41:06 --> URI Class Initialized
DEBUG - 2017-08-22 07:41:06 --> No URI present. Default controller set.
INFO - 2017-08-22 07:41:06 --> Router Class Initialized
INFO - 2017-08-22 07:41:06 --> Output Class Initialized
INFO - 2017-08-22 07:41:06 --> Security Class Initialized
DEBUG - 2017-08-22 07:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:41:06 --> Input Class Initialized
INFO - 2017-08-22 07:41:06 --> Language Class Initialized
INFO - 2017-08-22 07:41:06 --> Loader Class Initialized
INFO - 2017-08-22 07:41:06 --> Helper loaded: url_helper
INFO - 2017-08-22 07:41:06 --> Helper loaded: file_helper
INFO - 2017-08-22 07:41:06 --> Database Driver Class Initialized
INFO - 2017-08-22 07:41:06 --> Email Class Initialized
DEBUG - 2017-08-22 07:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:41:06 --> Table Class Initialized
INFO - 2017-08-22 07:41:06 --> Controller Class Initialized
INFO - 2017-08-22 07:41:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:41:06 --> Final output sent to browser
DEBUG - 2017-08-22 07:41:07 --> Total execution time: 0.2851
INFO - 2017-08-22 07:41:07 --> Config Class Initialized
INFO - 2017-08-22 07:41:07 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:41:07 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:41:07 --> Utf8 Class Initialized
INFO - 2017-08-22 07:41:07 --> URI Class Initialized
INFO - 2017-08-22 07:41:07 --> Router Class Initialized
INFO - 2017-08-22 07:41:07 --> Output Class Initialized
INFO - 2017-08-22 07:41:07 --> Security Class Initialized
DEBUG - 2017-08-22 07:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:41:07 --> Input Class Initialized
INFO - 2017-08-22 07:41:07 --> Language Class Initialized
ERROR - 2017-08-22 07:41:07 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:41:07 --> Config Class Initialized
INFO - 2017-08-22 07:41:07 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:41:07 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:41:07 --> Utf8 Class Initialized
INFO - 2017-08-22 07:41:07 --> URI Class Initialized
INFO - 2017-08-22 07:41:07 --> Router Class Initialized
INFO - 2017-08-22 07:41:07 --> Output Class Initialized
INFO - 2017-08-22 07:41:07 --> Security Class Initialized
DEBUG - 2017-08-22 07:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:41:07 --> Input Class Initialized
INFO - 2017-08-22 07:41:07 --> Language Class Initialized
ERROR - 2017-08-22 07:41:07 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:42:05 --> Config Class Initialized
INFO - 2017-08-22 07:42:05 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:05 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:05 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:05 --> URI Class Initialized
DEBUG - 2017-08-22 07:42:05 --> No URI present. Default controller set.
INFO - 2017-08-22 07:42:05 --> Router Class Initialized
INFO - 2017-08-22 07:42:05 --> Output Class Initialized
INFO - 2017-08-22 07:42:05 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:05 --> Input Class Initialized
INFO - 2017-08-22 07:42:05 --> Language Class Initialized
INFO - 2017-08-22 07:42:05 --> Loader Class Initialized
INFO - 2017-08-22 07:42:06 --> Helper loaded: url_helper
INFO - 2017-08-22 07:42:06 --> Helper loaded: file_helper
INFO - 2017-08-22 07:42:06 --> Database Driver Class Initialized
INFO - 2017-08-22 07:42:06 --> Email Class Initialized
DEBUG - 2017-08-22 07:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:42:06 --> Table Class Initialized
INFO - 2017-08-22 07:42:06 --> Controller Class Initialized
INFO - 2017-08-22 07:42:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:42:06 --> Final output sent to browser
DEBUG - 2017-08-22 07:42:06 --> Total execution time: 0.2701
INFO - 2017-08-22 07:42:06 --> Config Class Initialized
INFO - 2017-08-22 07:42:06 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:06 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:06 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:06 --> URI Class Initialized
INFO - 2017-08-22 07:42:06 --> Router Class Initialized
INFO - 2017-08-22 07:42:06 --> Output Class Initialized
INFO - 2017-08-22 07:42:06 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:06 --> Input Class Initialized
INFO - 2017-08-22 07:42:06 --> Language Class Initialized
ERROR - 2017-08-22 07:42:06 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:42:06 --> Config Class Initialized
INFO - 2017-08-22 07:42:06 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:06 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:06 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:06 --> URI Class Initialized
INFO - 2017-08-22 07:42:07 --> Router Class Initialized
INFO - 2017-08-22 07:42:07 --> Output Class Initialized
INFO - 2017-08-22 07:42:07 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:07 --> Input Class Initialized
INFO - 2017-08-22 07:42:07 --> Language Class Initialized
ERROR - 2017-08-22 07:42:07 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:42:07 --> Config Class Initialized
INFO - 2017-08-22 07:42:07 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:07 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:07 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:07 --> URI Class Initialized
DEBUG - 2017-08-22 07:42:07 --> No URI present. Default controller set.
INFO - 2017-08-22 07:42:07 --> Router Class Initialized
INFO - 2017-08-22 07:42:07 --> Output Class Initialized
INFO - 2017-08-22 07:42:07 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:07 --> Input Class Initialized
INFO - 2017-08-22 07:42:07 --> Language Class Initialized
INFO - 2017-08-22 07:42:08 --> Loader Class Initialized
INFO - 2017-08-22 07:42:08 --> Helper loaded: url_helper
INFO - 2017-08-22 07:42:08 --> Helper loaded: file_helper
INFO - 2017-08-22 07:42:08 --> Database Driver Class Initialized
INFO - 2017-08-22 07:42:08 --> Email Class Initialized
DEBUG - 2017-08-22 07:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:42:08 --> Table Class Initialized
INFO - 2017-08-22 07:42:08 --> Controller Class Initialized
INFO - 2017-08-22 07:42:08 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:42:08 --> Final output sent to browser
DEBUG - 2017-08-22 07:42:08 --> Total execution time: 0.2670
INFO - 2017-08-22 07:42:08 --> Config Class Initialized
INFO - 2017-08-22 07:42:08 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:08 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:08 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:08 --> URI Class Initialized
INFO - 2017-08-22 07:42:08 --> Router Class Initialized
INFO - 2017-08-22 07:42:08 --> Output Class Initialized
INFO - 2017-08-22 07:42:08 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:08 --> Input Class Initialized
INFO - 2017-08-22 07:42:08 --> Language Class Initialized
ERROR - 2017-08-22 07:42:08 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:42:08 --> Config Class Initialized
INFO - 2017-08-22 07:42:08 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:08 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:08 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:08 --> URI Class Initialized
INFO - 2017-08-22 07:42:08 --> Router Class Initialized
INFO - 2017-08-22 07:42:08 --> Output Class Initialized
INFO - 2017-08-22 07:42:08 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:08 --> Input Class Initialized
INFO - 2017-08-22 07:42:08 --> Language Class Initialized
ERROR - 2017-08-22 07:42:08 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:42:24 --> Config Class Initialized
INFO - 2017-08-22 07:42:24 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:24 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:24 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:24 --> URI Class Initialized
DEBUG - 2017-08-22 07:42:24 --> No URI present. Default controller set.
INFO - 2017-08-22 07:42:24 --> Router Class Initialized
INFO - 2017-08-22 07:42:24 --> Output Class Initialized
INFO - 2017-08-22 07:42:24 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:24 --> Input Class Initialized
INFO - 2017-08-22 07:42:24 --> Language Class Initialized
INFO - 2017-08-22 07:42:24 --> Loader Class Initialized
INFO - 2017-08-22 07:42:24 --> Helper loaded: url_helper
INFO - 2017-08-22 07:42:24 --> Helper loaded: file_helper
INFO - 2017-08-22 07:42:24 --> Database Driver Class Initialized
INFO - 2017-08-22 07:42:24 --> Email Class Initialized
DEBUG - 2017-08-22 07:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:42:24 --> Table Class Initialized
INFO - 2017-08-22 07:42:24 --> Controller Class Initialized
INFO - 2017-08-22 07:42:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:42:24 --> Final output sent to browser
DEBUG - 2017-08-22 07:42:24 --> Total execution time: 0.2659
INFO - 2017-08-22 07:42:25 --> Config Class Initialized
INFO - 2017-08-22 07:42:25 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:25 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:25 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:25 --> URI Class Initialized
INFO - 2017-08-22 07:42:25 --> Router Class Initialized
INFO - 2017-08-22 07:42:25 --> Output Class Initialized
INFO - 2017-08-22 07:42:25 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:25 --> Input Class Initialized
INFO - 2017-08-22 07:42:25 --> Language Class Initialized
ERROR - 2017-08-22 07:42:25 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:42:25 --> Config Class Initialized
INFO - 2017-08-22 07:42:25 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:25 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:25 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:25 --> URI Class Initialized
INFO - 2017-08-22 07:42:25 --> Router Class Initialized
INFO - 2017-08-22 07:42:25 --> Output Class Initialized
INFO - 2017-08-22 07:42:25 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:25 --> Input Class Initialized
INFO - 2017-08-22 07:42:25 --> Language Class Initialized
ERROR - 2017-08-22 07:42:25 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:42:35 --> Config Class Initialized
INFO - 2017-08-22 07:42:35 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:35 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:35 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:35 --> URI Class Initialized
DEBUG - 2017-08-22 07:42:35 --> No URI present. Default controller set.
INFO - 2017-08-22 07:42:35 --> Router Class Initialized
INFO - 2017-08-22 07:42:35 --> Output Class Initialized
INFO - 2017-08-22 07:42:35 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:35 --> Input Class Initialized
INFO - 2017-08-22 07:42:35 --> Language Class Initialized
INFO - 2017-08-22 07:42:35 --> Loader Class Initialized
INFO - 2017-08-22 07:42:35 --> Helper loaded: url_helper
INFO - 2017-08-22 07:42:35 --> Helper loaded: file_helper
INFO - 2017-08-22 07:42:35 --> Database Driver Class Initialized
INFO - 2017-08-22 07:42:35 --> Email Class Initialized
DEBUG - 2017-08-22 07:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:42:35 --> Table Class Initialized
INFO - 2017-08-22 07:42:35 --> Controller Class Initialized
INFO - 2017-08-22 07:42:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:42:35 --> Final output sent to browser
DEBUG - 2017-08-22 07:42:35 --> Total execution time: 0.2727
INFO - 2017-08-22 07:42:35 --> Config Class Initialized
INFO - 2017-08-22 07:42:35 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:35 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:36 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:36 --> URI Class Initialized
INFO - 2017-08-22 07:42:36 --> Router Class Initialized
INFO - 2017-08-22 07:42:36 --> Output Class Initialized
INFO - 2017-08-22 07:42:36 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:36 --> Input Class Initialized
INFO - 2017-08-22 07:42:36 --> Language Class Initialized
ERROR - 2017-08-22 07:42:36 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:42:36 --> Config Class Initialized
INFO - 2017-08-22 07:42:36 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:36 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:36 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:36 --> URI Class Initialized
INFO - 2017-08-22 07:42:36 --> Router Class Initialized
INFO - 2017-08-22 07:42:36 --> Output Class Initialized
INFO - 2017-08-22 07:42:36 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:36 --> Input Class Initialized
INFO - 2017-08-22 07:42:36 --> Language Class Initialized
ERROR - 2017-08-22 07:42:36 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:42:46 --> Config Class Initialized
INFO - 2017-08-22 07:42:46 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:46 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:46 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:46 --> URI Class Initialized
DEBUG - 2017-08-22 07:42:46 --> No URI present. Default controller set.
INFO - 2017-08-22 07:42:46 --> Router Class Initialized
INFO - 2017-08-22 07:42:46 --> Output Class Initialized
INFO - 2017-08-22 07:42:46 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:46 --> Input Class Initialized
INFO - 2017-08-22 07:42:46 --> Language Class Initialized
INFO - 2017-08-22 07:42:46 --> Loader Class Initialized
INFO - 2017-08-22 07:42:46 --> Helper loaded: url_helper
INFO - 2017-08-22 07:42:46 --> Helper loaded: file_helper
INFO - 2017-08-22 07:42:46 --> Database Driver Class Initialized
INFO - 2017-08-22 07:42:46 --> Email Class Initialized
DEBUG - 2017-08-22 07:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:42:46 --> Table Class Initialized
INFO - 2017-08-22 07:42:47 --> Controller Class Initialized
INFO - 2017-08-22 07:42:47 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:42:47 --> Final output sent to browser
DEBUG - 2017-08-22 07:42:47 --> Total execution time: 0.2781
INFO - 2017-08-22 07:42:47 --> Config Class Initialized
INFO - 2017-08-22 07:42:47 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:47 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:47 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:47 --> URI Class Initialized
INFO - 2017-08-22 07:42:47 --> Router Class Initialized
INFO - 2017-08-22 07:42:47 --> Output Class Initialized
INFO - 2017-08-22 07:42:47 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:47 --> Input Class Initialized
INFO - 2017-08-22 07:42:47 --> Language Class Initialized
ERROR - 2017-08-22 07:42:47 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:42:47 --> Config Class Initialized
INFO - 2017-08-22 07:42:47 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:47 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:47 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:47 --> URI Class Initialized
INFO - 2017-08-22 07:42:47 --> Router Class Initialized
INFO - 2017-08-22 07:42:47 --> Output Class Initialized
INFO - 2017-08-22 07:42:47 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:47 --> Input Class Initialized
INFO - 2017-08-22 07:42:47 --> Language Class Initialized
ERROR - 2017-08-22 07:42:47 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:42:51 --> Config Class Initialized
INFO - 2017-08-22 07:42:51 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:51 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:51 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:51 --> URI Class Initialized
DEBUG - 2017-08-22 07:42:51 --> No URI present. Default controller set.
INFO - 2017-08-22 07:42:51 --> Router Class Initialized
INFO - 2017-08-22 07:42:51 --> Output Class Initialized
INFO - 2017-08-22 07:42:51 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:51 --> Input Class Initialized
INFO - 2017-08-22 07:42:51 --> Language Class Initialized
INFO - 2017-08-22 07:42:51 --> Loader Class Initialized
INFO - 2017-08-22 07:42:51 --> Helper loaded: url_helper
INFO - 2017-08-22 07:42:51 --> Helper loaded: file_helper
INFO - 2017-08-22 07:42:52 --> Database Driver Class Initialized
INFO - 2017-08-22 07:42:52 --> Email Class Initialized
DEBUG - 2017-08-22 07:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:42:52 --> Table Class Initialized
INFO - 2017-08-22 07:42:52 --> Controller Class Initialized
INFO - 2017-08-22 07:42:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:42:52 --> Final output sent to browser
DEBUG - 2017-08-22 07:42:52 --> Total execution time: 0.2783
INFO - 2017-08-22 07:42:52 --> Config Class Initialized
INFO - 2017-08-22 07:42:52 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:52 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:52 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:52 --> URI Class Initialized
INFO - 2017-08-22 07:42:52 --> Router Class Initialized
INFO - 2017-08-22 07:42:52 --> Output Class Initialized
INFO - 2017-08-22 07:42:52 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:52 --> Input Class Initialized
INFO - 2017-08-22 07:42:52 --> Language Class Initialized
ERROR - 2017-08-22 07:42:52 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:42:52 --> Config Class Initialized
INFO - 2017-08-22 07:42:52 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:42:52 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:42:52 --> Utf8 Class Initialized
INFO - 2017-08-22 07:42:52 --> URI Class Initialized
INFO - 2017-08-22 07:42:52 --> Router Class Initialized
INFO - 2017-08-22 07:42:52 --> Output Class Initialized
INFO - 2017-08-22 07:42:52 --> Security Class Initialized
DEBUG - 2017-08-22 07:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:42:52 --> Input Class Initialized
INFO - 2017-08-22 07:42:52 --> Language Class Initialized
ERROR - 2017-08-22 07:42:52 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:43:03 --> Config Class Initialized
INFO - 2017-08-22 07:43:03 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:43:03 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:43:03 --> Utf8 Class Initialized
INFO - 2017-08-22 07:43:03 --> URI Class Initialized
DEBUG - 2017-08-22 07:43:03 --> No URI present. Default controller set.
INFO - 2017-08-22 07:43:03 --> Router Class Initialized
INFO - 2017-08-22 07:43:03 --> Output Class Initialized
INFO - 2017-08-22 07:43:03 --> Security Class Initialized
DEBUG - 2017-08-22 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:43:03 --> Input Class Initialized
INFO - 2017-08-22 07:43:03 --> Language Class Initialized
INFO - 2017-08-22 07:43:03 --> Loader Class Initialized
INFO - 2017-08-22 07:43:03 --> Helper loaded: url_helper
INFO - 2017-08-22 07:43:03 --> Helper loaded: file_helper
INFO - 2017-08-22 07:43:03 --> Database Driver Class Initialized
INFO - 2017-08-22 07:43:03 --> Email Class Initialized
DEBUG - 2017-08-22 07:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:43:03 --> Table Class Initialized
INFO - 2017-08-22 07:43:03 --> Controller Class Initialized
INFO - 2017-08-22 07:43:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:43:03 --> Final output sent to browser
DEBUG - 2017-08-22 07:43:03 --> Total execution time: 0.2865
INFO - 2017-08-22 07:43:03 --> Config Class Initialized
INFO - 2017-08-22 07:43:03 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:43:03 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:43:03 --> Utf8 Class Initialized
INFO - 2017-08-22 07:43:03 --> URI Class Initialized
INFO - 2017-08-22 07:43:03 --> Router Class Initialized
INFO - 2017-08-22 07:43:03 --> Output Class Initialized
INFO - 2017-08-22 07:43:03 --> Security Class Initialized
DEBUG - 2017-08-22 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:43:03 --> Input Class Initialized
INFO - 2017-08-22 07:43:03 --> Language Class Initialized
ERROR - 2017-08-22 07:43:03 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:43:04 --> Config Class Initialized
INFO - 2017-08-22 07:43:04 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:43:04 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:43:04 --> Utf8 Class Initialized
INFO - 2017-08-22 07:43:04 --> URI Class Initialized
INFO - 2017-08-22 07:43:04 --> Router Class Initialized
INFO - 2017-08-22 07:43:04 --> Output Class Initialized
INFO - 2017-08-22 07:43:04 --> Security Class Initialized
DEBUG - 2017-08-22 07:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:43:04 --> Input Class Initialized
INFO - 2017-08-22 07:43:04 --> Language Class Initialized
ERROR - 2017-08-22 07:43:04 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:45:02 --> Config Class Initialized
INFO - 2017-08-22 07:45:02 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:45:02 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:45:02 --> Utf8 Class Initialized
INFO - 2017-08-22 07:45:02 --> URI Class Initialized
DEBUG - 2017-08-22 07:45:02 --> No URI present. Default controller set.
INFO - 2017-08-22 07:45:02 --> Router Class Initialized
INFO - 2017-08-22 07:45:02 --> Output Class Initialized
INFO - 2017-08-22 07:45:02 --> Security Class Initialized
DEBUG - 2017-08-22 07:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:45:02 --> Input Class Initialized
INFO - 2017-08-22 07:45:02 --> Language Class Initialized
INFO - 2017-08-22 07:45:02 --> Loader Class Initialized
INFO - 2017-08-22 07:45:02 --> Helper loaded: url_helper
INFO - 2017-08-22 07:45:02 --> Helper loaded: file_helper
INFO - 2017-08-22 07:45:02 --> Database Driver Class Initialized
INFO - 2017-08-22 07:45:02 --> Email Class Initialized
DEBUG - 2017-08-22 07:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:45:02 --> Table Class Initialized
INFO - 2017-08-22 07:45:02 --> Controller Class Initialized
INFO - 2017-08-22 07:45:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:45:02 --> Final output sent to browser
DEBUG - 2017-08-22 07:45:02 --> Total execution time: 0.2775
INFO - 2017-08-22 07:45:03 --> Config Class Initialized
INFO - 2017-08-22 07:45:03 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:45:03 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:45:03 --> Utf8 Class Initialized
INFO - 2017-08-22 07:45:03 --> URI Class Initialized
INFO - 2017-08-22 07:45:03 --> Router Class Initialized
INFO - 2017-08-22 07:45:03 --> Output Class Initialized
INFO - 2017-08-22 07:45:03 --> Security Class Initialized
DEBUG - 2017-08-22 07:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:45:03 --> Input Class Initialized
INFO - 2017-08-22 07:45:03 --> Language Class Initialized
ERROR - 2017-08-22 07:45:03 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:45:03 --> Config Class Initialized
INFO - 2017-08-22 07:45:03 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:45:03 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:45:03 --> Utf8 Class Initialized
INFO - 2017-08-22 07:45:03 --> URI Class Initialized
INFO - 2017-08-22 07:45:03 --> Router Class Initialized
INFO - 2017-08-22 07:45:03 --> Output Class Initialized
INFO - 2017-08-22 07:45:03 --> Security Class Initialized
DEBUG - 2017-08-22 07:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:45:03 --> Input Class Initialized
INFO - 2017-08-22 07:45:03 --> Language Class Initialized
ERROR - 2017-08-22 07:45:03 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:45:12 --> Config Class Initialized
INFO - 2017-08-22 07:45:12 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:45:12 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:45:12 --> Utf8 Class Initialized
INFO - 2017-08-22 07:45:12 --> URI Class Initialized
DEBUG - 2017-08-22 07:45:12 --> No URI present. Default controller set.
INFO - 2017-08-22 07:45:12 --> Router Class Initialized
INFO - 2017-08-22 07:45:12 --> Output Class Initialized
INFO - 2017-08-22 07:45:12 --> Security Class Initialized
DEBUG - 2017-08-22 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:45:12 --> Input Class Initialized
INFO - 2017-08-22 07:45:12 --> Language Class Initialized
INFO - 2017-08-22 07:45:12 --> Loader Class Initialized
INFO - 2017-08-22 07:45:12 --> Helper loaded: url_helper
INFO - 2017-08-22 07:45:12 --> Helper loaded: file_helper
INFO - 2017-08-22 07:45:12 --> Database Driver Class Initialized
INFO - 2017-08-22 07:45:12 --> Email Class Initialized
DEBUG - 2017-08-22 07:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:45:12 --> Table Class Initialized
INFO - 2017-08-22 07:45:12 --> Controller Class Initialized
INFO - 2017-08-22 07:45:12 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:45:12 --> Final output sent to browser
DEBUG - 2017-08-22 07:45:12 --> Total execution time: 0.2826
INFO - 2017-08-22 07:45:12 --> Config Class Initialized
INFO - 2017-08-22 07:45:12 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:45:12 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:45:12 --> Utf8 Class Initialized
INFO - 2017-08-22 07:45:12 --> URI Class Initialized
INFO - 2017-08-22 07:45:12 --> Router Class Initialized
INFO - 2017-08-22 07:45:12 --> Output Class Initialized
INFO - 2017-08-22 07:45:12 --> Security Class Initialized
DEBUG - 2017-08-22 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:45:12 --> Input Class Initialized
INFO - 2017-08-22 07:45:12 --> Language Class Initialized
ERROR - 2017-08-22 07:45:12 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:45:13 --> Config Class Initialized
INFO - 2017-08-22 07:45:13 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:45:13 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:45:13 --> Utf8 Class Initialized
INFO - 2017-08-22 07:45:13 --> URI Class Initialized
INFO - 2017-08-22 07:45:13 --> Router Class Initialized
INFO - 2017-08-22 07:45:13 --> Output Class Initialized
INFO - 2017-08-22 07:45:13 --> Security Class Initialized
DEBUG - 2017-08-22 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:45:13 --> Input Class Initialized
INFO - 2017-08-22 07:45:13 --> Language Class Initialized
ERROR - 2017-08-22 07:45:13 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:46:03 --> Config Class Initialized
INFO - 2017-08-22 07:46:03 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:46:03 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:46:03 --> Utf8 Class Initialized
INFO - 2017-08-22 07:46:03 --> URI Class Initialized
DEBUG - 2017-08-22 07:46:03 --> No URI present. Default controller set.
INFO - 2017-08-22 07:46:03 --> Router Class Initialized
INFO - 2017-08-22 07:46:03 --> Output Class Initialized
INFO - 2017-08-22 07:46:04 --> Security Class Initialized
DEBUG - 2017-08-22 07:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:46:04 --> Input Class Initialized
INFO - 2017-08-22 07:46:04 --> Language Class Initialized
INFO - 2017-08-22 07:46:04 --> Loader Class Initialized
INFO - 2017-08-22 07:46:04 --> Helper loaded: url_helper
INFO - 2017-08-22 07:46:04 --> Helper loaded: file_helper
INFO - 2017-08-22 07:46:04 --> Database Driver Class Initialized
INFO - 2017-08-22 07:46:04 --> Email Class Initialized
DEBUG - 2017-08-22 07:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:46:04 --> Table Class Initialized
INFO - 2017-08-22 07:46:04 --> Controller Class Initialized
INFO - 2017-08-22 07:46:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:46:04 --> Final output sent to browser
DEBUG - 2017-08-22 07:46:04 --> Total execution time: 0.2694
INFO - 2017-08-22 07:46:04 --> Config Class Initialized
INFO - 2017-08-22 07:46:04 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:46:04 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:46:04 --> Utf8 Class Initialized
INFO - 2017-08-22 07:46:04 --> URI Class Initialized
INFO - 2017-08-22 07:46:04 --> Router Class Initialized
INFO - 2017-08-22 07:46:04 --> Output Class Initialized
INFO - 2017-08-22 07:46:04 --> Security Class Initialized
DEBUG - 2017-08-22 07:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:46:04 --> Input Class Initialized
INFO - 2017-08-22 07:46:04 --> Language Class Initialized
ERROR - 2017-08-22 07:46:04 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:46:04 --> Config Class Initialized
INFO - 2017-08-22 07:46:04 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:46:04 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:46:04 --> Utf8 Class Initialized
INFO - 2017-08-22 07:46:04 --> URI Class Initialized
INFO - 2017-08-22 07:46:04 --> Router Class Initialized
INFO - 2017-08-22 07:46:05 --> Output Class Initialized
INFO - 2017-08-22 07:46:05 --> Security Class Initialized
DEBUG - 2017-08-22 07:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:46:05 --> Input Class Initialized
INFO - 2017-08-22 07:46:05 --> Language Class Initialized
ERROR - 2017-08-22 07:46:05 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:47:13 --> Config Class Initialized
INFO - 2017-08-22 07:47:13 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:47:13 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:47:13 --> Utf8 Class Initialized
INFO - 2017-08-22 07:47:13 --> URI Class Initialized
DEBUG - 2017-08-22 07:47:13 --> No URI present. Default controller set.
INFO - 2017-08-22 07:47:13 --> Router Class Initialized
INFO - 2017-08-22 07:47:13 --> Output Class Initialized
INFO - 2017-08-22 07:47:13 --> Security Class Initialized
DEBUG - 2017-08-22 07:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:47:13 --> Input Class Initialized
INFO - 2017-08-22 07:47:13 --> Language Class Initialized
INFO - 2017-08-22 07:47:13 --> Loader Class Initialized
INFO - 2017-08-22 07:47:13 --> Helper loaded: url_helper
INFO - 2017-08-22 07:47:13 --> Helper loaded: file_helper
INFO - 2017-08-22 07:47:13 --> Database Driver Class Initialized
INFO - 2017-08-22 07:47:13 --> Email Class Initialized
DEBUG - 2017-08-22 07:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:47:13 --> Table Class Initialized
INFO - 2017-08-22 07:47:13 --> Controller Class Initialized
INFO - 2017-08-22 07:47:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:47:13 --> Final output sent to browser
DEBUG - 2017-08-22 07:47:13 --> Total execution time: 0.2771
INFO - 2017-08-22 07:47:13 --> Config Class Initialized
INFO - 2017-08-22 07:47:13 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:47:13 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:47:13 --> Utf8 Class Initialized
INFO - 2017-08-22 07:47:13 --> URI Class Initialized
INFO - 2017-08-22 07:47:13 --> Router Class Initialized
INFO - 2017-08-22 07:47:13 --> Output Class Initialized
INFO - 2017-08-22 07:47:13 --> Security Class Initialized
DEBUG - 2017-08-22 07:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:47:13 --> Input Class Initialized
INFO - 2017-08-22 07:47:13 --> Language Class Initialized
ERROR - 2017-08-22 07:47:13 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:47:14 --> Config Class Initialized
INFO - 2017-08-22 07:47:14 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:47:14 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:47:14 --> Utf8 Class Initialized
INFO - 2017-08-22 07:47:14 --> URI Class Initialized
INFO - 2017-08-22 07:47:14 --> Router Class Initialized
INFO - 2017-08-22 07:47:14 --> Output Class Initialized
INFO - 2017-08-22 07:47:14 --> Security Class Initialized
DEBUG - 2017-08-22 07:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:47:14 --> Input Class Initialized
INFO - 2017-08-22 07:47:14 --> Language Class Initialized
ERROR - 2017-08-22 07:47:14 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:48:00 --> Config Class Initialized
INFO - 2017-08-22 07:48:00 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:48:00 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:48:00 --> Utf8 Class Initialized
INFO - 2017-08-22 07:48:00 --> URI Class Initialized
DEBUG - 2017-08-22 07:48:00 --> No URI present. Default controller set.
INFO - 2017-08-22 07:48:00 --> Router Class Initialized
INFO - 2017-08-22 07:48:00 --> Output Class Initialized
INFO - 2017-08-22 07:48:00 --> Security Class Initialized
DEBUG - 2017-08-22 07:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:48:00 --> Input Class Initialized
INFO - 2017-08-22 07:48:00 --> Language Class Initialized
INFO - 2017-08-22 07:48:00 --> Loader Class Initialized
INFO - 2017-08-22 07:48:00 --> Helper loaded: url_helper
INFO - 2017-08-22 07:48:00 --> Helper loaded: file_helper
INFO - 2017-08-22 07:48:00 --> Database Driver Class Initialized
INFO - 2017-08-22 07:48:00 --> Email Class Initialized
DEBUG - 2017-08-22 07:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:48:00 --> Table Class Initialized
INFO - 2017-08-22 07:48:00 --> Controller Class Initialized
INFO - 2017-08-22 07:48:00 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:48:00 --> Final output sent to browser
DEBUG - 2017-08-22 07:48:00 --> Total execution time: 0.2731
INFO - 2017-08-22 07:48:00 --> Config Class Initialized
INFO - 2017-08-22 07:48:00 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:48:00 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:48:01 --> Utf8 Class Initialized
INFO - 2017-08-22 07:48:01 --> URI Class Initialized
INFO - 2017-08-22 07:48:01 --> Router Class Initialized
INFO - 2017-08-22 07:48:01 --> Output Class Initialized
INFO - 2017-08-22 07:48:01 --> Security Class Initialized
DEBUG - 2017-08-22 07:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:48:01 --> Input Class Initialized
INFO - 2017-08-22 07:48:01 --> Language Class Initialized
ERROR - 2017-08-22 07:48:01 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:48:01 --> Config Class Initialized
INFO - 2017-08-22 07:48:01 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:48:01 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:48:01 --> Utf8 Class Initialized
INFO - 2017-08-22 07:48:01 --> URI Class Initialized
INFO - 2017-08-22 07:48:01 --> Router Class Initialized
INFO - 2017-08-22 07:48:01 --> Output Class Initialized
INFO - 2017-08-22 07:48:01 --> Security Class Initialized
DEBUG - 2017-08-22 07:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:48:01 --> Input Class Initialized
INFO - 2017-08-22 07:48:01 --> Language Class Initialized
ERROR - 2017-08-22 07:48:01 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:51:49 --> Config Class Initialized
INFO - 2017-08-22 07:51:49 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:51:49 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:51:49 --> Utf8 Class Initialized
INFO - 2017-08-22 07:51:49 --> URI Class Initialized
DEBUG - 2017-08-22 07:51:49 --> No URI present. Default controller set.
INFO - 2017-08-22 07:51:49 --> Router Class Initialized
INFO - 2017-08-22 07:51:49 --> Output Class Initialized
INFO - 2017-08-22 07:51:49 --> Security Class Initialized
DEBUG - 2017-08-22 07:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:51:49 --> Input Class Initialized
INFO - 2017-08-22 07:51:49 --> Language Class Initialized
INFO - 2017-08-22 07:51:49 --> Loader Class Initialized
INFO - 2017-08-22 07:51:49 --> Helper loaded: url_helper
INFO - 2017-08-22 07:51:49 --> Helper loaded: file_helper
INFO - 2017-08-22 07:51:49 --> Database Driver Class Initialized
INFO - 2017-08-22 07:51:49 --> Email Class Initialized
DEBUG - 2017-08-22 07:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:51:50 --> Table Class Initialized
INFO - 2017-08-22 07:51:50 --> Controller Class Initialized
INFO - 2017-08-22 07:51:50 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:51:50 --> Final output sent to browser
DEBUG - 2017-08-22 07:51:50 --> Total execution time: 0.3138
INFO - 2017-08-22 07:51:50 --> Config Class Initialized
INFO - 2017-08-22 07:51:50 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:51:50 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:51:50 --> Utf8 Class Initialized
INFO - 2017-08-22 07:51:50 --> URI Class Initialized
INFO - 2017-08-22 07:51:50 --> Router Class Initialized
INFO - 2017-08-22 07:51:50 --> Output Class Initialized
INFO - 2017-08-22 07:51:50 --> Security Class Initialized
DEBUG - 2017-08-22 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:51:50 --> Input Class Initialized
INFO - 2017-08-22 07:51:50 --> Language Class Initialized
ERROR - 2017-08-22 07:51:50 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:51:50 --> Config Class Initialized
INFO - 2017-08-22 07:51:50 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:51:50 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:51:50 --> Utf8 Class Initialized
INFO - 2017-08-22 07:51:51 --> URI Class Initialized
INFO - 2017-08-22 07:51:51 --> Router Class Initialized
INFO - 2017-08-22 07:51:51 --> Output Class Initialized
INFO - 2017-08-22 07:51:51 --> Security Class Initialized
DEBUG - 2017-08-22 07:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:51:51 --> Input Class Initialized
INFO - 2017-08-22 07:51:51 --> Language Class Initialized
ERROR - 2017-08-22 07:51:51 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:53:24 --> Config Class Initialized
INFO - 2017-08-22 07:53:24 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:53:24 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:53:24 --> Utf8 Class Initialized
INFO - 2017-08-22 07:53:24 --> URI Class Initialized
DEBUG - 2017-08-22 07:53:24 --> No URI present. Default controller set.
INFO - 2017-08-22 07:53:24 --> Router Class Initialized
INFO - 2017-08-22 07:53:24 --> Output Class Initialized
INFO - 2017-08-22 07:53:24 --> Security Class Initialized
DEBUG - 2017-08-22 07:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:53:24 --> Input Class Initialized
INFO - 2017-08-22 07:53:24 --> Language Class Initialized
INFO - 2017-08-22 07:53:24 --> Loader Class Initialized
INFO - 2017-08-22 07:53:24 --> Helper loaded: url_helper
INFO - 2017-08-22 07:53:24 --> Helper loaded: file_helper
INFO - 2017-08-22 07:53:24 --> Database Driver Class Initialized
INFO - 2017-08-22 07:53:24 --> Email Class Initialized
DEBUG - 2017-08-22 07:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:53:24 --> Table Class Initialized
INFO - 2017-08-22 07:53:24 --> Controller Class Initialized
INFO - 2017-08-22 07:53:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:53:24 --> Final output sent to browser
DEBUG - 2017-08-22 07:53:24 --> Total execution time: 0.3006
INFO - 2017-08-22 07:53:24 --> Config Class Initialized
INFO - 2017-08-22 07:53:24 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:53:24 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:53:24 --> Utf8 Class Initialized
INFO - 2017-08-22 07:53:24 --> URI Class Initialized
INFO - 2017-08-22 07:53:24 --> Router Class Initialized
INFO - 2017-08-22 07:53:24 --> Output Class Initialized
INFO - 2017-08-22 07:53:24 --> Security Class Initialized
DEBUG - 2017-08-22 07:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:53:24 --> Input Class Initialized
INFO - 2017-08-22 07:53:24 --> Language Class Initialized
ERROR - 2017-08-22 07:53:24 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:53:25 --> Config Class Initialized
INFO - 2017-08-22 07:53:25 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:53:25 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:53:25 --> Utf8 Class Initialized
INFO - 2017-08-22 07:53:25 --> URI Class Initialized
INFO - 2017-08-22 07:53:25 --> Router Class Initialized
INFO - 2017-08-22 07:53:25 --> Output Class Initialized
INFO - 2017-08-22 07:53:25 --> Security Class Initialized
DEBUG - 2017-08-22 07:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:53:25 --> Input Class Initialized
INFO - 2017-08-22 07:53:25 --> Language Class Initialized
ERROR - 2017-08-22 07:53:25 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:53:29 --> Config Class Initialized
INFO - 2017-08-22 07:53:29 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:53:29 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:53:29 --> Utf8 Class Initialized
INFO - 2017-08-22 07:53:29 --> URI Class Initialized
DEBUG - 2017-08-22 07:53:29 --> No URI present. Default controller set.
INFO - 2017-08-22 07:53:29 --> Router Class Initialized
INFO - 2017-08-22 07:53:29 --> Output Class Initialized
INFO - 2017-08-22 07:53:29 --> Security Class Initialized
DEBUG - 2017-08-22 07:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:53:29 --> Input Class Initialized
INFO - 2017-08-22 07:53:29 --> Language Class Initialized
INFO - 2017-08-22 07:53:29 --> Loader Class Initialized
INFO - 2017-08-22 07:53:29 --> Helper loaded: url_helper
INFO - 2017-08-22 07:53:29 --> Helper loaded: file_helper
INFO - 2017-08-22 07:53:29 --> Database Driver Class Initialized
INFO - 2017-08-22 07:53:29 --> Email Class Initialized
DEBUG - 2017-08-22 07:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:53:29 --> Table Class Initialized
INFO - 2017-08-22 07:53:30 --> Controller Class Initialized
INFO - 2017-08-22 07:53:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:53:30 --> Final output sent to browser
DEBUG - 2017-08-22 07:53:30 --> Total execution time: 0.2936
INFO - 2017-08-22 07:53:30 --> Config Class Initialized
INFO - 2017-08-22 07:53:30 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:53:30 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:53:30 --> Utf8 Class Initialized
INFO - 2017-08-22 07:53:30 --> URI Class Initialized
INFO - 2017-08-22 07:53:30 --> Router Class Initialized
INFO - 2017-08-22 07:53:30 --> Output Class Initialized
INFO - 2017-08-22 07:53:30 --> Security Class Initialized
DEBUG - 2017-08-22 07:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:53:30 --> Input Class Initialized
INFO - 2017-08-22 07:53:30 --> Language Class Initialized
ERROR - 2017-08-22 07:53:30 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:53:30 --> Config Class Initialized
INFO - 2017-08-22 07:53:30 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:53:30 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:53:30 --> Utf8 Class Initialized
INFO - 2017-08-22 07:53:30 --> URI Class Initialized
INFO - 2017-08-22 07:53:30 --> Router Class Initialized
INFO - 2017-08-22 07:53:30 --> Output Class Initialized
INFO - 2017-08-22 07:53:30 --> Security Class Initialized
DEBUG - 2017-08-22 07:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:53:30 --> Input Class Initialized
INFO - 2017-08-22 07:53:30 --> Language Class Initialized
ERROR - 2017-08-22 07:53:30 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:53:43 --> Config Class Initialized
INFO - 2017-08-22 07:53:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:53:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:53:43 --> Utf8 Class Initialized
INFO - 2017-08-22 07:53:43 --> URI Class Initialized
DEBUG - 2017-08-22 07:53:43 --> No URI present. Default controller set.
INFO - 2017-08-22 07:53:43 --> Router Class Initialized
INFO - 2017-08-22 07:53:43 --> Output Class Initialized
INFO - 2017-08-22 07:53:43 --> Security Class Initialized
DEBUG - 2017-08-22 07:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:53:43 --> Input Class Initialized
INFO - 2017-08-22 07:53:43 --> Language Class Initialized
INFO - 2017-08-22 07:53:43 --> Loader Class Initialized
INFO - 2017-08-22 07:53:43 --> Helper loaded: url_helper
INFO - 2017-08-22 07:53:43 --> Helper loaded: file_helper
INFO - 2017-08-22 07:53:43 --> Database Driver Class Initialized
INFO - 2017-08-22 07:53:43 --> Email Class Initialized
DEBUG - 2017-08-22 07:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:53:43 --> Table Class Initialized
INFO - 2017-08-22 07:53:43 --> Controller Class Initialized
INFO - 2017-08-22 07:53:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:53:43 --> Final output sent to browser
DEBUG - 2017-08-22 07:53:43 --> Total execution time: 0.2740
INFO - 2017-08-22 07:53:43 --> Config Class Initialized
INFO - 2017-08-22 07:53:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:53:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:53:43 --> Utf8 Class Initialized
INFO - 2017-08-22 07:53:43 --> URI Class Initialized
INFO - 2017-08-22 07:53:43 --> Router Class Initialized
INFO - 2017-08-22 07:53:43 --> Output Class Initialized
INFO - 2017-08-22 07:53:43 --> Security Class Initialized
DEBUG - 2017-08-22 07:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:53:44 --> Input Class Initialized
INFO - 2017-08-22 07:53:44 --> Language Class Initialized
ERROR - 2017-08-22 07:53:44 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:53:44 --> Config Class Initialized
INFO - 2017-08-22 07:53:44 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:53:44 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:53:44 --> Utf8 Class Initialized
INFO - 2017-08-22 07:53:44 --> URI Class Initialized
INFO - 2017-08-22 07:53:44 --> Router Class Initialized
INFO - 2017-08-22 07:53:44 --> Output Class Initialized
INFO - 2017-08-22 07:53:44 --> Security Class Initialized
DEBUG - 2017-08-22 07:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:53:44 --> Input Class Initialized
INFO - 2017-08-22 07:53:44 --> Language Class Initialized
ERROR - 2017-08-22 07:53:44 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:53:56 --> Config Class Initialized
INFO - 2017-08-22 07:53:56 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:53:56 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:53:56 --> Utf8 Class Initialized
INFO - 2017-08-22 07:53:56 --> URI Class Initialized
DEBUG - 2017-08-22 07:53:56 --> No URI present. Default controller set.
INFO - 2017-08-22 07:53:56 --> Router Class Initialized
INFO - 2017-08-22 07:53:56 --> Output Class Initialized
INFO - 2017-08-22 07:53:56 --> Security Class Initialized
DEBUG - 2017-08-22 07:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:53:56 --> Input Class Initialized
INFO - 2017-08-22 07:53:56 --> Language Class Initialized
INFO - 2017-08-22 07:53:56 --> Loader Class Initialized
INFO - 2017-08-22 07:53:56 --> Helper loaded: url_helper
INFO - 2017-08-22 07:53:56 --> Helper loaded: file_helper
INFO - 2017-08-22 07:53:56 --> Database Driver Class Initialized
INFO - 2017-08-22 07:53:56 --> Email Class Initialized
DEBUG - 2017-08-22 07:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:53:56 --> Table Class Initialized
INFO - 2017-08-22 07:53:56 --> Controller Class Initialized
INFO - 2017-08-22 07:53:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:53:56 --> Final output sent to browser
DEBUG - 2017-08-22 07:53:56 --> Total execution time: 0.3023
INFO - 2017-08-22 07:53:56 --> Config Class Initialized
INFO - 2017-08-22 07:53:56 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:53:56 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:53:56 --> Utf8 Class Initialized
INFO - 2017-08-22 07:53:56 --> URI Class Initialized
INFO - 2017-08-22 07:53:56 --> Router Class Initialized
INFO - 2017-08-22 07:53:56 --> Output Class Initialized
INFO - 2017-08-22 07:53:56 --> Security Class Initialized
DEBUG - 2017-08-22 07:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:53:56 --> Input Class Initialized
INFO - 2017-08-22 07:53:56 --> Language Class Initialized
ERROR - 2017-08-22 07:53:56 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:53:57 --> Config Class Initialized
INFO - 2017-08-22 07:53:57 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:53:57 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:53:57 --> Utf8 Class Initialized
INFO - 2017-08-22 07:53:57 --> URI Class Initialized
INFO - 2017-08-22 07:53:57 --> Router Class Initialized
INFO - 2017-08-22 07:53:57 --> Output Class Initialized
INFO - 2017-08-22 07:53:57 --> Security Class Initialized
DEBUG - 2017-08-22 07:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:53:57 --> Input Class Initialized
INFO - 2017-08-22 07:53:57 --> Language Class Initialized
ERROR - 2017-08-22 07:53:57 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:54:12 --> Config Class Initialized
INFO - 2017-08-22 07:54:12 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:54:12 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:54:12 --> Utf8 Class Initialized
INFO - 2017-08-22 07:54:12 --> URI Class Initialized
DEBUG - 2017-08-22 07:54:12 --> No URI present. Default controller set.
INFO - 2017-08-22 07:54:12 --> Router Class Initialized
INFO - 2017-08-22 07:54:12 --> Output Class Initialized
INFO - 2017-08-22 07:54:12 --> Security Class Initialized
DEBUG - 2017-08-22 07:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:54:12 --> Input Class Initialized
INFO - 2017-08-22 07:54:12 --> Language Class Initialized
INFO - 2017-08-22 07:54:12 --> Loader Class Initialized
INFO - 2017-08-22 07:54:12 --> Helper loaded: url_helper
INFO - 2017-08-22 07:54:12 --> Helper loaded: file_helper
INFO - 2017-08-22 07:54:12 --> Database Driver Class Initialized
INFO - 2017-08-22 07:54:12 --> Email Class Initialized
DEBUG - 2017-08-22 07:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:54:12 --> Table Class Initialized
INFO - 2017-08-22 07:54:12 --> Controller Class Initialized
INFO - 2017-08-22 07:54:12 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:54:12 --> Final output sent to browser
DEBUG - 2017-08-22 07:54:13 --> Total execution time: 0.2901
INFO - 2017-08-22 07:54:13 --> Config Class Initialized
INFO - 2017-08-22 07:54:13 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:54:13 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:54:13 --> Utf8 Class Initialized
INFO - 2017-08-22 07:54:13 --> URI Class Initialized
INFO - 2017-08-22 07:54:13 --> Router Class Initialized
INFO - 2017-08-22 07:54:13 --> Output Class Initialized
INFO - 2017-08-22 07:54:13 --> Security Class Initialized
DEBUG - 2017-08-22 07:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:54:13 --> Input Class Initialized
INFO - 2017-08-22 07:54:13 --> Language Class Initialized
ERROR - 2017-08-22 07:54:13 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:54:13 --> Config Class Initialized
INFO - 2017-08-22 07:54:13 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:54:13 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:54:13 --> Utf8 Class Initialized
INFO - 2017-08-22 07:54:13 --> URI Class Initialized
INFO - 2017-08-22 07:54:13 --> Router Class Initialized
INFO - 2017-08-22 07:54:13 --> Output Class Initialized
INFO - 2017-08-22 07:54:13 --> Security Class Initialized
DEBUG - 2017-08-22 07:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:54:13 --> Input Class Initialized
INFO - 2017-08-22 07:54:13 --> Language Class Initialized
ERROR - 2017-08-22 07:54:13 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:54:20 --> Config Class Initialized
INFO - 2017-08-22 07:54:20 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:54:20 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:54:20 --> Utf8 Class Initialized
INFO - 2017-08-22 07:54:20 --> URI Class Initialized
DEBUG - 2017-08-22 07:54:20 --> No URI present. Default controller set.
INFO - 2017-08-22 07:54:20 --> Router Class Initialized
INFO - 2017-08-22 07:54:20 --> Output Class Initialized
INFO - 2017-08-22 07:54:20 --> Security Class Initialized
DEBUG - 2017-08-22 07:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:54:20 --> Input Class Initialized
INFO - 2017-08-22 07:54:20 --> Language Class Initialized
INFO - 2017-08-22 07:54:20 --> Loader Class Initialized
INFO - 2017-08-22 07:54:20 --> Helper loaded: url_helper
INFO - 2017-08-22 07:54:20 --> Helper loaded: file_helper
INFO - 2017-08-22 07:54:20 --> Database Driver Class Initialized
INFO - 2017-08-22 07:54:20 --> Email Class Initialized
DEBUG - 2017-08-22 07:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:54:20 --> Table Class Initialized
INFO - 2017-08-22 07:54:20 --> Controller Class Initialized
INFO - 2017-08-22 07:54:20 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:54:20 --> Final output sent to browser
DEBUG - 2017-08-22 07:54:20 --> Total execution time: 0.2920
INFO - 2017-08-22 07:54:21 --> Config Class Initialized
INFO - 2017-08-22 07:54:21 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:54:21 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:54:21 --> Utf8 Class Initialized
INFO - 2017-08-22 07:54:21 --> URI Class Initialized
INFO - 2017-08-22 07:54:21 --> Router Class Initialized
INFO - 2017-08-22 07:54:21 --> Output Class Initialized
INFO - 2017-08-22 07:54:21 --> Security Class Initialized
DEBUG - 2017-08-22 07:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:54:21 --> Input Class Initialized
INFO - 2017-08-22 07:54:21 --> Language Class Initialized
ERROR - 2017-08-22 07:54:21 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:54:21 --> Config Class Initialized
INFO - 2017-08-22 07:54:21 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:54:21 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:54:21 --> Utf8 Class Initialized
INFO - 2017-08-22 07:54:21 --> URI Class Initialized
INFO - 2017-08-22 07:54:21 --> Router Class Initialized
INFO - 2017-08-22 07:54:21 --> Output Class Initialized
INFO - 2017-08-22 07:54:21 --> Security Class Initialized
DEBUG - 2017-08-22 07:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:54:21 --> Input Class Initialized
INFO - 2017-08-22 07:54:21 --> Language Class Initialized
ERROR - 2017-08-22 07:54:21 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:54:41 --> Config Class Initialized
INFO - 2017-08-22 07:54:41 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:54:41 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:54:41 --> Utf8 Class Initialized
INFO - 2017-08-22 07:54:41 --> URI Class Initialized
DEBUG - 2017-08-22 07:54:41 --> No URI present. Default controller set.
INFO - 2017-08-22 07:54:41 --> Router Class Initialized
INFO - 2017-08-22 07:54:41 --> Output Class Initialized
INFO - 2017-08-22 07:54:41 --> Security Class Initialized
DEBUG - 2017-08-22 07:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:54:41 --> Input Class Initialized
INFO - 2017-08-22 07:54:41 --> Language Class Initialized
INFO - 2017-08-22 07:54:41 --> Loader Class Initialized
INFO - 2017-08-22 07:54:41 --> Helper loaded: url_helper
INFO - 2017-08-22 07:54:41 --> Helper loaded: file_helper
INFO - 2017-08-22 07:54:41 --> Database Driver Class Initialized
INFO - 2017-08-22 07:54:41 --> Email Class Initialized
DEBUG - 2017-08-22 07:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:54:41 --> Table Class Initialized
INFO - 2017-08-22 07:54:41 --> Controller Class Initialized
INFO - 2017-08-22 07:54:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:54:41 --> Final output sent to browser
DEBUG - 2017-08-22 07:54:41 --> Total execution time: 0.2897
INFO - 2017-08-22 07:54:41 --> Config Class Initialized
INFO - 2017-08-22 07:54:41 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:54:41 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:54:41 --> Utf8 Class Initialized
INFO - 2017-08-22 07:54:41 --> URI Class Initialized
INFO - 2017-08-22 07:54:41 --> Router Class Initialized
INFO - 2017-08-22 07:54:41 --> Output Class Initialized
INFO - 2017-08-22 07:54:41 --> Security Class Initialized
DEBUG - 2017-08-22 07:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:54:41 --> Input Class Initialized
INFO - 2017-08-22 07:54:41 --> Language Class Initialized
ERROR - 2017-08-22 07:54:41 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:54:42 --> Config Class Initialized
INFO - 2017-08-22 07:54:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:54:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:54:42 --> Utf8 Class Initialized
INFO - 2017-08-22 07:54:42 --> URI Class Initialized
INFO - 2017-08-22 07:54:42 --> Router Class Initialized
INFO - 2017-08-22 07:54:42 --> Output Class Initialized
INFO - 2017-08-22 07:54:42 --> Security Class Initialized
DEBUG - 2017-08-22 07:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:54:42 --> Input Class Initialized
INFO - 2017-08-22 07:54:42 --> Language Class Initialized
ERROR - 2017-08-22 07:54:42 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:55:39 --> Config Class Initialized
INFO - 2017-08-22 07:55:39 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:55:39 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:55:39 --> Utf8 Class Initialized
INFO - 2017-08-22 07:55:39 --> URI Class Initialized
DEBUG - 2017-08-22 07:55:39 --> No URI present. Default controller set.
INFO - 2017-08-22 07:55:39 --> Router Class Initialized
INFO - 2017-08-22 07:55:39 --> Output Class Initialized
INFO - 2017-08-22 07:55:39 --> Security Class Initialized
DEBUG - 2017-08-22 07:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:55:39 --> Input Class Initialized
INFO - 2017-08-22 07:55:39 --> Language Class Initialized
INFO - 2017-08-22 07:55:39 --> Loader Class Initialized
INFO - 2017-08-22 07:55:39 --> Helper loaded: url_helper
INFO - 2017-08-22 07:55:39 --> Helper loaded: file_helper
INFO - 2017-08-22 07:55:39 --> Database Driver Class Initialized
INFO - 2017-08-22 07:55:39 --> Email Class Initialized
DEBUG - 2017-08-22 07:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:55:39 --> Table Class Initialized
INFO - 2017-08-22 07:55:39 --> Controller Class Initialized
INFO - 2017-08-22 07:55:39 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:55:39 --> Final output sent to browser
DEBUG - 2017-08-22 07:55:39 --> Total execution time: 0.3072
INFO - 2017-08-22 07:55:40 --> Config Class Initialized
INFO - 2017-08-22 07:55:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:55:40 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:55:40 --> Utf8 Class Initialized
INFO - 2017-08-22 07:55:40 --> URI Class Initialized
INFO - 2017-08-22 07:55:40 --> Router Class Initialized
INFO - 2017-08-22 07:55:40 --> Output Class Initialized
INFO - 2017-08-22 07:55:40 --> Security Class Initialized
DEBUG - 2017-08-22 07:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:55:40 --> Input Class Initialized
INFO - 2017-08-22 07:55:40 --> Language Class Initialized
ERROR - 2017-08-22 07:55:40 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:55:40 --> Config Class Initialized
INFO - 2017-08-22 07:55:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:55:40 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:55:40 --> Utf8 Class Initialized
INFO - 2017-08-22 07:55:40 --> URI Class Initialized
INFO - 2017-08-22 07:55:40 --> Router Class Initialized
INFO - 2017-08-22 07:55:40 --> Output Class Initialized
INFO - 2017-08-22 07:55:40 --> Security Class Initialized
DEBUG - 2017-08-22 07:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:55:40 --> Input Class Initialized
INFO - 2017-08-22 07:55:40 --> Language Class Initialized
ERROR - 2017-08-22 07:55:40 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:55:52 --> Config Class Initialized
INFO - 2017-08-22 07:55:52 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:55:52 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:55:52 --> Utf8 Class Initialized
INFO - 2017-08-22 07:55:52 --> URI Class Initialized
DEBUG - 2017-08-22 07:55:52 --> No URI present. Default controller set.
INFO - 2017-08-22 07:55:52 --> Router Class Initialized
INFO - 2017-08-22 07:55:52 --> Output Class Initialized
INFO - 2017-08-22 07:55:52 --> Security Class Initialized
DEBUG - 2017-08-22 07:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:55:52 --> Input Class Initialized
INFO - 2017-08-22 07:55:52 --> Language Class Initialized
INFO - 2017-08-22 07:55:52 --> Loader Class Initialized
INFO - 2017-08-22 07:55:52 --> Helper loaded: url_helper
INFO - 2017-08-22 07:55:52 --> Helper loaded: file_helper
INFO - 2017-08-22 07:55:52 --> Database Driver Class Initialized
INFO - 2017-08-22 07:55:52 --> Email Class Initialized
DEBUG - 2017-08-22 07:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:55:52 --> Table Class Initialized
INFO - 2017-08-22 07:55:52 --> Controller Class Initialized
INFO - 2017-08-22 07:55:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:55:52 --> Final output sent to browser
DEBUG - 2017-08-22 07:55:52 --> Total execution time: 0.2823
INFO - 2017-08-22 07:55:52 --> Config Class Initialized
INFO - 2017-08-22 07:55:52 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:55:52 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:55:52 --> Utf8 Class Initialized
INFO - 2017-08-22 07:55:52 --> URI Class Initialized
INFO - 2017-08-22 07:55:52 --> Router Class Initialized
INFO - 2017-08-22 07:55:52 --> Output Class Initialized
INFO - 2017-08-22 07:55:52 --> Security Class Initialized
DEBUG - 2017-08-22 07:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:55:53 --> Input Class Initialized
INFO - 2017-08-22 07:55:53 --> Language Class Initialized
ERROR - 2017-08-22 07:55:53 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:55:53 --> Config Class Initialized
INFO - 2017-08-22 07:55:53 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:55:53 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:55:53 --> Utf8 Class Initialized
INFO - 2017-08-22 07:55:53 --> URI Class Initialized
INFO - 2017-08-22 07:55:53 --> Router Class Initialized
INFO - 2017-08-22 07:55:53 --> Output Class Initialized
INFO - 2017-08-22 07:55:53 --> Security Class Initialized
DEBUG - 2017-08-22 07:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:55:53 --> Input Class Initialized
INFO - 2017-08-22 07:55:53 --> Language Class Initialized
ERROR - 2017-08-22 07:55:53 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:56:05 --> Config Class Initialized
INFO - 2017-08-22 07:56:05 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:56:05 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:56:05 --> Utf8 Class Initialized
INFO - 2017-08-22 07:56:05 --> URI Class Initialized
DEBUG - 2017-08-22 07:56:05 --> No URI present. Default controller set.
INFO - 2017-08-22 07:56:05 --> Router Class Initialized
INFO - 2017-08-22 07:56:05 --> Output Class Initialized
INFO - 2017-08-22 07:56:05 --> Security Class Initialized
DEBUG - 2017-08-22 07:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:56:05 --> Input Class Initialized
INFO - 2017-08-22 07:56:05 --> Language Class Initialized
INFO - 2017-08-22 07:56:05 --> Loader Class Initialized
INFO - 2017-08-22 07:56:05 --> Helper loaded: url_helper
INFO - 2017-08-22 07:56:05 --> Helper loaded: file_helper
INFO - 2017-08-22 07:56:05 --> Database Driver Class Initialized
INFO - 2017-08-22 07:56:05 --> Email Class Initialized
DEBUG - 2017-08-22 07:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:56:05 --> Table Class Initialized
INFO - 2017-08-22 07:56:05 --> Controller Class Initialized
INFO - 2017-08-22 07:56:05 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:56:05 --> Final output sent to browser
DEBUG - 2017-08-22 07:56:05 --> Total execution time: 0.2962
INFO - 2017-08-22 07:56:05 --> Config Class Initialized
INFO - 2017-08-22 07:56:05 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:56:05 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:56:05 --> Utf8 Class Initialized
INFO - 2017-08-22 07:56:05 --> URI Class Initialized
INFO - 2017-08-22 07:56:05 --> Router Class Initialized
INFO - 2017-08-22 07:56:05 --> Output Class Initialized
INFO - 2017-08-22 07:56:05 --> Security Class Initialized
DEBUG - 2017-08-22 07:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:56:05 --> Input Class Initialized
INFO - 2017-08-22 07:56:05 --> Language Class Initialized
ERROR - 2017-08-22 07:56:05 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:56:06 --> Config Class Initialized
INFO - 2017-08-22 07:56:06 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:56:06 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:56:06 --> Utf8 Class Initialized
INFO - 2017-08-22 07:56:06 --> URI Class Initialized
INFO - 2017-08-22 07:56:06 --> Router Class Initialized
INFO - 2017-08-22 07:56:06 --> Output Class Initialized
INFO - 2017-08-22 07:56:06 --> Security Class Initialized
DEBUG - 2017-08-22 07:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:56:06 --> Input Class Initialized
INFO - 2017-08-22 07:56:06 --> Language Class Initialized
ERROR - 2017-08-22 07:56:06 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:56:30 --> Config Class Initialized
INFO - 2017-08-22 07:56:30 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:56:30 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:56:30 --> Utf8 Class Initialized
INFO - 2017-08-22 07:56:30 --> URI Class Initialized
DEBUG - 2017-08-22 07:56:30 --> No URI present. Default controller set.
INFO - 2017-08-22 07:56:30 --> Router Class Initialized
INFO - 2017-08-22 07:56:30 --> Output Class Initialized
INFO - 2017-08-22 07:56:30 --> Security Class Initialized
DEBUG - 2017-08-22 07:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:56:30 --> Input Class Initialized
INFO - 2017-08-22 07:56:30 --> Language Class Initialized
INFO - 2017-08-22 07:56:30 --> Loader Class Initialized
INFO - 2017-08-22 07:56:30 --> Helper loaded: url_helper
INFO - 2017-08-22 07:56:30 --> Helper loaded: file_helper
INFO - 2017-08-22 07:56:30 --> Database Driver Class Initialized
INFO - 2017-08-22 07:56:30 --> Email Class Initialized
DEBUG - 2017-08-22 07:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:56:30 --> Table Class Initialized
INFO - 2017-08-22 07:56:30 --> Controller Class Initialized
INFO - 2017-08-22 07:56:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:56:30 --> Final output sent to browser
DEBUG - 2017-08-22 07:56:30 --> Total execution time: 0.2952
INFO - 2017-08-22 07:56:30 --> Config Class Initialized
INFO - 2017-08-22 07:56:30 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:56:30 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:56:30 --> Utf8 Class Initialized
INFO - 2017-08-22 07:56:30 --> URI Class Initialized
INFO - 2017-08-22 07:56:30 --> Router Class Initialized
INFO - 2017-08-22 07:56:30 --> Output Class Initialized
INFO - 2017-08-22 07:56:30 --> Security Class Initialized
DEBUG - 2017-08-22 07:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:56:30 --> Input Class Initialized
INFO - 2017-08-22 07:56:30 --> Language Class Initialized
ERROR - 2017-08-22 07:56:30 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:56:31 --> Config Class Initialized
INFO - 2017-08-22 07:56:31 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:56:31 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:56:31 --> Utf8 Class Initialized
INFO - 2017-08-22 07:56:31 --> URI Class Initialized
INFO - 2017-08-22 07:56:31 --> Router Class Initialized
INFO - 2017-08-22 07:56:31 --> Output Class Initialized
INFO - 2017-08-22 07:56:31 --> Security Class Initialized
DEBUG - 2017-08-22 07:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:56:31 --> Input Class Initialized
INFO - 2017-08-22 07:56:31 --> Language Class Initialized
ERROR - 2017-08-22 07:56:31 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:56:45 --> Config Class Initialized
INFO - 2017-08-22 07:56:45 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:56:45 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:56:45 --> Utf8 Class Initialized
INFO - 2017-08-22 07:56:45 --> URI Class Initialized
DEBUG - 2017-08-22 07:56:45 --> No URI present. Default controller set.
INFO - 2017-08-22 07:56:45 --> Router Class Initialized
INFO - 2017-08-22 07:56:45 --> Output Class Initialized
INFO - 2017-08-22 07:56:46 --> Security Class Initialized
DEBUG - 2017-08-22 07:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:56:46 --> Input Class Initialized
INFO - 2017-08-22 07:56:46 --> Language Class Initialized
INFO - 2017-08-22 07:56:46 --> Loader Class Initialized
INFO - 2017-08-22 07:56:46 --> Helper loaded: url_helper
INFO - 2017-08-22 07:56:46 --> Helper loaded: file_helper
INFO - 2017-08-22 07:56:46 --> Database Driver Class Initialized
INFO - 2017-08-22 07:56:46 --> Email Class Initialized
DEBUG - 2017-08-22 07:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:56:46 --> Table Class Initialized
INFO - 2017-08-22 07:56:46 --> Controller Class Initialized
INFO - 2017-08-22 07:56:46 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:56:46 --> Final output sent to browser
DEBUG - 2017-08-22 07:56:46 --> Total execution time: 0.2989
INFO - 2017-08-22 07:56:46 --> Config Class Initialized
INFO - 2017-08-22 07:56:46 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:56:46 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:56:46 --> Utf8 Class Initialized
INFO - 2017-08-22 07:56:46 --> URI Class Initialized
INFO - 2017-08-22 07:56:46 --> Router Class Initialized
INFO - 2017-08-22 07:56:46 --> Output Class Initialized
INFO - 2017-08-22 07:56:46 --> Security Class Initialized
DEBUG - 2017-08-22 07:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:56:46 --> Input Class Initialized
INFO - 2017-08-22 07:56:46 --> Language Class Initialized
ERROR - 2017-08-22 07:56:46 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:56:46 --> Config Class Initialized
INFO - 2017-08-22 07:56:46 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:56:46 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:56:46 --> Utf8 Class Initialized
INFO - 2017-08-22 07:56:46 --> URI Class Initialized
INFO - 2017-08-22 07:56:47 --> Router Class Initialized
INFO - 2017-08-22 07:56:47 --> Output Class Initialized
INFO - 2017-08-22 07:56:47 --> Security Class Initialized
DEBUG - 2017-08-22 07:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:56:47 --> Input Class Initialized
INFO - 2017-08-22 07:56:47 --> Language Class Initialized
ERROR - 2017-08-22 07:56:47 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:57:39 --> Config Class Initialized
INFO - 2017-08-22 07:57:39 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:57:39 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:57:39 --> Utf8 Class Initialized
INFO - 2017-08-22 07:57:39 --> URI Class Initialized
DEBUG - 2017-08-22 07:57:39 --> No URI present. Default controller set.
INFO - 2017-08-22 07:57:39 --> Router Class Initialized
INFO - 2017-08-22 07:57:39 --> Output Class Initialized
INFO - 2017-08-22 07:57:39 --> Security Class Initialized
DEBUG - 2017-08-22 07:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:57:39 --> Input Class Initialized
INFO - 2017-08-22 07:57:39 --> Language Class Initialized
INFO - 2017-08-22 07:57:39 --> Loader Class Initialized
INFO - 2017-08-22 07:57:39 --> Helper loaded: url_helper
INFO - 2017-08-22 07:57:39 --> Helper loaded: file_helper
INFO - 2017-08-22 07:57:39 --> Database Driver Class Initialized
INFO - 2017-08-22 07:57:39 --> Email Class Initialized
DEBUG - 2017-08-22 07:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:57:39 --> Table Class Initialized
INFO - 2017-08-22 07:57:39 --> Controller Class Initialized
INFO - 2017-08-22 07:57:39 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:57:39 --> Final output sent to browser
DEBUG - 2017-08-22 07:57:39 --> Total execution time: 0.2942
INFO - 2017-08-22 07:57:40 --> Config Class Initialized
INFO - 2017-08-22 07:57:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:57:40 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:57:40 --> Utf8 Class Initialized
INFO - 2017-08-22 07:57:40 --> URI Class Initialized
INFO - 2017-08-22 07:57:40 --> Router Class Initialized
INFO - 2017-08-22 07:57:40 --> Output Class Initialized
INFO - 2017-08-22 07:57:40 --> Security Class Initialized
DEBUG - 2017-08-22 07:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:57:40 --> Input Class Initialized
INFO - 2017-08-22 07:57:40 --> Language Class Initialized
ERROR - 2017-08-22 07:57:40 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:57:40 --> Config Class Initialized
INFO - 2017-08-22 07:57:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:57:40 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:57:40 --> Utf8 Class Initialized
INFO - 2017-08-22 07:57:40 --> URI Class Initialized
INFO - 2017-08-22 07:57:40 --> Router Class Initialized
INFO - 2017-08-22 07:57:40 --> Output Class Initialized
INFO - 2017-08-22 07:57:40 --> Security Class Initialized
DEBUG - 2017-08-22 07:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:57:40 --> Input Class Initialized
INFO - 2017-08-22 07:57:40 --> Language Class Initialized
ERROR - 2017-08-22 07:57:40 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:58:12 --> Config Class Initialized
INFO - 2017-08-22 07:58:12 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:58:12 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:58:12 --> Utf8 Class Initialized
INFO - 2017-08-22 07:58:12 --> URI Class Initialized
DEBUG - 2017-08-22 07:58:12 --> No URI present. Default controller set.
INFO - 2017-08-22 07:58:12 --> Router Class Initialized
INFO - 2017-08-22 07:58:12 --> Output Class Initialized
INFO - 2017-08-22 07:58:12 --> Security Class Initialized
DEBUG - 2017-08-22 07:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:58:12 --> Input Class Initialized
INFO - 2017-08-22 07:58:12 --> Language Class Initialized
INFO - 2017-08-22 07:58:12 --> Loader Class Initialized
INFO - 2017-08-22 07:58:12 --> Helper loaded: url_helper
INFO - 2017-08-22 07:58:12 --> Helper loaded: file_helper
INFO - 2017-08-22 07:58:12 --> Database Driver Class Initialized
INFO - 2017-08-22 07:58:12 --> Email Class Initialized
DEBUG - 2017-08-22 07:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:58:12 --> Table Class Initialized
INFO - 2017-08-22 07:58:12 --> Controller Class Initialized
INFO - 2017-08-22 07:58:12 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:58:12 --> Final output sent to browser
DEBUG - 2017-08-22 07:58:12 --> Total execution time: 0.2963
INFO - 2017-08-22 07:58:12 --> Config Class Initialized
INFO - 2017-08-22 07:58:12 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:58:12 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:58:12 --> Utf8 Class Initialized
INFO - 2017-08-22 07:58:12 --> URI Class Initialized
INFO - 2017-08-22 07:58:12 --> Router Class Initialized
INFO - 2017-08-22 07:58:12 --> Output Class Initialized
INFO - 2017-08-22 07:58:12 --> Security Class Initialized
DEBUG - 2017-08-22 07:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:58:12 --> Input Class Initialized
INFO - 2017-08-22 07:58:12 --> Language Class Initialized
ERROR - 2017-08-22 07:58:12 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:58:13 --> Config Class Initialized
INFO - 2017-08-22 07:58:13 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:58:13 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:58:13 --> Utf8 Class Initialized
INFO - 2017-08-22 07:58:13 --> URI Class Initialized
INFO - 2017-08-22 07:58:13 --> Router Class Initialized
INFO - 2017-08-22 07:58:13 --> Output Class Initialized
INFO - 2017-08-22 07:58:13 --> Security Class Initialized
DEBUG - 2017-08-22 07:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:58:13 --> Input Class Initialized
INFO - 2017-08-22 07:58:13 --> Language Class Initialized
ERROR - 2017-08-22 07:58:13 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:58:41 --> Config Class Initialized
INFO - 2017-08-22 07:58:41 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:58:41 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:58:41 --> Utf8 Class Initialized
INFO - 2017-08-22 07:58:41 --> URI Class Initialized
DEBUG - 2017-08-22 07:58:41 --> No URI present. Default controller set.
INFO - 2017-08-22 07:58:41 --> Router Class Initialized
INFO - 2017-08-22 07:58:41 --> Output Class Initialized
INFO - 2017-08-22 07:58:41 --> Security Class Initialized
DEBUG - 2017-08-22 07:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:58:41 --> Input Class Initialized
INFO - 2017-08-22 07:58:41 --> Language Class Initialized
INFO - 2017-08-22 07:58:41 --> Loader Class Initialized
INFO - 2017-08-22 07:58:41 --> Helper loaded: url_helper
INFO - 2017-08-22 07:58:41 --> Helper loaded: file_helper
INFO - 2017-08-22 07:58:41 --> Database Driver Class Initialized
INFO - 2017-08-22 07:58:41 --> Email Class Initialized
DEBUG - 2017-08-22 07:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:58:41 --> Table Class Initialized
INFO - 2017-08-22 07:58:41 --> Controller Class Initialized
INFO - 2017-08-22 07:58:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 07:58:41 --> Final output sent to browser
DEBUG - 2017-08-22 07:58:41 --> Total execution time: 0.2870
INFO - 2017-08-22 07:58:41 --> Config Class Initialized
INFO - 2017-08-22 07:58:41 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:58:41 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:58:41 --> Utf8 Class Initialized
INFO - 2017-08-22 07:58:41 --> URI Class Initialized
INFO - 2017-08-22 07:58:41 --> Router Class Initialized
INFO - 2017-08-22 07:58:41 --> Output Class Initialized
INFO - 2017-08-22 07:58:41 --> Security Class Initialized
DEBUG - 2017-08-22 07:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:58:42 --> Input Class Initialized
INFO - 2017-08-22 07:58:42 --> Language Class Initialized
ERROR - 2017-08-22 07:58:42 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 07:58:42 --> Config Class Initialized
INFO - 2017-08-22 07:58:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:58:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:58:42 --> Utf8 Class Initialized
INFO - 2017-08-22 07:58:42 --> URI Class Initialized
INFO - 2017-08-22 07:58:42 --> Router Class Initialized
INFO - 2017-08-22 07:58:42 --> Output Class Initialized
INFO - 2017-08-22 07:58:42 --> Security Class Initialized
DEBUG - 2017-08-22 07:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:58:42 --> Input Class Initialized
INFO - 2017-08-22 07:58:42 --> Language Class Initialized
ERROR - 2017-08-22 07:58:42 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-22 08:02:22 --> Config Class Initialized
INFO - 2017-08-22 08:02:22 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:02:22 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:02:22 --> Utf8 Class Initialized
INFO - 2017-08-22 08:02:22 --> URI Class Initialized
DEBUG - 2017-08-22 08:02:22 --> No URI present. Default controller set.
INFO - 2017-08-22 08:02:22 --> Router Class Initialized
INFO - 2017-08-22 08:02:22 --> Output Class Initialized
INFO - 2017-08-22 08:02:22 --> Security Class Initialized
DEBUG - 2017-08-22 08:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:02:22 --> Input Class Initialized
INFO - 2017-08-22 08:02:22 --> Language Class Initialized
INFO - 2017-08-22 08:02:22 --> Loader Class Initialized
INFO - 2017-08-22 08:02:22 --> Helper loaded: url_helper
INFO - 2017-08-22 08:02:22 --> Helper loaded: file_helper
INFO - 2017-08-22 08:02:22 --> Database Driver Class Initialized
INFO - 2017-08-22 08:02:22 --> Email Class Initialized
DEBUG - 2017-08-22 08:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:02:22 --> Table Class Initialized
INFO - 2017-08-22 08:02:22 --> Controller Class Initialized
INFO - 2017-08-22 08:02:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:02:22 --> Final output sent to browser
DEBUG - 2017-08-22 08:02:22 --> Total execution time: 0.2861
INFO - 2017-08-22 08:03:07 --> Config Class Initialized
INFO - 2017-08-22 08:03:07 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:03:07 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:03:07 --> Utf8 Class Initialized
INFO - 2017-08-22 08:03:07 --> URI Class Initialized
DEBUG - 2017-08-22 08:03:07 --> No URI present. Default controller set.
INFO - 2017-08-22 08:03:07 --> Router Class Initialized
INFO - 2017-08-22 08:03:07 --> Output Class Initialized
INFO - 2017-08-22 08:03:07 --> Security Class Initialized
DEBUG - 2017-08-22 08:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:03:07 --> Input Class Initialized
INFO - 2017-08-22 08:03:07 --> Language Class Initialized
INFO - 2017-08-22 08:03:07 --> Loader Class Initialized
INFO - 2017-08-22 08:03:07 --> Helper loaded: url_helper
INFO - 2017-08-22 08:03:07 --> Helper loaded: file_helper
INFO - 2017-08-22 08:03:07 --> Database Driver Class Initialized
INFO - 2017-08-22 08:03:07 --> Email Class Initialized
DEBUG - 2017-08-22 08:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:03:07 --> Table Class Initialized
INFO - 2017-08-22 08:03:07 --> Controller Class Initialized
INFO - 2017-08-22 08:03:07 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:03:07 --> Final output sent to browser
DEBUG - 2017-08-22 08:03:07 --> Total execution time: 0.2940
INFO - 2017-08-22 08:03:14 --> Config Class Initialized
INFO - 2017-08-22 08:03:14 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:03:14 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:03:14 --> Utf8 Class Initialized
INFO - 2017-08-22 08:03:14 --> URI Class Initialized
DEBUG - 2017-08-22 08:03:14 --> No URI present. Default controller set.
INFO - 2017-08-22 08:03:14 --> Router Class Initialized
INFO - 2017-08-22 08:03:14 --> Output Class Initialized
INFO - 2017-08-22 08:03:14 --> Security Class Initialized
DEBUG - 2017-08-22 08:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:03:14 --> Input Class Initialized
INFO - 2017-08-22 08:03:14 --> Language Class Initialized
INFO - 2017-08-22 08:03:14 --> Loader Class Initialized
INFO - 2017-08-22 08:03:14 --> Helper loaded: url_helper
INFO - 2017-08-22 08:03:14 --> Helper loaded: file_helper
INFO - 2017-08-22 08:03:14 --> Database Driver Class Initialized
INFO - 2017-08-22 08:03:14 --> Email Class Initialized
DEBUG - 2017-08-22 08:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:03:14 --> Table Class Initialized
INFO - 2017-08-22 08:03:14 --> Controller Class Initialized
INFO - 2017-08-22 08:03:14 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:03:14 --> Final output sent to browser
DEBUG - 2017-08-22 08:03:14 --> Total execution time: 0.2946
INFO - 2017-08-22 08:04:05 --> Config Class Initialized
INFO - 2017-08-22 08:04:05 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:04:05 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:04:05 --> Utf8 Class Initialized
INFO - 2017-08-22 08:04:05 --> URI Class Initialized
DEBUG - 2017-08-22 08:04:05 --> No URI present. Default controller set.
INFO - 2017-08-22 08:04:06 --> Router Class Initialized
INFO - 2017-08-22 08:04:06 --> Output Class Initialized
INFO - 2017-08-22 08:04:06 --> Security Class Initialized
DEBUG - 2017-08-22 08:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:04:06 --> Input Class Initialized
INFO - 2017-08-22 08:04:06 --> Language Class Initialized
INFO - 2017-08-22 08:04:06 --> Loader Class Initialized
INFO - 2017-08-22 08:04:06 --> Helper loaded: url_helper
INFO - 2017-08-22 08:04:06 --> Helper loaded: file_helper
INFO - 2017-08-22 08:04:06 --> Database Driver Class Initialized
INFO - 2017-08-22 08:04:06 --> Email Class Initialized
DEBUG - 2017-08-22 08:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:04:06 --> Table Class Initialized
INFO - 2017-08-22 08:04:06 --> Controller Class Initialized
INFO - 2017-08-22 08:04:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:04:06 --> Final output sent to browser
DEBUG - 2017-08-22 08:04:06 --> Total execution time: 0.2989
INFO - 2017-08-22 08:04:16 --> Config Class Initialized
INFO - 2017-08-22 08:04:16 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:04:16 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:04:16 --> Utf8 Class Initialized
INFO - 2017-08-22 08:04:16 --> URI Class Initialized
DEBUG - 2017-08-22 08:04:16 --> No URI present. Default controller set.
INFO - 2017-08-22 08:04:16 --> Router Class Initialized
INFO - 2017-08-22 08:04:16 --> Output Class Initialized
INFO - 2017-08-22 08:04:16 --> Security Class Initialized
DEBUG - 2017-08-22 08:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:04:17 --> Input Class Initialized
INFO - 2017-08-22 08:04:17 --> Language Class Initialized
INFO - 2017-08-22 08:04:17 --> Loader Class Initialized
INFO - 2017-08-22 08:04:17 --> Helper loaded: url_helper
INFO - 2017-08-22 08:04:17 --> Helper loaded: file_helper
INFO - 2017-08-22 08:04:17 --> Database Driver Class Initialized
INFO - 2017-08-22 08:04:17 --> Email Class Initialized
DEBUG - 2017-08-22 08:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:04:17 --> Table Class Initialized
INFO - 2017-08-22 08:04:17 --> Controller Class Initialized
INFO - 2017-08-22 08:04:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:04:17 --> Final output sent to browser
DEBUG - 2017-08-22 08:04:17 --> Total execution time: 0.2879
INFO - 2017-08-22 08:04:25 --> Config Class Initialized
INFO - 2017-08-22 08:04:25 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:04:25 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:04:25 --> Utf8 Class Initialized
INFO - 2017-08-22 08:04:25 --> URI Class Initialized
DEBUG - 2017-08-22 08:04:25 --> No URI present. Default controller set.
INFO - 2017-08-22 08:04:25 --> Router Class Initialized
INFO - 2017-08-22 08:04:25 --> Output Class Initialized
INFO - 2017-08-22 08:04:25 --> Security Class Initialized
DEBUG - 2017-08-22 08:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:04:25 --> Input Class Initialized
INFO - 2017-08-22 08:04:25 --> Language Class Initialized
INFO - 2017-08-22 08:04:25 --> Loader Class Initialized
INFO - 2017-08-22 08:04:25 --> Helper loaded: url_helper
INFO - 2017-08-22 08:04:25 --> Helper loaded: file_helper
INFO - 2017-08-22 08:04:25 --> Database Driver Class Initialized
INFO - 2017-08-22 08:04:25 --> Email Class Initialized
DEBUG - 2017-08-22 08:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:04:25 --> Table Class Initialized
INFO - 2017-08-22 08:04:25 --> Controller Class Initialized
INFO - 2017-08-22 08:04:25 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:04:25 --> Final output sent to browser
DEBUG - 2017-08-22 08:04:25 --> Total execution time: 0.2959
INFO - 2017-08-22 08:05:11 --> Config Class Initialized
INFO - 2017-08-22 08:05:11 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:05:11 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:05:11 --> Utf8 Class Initialized
INFO - 2017-08-22 08:05:11 --> URI Class Initialized
DEBUG - 2017-08-22 08:05:11 --> No URI present. Default controller set.
INFO - 2017-08-22 08:05:11 --> Router Class Initialized
INFO - 2017-08-22 08:05:11 --> Output Class Initialized
INFO - 2017-08-22 08:05:11 --> Security Class Initialized
DEBUG - 2017-08-22 08:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:05:11 --> Input Class Initialized
INFO - 2017-08-22 08:05:11 --> Language Class Initialized
INFO - 2017-08-22 08:05:11 --> Loader Class Initialized
INFO - 2017-08-22 08:05:11 --> Helper loaded: url_helper
INFO - 2017-08-22 08:05:11 --> Helper loaded: file_helper
INFO - 2017-08-22 08:05:11 --> Database Driver Class Initialized
INFO - 2017-08-22 08:05:11 --> Email Class Initialized
DEBUG - 2017-08-22 08:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:05:11 --> Table Class Initialized
INFO - 2017-08-22 08:05:11 --> Controller Class Initialized
INFO - 2017-08-22 08:05:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:05:11 --> Final output sent to browser
DEBUG - 2017-08-22 08:05:11 --> Total execution time: 0.2913
INFO - 2017-08-22 08:06:09 --> Config Class Initialized
INFO - 2017-08-22 08:06:09 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:06:09 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:06:09 --> Utf8 Class Initialized
INFO - 2017-08-22 08:06:10 --> URI Class Initialized
DEBUG - 2017-08-22 08:06:10 --> No URI present. Default controller set.
INFO - 2017-08-22 08:06:10 --> Router Class Initialized
INFO - 2017-08-22 08:06:10 --> Output Class Initialized
INFO - 2017-08-22 08:06:10 --> Security Class Initialized
DEBUG - 2017-08-22 08:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:06:10 --> Input Class Initialized
INFO - 2017-08-22 08:06:10 --> Language Class Initialized
INFO - 2017-08-22 08:06:10 --> Loader Class Initialized
INFO - 2017-08-22 08:06:10 --> Helper loaded: url_helper
INFO - 2017-08-22 08:06:10 --> Helper loaded: file_helper
INFO - 2017-08-22 08:06:10 --> Database Driver Class Initialized
INFO - 2017-08-22 08:06:10 --> Email Class Initialized
DEBUG - 2017-08-22 08:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:06:10 --> Table Class Initialized
INFO - 2017-08-22 08:06:10 --> Controller Class Initialized
INFO - 2017-08-22 08:06:10 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:06:10 --> Final output sent to browser
DEBUG - 2017-08-22 08:06:10 --> Total execution time: 0.2966
INFO - 2017-08-22 08:06:23 --> Config Class Initialized
INFO - 2017-08-22 08:06:23 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:06:23 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:06:23 --> Utf8 Class Initialized
INFO - 2017-08-22 08:06:23 --> URI Class Initialized
DEBUG - 2017-08-22 08:06:23 --> No URI present. Default controller set.
INFO - 2017-08-22 08:06:23 --> Router Class Initialized
INFO - 2017-08-22 08:06:23 --> Output Class Initialized
INFO - 2017-08-22 08:06:23 --> Security Class Initialized
DEBUG - 2017-08-22 08:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:06:23 --> Input Class Initialized
INFO - 2017-08-22 08:06:23 --> Language Class Initialized
INFO - 2017-08-22 08:06:23 --> Loader Class Initialized
INFO - 2017-08-22 08:06:23 --> Helper loaded: url_helper
INFO - 2017-08-22 08:06:23 --> Helper loaded: file_helper
INFO - 2017-08-22 08:06:23 --> Database Driver Class Initialized
INFO - 2017-08-22 08:06:23 --> Email Class Initialized
DEBUG - 2017-08-22 08:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:06:23 --> Table Class Initialized
INFO - 2017-08-22 08:06:23 --> Controller Class Initialized
INFO - 2017-08-22 08:06:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:06:24 --> Final output sent to browser
DEBUG - 2017-08-22 08:06:24 --> Total execution time: 0.3030
INFO - 2017-08-22 08:06:27 --> Config Class Initialized
INFO - 2017-08-22 08:06:27 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:06:27 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:06:27 --> Utf8 Class Initialized
INFO - 2017-08-22 08:06:27 --> URI Class Initialized
DEBUG - 2017-08-22 08:06:27 --> No URI present. Default controller set.
INFO - 2017-08-22 08:06:27 --> Router Class Initialized
INFO - 2017-08-22 08:06:27 --> Output Class Initialized
INFO - 2017-08-22 08:06:27 --> Security Class Initialized
DEBUG - 2017-08-22 08:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:06:27 --> Input Class Initialized
INFO - 2017-08-22 08:06:27 --> Language Class Initialized
INFO - 2017-08-22 08:06:27 --> Loader Class Initialized
INFO - 2017-08-22 08:06:27 --> Helper loaded: url_helper
INFO - 2017-08-22 08:06:27 --> Helper loaded: file_helper
INFO - 2017-08-22 08:06:27 --> Database Driver Class Initialized
INFO - 2017-08-22 08:06:27 --> Email Class Initialized
DEBUG - 2017-08-22 08:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:06:27 --> Table Class Initialized
INFO - 2017-08-22 08:06:27 --> Controller Class Initialized
INFO - 2017-08-22 08:06:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:06:27 --> Final output sent to browser
DEBUG - 2017-08-22 08:06:27 --> Total execution time: 0.3008
INFO - 2017-08-22 08:06:32 --> Config Class Initialized
INFO - 2017-08-22 08:06:32 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:06:32 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:06:32 --> Utf8 Class Initialized
INFO - 2017-08-22 08:06:32 --> URI Class Initialized
DEBUG - 2017-08-22 08:06:32 --> No URI present. Default controller set.
INFO - 2017-08-22 08:06:32 --> Router Class Initialized
INFO - 2017-08-22 08:06:32 --> Output Class Initialized
INFO - 2017-08-22 08:06:32 --> Security Class Initialized
DEBUG - 2017-08-22 08:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:06:32 --> Input Class Initialized
INFO - 2017-08-22 08:06:32 --> Language Class Initialized
INFO - 2017-08-22 08:06:32 --> Loader Class Initialized
INFO - 2017-08-22 08:06:32 --> Helper loaded: url_helper
INFO - 2017-08-22 08:06:32 --> Helper loaded: file_helper
INFO - 2017-08-22 08:06:32 --> Database Driver Class Initialized
INFO - 2017-08-22 08:06:32 --> Email Class Initialized
DEBUG - 2017-08-22 08:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:06:32 --> Table Class Initialized
INFO - 2017-08-22 08:06:32 --> Controller Class Initialized
INFO - 2017-08-22 08:06:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:06:32 --> Final output sent to browser
DEBUG - 2017-08-22 08:06:32 --> Total execution time: 0.2976
INFO - 2017-08-22 08:06:40 --> Config Class Initialized
INFO - 2017-08-22 08:06:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:06:40 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:06:40 --> Utf8 Class Initialized
INFO - 2017-08-22 08:06:40 --> URI Class Initialized
DEBUG - 2017-08-22 08:06:40 --> No URI present. Default controller set.
INFO - 2017-08-22 08:06:40 --> Router Class Initialized
INFO - 2017-08-22 08:06:40 --> Output Class Initialized
INFO - 2017-08-22 08:06:40 --> Security Class Initialized
DEBUG - 2017-08-22 08:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:06:40 --> Input Class Initialized
INFO - 2017-08-22 08:06:40 --> Language Class Initialized
INFO - 2017-08-22 08:06:40 --> Loader Class Initialized
INFO - 2017-08-22 08:06:40 --> Helper loaded: url_helper
INFO - 2017-08-22 08:06:40 --> Helper loaded: file_helper
INFO - 2017-08-22 08:06:40 --> Database Driver Class Initialized
INFO - 2017-08-22 08:06:40 --> Email Class Initialized
DEBUG - 2017-08-22 08:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:06:40 --> Table Class Initialized
INFO - 2017-08-22 08:06:40 --> Controller Class Initialized
INFO - 2017-08-22 08:06:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:06:40 --> Final output sent to browser
DEBUG - 2017-08-22 08:06:40 --> Total execution time: 0.3144
INFO - 2017-08-22 08:07:19 --> Config Class Initialized
INFO - 2017-08-22 08:07:19 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:07:19 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:07:19 --> Utf8 Class Initialized
INFO - 2017-08-22 08:07:19 --> URI Class Initialized
DEBUG - 2017-08-22 08:07:19 --> No URI present. Default controller set.
INFO - 2017-08-22 08:07:19 --> Router Class Initialized
INFO - 2017-08-22 08:07:19 --> Output Class Initialized
INFO - 2017-08-22 08:07:19 --> Security Class Initialized
DEBUG - 2017-08-22 08:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:07:19 --> Input Class Initialized
INFO - 2017-08-22 08:07:19 --> Language Class Initialized
INFO - 2017-08-22 08:07:19 --> Loader Class Initialized
INFO - 2017-08-22 08:07:19 --> Helper loaded: url_helper
INFO - 2017-08-22 08:07:19 --> Helper loaded: file_helper
INFO - 2017-08-22 08:07:19 --> Database Driver Class Initialized
INFO - 2017-08-22 08:07:19 --> Email Class Initialized
DEBUG - 2017-08-22 08:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:07:19 --> Table Class Initialized
INFO - 2017-08-22 08:07:19 --> Controller Class Initialized
INFO - 2017-08-22 08:07:19 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:07:19 --> Final output sent to browser
DEBUG - 2017-08-22 08:07:19 --> Total execution time: 0.2886
INFO - 2017-08-22 08:10:17 --> Config Class Initialized
INFO - 2017-08-22 08:10:17 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:10:17 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:10:17 --> Utf8 Class Initialized
INFO - 2017-08-22 08:10:17 --> URI Class Initialized
DEBUG - 2017-08-22 08:10:17 --> No URI present. Default controller set.
INFO - 2017-08-22 08:10:17 --> Router Class Initialized
INFO - 2017-08-22 08:10:17 --> Output Class Initialized
INFO - 2017-08-22 08:10:17 --> Security Class Initialized
DEBUG - 2017-08-22 08:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:10:17 --> Input Class Initialized
INFO - 2017-08-22 08:10:17 --> Language Class Initialized
INFO - 2017-08-22 08:10:17 --> Loader Class Initialized
INFO - 2017-08-22 08:10:17 --> Helper loaded: url_helper
INFO - 2017-08-22 08:10:17 --> Helper loaded: file_helper
INFO - 2017-08-22 08:10:17 --> Database Driver Class Initialized
INFO - 2017-08-22 08:10:17 --> Email Class Initialized
DEBUG - 2017-08-22 08:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:10:17 --> Table Class Initialized
INFO - 2017-08-22 08:10:17 --> Controller Class Initialized
INFO - 2017-08-22 08:10:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:10:17 --> Final output sent to browser
DEBUG - 2017-08-22 08:10:17 --> Total execution time: 0.3029
INFO - 2017-08-22 08:11:34 --> Config Class Initialized
INFO - 2017-08-22 08:11:34 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:11:34 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:11:34 --> Utf8 Class Initialized
INFO - 2017-08-22 08:11:34 --> URI Class Initialized
DEBUG - 2017-08-22 08:11:34 --> No URI present. Default controller set.
INFO - 2017-08-22 08:11:34 --> Router Class Initialized
INFO - 2017-08-22 08:11:34 --> Output Class Initialized
INFO - 2017-08-22 08:11:34 --> Security Class Initialized
DEBUG - 2017-08-22 08:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:11:34 --> Input Class Initialized
INFO - 2017-08-22 08:11:34 --> Language Class Initialized
INFO - 2017-08-22 08:11:34 --> Loader Class Initialized
INFO - 2017-08-22 08:11:34 --> Helper loaded: url_helper
INFO - 2017-08-22 08:11:34 --> Helper loaded: file_helper
INFO - 2017-08-22 08:11:34 --> Database Driver Class Initialized
INFO - 2017-08-22 08:11:34 --> Email Class Initialized
DEBUG - 2017-08-22 08:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:11:34 --> Table Class Initialized
INFO - 2017-08-22 08:11:34 --> Controller Class Initialized
INFO - 2017-08-22 08:11:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:11:34 --> Final output sent to browser
DEBUG - 2017-08-22 08:11:34 --> Total execution time: 0.2984
INFO - 2017-08-22 08:11:43 --> Config Class Initialized
INFO - 2017-08-22 08:11:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:11:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:11:43 --> Utf8 Class Initialized
INFO - 2017-08-22 08:11:43 --> URI Class Initialized
DEBUG - 2017-08-22 08:11:43 --> No URI present. Default controller set.
INFO - 2017-08-22 08:11:43 --> Router Class Initialized
INFO - 2017-08-22 08:11:43 --> Output Class Initialized
INFO - 2017-08-22 08:11:43 --> Security Class Initialized
DEBUG - 2017-08-22 08:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:11:43 --> Input Class Initialized
INFO - 2017-08-22 08:11:43 --> Language Class Initialized
INFO - 2017-08-22 08:11:43 --> Loader Class Initialized
INFO - 2017-08-22 08:11:43 --> Helper loaded: url_helper
INFO - 2017-08-22 08:11:43 --> Helper loaded: file_helper
INFO - 2017-08-22 08:11:43 --> Database Driver Class Initialized
INFO - 2017-08-22 08:11:43 --> Email Class Initialized
DEBUG - 2017-08-22 08:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:11:43 --> Table Class Initialized
INFO - 2017-08-22 08:11:43 --> Controller Class Initialized
INFO - 2017-08-22 08:11:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:11:43 --> Final output sent to browser
DEBUG - 2017-08-22 08:11:43 --> Total execution time: 0.2994
INFO - 2017-08-22 08:13:57 --> Config Class Initialized
INFO - 2017-08-22 08:13:58 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:13:58 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:13:58 --> Utf8 Class Initialized
INFO - 2017-08-22 08:13:58 --> URI Class Initialized
DEBUG - 2017-08-22 08:13:58 --> No URI present. Default controller set.
INFO - 2017-08-22 08:13:58 --> Router Class Initialized
INFO - 2017-08-22 08:13:58 --> Output Class Initialized
INFO - 2017-08-22 08:13:58 --> Security Class Initialized
DEBUG - 2017-08-22 08:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:13:58 --> Input Class Initialized
INFO - 2017-08-22 08:13:58 --> Language Class Initialized
INFO - 2017-08-22 08:13:58 --> Loader Class Initialized
INFO - 2017-08-22 08:13:58 --> Helper loaded: url_helper
INFO - 2017-08-22 08:13:58 --> Helper loaded: file_helper
INFO - 2017-08-22 08:13:58 --> Database Driver Class Initialized
INFO - 2017-08-22 08:13:58 --> Email Class Initialized
DEBUG - 2017-08-22 08:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:13:58 --> Table Class Initialized
INFO - 2017-08-22 08:13:58 --> Controller Class Initialized
INFO - 2017-08-22 08:13:58 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:13:58 --> Final output sent to browser
DEBUG - 2017-08-22 08:13:58 --> Total execution time: 0.2912
INFO - 2017-08-22 08:14:13 --> Config Class Initialized
INFO - 2017-08-22 08:14:13 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:14:13 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:14:13 --> Utf8 Class Initialized
INFO - 2017-08-22 08:14:13 --> URI Class Initialized
DEBUG - 2017-08-22 08:14:13 --> No URI present. Default controller set.
INFO - 2017-08-22 08:14:13 --> Router Class Initialized
INFO - 2017-08-22 08:14:13 --> Output Class Initialized
INFO - 2017-08-22 08:14:13 --> Security Class Initialized
DEBUG - 2017-08-22 08:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:14:13 --> Input Class Initialized
INFO - 2017-08-22 08:14:13 --> Language Class Initialized
INFO - 2017-08-22 08:14:13 --> Loader Class Initialized
INFO - 2017-08-22 08:14:13 --> Helper loaded: url_helper
INFO - 2017-08-22 08:14:13 --> Helper loaded: file_helper
INFO - 2017-08-22 08:14:13 --> Database Driver Class Initialized
INFO - 2017-08-22 08:14:13 --> Email Class Initialized
DEBUG - 2017-08-22 08:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:14:13 --> Table Class Initialized
INFO - 2017-08-22 08:14:13 --> Controller Class Initialized
INFO - 2017-08-22 08:14:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:14:13 --> Final output sent to browser
DEBUG - 2017-08-22 08:14:13 --> Total execution time: 0.2909
INFO - 2017-08-22 08:14:22 --> Config Class Initialized
INFO - 2017-08-22 08:14:22 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:14:22 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:14:22 --> Utf8 Class Initialized
INFO - 2017-08-22 08:14:22 --> URI Class Initialized
DEBUG - 2017-08-22 08:14:22 --> No URI present. Default controller set.
INFO - 2017-08-22 08:14:22 --> Router Class Initialized
INFO - 2017-08-22 08:14:22 --> Output Class Initialized
INFO - 2017-08-22 08:14:22 --> Security Class Initialized
DEBUG - 2017-08-22 08:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:14:22 --> Input Class Initialized
INFO - 2017-08-22 08:14:22 --> Language Class Initialized
INFO - 2017-08-22 08:14:22 --> Loader Class Initialized
INFO - 2017-08-22 08:14:22 --> Helper loaded: url_helper
INFO - 2017-08-22 08:14:22 --> Helper loaded: file_helper
INFO - 2017-08-22 08:14:22 --> Database Driver Class Initialized
INFO - 2017-08-22 08:14:22 --> Email Class Initialized
DEBUG - 2017-08-22 08:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:14:22 --> Table Class Initialized
INFO - 2017-08-22 08:14:22 --> Controller Class Initialized
INFO - 2017-08-22 08:14:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-22 08:14:22 --> Final output sent to browser
DEBUG - 2017-08-22 08:14:22 --> Total execution time: 0.2837
