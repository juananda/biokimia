<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-15 06:28:12 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\biokimia\application\config\config.php 327
ERROR - 2017-08-15 06:28:16 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\biokimia\application\config\config.php 327
ERROR - 2017-08-15 06:28:21 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\biokimia\application\config\config.php 327
ERROR - 2017-08-15 06:28:21 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\biokimia\application\config\config.php 327
ERROR - 2017-08-15 06:28:21 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\biokimia\application\config\config.php 327
ERROR - 2017-08-15 06:28:22 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\biokimia\application\config\config.php 327
ERROR - 2017-08-15 06:28:22 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\biokimia\application\config\config.php 327
INFO - 2017-08-15 06:28:36 --> Config Class Initialized
INFO - 2017-08-15 06:28:36 --> Hooks Class Initialized
DEBUG - 2017-08-15 06:28:36 --> UTF-8 Support Enabled
INFO - 2017-08-15 06:28:36 --> Utf8 Class Initialized
INFO - 2017-08-15 06:28:36 --> URI Class Initialized
DEBUG - 2017-08-15 06:28:36 --> No URI present. Default controller set.
INFO - 2017-08-15 06:28:36 --> Router Class Initialized
INFO - 2017-08-15 06:28:36 --> Output Class Initialized
INFO - 2017-08-15 06:28:36 --> Security Class Initialized
DEBUG - 2017-08-15 06:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 06:28:36 --> Input Class Initialized
INFO - 2017-08-15 06:28:36 --> Language Class Initialized
INFO - 2017-08-15 06:28:36 --> Loader Class Initialized
INFO - 2017-08-15 06:28:36 --> Helper loaded: url_helper
INFO - 2017-08-15 06:28:36 --> Helper loaded: file_helper
INFO - 2017-08-15 06:28:36 --> Database Driver Class Initialized
INFO - 2017-08-15 06:28:36 --> Email Class Initialized
DEBUG - 2017-08-15 06:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 06:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 06:28:36 --> Table Class Initialized
INFO - 2017-08-15 06:28:36 --> Controller Class Initialized
INFO - 2017-08-15 06:28:36 --> Model Class Initialized
INFO - 2017-08-15 06:28:36 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-15 06:28:36 --> Final output sent to browser
DEBUG - 2017-08-15 06:28:36 --> Total execution time: 0.2833
INFO - 2017-08-15 06:28:37 --> Config Class Initialized
INFO - 2017-08-15 06:28:37 --> Hooks Class Initialized
DEBUG - 2017-08-15 06:28:37 --> UTF-8 Support Enabled
INFO - 2017-08-15 06:28:37 --> Utf8 Class Initialized
INFO - 2017-08-15 06:28:37 --> URI Class Initialized
DEBUG - 2017-08-15 06:28:37 --> No URI present. Default controller set.
INFO - 2017-08-15 06:28:37 --> Router Class Initialized
INFO - 2017-08-15 06:28:37 --> Output Class Initialized
INFO - 2017-08-15 06:28:37 --> Security Class Initialized
DEBUG - 2017-08-15 06:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 06:28:37 --> Input Class Initialized
INFO - 2017-08-15 06:28:37 --> Language Class Initialized
INFO - 2017-08-15 06:28:37 --> Loader Class Initialized
INFO - 2017-08-15 06:28:37 --> Helper loaded: url_helper
INFO - 2017-08-15 06:28:37 --> Helper loaded: file_helper
INFO - 2017-08-15 06:28:37 --> Database Driver Class Initialized
INFO - 2017-08-15 06:28:37 --> Email Class Initialized
DEBUG - 2017-08-15 06:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 06:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 06:28:37 --> Table Class Initialized
INFO - 2017-08-15 06:28:37 --> Controller Class Initialized
INFO - 2017-08-15 06:28:37 --> Model Class Initialized
INFO - 2017-08-15 06:28:37 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-15 06:28:37 --> Final output sent to browser
DEBUG - 2017-08-15 06:28:37 --> Total execution time: 0.2086
INFO - 2017-08-15 06:29:59 --> Config Class Initialized
INFO - 2017-08-15 06:29:59 --> Hooks Class Initialized
DEBUG - 2017-08-15 06:29:59 --> UTF-8 Support Enabled
INFO - 2017-08-15 06:29:59 --> Utf8 Class Initialized
INFO - 2017-08-15 06:29:59 --> URI Class Initialized
INFO - 2017-08-15 06:29:59 --> Router Class Initialized
INFO - 2017-08-15 06:29:59 --> Output Class Initialized
INFO - 2017-08-15 06:29:59 --> Security Class Initialized
DEBUG - 2017-08-15 06:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 06:29:59 --> Input Class Initialized
INFO - 2017-08-15 06:29:59 --> Language Class Initialized
INFO - 2017-08-15 06:29:59 --> Loader Class Initialized
INFO - 2017-08-15 06:29:59 --> Helper loaded: url_helper
INFO - 2017-08-15 06:29:59 --> Helper loaded: file_helper
INFO - 2017-08-15 06:29:59 --> Database Driver Class Initialized
INFO - 2017-08-15 06:29:59 --> Email Class Initialized
DEBUG - 2017-08-15 06:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 06:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 06:29:59 --> Table Class Initialized
INFO - 2017-08-15 06:29:59 --> Controller Class Initialized
INFO - 2017-08-15 06:29:59 --> Helper loaded: form_helper
INFO - 2017-08-15 06:29:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\test.php
INFO - 2017-08-15 06:29:59 --> Final output sent to browser
DEBUG - 2017-08-15 06:29:59 --> Total execution time: 0.1796
INFO - 2017-08-15 06:30:03 --> Config Class Initialized
INFO - 2017-08-15 06:30:03 --> Hooks Class Initialized
DEBUG - 2017-08-15 06:30:03 --> UTF-8 Support Enabled
INFO - 2017-08-15 06:30:03 --> Utf8 Class Initialized
INFO - 2017-08-15 06:30:03 --> URI Class Initialized
INFO - 2017-08-15 06:30:03 --> Router Class Initialized
INFO - 2017-08-15 06:30:03 --> Output Class Initialized
INFO - 2017-08-15 06:30:03 --> Security Class Initialized
DEBUG - 2017-08-15 06:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 06:30:03 --> Input Class Initialized
INFO - 2017-08-15 06:30:03 --> Language Class Initialized
INFO - 2017-08-15 06:30:03 --> Loader Class Initialized
INFO - 2017-08-15 06:30:03 --> Helper loaded: url_helper
INFO - 2017-08-15 06:30:03 --> Helper loaded: file_helper
INFO - 2017-08-15 06:30:03 --> Database Driver Class Initialized
INFO - 2017-08-15 06:30:03 --> Email Class Initialized
DEBUG - 2017-08-15 06:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 06:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 06:30:03 --> Table Class Initialized
INFO - 2017-08-15 06:30:03 --> Controller Class Initialized
INFO - 2017-08-15 06:30:03 --> Model Class Initialized
INFO - 2017-08-15 06:30:03 --> Config Class Initialized
INFO - 2017-08-15 06:30:03 --> Hooks Class Initialized
DEBUG - 2017-08-15 06:30:03 --> UTF-8 Support Enabled
INFO - 2017-08-15 06:30:03 --> Utf8 Class Initialized
INFO - 2017-08-15 06:30:03 --> URI Class Initialized
DEBUG - 2017-08-15 06:30:03 --> No URI present. Default controller set.
INFO - 2017-08-15 06:30:03 --> Router Class Initialized
INFO - 2017-08-15 06:30:03 --> Output Class Initialized
INFO - 2017-08-15 06:30:03 --> Security Class Initialized
DEBUG - 2017-08-15 06:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 06:30:03 --> Input Class Initialized
INFO - 2017-08-15 06:30:03 --> Language Class Initialized
INFO - 2017-08-15 06:30:03 --> Loader Class Initialized
INFO - 2017-08-15 06:30:03 --> Helper loaded: url_helper
INFO - 2017-08-15 06:30:03 --> Helper loaded: file_helper
INFO - 2017-08-15 06:30:03 --> Database Driver Class Initialized
INFO - 2017-08-15 06:30:03 --> Email Class Initialized
DEBUG - 2017-08-15 06:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 06:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 06:30:03 --> Table Class Initialized
INFO - 2017-08-15 06:30:03 --> Controller Class Initialized
INFO - 2017-08-15 06:30:03 --> Model Class Initialized
INFO - 2017-08-15 06:30:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-15 06:30:03 --> Final output sent to browser
DEBUG - 2017-08-15 06:30:03 --> Total execution time: 0.1969
INFO - 2017-08-15 06:30:14 --> Config Class Initialized
INFO - 2017-08-15 06:30:14 --> Hooks Class Initialized
DEBUG - 2017-08-15 06:30:14 --> UTF-8 Support Enabled
INFO - 2017-08-15 06:30:14 --> Utf8 Class Initialized
INFO - 2017-08-15 06:30:14 --> URI Class Initialized
INFO - 2017-08-15 06:30:14 --> Router Class Initialized
INFO - 2017-08-15 06:30:14 --> Output Class Initialized
INFO - 2017-08-15 06:30:14 --> Security Class Initialized
DEBUG - 2017-08-15 06:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 06:30:14 --> Input Class Initialized
INFO - 2017-08-15 06:30:14 --> Language Class Initialized
INFO - 2017-08-15 06:30:14 --> Loader Class Initialized
INFO - 2017-08-15 06:30:14 --> Helper loaded: url_helper
INFO - 2017-08-15 06:30:14 --> Helper loaded: file_helper
INFO - 2017-08-15 06:30:14 --> Database Driver Class Initialized
INFO - 2017-08-15 06:30:14 --> Email Class Initialized
DEBUG - 2017-08-15 06:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 06:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 06:30:14 --> Table Class Initialized
INFO - 2017-08-15 06:30:14 --> Controller Class Initialized
INFO - 2017-08-15 06:30:14 --> Model Class Initialized
INFO - 2017-08-15 06:30:14 --> Helper loaded: form_helper
INFO - 2017-08-15 06:30:14 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_edit.php
INFO - 2017-08-15 06:30:14 --> Final output sent to browser
DEBUG - 2017-08-15 06:30:14 --> Total execution time: 0.1811
INFO - 2017-08-15 06:30:16 --> Config Class Initialized
INFO - 2017-08-15 06:30:16 --> Hooks Class Initialized
DEBUG - 2017-08-15 06:30:16 --> UTF-8 Support Enabled
INFO - 2017-08-15 06:30:16 --> Utf8 Class Initialized
INFO - 2017-08-15 06:30:16 --> URI Class Initialized
INFO - 2017-08-15 06:30:16 --> Router Class Initialized
INFO - 2017-08-15 06:30:16 --> Output Class Initialized
INFO - 2017-08-15 06:30:16 --> Security Class Initialized
DEBUG - 2017-08-15 06:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 06:30:16 --> Input Class Initialized
INFO - 2017-08-15 06:30:16 --> Language Class Initialized
INFO - 2017-08-15 06:30:16 --> Loader Class Initialized
INFO - 2017-08-15 06:30:16 --> Helper loaded: url_helper
INFO - 2017-08-15 06:30:16 --> Helper loaded: file_helper
INFO - 2017-08-15 06:30:16 --> Database Driver Class Initialized
INFO - 2017-08-15 06:30:16 --> Email Class Initialized
DEBUG - 2017-08-15 06:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 06:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 06:30:16 --> Table Class Initialized
INFO - 2017-08-15 06:30:16 --> Controller Class Initialized
INFO - 2017-08-15 06:30:16 --> Model Class Initialized
INFO - 2017-08-15 06:30:16 --> Config Class Initialized
INFO - 2017-08-15 06:30:16 --> Hooks Class Initialized
DEBUG - 2017-08-15 06:30:16 --> UTF-8 Support Enabled
INFO - 2017-08-15 06:30:16 --> Utf8 Class Initialized
INFO - 2017-08-15 06:30:16 --> URI Class Initialized
DEBUG - 2017-08-15 06:30:17 --> No URI present. Default controller set.
INFO - 2017-08-15 06:30:17 --> Router Class Initialized
INFO - 2017-08-15 06:30:17 --> Output Class Initialized
INFO - 2017-08-15 06:30:17 --> Security Class Initialized
DEBUG - 2017-08-15 06:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 06:30:17 --> Input Class Initialized
INFO - 2017-08-15 06:30:17 --> Language Class Initialized
INFO - 2017-08-15 06:30:17 --> Loader Class Initialized
INFO - 2017-08-15 06:30:17 --> Helper loaded: url_helper
INFO - 2017-08-15 06:30:17 --> Helper loaded: file_helper
INFO - 2017-08-15 06:30:17 --> Database Driver Class Initialized
INFO - 2017-08-15 06:30:17 --> Email Class Initialized
DEBUG - 2017-08-15 06:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 06:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 06:30:17 --> Table Class Initialized
INFO - 2017-08-15 06:30:17 --> Controller Class Initialized
INFO - 2017-08-15 06:30:17 --> Model Class Initialized
INFO - 2017-08-15 06:30:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-15 06:30:17 --> Final output sent to browser
DEBUG - 2017-08-15 06:30:17 --> Total execution time: 0.1923
INFO - 2017-08-15 06:30:20 --> Config Class Initialized
INFO - 2017-08-15 06:30:20 --> Hooks Class Initialized
DEBUG - 2017-08-15 06:30:20 --> UTF-8 Support Enabled
INFO - 2017-08-15 06:30:20 --> Utf8 Class Initialized
INFO - 2017-08-15 06:30:20 --> URI Class Initialized
INFO - 2017-08-15 06:30:20 --> Router Class Initialized
INFO - 2017-08-15 06:30:20 --> Output Class Initialized
INFO - 2017-08-15 06:30:20 --> Security Class Initialized
DEBUG - 2017-08-15 06:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 06:30:20 --> Input Class Initialized
INFO - 2017-08-15 06:30:20 --> Language Class Initialized
INFO - 2017-08-15 06:30:20 --> Loader Class Initialized
INFO - 2017-08-15 06:30:20 --> Helper loaded: url_helper
INFO - 2017-08-15 06:30:20 --> Helper loaded: file_helper
INFO - 2017-08-15 06:30:20 --> Database Driver Class Initialized
INFO - 2017-08-15 06:30:20 --> Email Class Initialized
DEBUG - 2017-08-15 06:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 06:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 06:30:20 --> Table Class Initialized
INFO - 2017-08-15 06:30:20 --> Controller Class Initialized
INFO - 2017-08-15 06:30:20 --> Model Class Initialized
INFO - 2017-08-15 06:30:20 --> Config Class Initialized
INFO - 2017-08-15 06:30:20 --> Hooks Class Initialized
DEBUG - 2017-08-15 06:30:20 --> UTF-8 Support Enabled
INFO - 2017-08-15 06:30:20 --> Utf8 Class Initialized
INFO - 2017-08-15 06:30:20 --> URI Class Initialized
DEBUG - 2017-08-15 06:30:20 --> No URI present. Default controller set.
INFO - 2017-08-15 06:30:20 --> Router Class Initialized
INFO - 2017-08-15 06:30:20 --> Output Class Initialized
INFO - 2017-08-15 06:30:20 --> Security Class Initialized
DEBUG - 2017-08-15 06:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 06:30:20 --> Input Class Initialized
INFO - 2017-08-15 06:30:20 --> Language Class Initialized
INFO - 2017-08-15 06:30:20 --> Loader Class Initialized
INFO - 2017-08-15 06:30:20 --> Helper loaded: url_helper
INFO - 2017-08-15 06:30:20 --> Helper loaded: file_helper
INFO - 2017-08-15 06:30:20 --> Database Driver Class Initialized
INFO - 2017-08-15 06:30:20 --> Email Class Initialized
DEBUG - 2017-08-15 06:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 06:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 06:30:20 --> Table Class Initialized
INFO - 2017-08-15 06:30:20 --> Controller Class Initialized
INFO - 2017-08-15 06:30:20 --> Model Class Initialized
INFO - 2017-08-15 06:30:20 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-15 06:30:20 --> Final output sent to browser
DEBUG - 2017-08-15 06:30:20 --> Total execution time: 0.2557
INFO - 2017-08-15 08:07:22 --> Config Class Initialized
INFO - 2017-08-15 08:07:22 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:07:22 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:07:22 --> Utf8 Class Initialized
INFO - 2017-08-15 08:07:22 --> URI Class Initialized
DEBUG - 2017-08-15 08:07:22 --> No URI present. Default controller set.
INFO - 2017-08-15 08:07:22 --> Router Class Initialized
INFO - 2017-08-15 08:07:22 --> Output Class Initialized
INFO - 2017-08-15 08:07:22 --> Security Class Initialized
DEBUG - 2017-08-15 08:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:07:22 --> Input Class Initialized
INFO - 2017-08-15 08:07:22 --> Language Class Initialized
INFO - 2017-08-15 08:07:22 --> Loader Class Initialized
INFO - 2017-08-15 08:07:22 --> Helper loaded: url_helper
INFO - 2017-08-15 08:07:22 --> Helper loaded: file_helper
INFO - 2017-08-15 08:07:22 --> Database Driver Class Initialized
INFO - 2017-08-15 08:07:22 --> Email Class Initialized
DEBUG - 2017-08-15 08:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:07:22 --> Table Class Initialized
INFO - 2017-08-15 08:07:22 --> Controller Class Initialized
INFO - 2017-08-15 08:07:22 --> Model Class Initialized
INFO - 2017-08-15 08:07:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-15 08:07:22 --> Final output sent to browser
DEBUG - 2017-08-15 08:07:22 --> Total execution time: 0.1828
INFO - 2017-08-15 08:07:25 --> Config Class Initialized
INFO - 2017-08-15 08:07:25 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:07:25 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:07:25 --> Utf8 Class Initialized
INFO - 2017-08-15 08:07:25 --> URI Class Initialized
INFO - 2017-08-15 08:07:25 --> Router Class Initialized
INFO - 2017-08-15 08:07:25 --> Output Class Initialized
INFO - 2017-08-15 08:07:25 --> Security Class Initialized
DEBUG - 2017-08-15 08:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:07:25 --> Input Class Initialized
INFO - 2017-08-15 08:07:25 --> Language Class Initialized
INFO - 2017-08-15 08:07:25 --> Loader Class Initialized
INFO - 2017-08-15 08:07:25 --> Helper loaded: url_helper
INFO - 2017-08-15 08:07:25 --> Helper loaded: file_helper
INFO - 2017-08-15 08:07:25 --> Database Driver Class Initialized
INFO - 2017-08-15 08:07:25 --> Email Class Initialized
DEBUG - 2017-08-15 08:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:07:25 --> Table Class Initialized
INFO - 2017-08-15 08:07:25 --> Controller Class Initialized
INFO - 2017-08-15 08:07:25 --> Helper loaded: form_helper
INFO - 2017-08-15 08:07:25 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:07:25 --> Final output sent to browser
DEBUG - 2017-08-15 08:07:25 --> Total execution time: 0.1878
INFO - 2017-08-15 08:07:36 --> Config Class Initialized
INFO - 2017-08-15 08:07:36 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:07:36 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:07:36 --> Utf8 Class Initialized
INFO - 2017-08-15 08:07:36 --> URI Class Initialized
INFO - 2017-08-15 08:07:36 --> Router Class Initialized
INFO - 2017-08-15 08:07:36 --> Output Class Initialized
INFO - 2017-08-15 08:07:36 --> Security Class Initialized
DEBUG - 2017-08-15 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:07:36 --> Input Class Initialized
INFO - 2017-08-15 08:07:36 --> Language Class Initialized
INFO - 2017-08-15 08:07:36 --> Loader Class Initialized
INFO - 2017-08-15 08:07:36 --> Helper loaded: url_helper
INFO - 2017-08-15 08:07:36 --> Helper loaded: file_helper
INFO - 2017-08-15 08:07:36 --> Database Driver Class Initialized
INFO - 2017-08-15 08:07:36 --> Email Class Initialized
DEBUG - 2017-08-15 08:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:07:36 --> Table Class Initialized
INFO - 2017-08-15 08:07:36 --> Controller Class Initialized
INFO - 2017-08-15 08:07:36 --> Helper loaded: form_helper
INFO - 2017-08-15 08:07:36 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:07:36 --> Final output sent to browser
DEBUG - 2017-08-15 08:07:36 --> Total execution time: 0.1814
INFO - 2017-08-15 08:08:22 --> Config Class Initialized
INFO - 2017-08-15 08:08:22 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:08:22 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:08:22 --> Utf8 Class Initialized
INFO - 2017-08-15 08:08:22 --> URI Class Initialized
INFO - 2017-08-15 08:08:22 --> Router Class Initialized
INFO - 2017-08-15 08:08:22 --> Output Class Initialized
INFO - 2017-08-15 08:08:22 --> Security Class Initialized
DEBUG - 2017-08-15 08:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:08:22 --> Input Class Initialized
INFO - 2017-08-15 08:08:22 --> Language Class Initialized
INFO - 2017-08-15 08:08:22 --> Loader Class Initialized
INFO - 2017-08-15 08:08:22 --> Helper loaded: url_helper
INFO - 2017-08-15 08:08:22 --> Helper loaded: file_helper
INFO - 2017-08-15 08:08:22 --> Database Driver Class Initialized
INFO - 2017-08-15 08:08:22 --> Email Class Initialized
DEBUG - 2017-08-15 08:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:08:22 --> Table Class Initialized
INFO - 2017-08-15 08:08:22 --> Controller Class Initialized
INFO - 2017-08-15 08:08:22 --> Config Class Initialized
INFO - 2017-08-15 08:08:22 --> Helper loaded: form_helper
INFO - 2017-08-15 08:08:22 --> Hooks Class Initialized
INFO - 2017-08-15 08:08:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
DEBUG - 2017-08-15 08:08:22 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:08:22 --> Final output sent to browser
INFO - 2017-08-15 08:08:23 --> Utf8 Class Initialized
DEBUG - 2017-08-15 08:08:23 --> Total execution time: 0.2000
INFO - 2017-08-15 08:08:23 --> URI Class Initialized
INFO - 2017-08-15 08:08:23 --> Router Class Initialized
INFO - 2017-08-15 08:08:23 --> Output Class Initialized
INFO - 2017-08-15 08:08:23 --> Security Class Initialized
DEBUG - 2017-08-15 08:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:08:23 --> Input Class Initialized
INFO - 2017-08-15 08:08:23 --> Language Class Initialized
INFO - 2017-08-15 08:08:23 --> Loader Class Initialized
INFO - 2017-08-15 08:08:23 --> Helper loaded: url_helper
INFO - 2017-08-15 08:08:23 --> Helper loaded: file_helper
INFO - 2017-08-15 08:08:23 --> Database Driver Class Initialized
INFO - 2017-08-15 08:08:23 --> Email Class Initialized
DEBUG - 2017-08-15 08:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:08:23 --> Table Class Initialized
INFO - 2017-08-15 08:08:23 --> Controller Class Initialized
INFO - 2017-08-15 08:08:23 --> Helper loaded: form_helper
INFO - 2017-08-15 08:08:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:08:23 --> Final output sent to browser
DEBUG - 2017-08-15 08:08:23 --> Total execution time: 0.1898
INFO - 2017-08-15 08:08:26 --> Config Class Initialized
INFO - 2017-08-15 08:08:26 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:08:26 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:08:26 --> Utf8 Class Initialized
INFO - 2017-08-15 08:08:26 --> URI Class Initialized
INFO - 2017-08-15 08:08:26 --> Router Class Initialized
INFO - 2017-08-15 08:08:26 --> Output Class Initialized
INFO - 2017-08-15 08:08:26 --> Security Class Initialized
DEBUG - 2017-08-15 08:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:08:26 --> Input Class Initialized
INFO - 2017-08-15 08:08:26 --> Language Class Initialized
INFO - 2017-08-15 08:08:26 --> Loader Class Initialized
INFO - 2017-08-15 08:08:26 --> Helper loaded: url_helper
INFO - 2017-08-15 08:08:26 --> Helper loaded: file_helper
INFO - 2017-08-15 08:08:26 --> Database Driver Class Initialized
INFO - 2017-08-15 08:08:26 --> Email Class Initialized
DEBUG - 2017-08-15 08:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:08:26 --> Table Class Initialized
INFO - 2017-08-15 08:08:26 --> Controller Class Initialized
INFO - 2017-08-15 08:08:26 --> Helper loaded: form_helper
INFO - 2017-08-15 08:08:26 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:08:26 --> Final output sent to browser
DEBUG - 2017-08-15 08:08:26 --> Total execution time: 0.1725
INFO - 2017-08-15 08:09:01 --> Config Class Initialized
INFO - 2017-08-15 08:09:01 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:09:01 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:09:01 --> Utf8 Class Initialized
INFO - 2017-08-15 08:09:01 --> URI Class Initialized
INFO - 2017-08-15 08:09:01 --> Router Class Initialized
INFO - 2017-08-15 08:09:01 --> Output Class Initialized
INFO - 2017-08-15 08:09:01 --> Security Class Initialized
DEBUG - 2017-08-15 08:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:09:01 --> Input Class Initialized
INFO - 2017-08-15 08:09:01 --> Language Class Initialized
INFO - 2017-08-15 08:09:01 --> Loader Class Initialized
INFO - 2017-08-15 08:09:01 --> Helper loaded: url_helper
INFO - 2017-08-15 08:09:01 --> Helper loaded: file_helper
INFO - 2017-08-15 08:09:01 --> Database Driver Class Initialized
INFO - 2017-08-15 08:09:01 --> Email Class Initialized
DEBUG - 2017-08-15 08:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:09:01 --> Table Class Initialized
INFO - 2017-08-15 08:09:01 --> Controller Class Initialized
INFO - 2017-08-15 08:09:01 --> Helper loaded: form_helper
INFO - 2017-08-15 08:09:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:09:01 --> Final output sent to browser
DEBUG - 2017-08-15 08:09:01 --> Total execution time: 0.1795
INFO - 2017-08-15 08:09:38 --> Config Class Initialized
INFO - 2017-08-15 08:09:38 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:09:38 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:09:38 --> Utf8 Class Initialized
INFO - 2017-08-15 08:09:38 --> URI Class Initialized
INFO - 2017-08-15 08:09:38 --> Router Class Initialized
INFO - 2017-08-15 08:09:38 --> Output Class Initialized
INFO - 2017-08-15 08:09:38 --> Security Class Initialized
DEBUG - 2017-08-15 08:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:09:38 --> Input Class Initialized
INFO - 2017-08-15 08:09:38 --> Language Class Initialized
INFO - 2017-08-15 08:09:38 --> Loader Class Initialized
INFO - 2017-08-15 08:09:38 --> Helper loaded: url_helper
INFO - 2017-08-15 08:09:38 --> Helper loaded: file_helper
INFO - 2017-08-15 08:09:38 --> Database Driver Class Initialized
INFO - 2017-08-15 08:09:38 --> Email Class Initialized
DEBUG - 2017-08-15 08:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:09:38 --> Table Class Initialized
INFO - 2017-08-15 08:09:38 --> Controller Class Initialized
INFO - 2017-08-15 08:09:38 --> Helper loaded: form_helper
INFO - 2017-08-15 08:09:38 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:09:38 --> Final output sent to browser
DEBUG - 2017-08-15 08:09:38 --> Total execution time: 0.1874
INFO - 2017-08-15 08:09:39 --> Config Class Initialized
INFO - 2017-08-15 08:09:39 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:09:39 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:09:39 --> Utf8 Class Initialized
INFO - 2017-08-15 08:09:39 --> URI Class Initialized
INFO - 2017-08-15 08:09:39 --> Router Class Initialized
INFO - 2017-08-15 08:09:39 --> Output Class Initialized
INFO - 2017-08-15 08:09:39 --> Security Class Initialized
DEBUG - 2017-08-15 08:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:09:39 --> Input Class Initialized
INFO - 2017-08-15 08:09:39 --> Language Class Initialized
INFO - 2017-08-15 08:09:39 --> Loader Class Initialized
INFO - 2017-08-15 08:09:39 --> Helper loaded: url_helper
INFO - 2017-08-15 08:09:39 --> Helper loaded: file_helper
INFO - 2017-08-15 08:09:39 --> Database Driver Class Initialized
INFO - 2017-08-15 08:09:39 --> Email Class Initialized
DEBUG - 2017-08-15 08:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:09:39 --> Table Class Initialized
INFO - 2017-08-15 08:09:39 --> Controller Class Initialized
INFO - 2017-08-15 08:09:39 --> Helper loaded: form_helper
INFO - 2017-08-15 08:09:39 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:09:39 --> Final output sent to browser
DEBUG - 2017-08-15 08:09:39 --> Total execution time: 0.1901
INFO - 2017-08-15 08:09:42 --> Config Class Initialized
INFO - 2017-08-15 08:09:42 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:09:42 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:09:42 --> Utf8 Class Initialized
INFO - 2017-08-15 08:09:42 --> URI Class Initialized
INFO - 2017-08-15 08:09:42 --> Router Class Initialized
INFO - 2017-08-15 08:09:42 --> Output Class Initialized
INFO - 2017-08-15 08:09:42 --> Security Class Initialized
DEBUG - 2017-08-15 08:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:09:42 --> Input Class Initialized
INFO - 2017-08-15 08:09:42 --> Language Class Initialized
INFO - 2017-08-15 08:09:42 --> Loader Class Initialized
INFO - 2017-08-15 08:09:42 --> Helper loaded: url_helper
INFO - 2017-08-15 08:09:42 --> Helper loaded: file_helper
INFO - 2017-08-15 08:09:42 --> Database Driver Class Initialized
INFO - 2017-08-15 08:09:42 --> Email Class Initialized
DEBUG - 2017-08-15 08:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:09:42 --> Table Class Initialized
INFO - 2017-08-15 08:09:42 --> Controller Class Initialized
INFO - 2017-08-15 08:09:42 --> Helper loaded: form_helper
INFO - 2017-08-15 08:09:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:09:42 --> Final output sent to browser
DEBUG - 2017-08-15 08:09:42 --> Total execution time: 0.1896
INFO - 2017-08-15 08:09:55 --> Config Class Initialized
INFO - 2017-08-15 08:09:55 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:09:55 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:09:55 --> Utf8 Class Initialized
INFO - 2017-08-15 08:09:55 --> URI Class Initialized
INFO - 2017-08-15 08:09:55 --> Router Class Initialized
INFO - 2017-08-15 08:09:55 --> Output Class Initialized
INFO - 2017-08-15 08:09:55 --> Security Class Initialized
DEBUG - 2017-08-15 08:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:09:55 --> Input Class Initialized
INFO - 2017-08-15 08:09:55 --> Language Class Initialized
INFO - 2017-08-15 08:09:55 --> Loader Class Initialized
INFO - 2017-08-15 08:09:55 --> Helper loaded: url_helper
INFO - 2017-08-15 08:09:56 --> Helper loaded: file_helper
INFO - 2017-08-15 08:09:56 --> Database Driver Class Initialized
INFO - 2017-08-15 08:09:56 --> Email Class Initialized
DEBUG - 2017-08-15 08:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:09:56 --> Table Class Initialized
INFO - 2017-08-15 08:09:56 --> Controller Class Initialized
INFO - 2017-08-15 08:09:56 --> Helper loaded: form_helper
INFO - 2017-08-15 08:09:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:09:56 --> Final output sent to browser
DEBUG - 2017-08-15 08:09:56 --> Total execution time: 0.1815
INFO - 2017-08-15 08:09:56 --> Config Class Initialized
INFO - 2017-08-15 08:09:56 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:09:56 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:09:56 --> Utf8 Class Initialized
INFO - 2017-08-15 08:09:56 --> URI Class Initialized
INFO - 2017-08-15 08:09:56 --> Router Class Initialized
INFO - 2017-08-15 08:09:56 --> Output Class Initialized
INFO - 2017-08-15 08:09:56 --> Security Class Initialized
DEBUG - 2017-08-15 08:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:09:56 --> Input Class Initialized
INFO - 2017-08-15 08:09:56 --> Language Class Initialized
INFO - 2017-08-15 08:09:56 --> Loader Class Initialized
INFO - 2017-08-15 08:09:56 --> Helper loaded: url_helper
INFO - 2017-08-15 08:09:56 --> Helper loaded: file_helper
INFO - 2017-08-15 08:09:56 --> Database Driver Class Initialized
INFO - 2017-08-15 08:09:56 --> Email Class Initialized
DEBUG - 2017-08-15 08:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:09:56 --> Table Class Initialized
INFO - 2017-08-15 08:09:56 --> Controller Class Initialized
INFO - 2017-08-15 08:09:56 --> Helper loaded: form_helper
INFO - 2017-08-15 08:09:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:09:56 --> Final output sent to browser
DEBUG - 2017-08-15 08:09:56 --> Total execution time: 0.1901
INFO - 2017-08-15 08:10:00 --> Config Class Initialized
INFO - 2017-08-15 08:10:00 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:10:00 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:10:00 --> Utf8 Class Initialized
INFO - 2017-08-15 08:10:00 --> URI Class Initialized
INFO - 2017-08-15 08:10:00 --> Router Class Initialized
INFO - 2017-08-15 08:10:00 --> Output Class Initialized
INFO - 2017-08-15 08:10:00 --> Security Class Initialized
DEBUG - 2017-08-15 08:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:10:00 --> Input Class Initialized
INFO - 2017-08-15 08:10:00 --> Language Class Initialized
INFO - 2017-08-15 08:10:00 --> Loader Class Initialized
INFO - 2017-08-15 08:10:00 --> Helper loaded: url_helper
INFO - 2017-08-15 08:10:00 --> Helper loaded: file_helper
INFO - 2017-08-15 08:10:00 --> Database Driver Class Initialized
INFO - 2017-08-15 08:10:00 --> Email Class Initialized
DEBUG - 2017-08-15 08:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:10:00 --> Table Class Initialized
INFO - 2017-08-15 08:10:00 --> Controller Class Initialized
INFO - 2017-08-15 08:10:00 --> Helper loaded: form_helper
INFO - 2017-08-15 08:10:00 --> Upload Class Initialized
INFO - 2017-08-15 08:10:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-08-15 08:10:00 --> The upload path does not appear to be valid.
ERROR - 2017-08-15 08:10:00 --> Severity: Error --> Call to undefined method CI_Upload::display_error() C:\xampp\htdocs\biokimia\application\controllers\Upload.php 27
INFO - 2017-08-15 08:11:47 --> Config Class Initialized
INFO - 2017-08-15 08:11:47 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:11:47 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:11:47 --> Utf8 Class Initialized
INFO - 2017-08-15 08:11:47 --> URI Class Initialized
INFO - 2017-08-15 08:11:47 --> Router Class Initialized
INFO - 2017-08-15 08:11:47 --> Output Class Initialized
INFO - 2017-08-15 08:11:47 --> Security Class Initialized
DEBUG - 2017-08-15 08:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:11:47 --> Input Class Initialized
INFO - 2017-08-15 08:11:47 --> Language Class Initialized
INFO - 2017-08-15 08:11:47 --> Loader Class Initialized
INFO - 2017-08-15 08:11:47 --> Helper loaded: url_helper
INFO - 2017-08-15 08:11:47 --> Helper loaded: file_helper
INFO - 2017-08-15 08:11:47 --> Database Driver Class Initialized
INFO - 2017-08-15 08:11:47 --> Email Class Initialized
DEBUG - 2017-08-15 08:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:11:47 --> Table Class Initialized
INFO - 2017-08-15 08:11:47 --> Controller Class Initialized
INFO - 2017-08-15 08:11:47 --> Helper loaded: form_helper
INFO - 2017-08-15 08:11:47 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:11:47 --> Final output sent to browser
DEBUG - 2017-08-15 08:11:47 --> Total execution time: 0.2323
INFO - 2017-08-15 08:11:52 --> Config Class Initialized
INFO - 2017-08-15 08:11:52 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:11:52 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:11:52 --> Utf8 Class Initialized
INFO - 2017-08-15 08:11:52 --> URI Class Initialized
INFO - 2017-08-15 08:11:52 --> Router Class Initialized
INFO - 2017-08-15 08:11:52 --> Output Class Initialized
INFO - 2017-08-15 08:11:52 --> Security Class Initialized
DEBUG - 2017-08-15 08:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:11:52 --> Input Class Initialized
INFO - 2017-08-15 08:11:52 --> Language Class Initialized
INFO - 2017-08-15 08:11:52 --> Loader Class Initialized
INFO - 2017-08-15 08:11:52 --> Helper loaded: url_helper
INFO - 2017-08-15 08:11:52 --> Helper loaded: file_helper
INFO - 2017-08-15 08:11:52 --> Database Driver Class Initialized
INFO - 2017-08-15 08:11:52 --> Email Class Initialized
DEBUG - 2017-08-15 08:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:11:52 --> Table Class Initialized
INFO - 2017-08-15 08:11:52 --> Controller Class Initialized
INFO - 2017-08-15 08:11:52 --> Helper loaded: form_helper
INFO - 2017-08-15 08:11:52 --> Upload Class Initialized
INFO - 2017-08-15 08:11:52 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-08-15 08:11:52 --> The upload path does not appear to be valid.
ERROR - 2017-08-15 08:11:52 --> Severity: Error --> Call to undefined method CI_Upload::display_error() C:\xampp\htdocs\biokimia\application\controllers\Upload.php 27
INFO - 2017-08-15 08:11:56 --> Config Class Initialized
INFO - 2017-08-15 08:11:56 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:11:56 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:11:56 --> Utf8 Class Initialized
INFO - 2017-08-15 08:11:56 --> URI Class Initialized
INFO - 2017-08-15 08:11:56 --> Router Class Initialized
INFO - 2017-08-15 08:11:56 --> Output Class Initialized
INFO - 2017-08-15 08:11:56 --> Security Class Initialized
DEBUG - 2017-08-15 08:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:11:56 --> Input Class Initialized
INFO - 2017-08-15 08:11:56 --> Language Class Initialized
INFO - 2017-08-15 08:11:56 --> Loader Class Initialized
INFO - 2017-08-15 08:11:56 --> Helper loaded: url_helper
INFO - 2017-08-15 08:11:56 --> Helper loaded: file_helper
INFO - 2017-08-15 08:11:56 --> Database Driver Class Initialized
INFO - 2017-08-15 08:11:56 --> Email Class Initialized
DEBUG - 2017-08-15 08:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:11:56 --> Table Class Initialized
INFO - 2017-08-15 08:11:56 --> Controller Class Initialized
INFO - 2017-08-15 08:11:56 --> Helper loaded: form_helper
INFO - 2017-08-15 08:11:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:11:56 --> Final output sent to browser
DEBUG - 2017-08-15 08:11:56 --> Total execution time: 0.1869
INFO - 2017-08-15 08:12:03 --> Config Class Initialized
INFO - 2017-08-15 08:12:03 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:12:03 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:12:03 --> Utf8 Class Initialized
INFO - 2017-08-15 08:12:03 --> URI Class Initialized
INFO - 2017-08-15 08:12:03 --> Router Class Initialized
INFO - 2017-08-15 08:12:03 --> Output Class Initialized
INFO - 2017-08-15 08:12:03 --> Security Class Initialized
DEBUG - 2017-08-15 08:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:12:03 --> Input Class Initialized
INFO - 2017-08-15 08:12:03 --> Language Class Initialized
INFO - 2017-08-15 08:12:03 --> Loader Class Initialized
INFO - 2017-08-15 08:12:03 --> Helper loaded: url_helper
INFO - 2017-08-15 08:12:03 --> Helper loaded: file_helper
INFO - 2017-08-15 08:12:03 --> Database Driver Class Initialized
INFO - 2017-08-15 08:12:03 --> Email Class Initialized
DEBUG - 2017-08-15 08:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:12:03 --> Table Class Initialized
INFO - 2017-08-15 08:12:03 --> Controller Class Initialized
INFO - 2017-08-15 08:12:03 --> Helper loaded: form_helper
INFO - 2017-08-15 08:12:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:12:03 --> Final output sent to browser
DEBUG - 2017-08-15 08:12:03 --> Total execution time: 0.1844
INFO - 2017-08-15 08:12:07 --> Config Class Initialized
INFO - 2017-08-15 08:12:07 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:12:07 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:12:07 --> Utf8 Class Initialized
INFO - 2017-08-15 08:12:07 --> URI Class Initialized
INFO - 2017-08-15 08:12:07 --> Router Class Initialized
INFO - 2017-08-15 08:12:07 --> Output Class Initialized
INFO - 2017-08-15 08:12:07 --> Security Class Initialized
DEBUG - 2017-08-15 08:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:12:07 --> Input Class Initialized
INFO - 2017-08-15 08:12:07 --> Language Class Initialized
INFO - 2017-08-15 08:12:07 --> Loader Class Initialized
INFO - 2017-08-15 08:12:07 --> Helper loaded: url_helper
INFO - 2017-08-15 08:12:07 --> Helper loaded: file_helper
INFO - 2017-08-15 08:12:07 --> Database Driver Class Initialized
INFO - 2017-08-15 08:12:07 --> Email Class Initialized
DEBUG - 2017-08-15 08:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:12:07 --> Table Class Initialized
INFO - 2017-08-15 08:12:07 --> Controller Class Initialized
INFO - 2017-08-15 08:12:07 --> Helper loaded: form_helper
INFO - 2017-08-15 08:12:07 --> Upload Class Initialized
INFO - 2017-08-15 08:12:07 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-08-15 08:12:07 --> The upload path does not appear to be valid.
ERROR - 2017-08-15 08:12:07 --> Severity: Error --> Call to undefined method CI_Upload::display_error() C:\xampp\htdocs\biokimia\application\controllers\Upload.php 27
INFO - 2017-08-15 08:13:10 --> Config Class Initialized
INFO - 2017-08-15 08:13:10 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:13:10 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:13:10 --> Utf8 Class Initialized
INFO - 2017-08-15 08:13:10 --> URI Class Initialized
INFO - 2017-08-15 08:13:10 --> Router Class Initialized
INFO - 2017-08-15 08:13:10 --> Output Class Initialized
INFO - 2017-08-15 08:13:10 --> Security Class Initialized
DEBUG - 2017-08-15 08:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:13:10 --> Input Class Initialized
INFO - 2017-08-15 08:13:10 --> Language Class Initialized
INFO - 2017-08-15 08:13:10 --> Loader Class Initialized
INFO - 2017-08-15 08:13:10 --> Helper loaded: url_helper
INFO - 2017-08-15 08:13:10 --> Helper loaded: file_helper
INFO - 2017-08-15 08:13:10 --> Database Driver Class Initialized
INFO - 2017-08-15 08:13:10 --> Email Class Initialized
DEBUG - 2017-08-15 08:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:13:10 --> Table Class Initialized
INFO - 2017-08-15 08:13:10 --> Controller Class Initialized
INFO - 2017-08-15 08:13:10 --> Helper loaded: form_helper
INFO - 2017-08-15 08:13:10 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:13:10 --> Final output sent to browser
DEBUG - 2017-08-15 08:13:10 --> Total execution time: 0.1913
INFO - 2017-08-15 08:13:11 --> Config Class Initialized
INFO - 2017-08-15 08:13:11 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:13:11 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:13:11 --> Utf8 Class Initialized
INFO - 2017-08-15 08:13:11 --> URI Class Initialized
INFO - 2017-08-15 08:13:11 --> Router Class Initialized
INFO - 2017-08-15 08:13:11 --> Output Class Initialized
INFO - 2017-08-15 08:13:11 --> Security Class Initialized
DEBUG - 2017-08-15 08:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:13:11 --> Input Class Initialized
INFO - 2017-08-15 08:13:11 --> Language Class Initialized
INFO - 2017-08-15 08:13:11 --> Loader Class Initialized
INFO - 2017-08-15 08:13:11 --> Helper loaded: url_helper
INFO - 2017-08-15 08:13:11 --> Helper loaded: file_helper
INFO - 2017-08-15 08:13:11 --> Database Driver Class Initialized
INFO - 2017-08-15 08:13:11 --> Email Class Initialized
DEBUG - 2017-08-15 08:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:13:11 --> Table Class Initialized
INFO - 2017-08-15 08:13:11 --> Controller Class Initialized
INFO - 2017-08-15 08:13:11 --> Helper loaded: form_helper
INFO - 2017-08-15 08:13:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:13:11 --> Final output sent to browser
DEBUG - 2017-08-15 08:13:11 --> Total execution time: 0.1807
INFO - 2017-08-15 08:13:14 --> Config Class Initialized
INFO - 2017-08-15 08:13:14 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:13:14 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:13:14 --> Utf8 Class Initialized
INFO - 2017-08-15 08:13:14 --> URI Class Initialized
INFO - 2017-08-15 08:13:14 --> Router Class Initialized
INFO - 2017-08-15 08:13:14 --> Output Class Initialized
INFO - 2017-08-15 08:13:14 --> Security Class Initialized
DEBUG - 2017-08-15 08:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:13:14 --> Input Class Initialized
INFO - 2017-08-15 08:13:14 --> Language Class Initialized
INFO - 2017-08-15 08:13:14 --> Loader Class Initialized
INFO - 2017-08-15 08:13:14 --> Helper loaded: url_helper
INFO - 2017-08-15 08:13:14 --> Helper loaded: file_helper
INFO - 2017-08-15 08:13:14 --> Database Driver Class Initialized
INFO - 2017-08-15 08:13:14 --> Email Class Initialized
DEBUG - 2017-08-15 08:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:13:14 --> Table Class Initialized
INFO - 2017-08-15 08:13:14 --> Controller Class Initialized
INFO - 2017-08-15 08:13:14 --> Helper loaded: form_helper
INFO - 2017-08-15 08:13:14 --> Upload Class Initialized
INFO - 2017-08-15 08:13:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-08-15 08:13:14 --> The upload path does not appear to be valid.
INFO - 2017-08-15 08:13:14 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:13:14 --> Final output sent to browser
DEBUG - 2017-08-15 08:13:14 --> Total execution time: 0.2913
INFO - 2017-08-15 08:13:32 --> Config Class Initialized
INFO - 2017-08-15 08:13:32 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:13:32 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:13:32 --> Utf8 Class Initialized
INFO - 2017-08-15 08:13:32 --> URI Class Initialized
INFO - 2017-08-15 08:13:32 --> Router Class Initialized
INFO - 2017-08-15 08:13:32 --> Output Class Initialized
INFO - 2017-08-15 08:13:32 --> Security Class Initialized
DEBUG - 2017-08-15 08:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:13:32 --> Input Class Initialized
INFO - 2017-08-15 08:13:32 --> Language Class Initialized
INFO - 2017-08-15 08:13:32 --> Loader Class Initialized
INFO - 2017-08-15 08:13:32 --> Helper loaded: url_helper
INFO - 2017-08-15 08:13:32 --> Helper loaded: file_helper
INFO - 2017-08-15 08:13:32 --> Database Driver Class Initialized
INFO - 2017-08-15 08:13:32 --> Email Class Initialized
DEBUG - 2017-08-15 08:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:13:32 --> Table Class Initialized
INFO - 2017-08-15 08:13:32 --> Controller Class Initialized
INFO - 2017-08-15 08:13:32 --> Helper loaded: form_helper
INFO - 2017-08-15 08:13:32 --> Upload Class Initialized
INFO - 2017-08-15 08:13:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_success.php
INFO - 2017-08-15 08:13:32 --> Final output sent to browser
DEBUG - 2017-08-15 08:13:32 --> Total execution time: 0.2115
INFO - 2017-08-15 08:21:03 --> Config Class Initialized
INFO - 2017-08-15 08:21:03 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:21:03 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:21:03 --> Utf8 Class Initialized
INFO - 2017-08-15 08:21:03 --> URI Class Initialized
INFO - 2017-08-15 08:21:03 --> Router Class Initialized
INFO - 2017-08-15 08:21:03 --> Output Class Initialized
INFO - 2017-08-15 08:21:03 --> Security Class Initialized
DEBUG - 2017-08-15 08:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:21:03 --> Input Class Initialized
INFO - 2017-08-15 08:21:03 --> Language Class Initialized
INFO - 2017-08-15 08:21:03 --> Loader Class Initialized
INFO - 2017-08-15 08:21:03 --> Helper loaded: url_helper
INFO - 2017-08-15 08:21:03 --> Helper loaded: file_helper
INFO - 2017-08-15 08:21:03 --> Database Driver Class Initialized
INFO - 2017-08-15 08:21:03 --> Email Class Initialized
DEBUG - 2017-08-15 08:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:21:03 --> Table Class Initialized
INFO - 2017-08-15 08:21:03 --> Controller Class Initialized
INFO - 2017-08-15 08:21:03 --> Helper loaded: form_helper
INFO - 2017-08-15 08:21:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:21:03 --> Final output sent to browser
DEBUG - 2017-08-15 08:21:03 --> Total execution time: 0.1875
INFO - 2017-08-15 08:21:03 --> Config Class Initialized
INFO - 2017-08-15 08:21:03 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:21:03 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:21:03 --> Utf8 Class Initialized
INFO - 2017-08-15 08:21:03 --> URI Class Initialized
INFO - 2017-08-15 08:21:03 --> Router Class Initialized
INFO - 2017-08-15 08:21:03 --> Output Class Initialized
INFO - 2017-08-15 08:21:03 --> Security Class Initialized
DEBUG - 2017-08-15 08:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:21:03 --> Input Class Initialized
INFO - 2017-08-15 08:21:03 --> Language Class Initialized
INFO - 2017-08-15 08:21:03 --> Loader Class Initialized
INFO - 2017-08-15 08:21:03 --> Helper loaded: url_helper
INFO - 2017-08-15 08:21:03 --> Helper loaded: file_helper
INFO - 2017-08-15 08:21:03 --> Database Driver Class Initialized
INFO - 2017-08-15 08:21:03 --> Email Class Initialized
DEBUG - 2017-08-15 08:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:21:03 --> Table Class Initialized
INFO - 2017-08-15 08:21:03 --> Controller Class Initialized
INFO - 2017-08-15 08:21:03 --> Helper loaded: form_helper
INFO - 2017-08-15 08:21:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:21:03 --> Final output sent to browser
DEBUG - 2017-08-15 08:21:03 --> Total execution time: 0.1817
INFO - 2017-08-15 08:27:00 --> Config Class Initialized
INFO - 2017-08-15 08:27:00 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:27:00 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:27:00 --> Utf8 Class Initialized
INFO - 2017-08-15 08:27:00 --> URI Class Initialized
INFO - 2017-08-15 08:27:00 --> Router Class Initialized
INFO - 2017-08-15 08:27:00 --> Output Class Initialized
INFO - 2017-08-15 08:27:00 --> Security Class Initialized
DEBUG - 2017-08-15 08:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:27:00 --> Input Class Initialized
INFO - 2017-08-15 08:27:00 --> Language Class Initialized
INFO - 2017-08-15 08:27:00 --> Loader Class Initialized
INFO - 2017-08-15 08:27:01 --> Helper loaded: url_helper
INFO - 2017-08-15 08:27:01 --> Helper loaded: file_helper
INFO - 2017-08-15 08:27:01 --> Database Driver Class Initialized
INFO - 2017-08-15 08:27:01 --> Email Class Initialized
DEBUG - 2017-08-15 08:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:27:01 --> Table Class Initialized
INFO - 2017-08-15 08:27:01 --> Controller Class Initialized
INFO - 2017-08-15 08:27:01 --> Helper loaded: form_helper
INFO - 2017-08-15 08:27:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 08:27:01 --> Final output sent to browser
DEBUG - 2017-08-15 08:27:01 --> Total execution time: 0.2044
INFO - 2017-08-15 08:27:04 --> Config Class Initialized
INFO - 2017-08-15 08:27:04 --> Hooks Class Initialized
DEBUG - 2017-08-15 08:27:04 --> UTF-8 Support Enabled
INFO - 2017-08-15 08:27:04 --> Utf8 Class Initialized
INFO - 2017-08-15 08:27:04 --> URI Class Initialized
INFO - 2017-08-15 08:27:04 --> Router Class Initialized
INFO - 2017-08-15 08:27:04 --> Output Class Initialized
INFO - 2017-08-15 08:27:04 --> Security Class Initialized
DEBUG - 2017-08-15 08:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 08:27:04 --> Input Class Initialized
INFO - 2017-08-15 08:27:04 --> Language Class Initialized
INFO - 2017-08-15 08:27:04 --> Loader Class Initialized
INFO - 2017-08-15 08:27:04 --> Helper loaded: url_helper
INFO - 2017-08-15 08:27:04 --> Helper loaded: file_helper
INFO - 2017-08-15 08:27:04 --> Database Driver Class Initialized
INFO - 2017-08-15 08:27:04 --> Email Class Initialized
DEBUG - 2017-08-15 08:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 08:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 08:27:04 --> Table Class Initialized
INFO - 2017-08-15 08:27:04 --> Controller Class Initialized
INFO - 2017-08-15 08:27:04 --> Helper loaded: form_helper
INFO - 2017-08-15 08:27:04 --> Upload Class Initialized
INFO - 2017-08-15 08:27:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_success.php
INFO - 2017-08-15 08:27:04 --> Final output sent to browser
DEBUG - 2017-08-15 08:27:04 --> Total execution time: 0.2084
INFO - 2017-08-15 09:58:27 --> Config Class Initialized
INFO - 2017-08-15 09:58:27 --> Hooks Class Initialized
DEBUG - 2017-08-15 09:58:27 --> UTF-8 Support Enabled
INFO - 2017-08-15 09:58:27 --> Utf8 Class Initialized
INFO - 2017-08-15 09:58:27 --> URI Class Initialized
INFO - 2017-08-15 09:58:27 --> Router Class Initialized
INFO - 2017-08-15 09:58:27 --> Output Class Initialized
INFO - 2017-08-15 09:58:27 --> Security Class Initialized
DEBUG - 2017-08-15 09:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 09:58:27 --> Input Class Initialized
INFO - 2017-08-15 09:58:27 --> Language Class Initialized
INFO - 2017-08-15 09:58:27 --> Loader Class Initialized
INFO - 2017-08-15 09:58:27 --> Helper loaded: url_helper
INFO - 2017-08-15 09:58:27 --> Helper loaded: file_helper
INFO - 2017-08-15 09:58:28 --> Database Driver Class Initialized
INFO - 2017-08-15 09:58:28 --> Email Class Initialized
DEBUG - 2017-08-15 09:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 09:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 09:58:28 --> Table Class Initialized
INFO - 2017-08-15 09:58:28 --> Controller Class Initialized
INFO - 2017-08-15 09:58:28 --> Helper loaded: form_helper
INFO - 2017-08-15 09:58:28 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-15 09:58:28 --> Final output sent to browser
DEBUG - 2017-08-15 09:58:28 --> Total execution time: 1.0381
INFO - 2017-08-15 16:37:47 --> Config Class Initialized
INFO - 2017-08-15 16:37:47 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:37:47 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:37:48 --> Utf8 Class Initialized
INFO - 2017-08-15 16:37:48 --> URI Class Initialized
DEBUG - 2017-08-15 16:37:48 --> No URI present. Default controller set.
INFO - 2017-08-15 16:37:48 --> Router Class Initialized
INFO - 2017-08-15 16:37:48 --> Output Class Initialized
INFO - 2017-08-15 16:37:48 --> Security Class Initialized
DEBUG - 2017-08-15 16:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:37:48 --> Input Class Initialized
INFO - 2017-08-15 16:37:48 --> Language Class Initialized
INFO - 2017-08-15 16:37:48 --> Loader Class Initialized
INFO - 2017-08-15 16:37:48 --> Helper loaded: url_helper
INFO - 2017-08-15 16:37:48 --> Helper loaded: file_helper
INFO - 2017-08-15 16:37:48 --> Database Driver Class Initialized
INFO - 2017-08-15 16:37:48 --> Email Class Initialized
DEBUG - 2017-08-15 16:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:37:48 --> Table Class Initialized
INFO - 2017-08-15 16:37:48 --> Controller Class Initialized
INFO - 2017-08-15 16:37:48 --> Model Class Initialized
INFO - 2017-08-15 16:37:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-15 16:37:48 --> Final output sent to browser
DEBUG - 2017-08-15 16:37:48 --> Total execution time: 1.1315
INFO - 2017-08-15 16:40:33 --> Config Class Initialized
INFO - 2017-08-15 16:40:34 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:40:34 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:40:34 --> Utf8 Class Initialized
INFO - 2017-08-15 16:40:34 --> URI Class Initialized
INFO - 2017-08-15 16:40:34 --> Router Class Initialized
INFO - 2017-08-15 16:40:34 --> Output Class Initialized
INFO - 2017-08-15 16:40:34 --> Security Class Initialized
DEBUG - 2017-08-15 16:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:40:34 --> Input Class Initialized
INFO - 2017-08-15 16:40:34 --> Language Class Initialized
INFO - 2017-08-15 16:40:34 --> Loader Class Initialized
INFO - 2017-08-15 16:40:34 --> Helper loaded: url_helper
INFO - 2017-08-15 16:40:34 --> Helper loaded: file_helper
INFO - 2017-08-15 16:40:34 --> Database Driver Class Initialized
INFO - 2017-08-15 16:40:34 --> Email Class Initialized
DEBUG - 2017-08-15 16:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:40:34 --> Table Class Initialized
INFO - 2017-08-15 16:40:34 --> Controller Class Initialized
DEBUG - 2017-08-15 16:40:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:40:34 --> Helper loaded: form_helper
INFO - 2017-08-15 16:40:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:40:34 --> Final output sent to browser
DEBUG - 2017-08-15 16:40:34 --> Total execution time: 0.2256
INFO - 2017-08-15 16:41:41 --> Config Class Initialized
INFO - 2017-08-15 16:41:41 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:41:41 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:41:42 --> Utf8 Class Initialized
INFO - 2017-08-15 16:41:42 --> URI Class Initialized
INFO - 2017-08-15 16:41:42 --> Router Class Initialized
INFO - 2017-08-15 16:41:42 --> Output Class Initialized
INFO - 2017-08-15 16:41:42 --> Security Class Initialized
DEBUG - 2017-08-15 16:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:41:42 --> Input Class Initialized
INFO - 2017-08-15 16:41:42 --> Language Class Initialized
INFO - 2017-08-15 16:41:42 --> Loader Class Initialized
INFO - 2017-08-15 16:41:42 --> Helper loaded: url_helper
INFO - 2017-08-15 16:41:42 --> Helper loaded: file_helper
INFO - 2017-08-15 16:41:42 --> Database Driver Class Initialized
INFO - 2017-08-15 16:41:42 --> Email Class Initialized
DEBUG - 2017-08-15 16:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:41:42 --> Table Class Initialized
INFO - 2017-08-15 16:41:42 --> Controller Class Initialized
DEBUG - 2017-08-15 16:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:41:42 --> Helper loaded: form_helper
INFO - 2017-08-15 16:41:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:41:42 --> Final output sent to browser
DEBUG - 2017-08-15 16:41:42 --> Total execution time: 0.1916
INFO - 2017-08-15 16:41:44 --> Config Class Initialized
INFO - 2017-08-15 16:41:44 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:41:44 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:41:44 --> Utf8 Class Initialized
INFO - 2017-08-15 16:41:44 --> URI Class Initialized
INFO - 2017-08-15 16:41:44 --> Router Class Initialized
INFO - 2017-08-15 16:41:44 --> Output Class Initialized
INFO - 2017-08-15 16:41:44 --> Security Class Initialized
DEBUG - 2017-08-15 16:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:41:44 --> Input Class Initialized
INFO - 2017-08-15 16:41:44 --> Language Class Initialized
INFO - 2017-08-15 16:41:44 --> Loader Class Initialized
INFO - 2017-08-15 16:41:44 --> Helper loaded: url_helper
INFO - 2017-08-15 16:41:44 --> Helper loaded: file_helper
INFO - 2017-08-15 16:41:44 --> Database Driver Class Initialized
INFO - 2017-08-15 16:41:44 --> Email Class Initialized
DEBUG - 2017-08-15 16:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:41:44 --> Table Class Initialized
INFO - 2017-08-15 16:41:44 --> Controller Class Initialized
DEBUG - 2017-08-15 16:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:41:44 --> Helper loaded: form_helper
INFO - 2017-08-15 16:41:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:41:44 --> Final output sent to browser
DEBUG - 2017-08-15 16:41:44 --> Total execution time: 0.2021
INFO - 2017-08-15 16:48:25 --> Config Class Initialized
INFO - 2017-08-15 16:48:25 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:48:25 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:48:25 --> Utf8 Class Initialized
INFO - 2017-08-15 16:48:25 --> URI Class Initialized
INFO - 2017-08-15 16:48:25 --> Router Class Initialized
INFO - 2017-08-15 16:48:25 --> Output Class Initialized
INFO - 2017-08-15 16:48:25 --> Security Class Initialized
DEBUG - 2017-08-15 16:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:48:25 --> Input Class Initialized
INFO - 2017-08-15 16:48:25 --> Language Class Initialized
INFO - 2017-08-15 16:48:25 --> Loader Class Initialized
INFO - 2017-08-15 16:48:25 --> Helper loaded: url_helper
INFO - 2017-08-15 16:48:25 --> Helper loaded: file_helper
INFO - 2017-08-15 16:48:25 --> Database Driver Class Initialized
INFO - 2017-08-15 16:48:25 --> Email Class Initialized
DEBUG - 2017-08-15 16:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:48:25 --> Table Class Initialized
INFO - 2017-08-15 16:48:25 --> Controller Class Initialized
DEBUG - 2017-08-15 16:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:48:26 --> Helper loaded: form_helper
INFO - 2017-08-15 16:48:26 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:48:26 --> Final output sent to browser
DEBUG - 2017-08-15 16:48:26 --> Total execution time: 0.2320
INFO - 2017-08-15 16:48:33 --> Config Class Initialized
INFO - 2017-08-15 16:48:33 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:48:33 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:48:33 --> Utf8 Class Initialized
INFO - 2017-08-15 16:48:33 --> URI Class Initialized
INFO - 2017-08-15 16:48:33 --> Router Class Initialized
INFO - 2017-08-15 16:48:33 --> Output Class Initialized
INFO - 2017-08-15 16:48:33 --> Security Class Initialized
DEBUG - 2017-08-15 16:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:48:33 --> Input Class Initialized
INFO - 2017-08-15 16:48:33 --> Language Class Initialized
INFO - 2017-08-15 16:48:33 --> Loader Class Initialized
INFO - 2017-08-15 16:48:33 --> Helper loaded: url_helper
INFO - 2017-08-15 16:48:33 --> Helper loaded: file_helper
INFO - 2017-08-15 16:48:33 --> Database Driver Class Initialized
INFO - 2017-08-15 16:48:33 --> Email Class Initialized
DEBUG - 2017-08-15 16:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:48:33 --> Table Class Initialized
INFO - 2017-08-15 16:48:33 --> Controller Class Initialized
DEBUG - 2017-08-15 16:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:48:33 --> Helper loaded: form_helper
DEBUG - 2017-08-15 16:48:33 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:48:34 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-15 16:48:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:48:34 --> Final output sent to browser
DEBUG - 2017-08-15 16:48:34 --> Total execution time: 1.0557
INFO - 2017-08-15 16:48:56 --> Config Class Initialized
INFO - 2017-08-15 16:48:56 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:48:56 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:48:56 --> Utf8 Class Initialized
INFO - 2017-08-15 16:48:56 --> URI Class Initialized
INFO - 2017-08-15 16:48:56 --> Router Class Initialized
INFO - 2017-08-15 16:48:56 --> Output Class Initialized
INFO - 2017-08-15 16:48:57 --> Security Class Initialized
DEBUG - 2017-08-15 16:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:48:57 --> Input Class Initialized
INFO - 2017-08-15 16:48:57 --> Language Class Initialized
INFO - 2017-08-15 16:48:57 --> Loader Class Initialized
INFO - 2017-08-15 16:48:57 --> Helper loaded: url_helper
INFO - 2017-08-15 16:48:57 --> Helper loaded: file_helper
INFO - 2017-08-15 16:48:57 --> Database Driver Class Initialized
INFO - 2017-08-15 16:48:57 --> Email Class Initialized
DEBUG - 2017-08-15 16:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:48:57 --> Table Class Initialized
INFO - 2017-08-15 16:48:57 --> Controller Class Initialized
DEBUG - 2017-08-15 16:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:48:57 --> Helper loaded: form_helper
DEBUG - 2017-08-15 16:48:57 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:48:57 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-15 16:48:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:48:57 --> Final output sent to browser
DEBUG - 2017-08-15 16:48:57 --> Total execution time: 0.6655
INFO - 2017-08-15 16:49:49 --> Config Class Initialized
INFO - 2017-08-15 16:49:49 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:49:49 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:49:49 --> Utf8 Class Initialized
INFO - 2017-08-15 16:49:49 --> URI Class Initialized
INFO - 2017-08-15 16:49:49 --> Router Class Initialized
INFO - 2017-08-15 16:49:49 --> Output Class Initialized
INFO - 2017-08-15 16:49:49 --> Security Class Initialized
DEBUG - 2017-08-15 16:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:49:49 --> Input Class Initialized
INFO - 2017-08-15 16:49:49 --> Language Class Initialized
INFO - 2017-08-15 16:49:49 --> Loader Class Initialized
INFO - 2017-08-15 16:49:49 --> Helper loaded: url_helper
INFO - 2017-08-15 16:49:49 --> Helper loaded: file_helper
INFO - 2017-08-15 16:49:49 --> Database Driver Class Initialized
INFO - 2017-08-15 16:49:50 --> Email Class Initialized
DEBUG - 2017-08-15 16:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:49:50 --> Table Class Initialized
INFO - 2017-08-15 16:49:50 --> Controller Class Initialized
DEBUG - 2017-08-15 16:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:49:50 --> Helper loaded: form_helper
DEBUG - 2017-08-15 16:49:50 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:49:50 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-15 16:49:50 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:49:50 --> Final output sent to browser
DEBUG - 2017-08-15 16:49:50 --> Total execution time: 0.3196
INFO - 2017-08-15 16:49:56 --> Config Class Initialized
INFO - 2017-08-15 16:49:56 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:49:56 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:49:56 --> Utf8 Class Initialized
INFO - 2017-08-15 16:49:56 --> URI Class Initialized
INFO - 2017-08-15 16:49:56 --> Router Class Initialized
INFO - 2017-08-15 16:49:56 --> Output Class Initialized
INFO - 2017-08-15 16:49:56 --> Security Class Initialized
DEBUG - 2017-08-15 16:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:49:56 --> Input Class Initialized
INFO - 2017-08-15 16:49:56 --> Language Class Initialized
INFO - 2017-08-15 16:49:56 --> Loader Class Initialized
INFO - 2017-08-15 16:49:56 --> Helper loaded: url_helper
INFO - 2017-08-15 16:49:56 --> Helper loaded: file_helper
INFO - 2017-08-15 16:49:56 --> Database Driver Class Initialized
INFO - 2017-08-15 16:49:56 --> Email Class Initialized
DEBUG - 2017-08-15 16:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:49:57 --> Table Class Initialized
INFO - 2017-08-15 16:49:57 --> Controller Class Initialized
DEBUG - 2017-08-15 16:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:49:57 --> Helper loaded: form_helper
DEBUG - 2017-08-15 16:49:57 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:49:57 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-15 16:49:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:49:57 --> Final output sent to browser
DEBUG - 2017-08-15 16:49:57 --> Total execution time: 0.2896
INFO - 2017-08-15 16:50:52 --> Config Class Initialized
INFO - 2017-08-15 16:50:52 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:50:52 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:50:52 --> Utf8 Class Initialized
INFO - 2017-08-15 16:50:52 --> URI Class Initialized
INFO - 2017-08-15 16:50:52 --> Router Class Initialized
INFO - 2017-08-15 16:50:52 --> Output Class Initialized
INFO - 2017-08-15 16:50:52 --> Security Class Initialized
DEBUG - 2017-08-15 16:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:50:52 --> Input Class Initialized
INFO - 2017-08-15 16:50:52 --> Language Class Initialized
ERROR - 2017-08-15 16:50:52 --> 404 Page Not Found: Email_controller/email
INFO - 2017-08-15 16:51:10 --> Config Class Initialized
INFO - 2017-08-15 16:51:10 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:51:10 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:51:10 --> Utf8 Class Initialized
INFO - 2017-08-15 16:51:10 --> URI Class Initialized
INFO - 2017-08-15 16:51:10 --> Router Class Initialized
INFO - 2017-08-15 16:51:10 --> Output Class Initialized
INFO - 2017-08-15 16:51:10 --> Security Class Initialized
DEBUG - 2017-08-15 16:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:51:10 --> Input Class Initialized
INFO - 2017-08-15 16:51:10 --> Language Class Initialized
INFO - 2017-08-15 16:51:10 --> Loader Class Initialized
INFO - 2017-08-15 16:51:10 --> Helper loaded: url_helper
INFO - 2017-08-15 16:51:10 --> Helper loaded: file_helper
INFO - 2017-08-15 16:51:10 --> Database Driver Class Initialized
INFO - 2017-08-15 16:51:10 --> Email Class Initialized
DEBUG - 2017-08-15 16:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:51:10 --> Table Class Initialized
INFO - 2017-08-15 16:51:10 --> Controller Class Initialized
DEBUG - 2017-08-15 16:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:51:10 --> Helper loaded: form_helper
INFO - 2017-08-15 16:51:10 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:51:10 --> Final output sent to browser
DEBUG - 2017-08-15 16:51:10 --> Total execution time: 0.2174
INFO - 2017-08-15 16:51:16 --> Config Class Initialized
INFO - 2017-08-15 16:51:16 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:51:16 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:51:16 --> Utf8 Class Initialized
INFO - 2017-08-15 16:51:16 --> URI Class Initialized
INFO - 2017-08-15 16:51:16 --> Router Class Initialized
INFO - 2017-08-15 16:51:16 --> Output Class Initialized
INFO - 2017-08-15 16:51:16 --> Security Class Initialized
DEBUG - 2017-08-15 16:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:51:16 --> Input Class Initialized
INFO - 2017-08-15 16:51:16 --> Language Class Initialized
INFO - 2017-08-15 16:51:16 --> Loader Class Initialized
INFO - 2017-08-15 16:51:16 --> Helper loaded: url_helper
INFO - 2017-08-15 16:51:16 --> Helper loaded: file_helper
INFO - 2017-08-15 16:51:16 --> Database Driver Class Initialized
INFO - 2017-08-15 16:51:16 --> Email Class Initialized
DEBUG - 2017-08-15 16:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:51:16 --> Table Class Initialized
INFO - 2017-08-15 16:51:16 --> Controller Class Initialized
DEBUG - 2017-08-15 16:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:51:16 --> Helper loaded: form_helper
DEBUG - 2017-08-15 16:51:16 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:51:16 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-15 16:51:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:51:16 --> Final output sent to browser
DEBUG - 2017-08-15 16:51:16 --> Total execution time: 0.2887
INFO - 2017-08-15 16:52:39 --> Config Class Initialized
INFO - 2017-08-15 16:52:39 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:52:39 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:52:39 --> Utf8 Class Initialized
INFO - 2017-08-15 16:52:39 --> URI Class Initialized
INFO - 2017-08-15 16:52:39 --> Router Class Initialized
INFO - 2017-08-15 16:52:39 --> Output Class Initialized
INFO - 2017-08-15 16:52:39 --> Security Class Initialized
DEBUG - 2017-08-15 16:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:52:39 --> Input Class Initialized
INFO - 2017-08-15 16:52:39 --> Language Class Initialized
INFO - 2017-08-15 16:52:39 --> Loader Class Initialized
INFO - 2017-08-15 16:52:39 --> Helper loaded: url_helper
INFO - 2017-08-15 16:52:39 --> Helper loaded: file_helper
INFO - 2017-08-15 16:52:39 --> Database Driver Class Initialized
INFO - 2017-08-15 16:52:39 --> Email Class Initialized
DEBUG - 2017-08-15 16:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:52:39 --> Table Class Initialized
INFO - 2017-08-15 16:52:39 --> Controller Class Initialized
DEBUG - 2017-08-15 16:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:52:39 --> Helper loaded: form_helper
INFO - 2017-08-15 16:52:39 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:52:39 --> Final output sent to browser
DEBUG - 2017-08-15 16:52:39 --> Total execution time: 0.2074
INFO - 2017-08-15 16:52:44 --> Config Class Initialized
INFO - 2017-08-15 16:52:44 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:52:44 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:52:44 --> Utf8 Class Initialized
INFO - 2017-08-15 16:52:44 --> URI Class Initialized
INFO - 2017-08-15 16:52:45 --> Router Class Initialized
INFO - 2017-08-15 16:52:45 --> Output Class Initialized
INFO - 2017-08-15 16:52:45 --> Security Class Initialized
DEBUG - 2017-08-15 16:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:52:45 --> Input Class Initialized
INFO - 2017-08-15 16:52:45 --> Language Class Initialized
INFO - 2017-08-15 16:52:45 --> Loader Class Initialized
INFO - 2017-08-15 16:52:45 --> Helper loaded: url_helper
INFO - 2017-08-15 16:52:45 --> Helper loaded: file_helper
INFO - 2017-08-15 16:52:45 --> Database Driver Class Initialized
INFO - 2017-08-15 16:52:45 --> Email Class Initialized
DEBUG - 2017-08-15 16:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:52:45 --> Table Class Initialized
INFO - 2017-08-15 16:52:45 --> Controller Class Initialized
DEBUG - 2017-08-15 16:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:52:45 --> Helper loaded: form_helper
INFO - 2017-08-15 16:52:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:52:45 --> Final output sent to browser
DEBUG - 2017-08-15 16:52:45 --> Total execution time: 0.2182
INFO - 2017-08-15 16:52:49 --> Config Class Initialized
INFO - 2017-08-15 16:52:49 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:52:49 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:52:49 --> Utf8 Class Initialized
INFO - 2017-08-15 16:52:49 --> URI Class Initialized
INFO - 2017-08-15 16:52:49 --> Router Class Initialized
INFO - 2017-08-15 16:52:49 --> Output Class Initialized
INFO - 2017-08-15 16:52:49 --> Security Class Initialized
DEBUG - 2017-08-15 16:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:52:49 --> Input Class Initialized
INFO - 2017-08-15 16:52:49 --> Language Class Initialized
INFO - 2017-08-15 16:52:49 --> Loader Class Initialized
INFO - 2017-08-15 16:52:49 --> Helper loaded: url_helper
INFO - 2017-08-15 16:52:49 --> Helper loaded: file_helper
INFO - 2017-08-15 16:52:49 --> Database Driver Class Initialized
INFO - 2017-08-15 16:52:49 --> Email Class Initialized
DEBUG - 2017-08-15 16:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:52:49 --> Table Class Initialized
INFO - 2017-08-15 16:52:49 --> Controller Class Initialized
DEBUG - 2017-08-15 16:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:52:49 --> Helper loaded: form_helper
DEBUG - 2017-08-15 16:52:49 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:52:50 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-15 16:52:50 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:52:50 --> Final output sent to browser
DEBUG - 2017-08-15 16:52:50 --> Total execution time: 0.3086
INFO - 2017-08-15 16:53:04 --> Config Class Initialized
INFO - 2017-08-15 16:53:04 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:53:04 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:53:04 --> Utf8 Class Initialized
INFO - 2017-08-15 16:53:04 --> URI Class Initialized
INFO - 2017-08-15 16:53:04 --> Router Class Initialized
INFO - 2017-08-15 16:53:04 --> Output Class Initialized
INFO - 2017-08-15 16:53:04 --> Security Class Initialized
DEBUG - 2017-08-15 16:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:53:04 --> Input Class Initialized
INFO - 2017-08-15 16:53:04 --> Language Class Initialized
INFO - 2017-08-15 16:53:04 --> Loader Class Initialized
INFO - 2017-08-15 16:53:04 --> Helper loaded: url_helper
INFO - 2017-08-15 16:53:04 --> Helper loaded: file_helper
INFO - 2017-08-15 16:53:04 --> Database Driver Class Initialized
INFO - 2017-08-15 16:53:04 --> Email Class Initialized
DEBUG - 2017-08-15 16:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:53:04 --> Table Class Initialized
INFO - 2017-08-15 16:53:04 --> Controller Class Initialized
DEBUG - 2017-08-15 16:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:53:04 --> Helper loaded: form_helper
DEBUG - 2017-08-15 16:53:04 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:53:04 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-15 16:53:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:53:04 --> Final output sent to browser
DEBUG - 2017-08-15 16:53:04 --> Total execution time: 0.2996
INFO - 2017-08-15 16:58:32 --> Config Class Initialized
INFO - 2017-08-15 16:58:32 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:58:32 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:58:32 --> Utf8 Class Initialized
INFO - 2017-08-15 16:58:32 --> URI Class Initialized
INFO - 2017-08-15 16:58:32 --> Router Class Initialized
INFO - 2017-08-15 16:58:32 --> Output Class Initialized
INFO - 2017-08-15 16:58:32 --> Security Class Initialized
DEBUG - 2017-08-15 16:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:58:32 --> Input Class Initialized
INFO - 2017-08-15 16:58:32 --> Language Class Initialized
INFO - 2017-08-15 16:58:32 --> Loader Class Initialized
INFO - 2017-08-15 16:58:32 --> Helper loaded: url_helper
INFO - 2017-08-15 16:58:32 --> Helper loaded: file_helper
INFO - 2017-08-15 16:58:32 --> Database Driver Class Initialized
INFO - 2017-08-15 16:58:32 --> Email Class Initialized
DEBUG - 2017-08-15 16:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:58:32 --> Table Class Initialized
INFO - 2017-08-15 16:58:32 --> Controller Class Initialized
DEBUG - 2017-08-15 16:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:58:32 --> Helper loaded: form_helper
DEBUG - 2017-08-15 16:58:32 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:58:32 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-15 16:58:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:58:32 --> Final output sent to browser
DEBUG - 2017-08-15 16:58:32 --> Total execution time: 0.3278
INFO - 2017-08-15 16:58:34 --> Config Class Initialized
INFO - 2017-08-15 16:58:34 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:58:34 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:58:34 --> Utf8 Class Initialized
INFO - 2017-08-15 16:58:34 --> URI Class Initialized
INFO - 2017-08-15 16:58:34 --> Router Class Initialized
INFO - 2017-08-15 16:58:34 --> Output Class Initialized
INFO - 2017-08-15 16:58:34 --> Security Class Initialized
DEBUG - 2017-08-15 16:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:58:34 --> Input Class Initialized
INFO - 2017-08-15 16:58:34 --> Language Class Initialized
INFO - 2017-08-15 16:58:34 --> Loader Class Initialized
INFO - 2017-08-15 16:58:34 --> Helper loaded: url_helper
INFO - 2017-08-15 16:58:34 --> Helper loaded: file_helper
INFO - 2017-08-15 16:58:34 --> Database Driver Class Initialized
INFO - 2017-08-15 16:58:34 --> Email Class Initialized
DEBUG - 2017-08-15 16:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:58:34 --> Table Class Initialized
INFO - 2017-08-15 16:58:34 --> Controller Class Initialized
DEBUG - 2017-08-15 16:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:58:34 --> Helper loaded: form_helper
DEBUG - 2017-08-15 16:58:34 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:58:34 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-15 16:58:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:58:34 --> Final output sent to browser
DEBUG - 2017-08-15 16:58:34 --> Total execution time: 0.3077
INFO - 2017-08-15 16:58:36 --> Config Class Initialized
INFO - 2017-08-15 16:58:36 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:58:36 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:58:36 --> Utf8 Class Initialized
INFO - 2017-08-15 16:58:36 --> URI Class Initialized
INFO - 2017-08-15 16:58:36 --> Router Class Initialized
INFO - 2017-08-15 16:58:36 --> Output Class Initialized
INFO - 2017-08-15 16:58:36 --> Security Class Initialized
DEBUG - 2017-08-15 16:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:58:36 --> Input Class Initialized
INFO - 2017-08-15 16:58:36 --> Language Class Initialized
INFO - 2017-08-15 16:58:36 --> Loader Class Initialized
INFO - 2017-08-15 16:58:36 --> Helper loaded: url_helper
INFO - 2017-08-15 16:58:36 --> Helper loaded: file_helper
INFO - 2017-08-15 16:58:36 --> Database Driver Class Initialized
INFO - 2017-08-15 16:58:36 --> Email Class Initialized
DEBUG - 2017-08-15 16:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:58:36 --> Table Class Initialized
INFO - 2017-08-15 16:58:36 --> Controller Class Initialized
DEBUG - 2017-08-15 16:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:58:36 --> Helper loaded: form_helper
DEBUG - 2017-08-15 16:58:36 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:58:36 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-15 16:58:36 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:58:36 --> Final output sent to browser
DEBUG - 2017-08-15 16:58:36 --> Total execution time: 0.3079
INFO - 2017-08-15 16:58:41 --> Config Class Initialized
INFO - 2017-08-15 16:58:41 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:58:41 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:58:41 --> Utf8 Class Initialized
INFO - 2017-08-15 16:58:41 --> URI Class Initialized
INFO - 2017-08-15 16:58:41 --> Router Class Initialized
INFO - 2017-08-15 16:58:41 --> Output Class Initialized
INFO - 2017-08-15 16:58:41 --> Security Class Initialized
DEBUG - 2017-08-15 16:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:58:42 --> Input Class Initialized
INFO - 2017-08-15 16:58:42 --> Language Class Initialized
INFO - 2017-08-15 16:58:42 --> Loader Class Initialized
INFO - 2017-08-15 16:58:42 --> Helper loaded: url_helper
INFO - 2017-08-15 16:58:42 --> Helper loaded: file_helper
INFO - 2017-08-15 16:58:42 --> Database Driver Class Initialized
INFO - 2017-08-15 16:58:42 --> Email Class Initialized
DEBUG - 2017-08-15 16:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:58:42 --> Table Class Initialized
INFO - 2017-08-15 16:58:42 --> Controller Class Initialized
DEBUG - 2017-08-15 16:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:58:42 --> Helper loaded: form_helper
INFO - 2017-08-15 16:58:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:58:42 --> Final output sent to browser
DEBUG - 2017-08-15 16:58:42 --> Total execution time: 0.2250
INFO - 2017-08-15 16:58:45 --> Config Class Initialized
INFO - 2017-08-15 16:58:45 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:58:45 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:58:45 --> Utf8 Class Initialized
INFO - 2017-08-15 16:58:45 --> URI Class Initialized
INFO - 2017-08-15 16:58:45 --> Router Class Initialized
INFO - 2017-08-15 16:58:45 --> Output Class Initialized
INFO - 2017-08-15 16:58:45 --> Security Class Initialized
DEBUG - 2017-08-15 16:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:58:46 --> Input Class Initialized
INFO - 2017-08-15 16:58:46 --> Language Class Initialized
INFO - 2017-08-15 16:58:46 --> Loader Class Initialized
INFO - 2017-08-15 16:58:46 --> Helper loaded: url_helper
INFO - 2017-08-15 16:58:46 --> Helper loaded: file_helper
INFO - 2017-08-15 16:58:46 --> Database Driver Class Initialized
INFO - 2017-08-15 16:58:46 --> Email Class Initialized
DEBUG - 2017-08-15 16:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:58:46 --> Table Class Initialized
INFO - 2017-08-15 16:58:46 --> Controller Class Initialized
DEBUG - 2017-08-15 16:58:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:58:46 --> Helper loaded: form_helper
INFO - 2017-08-15 16:58:46 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:58:46 --> Final output sent to browser
DEBUG - 2017-08-15 16:58:46 --> Total execution time: 0.2261
INFO - 2017-08-15 16:58:53 --> Config Class Initialized
INFO - 2017-08-15 16:58:53 --> Hooks Class Initialized
DEBUG - 2017-08-15 16:58:53 --> UTF-8 Support Enabled
INFO - 2017-08-15 16:58:53 --> Utf8 Class Initialized
INFO - 2017-08-15 16:58:53 --> URI Class Initialized
INFO - 2017-08-15 16:58:53 --> Router Class Initialized
INFO - 2017-08-15 16:58:53 --> Output Class Initialized
INFO - 2017-08-15 16:58:53 --> Security Class Initialized
DEBUG - 2017-08-15 16:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-15 16:58:53 --> Input Class Initialized
INFO - 2017-08-15 16:58:53 --> Language Class Initialized
INFO - 2017-08-15 16:58:53 --> Loader Class Initialized
INFO - 2017-08-15 16:58:53 --> Helper loaded: url_helper
INFO - 2017-08-15 16:58:53 --> Helper loaded: file_helper
INFO - 2017-08-15 16:58:53 --> Database Driver Class Initialized
INFO - 2017-08-15 16:58:53 --> Email Class Initialized
DEBUG - 2017-08-15 16:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-15 16:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-15 16:58:53 --> Table Class Initialized
INFO - 2017-08-15 16:58:53 --> Controller Class Initialized
DEBUG - 2017-08-15 16:58:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:58:53 --> Helper loaded: form_helper
DEBUG - 2017-08-15 16:58:53 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-15 16:58:53 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-15 16:58:53 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-15 16:58:53 --> Final output sent to browser
DEBUG - 2017-08-15 16:58:53 --> Total execution time: 0.2985
