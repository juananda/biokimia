<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-21 06:16:40 --> Config Class Initialized
INFO - 2017-08-21 06:16:40 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:16:40 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:16:40 --> Utf8 Class Initialized
INFO - 2017-08-21 06:16:40 --> URI Class Initialized
INFO - 2017-08-21 06:16:40 --> Router Class Initialized
INFO - 2017-08-21 06:16:41 --> Output Class Initialized
INFO - 2017-08-21 06:16:41 --> Security Class Initialized
DEBUG - 2017-08-21 06:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:16:41 --> Input Class Initialized
INFO - 2017-08-21 06:16:41 --> Language Class Initialized
INFO - 2017-08-21 06:16:41 --> Loader Class Initialized
INFO - 2017-08-21 06:16:41 --> Helper loaded: url_helper
INFO - 2017-08-21 06:16:41 --> Helper loaded: file_helper
INFO - 2017-08-21 06:16:42 --> Database Driver Class Initialized
INFO - 2017-08-21 06:16:42 --> Email Class Initialized
DEBUG - 2017-08-21 06:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:16:42 --> Table Class Initialized
INFO - 2017-08-21 06:16:42 --> Controller Class Initialized
INFO - 2017-08-21 06:16:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 06:16:42 --> Final output sent to browser
DEBUG - 2017-08-21 06:16:42 --> Total execution time: 2.0551
INFO - 2017-08-21 06:20:57 --> Config Class Initialized
INFO - 2017-08-21 06:20:58 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:20:58 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:20:58 --> Utf8 Class Initialized
INFO - 2017-08-21 06:20:58 --> URI Class Initialized
INFO - 2017-08-21 06:20:58 --> Router Class Initialized
INFO - 2017-08-21 06:20:58 --> Output Class Initialized
INFO - 2017-08-21 06:20:58 --> Security Class Initialized
DEBUG - 2017-08-21 06:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:20:58 --> Input Class Initialized
INFO - 2017-08-21 06:20:58 --> Language Class Initialized
INFO - 2017-08-21 06:20:58 --> Loader Class Initialized
INFO - 2017-08-21 06:20:58 --> Helper loaded: url_helper
INFO - 2017-08-21 06:20:58 --> Helper loaded: file_helper
INFO - 2017-08-21 06:20:58 --> Database Driver Class Initialized
INFO - 2017-08-21 06:20:58 --> Email Class Initialized
DEBUG - 2017-08-21 06:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:20:58 --> Table Class Initialized
INFO - 2017-08-21 06:20:58 --> Controller Class Initialized
INFO - 2017-08-21 06:20:58 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 06:20:58 --> Final output sent to browser
DEBUG - 2017-08-21 06:20:58 --> Total execution time: 0.2840
INFO - 2017-08-21 06:20:59 --> Config Class Initialized
INFO - 2017-08-21 06:20:59 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:20:59 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:20:59 --> Utf8 Class Initialized
INFO - 2017-08-21 06:20:59 --> URI Class Initialized
INFO - 2017-08-21 06:20:59 --> Router Class Initialized
INFO - 2017-08-21 06:20:59 --> Output Class Initialized
INFO - 2017-08-21 06:20:59 --> Security Class Initialized
DEBUG - 2017-08-21 06:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:20:59 --> Input Class Initialized
INFO - 2017-08-21 06:20:59 --> Language Class Initialized
INFO - 2017-08-21 06:20:59 --> Loader Class Initialized
INFO - 2017-08-21 06:20:59 --> Helper loaded: url_helper
INFO - 2017-08-21 06:20:59 --> Helper loaded: file_helper
INFO - 2017-08-21 06:20:59 --> Database Driver Class Initialized
INFO - 2017-08-21 06:20:59 --> Email Class Initialized
DEBUG - 2017-08-21 06:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:20:59 --> Table Class Initialized
INFO - 2017-08-21 06:20:59 --> Controller Class Initialized
INFO - 2017-08-21 06:20:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 06:20:59 --> Final output sent to browser
DEBUG - 2017-08-21 06:20:59 --> Total execution time: 0.1475
INFO - 2017-08-21 06:21:04 --> Config Class Initialized
INFO - 2017-08-21 06:21:04 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:21:04 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:21:04 --> Utf8 Class Initialized
INFO - 2017-08-21 06:21:04 --> URI Class Initialized
INFO - 2017-08-21 06:21:04 --> Router Class Initialized
INFO - 2017-08-21 06:21:04 --> Output Class Initialized
INFO - 2017-08-21 06:21:04 --> Security Class Initialized
DEBUG - 2017-08-21 06:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:21:04 --> Input Class Initialized
INFO - 2017-08-21 06:21:04 --> Language Class Initialized
INFO - 2017-08-21 06:21:04 --> Loader Class Initialized
INFO - 2017-08-21 06:21:04 --> Helper loaded: url_helper
INFO - 2017-08-21 06:21:04 --> Helper loaded: file_helper
INFO - 2017-08-21 06:21:04 --> Database Driver Class Initialized
INFO - 2017-08-21 06:21:04 --> Email Class Initialized
DEBUG - 2017-08-21 06:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:21:04 --> Table Class Initialized
INFO - 2017-08-21 06:21:04 --> Controller Class Initialized
INFO - 2017-08-21 06:21:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 06:21:04 --> Final output sent to browser
DEBUG - 2017-08-21 06:21:04 --> Total execution time: 0.1569
INFO - 2017-08-21 06:21:07 --> Config Class Initialized
INFO - 2017-08-21 06:21:07 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:21:07 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:21:07 --> Utf8 Class Initialized
INFO - 2017-08-21 06:21:10 --> Config Class Initialized
INFO - 2017-08-21 06:21:10 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:21:10 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:21:10 --> Utf8 Class Initialized
INFO - 2017-08-21 06:21:10 --> URI Class Initialized
INFO - 2017-08-21 06:21:10 --> Router Class Initialized
INFO - 2017-08-21 06:21:10 --> Output Class Initialized
INFO - 2017-08-21 06:21:10 --> Security Class Initialized
DEBUG - 2017-08-21 06:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:21:10 --> Input Class Initialized
INFO - 2017-08-21 06:21:10 --> Language Class Initialized
INFO - 2017-08-21 06:21:10 --> Loader Class Initialized
INFO - 2017-08-21 06:21:10 --> Helper loaded: url_helper
INFO - 2017-08-21 06:21:10 --> Helper loaded: file_helper
INFO - 2017-08-21 06:21:10 --> Database Driver Class Initialized
INFO - 2017-08-21 06:21:11 --> Email Class Initialized
DEBUG - 2017-08-21 06:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:21:11 --> Table Class Initialized
INFO - 2017-08-21 06:21:11 --> Controller Class Initialized
INFO - 2017-08-21 06:21:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 06:21:11 --> Final output sent to browser
DEBUG - 2017-08-21 06:21:11 --> Total execution time: 0.1518
INFO - 2017-08-21 06:21:20 --> Config Class Initialized
INFO - 2017-08-21 06:21:20 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:21:20 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:21:20 --> Utf8 Class Initialized
INFO - 2017-08-21 06:21:20 --> URI Class Initialized
INFO - 2017-08-21 06:21:20 --> Router Class Initialized
INFO - 2017-08-21 06:21:20 --> Output Class Initialized
INFO - 2017-08-21 06:21:20 --> Security Class Initialized
DEBUG - 2017-08-21 06:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:21:20 --> Input Class Initialized
INFO - 2017-08-21 06:21:20 --> Language Class Initialized
INFO - 2017-08-21 06:21:20 --> Loader Class Initialized
INFO - 2017-08-21 06:21:20 --> Helper loaded: url_helper
INFO - 2017-08-21 06:21:20 --> Helper loaded: file_helper
INFO - 2017-08-21 06:21:20 --> Database Driver Class Initialized
INFO - 2017-08-21 06:21:20 --> Email Class Initialized
DEBUG - 2017-08-21 06:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:21:20 --> Table Class Initialized
INFO - 2017-08-21 06:21:20 --> Controller Class Initialized
INFO - 2017-08-21 06:21:20 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 06:21:20 --> Final output sent to browser
DEBUG - 2017-08-21 06:21:20 --> Total execution time: 0.1550
INFO - 2017-08-21 06:25:52 --> Config Class Initialized
INFO - 2017-08-21 06:25:52 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:25:52 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:25:52 --> Utf8 Class Initialized
INFO - 2017-08-21 06:25:52 --> URI Class Initialized
INFO - 2017-08-21 06:25:52 --> Router Class Initialized
INFO - 2017-08-21 06:25:52 --> Output Class Initialized
INFO - 2017-08-21 06:25:52 --> Security Class Initialized
DEBUG - 2017-08-21 06:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:25:52 --> Input Class Initialized
INFO - 2017-08-21 06:25:52 --> Language Class Initialized
INFO - 2017-08-21 06:25:52 --> Loader Class Initialized
INFO - 2017-08-21 06:25:52 --> Helper loaded: url_helper
INFO - 2017-08-21 06:25:52 --> Helper loaded: file_helper
INFO - 2017-08-21 06:25:52 --> Database Driver Class Initialized
INFO - 2017-08-21 06:25:52 --> Email Class Initialized
DEBUG - 2017-08-21 06:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:25:52 --> Table Class Initialized
INFO - 2017-08-21 06:25:52 --> Controller Class Initialized
INFO - 2017-08-21 06:25:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 06:25:52 --> Final output sent to browser
DEBUG - 2017-08-21 06:25:52 --> Total execution time: 0.1540
INFO - 2017-08-21 06:25:58 --> Config Class Initialized
INFO - 2017-08-21 06:25:58 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:25:58 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:25:58 --> Utf8 Class Initialized
INFO - 2017-08-21 06:25:58 --> URI Class Initialized
INFO - 2017-08-21 06:25:58 --> Router Class Initialized
INFO - 2017-08-21 06:25:58 --> Output Class Initialized
INFO - 2017-08-21 06:25:58 --> Security Class Initialized
DEBUG - 2017-08-21 06:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:25:58 --> Input Class Initialized
INFO - 2017-08-21 06:25:58 --> Language Class Initialized
INFO - 2017-08-21 06:25:58 --> Loader Class Initialized
INFO - 2017-08-21 06:25:58 --> Helper loaded: url_helper
INFO - 2017-08-21 06:25:58 --> Helper loaded: file_helper
INFO - 2017-08-21 06:25:58 --> Database Driver Class Initialized
INFO - 2017-08-21 06:25:58 --> Email Class Initialized
DEBUG - 2017-08-21 06:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:25:58 --> Table Class Initialized
INFO - 2017-08-21 06:25:58 --> Controller Class Initialized
INFO - 2017-08-21 06:25:58 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 06:25:58 --> Final output sent to browser
DEBUG - 2017-08-21 06:25:58 --> Total execution time: 0.2255
INFO - 2017-08-21 06:26:03 --> Config Class Initialized
INFO - 2017-08-21 06:26:03 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:26:03 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:26:03 --> Utf8 Class Initialized
INFO - 2017-08-21 06:26:03 --> URI Class Initialized
INFO - 2017-08-21 06:26:03 --> Router Class Initialized
INFO - 2017-08-21 06:26:03 --> Output Class Initialized
INFO - 2017-08-21 06:26:03 --> Security Class Initialized
DEBUG - 2017-08-21 06:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:26:03 --> Input Class Initialized
INFO - 2017-08-21 06:26:03 --> Language Class Initialized
INFO - 2017-08-21 06:26:03 --> Loader Class Initialized
INFO - 2017-08-21 06:26:03 --> Helper loaded: url_helper
INFO - 2017-08-21 06:26:03 --> Helper loaded: file_helper
INFO - 2017-08-21 06:26:03 --> Database Driver Class Initialized
INFO - 2017-08-21 06:26:03 --> Email Class Initialized
DEBUG - 2017-08-21 06:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:26:03 --> Table Class Initialized
INFO - 2017-08-21 06:26:03 --> Controller Class Initialized
INFO - 2017-08-21 06:26:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 06:26:03 --> Final output sent to browser
DEBUG - 2017-08-21 06:26:03 --> Total execution time: 0.1756
INFO - 2017-08-21 06:26:08 --> Config Class Initialized
INFO - 2017-08-21 06:26:08 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:26:08 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:26:08 --> Utf8 Class Initialized
INFO - 2017-08-21 06:26:08 --> URI Class Initialized
INFO - 2017-08-21 06:26:09 --> Router Class Initialized
INFO - 2017-08-21 06:26:09 --> Output Class Initialized
INFO - 2017-08-21 06:26:09 --> Security Class Initialized
DEBUG - 2017-08-21 06:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:26:09 --> Input Class Initialized
INFO - 2017-08-21 06:26:09 --> Language Class Initialized
INFO - 2017-08-21 06:26:09 --> Loader Class Initialized
INFO - 2017-08-21 06:26:09 --> Helper loaded: url_helper
INFO - 2017-08-21 06:26:09 --> Helper loaded: file_helper
INFO - 2017-08-21 06:26:09 --> Database Driver Class Initialized
INFO - 2017-08-21 06:26:09 --> Email Class Initialized
DEBUG - 2017-08-21 06:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:26:09 --> Table Class Initialized
INFO - 2017-08-21 06:26:09 --> Controller Class Initialized
INFO - 2017-08-21 06:26:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 06:26:09 --> Final output sent to browser
DEBUG - 2017-08-21 06:26:09 --> Total execution time: 0.7980
INFO - 2017-08-21 06:26:38 --> Config Class Initialized
INFO - 2017-08-21 06:26:38 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:26:38 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:26:38 --> Utf8 Class Initialized
INFO - 2017-08-21 06:26:38 --> URI Class Initialized
INFO - 2017-08-21 06:26:38 --> Router Class Initialized
INFO - 2017-08-21 06:26:38 --> Output Class Initialized
INFO - 2017-08-21 06:26:38 --> Security Class Initialized
DEBUG - 2017-08-21 06:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:26:38 --> Input Class Initialized
INFO - 2017-08-21 06:26:38 --> Language Class Initialized
INFO - 2017-08-21 06:26:38 --> Loader Class Initialized
INFO - 2017-08-21 06:26:38 --> Helper loaded: url_helper
INFO - 2017-08-21 06:26:38 --> Helper loaded: file_helper
INFO - 2017-08-21 06:26:38 --> Database Driver Class Initialized
INFO - 2017-08-21 06:26:38 --> Email Class Initialized
DEBUG - 2017-08-21 06:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:26:38 --> Table Class Initialized
INFO - 2017-08-21 06:26:38 --> Controller Class Initialized
INFO - 2017-08-21 06:26:38 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:26:39 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 80
ERROR - 2017-08-21 06:26:39 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 80
INFO - 2017-08-21 06:26:53 --> Config Class Initialized
INFO - 2017-08-21 06:26:53 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:26:53 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:26:53 --> Utf8 Class Initialized
INFO - 2017-08-21 06:26:53 --> URI Class Initialized
INFO - 2017-08-21 06:26:53 --> Router Class Initialized
INFO - 2017-08-21 06:26:53 --> Output Class Initialized
INFO - 2017-08-21 06:26:53 --> Security Class Initialized
DEBUG - 2017-08-21 06:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:26:53 --> Input Class Initialized
INFO - 2017-08-21 06:26:53 --> Language Class Initialized
INFO - 2017-08-21 06:26:53 --> Loader Class Initialized
INFO - 2017-08-21 06:26:53 --> Helper loaded: url_helper
INFO - 2017-08-21 06:26:53 --> Helper loaded: file_helper
INFO - 2017-08-21 06:26:53 --> Database Driver Class Initialized
INFO - 2017-08-21 06:26:53 --> Email Class Initialized
DEBUG - 2017-08-21 06:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:26:53 --> Table Class Initialized
INFO - 2017-08-21 06:26:53 --> Controller Class Initialized
INFO - 2017-08-21 06:26:53 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:26:53 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 80
ERROR - 2017-08-21 06:26:53 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 80
INFO - 2017-08-21 06:27:32 --> Config Class Initialized
INFO - 2017-08-21 06:27:32 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:27:32 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:27:32 --> Utf8 Class Initialized
INFO - 2017-08-21 06:27:32 --> URI Class Initialized
INFO - 2017-08-21 06:27:32 --> Router Class Initialized
INFO - 2017-08-21 06:27:32 --> Output Class Initialized
INFO - 2017-08-21 06:27:32 --> Security Class Initialized
DEBUG - 2017-08-21 06:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:27:32 --> Input Class Initialized
INFO - 2017-08-21 06:27:32 --> Language Class Initialized
INFO - 2017-08-21 06:27:32 --> Loader Class Initialized
INFO - 2017-08-21 06:27:32 --> Helper loaded: url_helper
INFO - 2017-08-21 06:27:32 --> Helper loaded: file_helper
INFO - 2017-08-21 06:27:32 --> Database Driver Class Initialized
INFO - 2017-08-21 06:27:32 --> Email Class Initialized
DEBUG - 2017-08-21 06:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:27:32 --> Table Class Initialized
INFO - 2017-08-21 06:27:32 --> Controller Class Initialized
INFO - 2017-08-21 06:27:32 --> Image Lib Class Initialized
INFO - 2017-08-21 06:27:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:27:32 --> Final output sent to browser
DEBUG - 2017-08-21 06:27:32 --> Total execution time: 0.1678
INFO - 2017-08-21 06:29:11 --> Config Class Initialized
INFO - 2017-08-21 06:29:11 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:29:12 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:29:12 --> Utf8 Class Initialized
INFO - 2017-08-21 06:29:12 --> URI Class Initialized
INFO - 2017-08-21 06:29:12 --> Router Class Initialized
INFO - 2017-08-21 06:29:12 --> Output Class Initialized
INFO - 2017-08-21 06:29:12 --> Security Class Initialized
DEBUG - 2017-08-21 06:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:29:12 --> Input Class Initialized
INFO - 2017-08-21 06:29:12 --> Language Class Initialized
INFO - 2017-08-21 06:29:12 --> Loader Class Initialized
INFO - 2017-08-21 06:29:12 --> Helper loaded: url_helper
INFO - 2017-08-21 06:29:12 --> Helper loaded: file_helper
INFO - 2017-08-21 06:29:12 --> Database Driver Class Initialized
INFO - 2017-08-21 06:29:12 --> Email Class Initialized
DEBUG - 2017-08-21 06:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:29:12 --> Table Class Initialized
INFO - 2017-08-21 06:29:12 --> Controller Class Initialized
INFO - 2017-08-21 06:29:12 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:29:12 --> The path to the image is not correct.
INFO - 2017-08-21 06:29:12 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:29:12 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:29:12 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:30:29 --> Config Class Initialized
INFO - 2017-08-21 06:30:29 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:30:30 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:30:30 --> Utf8 Class Initialized
INFO - 2017-08-21 06:30:30 --> URI Class Initialized
INFO - 2017-08-21 06:30:30 --> Router Class Initialized
INFO - 2017-08-21 06:30:30 --> Output Class Initialized
INFO - 2017-08-21 06:30:30 --> Security Class Initialized
DEBUG - 2017-08-21 06:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:30:30 --> Input Class Initialized
INFO - 2017-08-21 06:30:30 --> Language Class Initialized
INFO - 2017-08-21 06:30:30 --> Loader Class Initialized
INFO - 2017-08-21 06:30:30 --> Helper loaded: url_helper
INFO - 2017-08-21 06:30:30 --> Helper loaded: file_helper
INFO - 2017-08-21 06:30:30 --> Database Driver Class Initialized
INFO - 2017-08-21 06:30:30 --> Email Class Initialized
DEBUG - 2017-08-21 06:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:30:30 --> Table Class Initialized
INFO - 2017-08-21 06:30:30 --> Controller Class Initialized
INFO - 2017-08-21 06:30:30 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:30:30 --> The path to the image is not correct.
INFO - 2017-08-21 06:30:30 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:30:30 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:30:30 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:30:44 --> Config Class Initialized
INFO - 2017-08-21 06:30:44 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:30:44 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:30:44 --> Utf8 Class Initialized
INFO - 2017-08-21 06:30:44 --> URI Class Initialized
INFO - 2017-08-21 06:30:44 --> Router Class Initialized
INFO - 2017-08-21 06:30:44 --> Output Class Initialized
INFO - 2017-08-21 06:30:44 --> Security Class Initialized
DEBUG - 2017-08-21 06:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:30:44 --> Input Class Initialized
INFO - 2017-08-21 06:30:44 --> Language Class Initialized
INFO - 2017-08-21 06:30:44 --> Loader Class Initialized
INFO - 2017-08-21 06:30:44 --> Helper loaded: url_helper
INFO - 2017-08-21 06:30:44 --> Helper loaded: file_helper
INFO - 2017-08-21 06:30:44 --> Database Driver Class Initialized
INFO - 2017-08-21 06:30:45 --> Email Class Initialized
DEBUG - 2017-08-21 06:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:30:45 --> Table Class Initialized
INFO - 2017-08-21 06:30:45 --> Controller Class Initialized
INFO - 2017-08-21 06:30:45 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:30:45 --> The path to the image is not correct.
INFO - 2017-08-21 06:30:45 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:30:45 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:30:45 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:30:47 --> Config Class Initialized
INFO - 2017-08-21 06:30:47 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:30:47 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:30:47 --> Utf8 Class Initialized
INFO - 2017-08-21 06:30:47 --> URI Class Initialized
INFO - 2017-08-21 06:30:47 --> Router Class Initialized
INFO - 2017-08-21 06:30:47 --> Output Class Initialized
INFO - 2017-08-21 06:30:47 --> Security Class Initialized
DEBUG - 2017-08-21 06:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:30:47 --> Input Class Initialized
INFO - 2017-08-21 06:30:47 --> Language Class Initialized
INFO - 2017-08-21 06:30:47 --> Loader Class Initialized
INFO - 2017-08-21 06:30:47 --> Helper loaded: url_helper
INFO - 2017-08-21 06:30:47 --> Helper loaded: file_helper
INFO - 2017-08-21 06:30:47 --> Database Driver Class Initialized
INFO - 2017-08-21 06:30:47 --> Email Class Initialized
DEBUG - 2017-08-21 06:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:30:47 --> Table Class Initialized
INFO - 2017-08-21 06:30:47 --> Controller Class Initialized
INFO - 2017-08-21 06:30:47 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:30:47 --> The path to the image is not correct.
INFO - 2017-08-21 06:30:47 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:30:47 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:30:47 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:32:56 --> Config Class Initialized
INFO - 2017-08-21 06:32:56 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:32:57 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:32:57 --> Utf8 Class Initialized
INFO - 2017-08-21 06:32:57 --> URI Class Initialized
INFO - 2017-08-21 06:32:57 --> Router Class Initialized
INFO - 2017-08-21 06:32:57 --> Output Class Initialized
INFO - 2017-08-21 06:32:57 --> Security Class Initialized
DEBUG - 2017-08-21 06:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:32:57 --> Input Class Initialized
INFO - 2017-08-21 06:32:57 --> Language Class Initialized
INFO - 2017-08-21 06:32:57 --> Loader Class Initialized
INFO - 2017-08-21 06:32:57 --> Helper loaded: url_helper
INFO - 2017-08-21 06:32:57 --> Helper loaded: file_helper
INFO - 2017-08-21 06:32:57 --> Database Driver Class Initialized
INFO - 2017-08-21 06:32:57 --> Email Class Initialized
DEBUG - 2017-08-21 06:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:32:57 --> Table Class Initialized
INFO - 2017-08-21 06:32:57 --> Controller Class Initialized
INFO - 2017-08-21 06:32:57 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:32:57 --> The path to the image is not correct.
INFO - 2017-08-21 06:32:57 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:32:57 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:32:57 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:33:00 --> Config Class Initialized
INFO - 2017-08-21 06:33:00 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:33:00 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:33:00 --> Utf8 Class Initialized
INFO - 2017-08-21 06:33:00 --> URI Class Initialized
INFO - 2017-08-21 06:33:00 --> Router Class Initialized
INFO - 2017-08-21 06:33:00 --> Output Class Initialized
INFO - 2017-08-21 06:33:00 --> Security Class Initialized
DEBUG - 2017-08-21 06:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:33:00 --> Input Class Initialized
INFO - 2017-08-21 06:33:00 --> Language Class Initialized
INFO - 2017-08-21 06:33:00 --> Loader Class Initialized
INFO - 2017-08-21 06:33:00 --> Helper loaded: url_helper
INFO - 2017-08-21 06:33:00 --> Helper loaded: file_helper
INFO - 2017-08-21 06:33:00 --> Database Driver Class Initialized
INFO - 2017-08-21 06:33:00 --> Email Class Initialized
DEBUG - 2017-08-21 06:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:33:00 --> Table Class Initialized
INFO - 2017-08-21 06:33:00 --> Controller Class Initialized
INFO - 2017-08-21 06:33:00 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:33:00 --> The path to the image is not correct.
INFO - 2017-08-21 06:33:00 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:33:00 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:33:00 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:33:01 --> Config Class Initialized
INFO - 2017-08-21 06:33:01 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:33:01 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:33:01 --> Utf8 Class Initialized
INFO - 2017-08-21 06:33:01 --> URI Class Initialized
INFO - 2017-08-21 06:33:01 --> Router Class Initialized
INFO - 2017-08-21 06:33:01 --> Output Class Initialized
INFO - 2017-08-21 06:33:01 --> Security Class Initialized
DEBUG - 2017-08-21 06:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:33:01 --> Input Class Initialized
INFO - 2017-08-21 06:33:01 --> Language Class Initialized
INFO - 2017-08-21 06:33:01 --> Loader Class Initialized
INFO - 2017-08-21 06:33:01 --> Helper loaded: url_helper
INFO - 2017-08-21 06:33:01 --> Helper loaded: file_helper
INFO - 2017-08-21 06:33:01 --> Database Driver Class Initialized
INFO - 2017-08-21 06:33:01 --> Email Class Initialized
DEBUG - 2017-08-21 06:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:33:01 --> Table Class Initialized
INFO - 2017-08-21 06:33:01 --> Controller Class Initialized
INFO - 2017-08-21 06:33:01 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:33:01 --> The path to the image is not correct.
INFO - 2017-08-21 06:33:01 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:33:01 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:33:01 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:33:27 --> Config Class Initialized
INFO - 2017-08-21 06:33:27 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:33:27 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:33:27 --> Utf8 Class Initialized
INFO - 2017-08-21 06:33:27 --> URI Class Initialized
INFO - 2017-08-21 06:33:27 --> Router Class Initialized
INFO - 2017-08-21 06:33:27 --> Output Class Initialized
INFO - 2017-08-21 06:33:27 --> Security Class Initialized
DEBUG - 2017-08-21 06:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:33:27 --> Input Class Initialized
INFO - 2017-08-21 06:33:27 --> Language Class Initialized
INFO - 2017-08-21 06:33:27 --> Loader Class Initialized
INFO - 2017-08-21 06:33:27 --> Helper loaded: url_helper
INFO - 2017-08-21 06:33:27 --> Helper loaded: file_helper
INFO - 2017-08-21 06:33:27 --> Database Driver Class Initialized
INFO - 2017-08-21 06:33:27 --> Email Class Initialized
DEBUG - 2017-08-21 06:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:33:27 --> Table Class Initialized
INFO - 2017-08-21 06:33:27 --> Controller Class Initialized
INFO - 2017-08-21 06:33:27 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:33:27 --> The path to the image is not correct.
INFO - 2017-08-21 06:33:27 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:33:27 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:33:27 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:33:39 --> Config Class Initialized
INFO - 2017-08-21 06:33:39 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:33:39 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:33:39 --> Utf8 Class Initialized
INFO - 2017-08-21 06:33:39 --> URI Class Initialized
INFO - 2017-08-21 06:33:40 --> Router Class Initialized
INFO - 2017-08-21 06:33:40 --> Output Class Initialized
INFO - 2017-08-21 06:33:40 --> Security Class Initialized
DEBUG - 2017-08-21 06:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:33:40 --> Input Class Initialized
INFO - 2017-08-21 06:33:40 --> Language Class Initialized
INFO - 2017-08-21 06:33:40 --> Loader Class Initialized
INFO - 2017-08-21 06:33:40 --> Helper loaded: url_helper
INFO - 2017-08-21 06:33:40 --> Helper loaded: file_helper
INFO - 2017-08-21 06:33:40 --> Database Driver Class Initialized
INFO - 2017-08-21 06:33:40 --> Email Class Initialized
DEBUG - 2017-08-21 06:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:33:40 --> Table Class Initialized
INFO - 2017-08-21 06:33:40 --> Controller Class Initialized
INFO - 2017-08-21 06:33:40 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:33:40 --> The path to the image is not correct.
INFO - 2017-08-21 06:33:40 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:33:40 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:33:40 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:33:51 --> Config Class Initialized
INFO - 2017-08-21 06:33:51 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:33:51 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:33:51 --> Utf8 Class Initialized
INFO - 2017-08-21 06:33:51 --> URI Class Initialized
INFO - 2017-08-21 06:33:51 --> Router Class Initialized
INFO - 2017-08-21 06:33:51 --> Output Class Initialized
INFO - 2017-08-21 06:33:51 --> Security Class Initialized
DEBUG - 2017-08-21 06:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:33:51 --> Input Class Initialized
INFO - 2017-08-21 06:33:51 --> Language Class Initialized
INFO - 2017-08-21 06:33:51 --> Loader Class Initialized
INFO - 2017-08-21 06:33:51 --> Helper loaded: url_helper
INFO - 2017-08-21 06:33:51 --> Helper loaded: file_helper
INFO - 2017-08-21 06:33:51 --> Database Driver Class Initialized
INFO - 2017-08-21 06:33:51 --> Email Class Initialized
DEBUG - 2017-08-21 06:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:33:51 --> Table Class Initialized
INFO - 2017-08-21 06:33:51 --> Controller Class Initialized
INFO - 2017-08-21 06:33:51 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:33:51 --> The path to the image is not correct.
INFO - 2017-08-21 06:33:51 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:33:51 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:33:51 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:34:02 --> Config Class Initialized
INFO - 2017-08-21 06:34:02 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:34:02 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:34:02 --> Utf8 Class Initialized
INFO - 2017-08-21 06:34:02 --> URI Class Initialized
INFO - 2017-08-21 06:34:02 --> Router Class Initialized
INFO - 2017-08-21 06:34:02 --> Output Class Initialized
INFO - 2017-08-21 06:34:02 --> Security Class Initialized
DEBUG - 2017-08-21 06:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:34:02 --> Input Class Initialized
INFO - 2017-08-21 06:34:02 --> Language Class Initialized
INFO - 2017-08-21 06:34:02 --> Loader Class Initialized
INFO - 2017-08-21 06:34:02 --> Helper loaded: url_helper
INFO - 2017-08-21 06:34:02 --> Helper loaded: file_helper
INFO - 2017-08-21 06:34:02 --> Database Driver Class Initialized
INFO - 2017-08-21 06:34:02 --> Email Class Initialized
DEBUG - 2017-08-21 06:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:34:02 --> Table Class Initialized
INFO - 2017-08-21 06:34:02 --> Controller Class Initialized
INFO - 2017-08-21 06:34:02 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:34:02 --> The path to the image is not correct.
INFO - 2017-08-21 06:34:02 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:34:02 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:34:02 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:35:16 --> Config Class Initialized
INFO - 2017-08-21 06:35:16 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:35:16 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:35:16 --> Utf8 Class Initialized
INFO - 2017-08-21 06:35:16 --> URI Class Initialized
INFO - 2017-08-21 06:35:16 --> Router Class Initialized
INFO - 2017-08-21 06:35:16 --> Output Class Initialized
INFO - 2017-08-21 06:35:16 --> Security Class Initialized
DEBUG - 2017-08-21 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:35:16 --> Input Class Initialized
INFO - 2017-08-21 06:35:16 --> Language Class Initialized
INFO - 2017-08-21 06:35:16 --> Loader Class Initialized
INFO - 2017-08-21 06:35:16 --> Helper loaded: url_helper
INFO - 2017-08-21 06:35:16 --> Helper loaded: file_helper
INFO - 2017-08-21 06:35:16 --> Database Driver Class Initialized
INFO - 2017-08-21 06:35:16 --> Email Class Initialized
DEBUG - 2017-08-21 06:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:35:16 --> Table Class Initialized
INFO - 2017-08-21 06:35:16 --> Controller Class Initialized
INFO - 2017-08-21 06:35:16 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:35:16 --> The path to the image is not correct.
INFO - 2017-08-21 06:35:16 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:35:16 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:35:16 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:35:33 --> Config Class Initialized
INFO - 2017-08-21 06:35:33 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:35:33 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:35:33 --> Utf8 Class Initialized
INFO - 2017-08-21 06:35:33 --> URI Class Initialized
INFO - 2017-08-21 06:35:33 --> Router Class Initialized
INFO - 2017-08-21 06:35:33 --> Output Class Initialized
INFO - 2017-08-21 06:35:33 --> Security Class Initialized
DEBUG - 2017-08-21 06:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:35:33 --> Input Class Initialized
INFO - 2017-08-21 06:35:33 --> Language Class Initialized
INFO - 2017-08-21 06:35:33 --> Loader Class Initialized
INFO - 2017-08-21 06:35:33 --> Helper loaded: url_helper
INFO - 2017-08-21 06:35:33 --> Helper loaded: file_helper
INFO - 2017-08-21 06:35:33 --> Database Driver Class Initialized
INFO - 2017-08-21 06:35:33 --> Email Class Initialized
DEBUG - 2017-08-21 06:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:35:33 --> Table Class Initialized
INFO - 2017-08-21 06:35:33 --> Controller Class Initialized
INFO - 2017-08-21 06:35:33 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:35:33 --> The path to the image is not correct.
INFO - 2017-08-21 06:35:33 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:35:33 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:35:33 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:36:50 --> Config Class Initialized
INFO - 2017-08-21 06:36:50 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:36:50 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:36:50 --> Utf8 Class Initialized
INFO - 2017-08-21 06:36:50 --> URI Class Initialized
INFO - 2017-08-21 06:36:50 --> Router Class Initialized
INFO - 2017-08-21 06:36:50 --> Output Class Initialized
INFO - 2017-08-21 06:36:50 --> Security Class Initialized
DEBUG - 2017-08-21 06:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:36:50 --> Input Class Initialized
INFO - 2017-08-21 06:36:50 --> Language Class Initialized
INFO - 2017-08-21 06:36:50 --> Loader Class Initialized
INFO - 2017-08-21 06:36:50 --> Helper loaded: url_helper
INFO - 2017-08-21 06:36:50 --> Helper loaded: file_helper
INFO - 2017-08-21 06:36:50 --> Database Driver Class Initialized
INFO - 2017-08-21 06:36:50 --> Email Class Initialized
DEBUG - 2017-08-21 06:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:36:50 --> Table Class Initialized
INFO - 2017-08-21 06:36:50 --> Controller Class Initialized
INFO - 2017-08-21 06:36:50 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:36:50 --> The path to the image is not correct.
INFO - 2017-08-21 06:36:50 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:36:50 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:36:50 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:36:52 --> Config Class Initialized
INFO - 2017-08-21 06:36:52 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:36:52 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:36:52 --> Utf8 Class Initialized
INFO - 2017-08-21 06:36:52 --> URI Class Initialized
INFO - 2017-08-21 06:36:52 --> Router Class Initialized
INFO - 2017-08-21 06:36:52 --> Output Class Initialized
INFO - 2017-08-21 06:36:52 --> Security Class Initialized
DEBUG - 2017-08-21 06:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:36:52 --> Input Class Initialized
INFO - 2017-08-21 06:36:52 --> Language Class Initialized
INFO - 2017-08-21 06:36:52 --> Loader Class Initialized
INFO - 2017-08-21 06:36:52 --> Helper loaded: url_helper
INFO - 2017-08-21 06:36:52 --> Helper loaded: file_helper
INFO - 2017-08-21 06:36:52 --> Database Driver Class Initialized
INFO - 2017-08-21 06:36:52 --> Email Class Initialized
DEBUG - 2017-08-21 06:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:36:52 --> Table Class Initialized
INFO - 2017-08-21 06:36:52 --> Controller Class Initialized
INFO - 2017-08-21 06:36:52 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:36:52 --> The path to the image is not correct.
INFO - 2017-08-21 06:36:52 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:36:52 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:36:52 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:37:08 --> Config Class Initialized
INFO - 2017-08-21 06:37:09 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:37:09 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:37:09 --> Utf8 Class Initialized
INFO - 2017-08-21 06:37:09 --> URI Class Initialized
INFO - 2017-08-21 06:37:09 --> Router Class Initialized
INFO - 2017-08-21 06:37:09 --> Output Class Initialized
INFO - 2017-08-21 06:37:09 --> Security Class Initialized
DEBUG - 2017-08-21 06:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:37:09 --> Input Class Initialized
INFO - 2017-08-21 06:37:09 --> Language Class Initialized
INFO - 2017-08-21 06:37:09 --> Loader Class Initialized
INFO - 2017-08-21 06:37:09 --> Helper loaded: url_helper
INFO - 2017-08-21 06:37:09 --> Helper loaded: file_helper
INFO - 2017-08-21 06:37:09 --> Database Driver Class Initialized
INFO - 2017-08-21 06:37:09 --> Email Class Initialized
DEBUG - 2017-08-21 06:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:37:09 --> Table Class Initialized
INFO - 2017-08-21 06:37:09 --> Controller Class Initialized
INFO - 2017-08-21 06:37:09 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:37:09 --> The path to the image is not correct.
INFO - 2017-08-21 06:37:09 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:37:09 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:37:09 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:37:19 --> Config Class Initialized
INFO - 2017-08-21 06:37:19 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:37:19 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:37:19 --> Utf8 Class Initialized
INFO - 2017-08-21 06:37:19 --> URI Class Initialized
INFO - 2017-08-21 06:37:19 --> Router Class Initialized
INFO - 2017-08-21 06:37:19 --> Output Class Initialized
INFO - 2017-08-21 06:37:19 --> Security Class Initialized
DEBUG - 2017-08-21 06:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:37:19 --> Input Class Initialized
INFO - 2017-08-21 06:37:19 --> Language Class Initialized
INFO - 2017-08-21 06:37:19 --> Loader Class Initialized
INFO - 2017-08-21 06:37:19 --> Helper loaded: url_helper
INFO - 2017-08-21 06:37:19 --> Helper loaded: file_helper
INFO - 2017-08-21 06:37:19 --> Database Driver Class Initialized
INFO - 2017-08-21 06:37:19 --> Email Class Initialized
DEBUG - 2017-08-21 06:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:37:19 --> Table Class Initialized
INFO - 2017-08-21 06:37:19 --> Controller Class Initialized
INFO - 2017-08-21 06:37:20 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:37:20 --> The path to the image is not correct.
INFO - 2017-08-21 06:37:20 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:37:20 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:37:20 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:38:34 --> Config Class Initialized
INFO - 2017-08-21 06:38:34 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:38:34 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:38:34 --> Utf8 Class Initialized
INFO - 2017-08-21 06:38:34 --> URI Class Initialized
INFO - 2017-08-21 06:38:34 --> Router Class Initialized
INFO - 2017-08-21 06:38:34 --> Output Class Initialized
INFO - 2017-08-21 06:38:34 --> Security Class Initialized
DEBUG - 2017-08-21 06:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:38:34 --> Input Class Initialized
INFO - 2017-08-21 06:38:34 --> Language Class Initialized
INFO - 2017-08-21 06:38:34 --> Loader Class Initialized
INFO - 2017-08-21 06:38:34 --> Helper loaded: url_helper
INFO - 2017-08-21 06:38:34 --> Helper loaded: file_helper
INFO - 2017-08-21 06:38:34 --> Database Driver Class Initialized
INFO - 2017-08-21 06:38:34 --> Email Class Initialized
DEBUG - 2017-08-21 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:38:34 --> Table Class Initialized
INFO - 2017-08-21 06:38:34 --> Controller Class Initialized
INFO - 2017-08-21 06:38:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:38:34 --> Final output sent to browser
DEBUG - 2017-08-21 06:38:34 --> Total execution time: 0.1673
INFO - 2017-08-21 06:38:35 --> Config Class Initialized
INFO - 2017-08-21 06:38:35 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:38:35 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:38:35 --> Utf8 Class Initialized
INFO - 2017-08-21 06:38:35 --> URI Class Initialized
INFO - 2017-08-21 06:38:35 --> Router Class Initialized
INFO - 2017-08-21 06:38:35 --> Output Class Initialized
INFO - 2017-08-21 06:38:35 --> Security Class Initialized
DEBUG - 2017-08-21 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:38:35 --> Input Class Initialized
INFO - 2017-08-21 06:38:35 --> Language Class Initialized
ERROR - 2017-08-21 06:38:35 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 06:38:57 --> Config Class Initialized
INFO - 2017-08-21 06:38:57 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:38:57 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:38:57 --> Utf8 Class Initialized
INFO - 2017-08-21 06:38:57 --> URI Class Initialized
INFO - 2017-08-21 06:38:57 --> Router Class Initialized
INFO - 2017-08-21 06:38:57 --> Output Class Initialized
INFO - 2017-08-21 06:38:57 --> Security Class Initialized
DEBUG - 2017-08-21 06:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:38:57 --> Input Class Initialized
INFO - 2017-08-21 06:38:57 --> Language Class Initialized
INFO - 2017-08-21 06:38:57 --> Loader Class Initialized
INFO - 2017-08-21 06:38:57 --> Helper loaded: url_helper
INFO - 2017-08-21 06:38:57 --> Helper loaded: file_helper
INFO - 2017-08-21 06:38:57 --> Database Driver Class Initialized
INFO - 2017-08-21 06:38:57 --> Email Class Initialized
DEBUG - 2017-08-21 06:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:38:57 --> Table Class Initialized
INFO - 2017-08-21 06:38:57 --> Controller Class Initialized
INFO - 2017-08-21 06:38:57 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:38:57 --> The path to the image is not correct.
INFO - 2017-08-21 06:38:57 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:38:57 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 81
ERROR - 2017-08-21 06:38:57 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 81
INFO - 2017-08-21 06:39:17 --> Config Class Initialized
INFO - 2017-08-21 06:39:17 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:39:17 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:39:17 --> Utf8 Class Initialized
INFO - 2017-08-21 06:39:17 --> URI Class Initialized
INFO - 2017-08-21 06:39:17 --> Router Class Initialized
INFO - 2017-08-21 06:39:17 --> Output Class Initialized
INFO - 2017-08-21 06:39:17 --> Security Class Initialized
DEBUG - 2017-08-21 06:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:39:17 --> Input Class Initialized
INFO - 2017-08-21 06:39:17 --> Language Class Initialized
INFO - 2017-08-21 06:39:17 --> Loader Class Initialized
INFO - 2017-08-21 06:39:17 --> Helper loaded: url_helper
INFO - 2017-08-21 06:39:17 --> Helper loaded: file_helper
INFO - 2017-08-21 06:39:17 --> Database Driver Class Initialized
INFO - 2017-08-21 06:39:17 --> Email Class Initialized
DEBUG - 2017-08-21 06:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:39:17 --> Table Class Initialized
INFO - 2017-08-21 06:39:17 --> Controller Class Initialized
INFO - 2017-08-21 06:39:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:39:17 --> Final output sent to browser
DEBUG - 2017-08-21 06:39:17 --> Total execution time: 0.1811
INFO - 2017-08-21 06:39:23 --> Config Class Initialized
INFO - 2017-08-21 06:39:23 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:39:23 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:39:23 --> Utf8 Class Initialized
INFO - 2017-08-21 06:39:23 --> URI Class Initialized
INFO - 2017-08-21 06:39:23 --> Router Class Initialized
INFO - 2017-08-21 06:39:23 --> Output Class Initialized
INFO - 2017-08-21 06:39:23 --> Security Class Initialized
DEBUG - 2017-08-21 06:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:39:23 --> Input Class Initialized
INFO - 2017-08-21 06:39:23 --> Language Class Initialized
INFO - 2017-08-21 06:39:23 --> Loader Class Initialized
INFO - 2017-08-21 06:39:23 --> Helper loaded: url_helper
INFO - 2017-08-21 06:39:23 --> Helper loaded: file_helper
INFO - 2017-08-21 06:39:23 --> Database Driver Class Initialized
INFO - 2017-08-21 06:39:23 --> Email Class Initialized
DEBUG - 2017-08-21 06:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:39:23 --> Table Class Initialized
INFO - 2017-08-21 06:39:23 --> Controller Class Initialized
INFO - 2017-08-21 06:39:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:39:23 --> Final output sent to browser
DEBUG - 2017-08-21 06:39:23 --> Total execution time: 0.1737
INFO - 2017-08-21 06:39:31 --> Config Class Initialized
INFO - 2017-08-21 06:39:31 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:39:31 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:39:31 --> Utf8 Class Initialized
INFO - 2017-08-21 06:39:31 --> URI Class Initialized
INFO - 2017-08-21 06:39:31 --> Router Class Initialized
INFO - 2017-08-21 06:39:31 --> Output Class Initialized
INFO - 2017-08-21 06:39:31 --> Security Class Initialized
DEBUG - 2017-08-21 06:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:39:31 --> Input Class Initialized
INFO - 2017-08-21 06:39:31 --> Language Class Initialized
INFO - 2017-08-21 06:39:31 --> Loader Class Initialized
INFO - 2017-08-21 06:39:31 --> Helper loaded: url_helper
INFO - 2017-08-21 06:39:31 --> Helper loaded: file_helper
INFO - 2017-08-21 06:39:31 --> Database Driver Class Initialized
INFO - 2017-08-21 06:39:31 --> Email Class Initialized
DEBUG - 2017-08-21 06:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:39:31 --> Table Class Initialized
INFO - 2017-08-21 06:39:31 --> Controller Class Initialized
INFO - 2017-08-21 06:39:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:39:31 --> Final output sent to browser
DEBUG - 2017-08-21 06:39:31 --> Total execution time: 0.1653
INFO - 2017-08-21 06:39:40 --> Config Class Initialized
INFO - 2017-08-21 06:39:40 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:39:40 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:39:40 --> Utf8 Class Initialized
INFO - 2017-08-21 06:39:40 --> URI Class Initialized
INFO - 2017-08-21 06:39:41 --> Router Class Initialized
INFO - 2017-08-21 06:39:41 --> Output Class Initialized
INFO - 2017-08-21 06:39:41 --> Security Class Initialized
DEBUG - 2017-08-21 06:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:39:41 --> Input Class Initialized
INFO - 2017-08-21 06:39:41 --> Language Class Initialized
INFO - 2017-08-21 06:39:41 --> Loader Class Initialized
INFO - 2017-08-21 06:39:41 --> Helper loaded: url_helper
INFO - 2017-08-21 06:39:41 --> Helper loaded: file_helper
INFO - 2017-08-21 06:39:41 --> Database Driver Class Initialized
INFO - 2017-08-21 06:39:41 --> Email Class Initialized
DEBUG - 2017-08-21 06:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:39:41 --> Table Class Initialized
INFO - 2017-08-21 06:39:41 --> Controller Class Initialized
INFO - 2017-08-21 06:39:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:39:41 --> Final output sent to browser
DEBUG - 2017-08-21 06:39:41 --> Total execution time: 0.1660
INFO - 2017-08-21 06:39:42 --> Config Class Initialized
INFO - 2017-08-21 06:39:42 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:39:42 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:39:42 --> Utf8 Class Initialized
INFO - 2017-08-21 06:39:42 --> URI Class Initialized
INFO - 2017-08-21 06:39:42 --> Router Class Initialized
INFO - 2017-08-21 06:39:42 --> Output Class Initialized
INFO - 2017-08-21 06:39:42 --> Security Class Initialized
DEBUG - 2017-08-21 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:39:42 --> Input Class Initialized
INFO - 2017-08-21 06:39:42 --> Language Class Initialized
INFO - 2017-08-21 06:39:42 --> Loader Class Initialized
INFO - 2017-08-21 06:39:42 --> Helper loaded: url_helper
INFO - 2017-08-21 06:39:42 --> Helper loaded: file_helper
INFO - 2017-08-21 06:39:42 --> Database Driver Class Initialized
INFO - 2017-08-21 06:39:42 --> Email Class Initialized
DEBUG - 2017-08-21 06:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:39:42 --> Table Class Initialized
INFO - 2017-08-21 06:39:42 --> Controller Class Initialized
INFO - 2017-08-21 06:39:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:39:42 --> Final output sent to browser
DEBUG - 2017-08-21 06:39:42 --> Total execution time: 0.1620
INFO - 2017-08-21 06:40:13 --> Config Class Initialized
INFO - 2017-08-21 06:40:13 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:40:13 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:40:13 --> Utf8 Class Initialized
INFO - 2017-08-21 06:40:13 --> URI Class Initialized
INFO - 2017-08-21 06:40:13 --> Router Class Initialized
INFO - 2017-08-21 06:40:13 --> Output Class Initialized
INFO - 2017-08-21 06:40:13 --> Security Class Initialized
DEBUG - 2017-08-21 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:40:13 --> Input Class Initialized
INFO - 2017-08-21 06:40:13 --> Language Class Initialized
INFO - 2017-08-21 06:40:13 --> Loader Class Initialized
INFO - 2017-08-21 06:40:13 --> Helper loaded: url_helper
INFO - 2017-08-21 06:40:13 --> Helper loaded: file_helper
INFO - 2017-08-21 06:40:13 --> Database Driver Class Initialized
INFO - 2017-08-21 06:40:13 --> Email Class Initialized
DEBUG - 2017-08-21 06:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:40:13 --> Table Class Initialized
INFO - 2017-08-21 06:40:13 --> Controller Class Initialized
ERROR - 2017-08-21 06:40:13 --> Severity: Notice --> Use of undefined constant abc - assumed 'abc' C:\xampp\htdocs\biokimia\application\views\Article.php 205
INFO - 2017-08-21 06:40:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:40:13 --> Final output sent to browser
DEBUG - 2017-08-21 06:40:13 --> Total execution time: 0.1820
INFO - 2017-08-21 06:40:13 --> Config Class Initialized
INFO - 2017-08-21 06:40:13 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:40:13 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:40:13 --> Utf8 Class Initialized
INFO - 2017-08-21 06:40:13 --> URI Class Initialized
INFO - 2017-08-21 06:40:13 --> Router Class Initialized
INFO - 2017-08-21 06:40:13 --> Output Class Initialized
INFO - 2017-08-21 06:40:13 --> Security Class Initialized
DEBUG - 2017-08-21 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:40:13 --> Input Class Initialized
INFO - 2017-08-21 06:40:13 --> Language Class Initialized
ERROR - 2017-08-21 06:40:13 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 06:40:39 --> Config Class Initialized
INFO - 2017-08-21 06:40:39 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:40:39 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:40:39 --> Utf8 Class Initialized
INFO - 2017-08-21 06:40:39 --> URI Class Initialized
INFO - 2017-08-21 06:40:39 --> Router Class Initialized
INFO - 2017-08-21 06:40:39 --> Output Class Initialized
INFO - 2017-08-21 06:40:39 --> Security Class Initialized
DEBUG - 2017-08-21 06:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:40:39 --> Input Class Initialized
INFO - 2017-08-21 06:40:39 --> Language Class Initialized
INFO - 2017-08-21 06:40:39 --> Loader Class Initialized
INFO - 2017-08-21 06:40:39 --> Helper loaded: url_helper
INFO - 2017-08-21 06:40:39 --> Helper loaded: file_helper
INFO - 2017-08-21 06:40:39 --> Database Driver Class Initialized
INFO - 2017-08-21 06:40:39 --> Email Class Initialized
DEBUG - 2017-08-21 06:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:40:39 --> Table Class Initialized
INFO - 2017-08-21 06:40:39 --> Controller Class Initialized
ERROR - 2017-08-21 06:40:39 --> Severity: Parsing Error --> syntax error, unexpected 'abc' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\biokimia\application\views\Article.php 205
INFO - 2017-08-21 06:41:12 --> Config Class Initialized
INFO - 2017-08-21 06:41:12 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:41:12 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:41:12 --> Utf8 Class Initialized
INFO - 2017-08-21 06:41:12 --> URI Class Initialized
INFO - 2017-08-21 06:41:12 --> Router Class Initialized
INFO - 2017-08-21 06:41:12 --> Output Class Initialized
INFO - 2017-08-21 06:41:12 --> Security Class Initialized
DEBUG - 2017-08-21 06:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:41:12 --> Input Class Initialized
INFO - 2017-08-21 06:41:12 --> Language Class Initialized
INFO - 2017-08-21 06:41:12 --> Loader Class Initialized
INFO - 2017-08-21 06:41:12 --> Helper loaded: url_helper
INFO - 2017-08-21 06:41:12 --> Helper loaded: file_helper
INFO - 2017-08-21 06:41:12 --> Database Driver Class Initialized
INFO - 2017-08-21 06:41:12 --> Email Class Initialized
DEBUG - 2017-08-21 06:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:41:12 --> Table Class Initialized
INFO - 2017-08-21 06:41:12 --> Controller Class Initialized
INFO - 2017-08-21 06:41:12 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:41:12 --> Final output sent to browser
DEBUG - 2017-08-21 06:41:12 --> Total execution time: 0.1776
INFO - 2017-08-21 06:41:12 --> Config Class Initialized
INFO - 2017-08-21 06:41:12 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:41:12 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:41:12 --> Utf8 Class Initialized
INFO - 2017-08-21 06:41:12 --> URI Class Initialized
INFO - 2017-08-21 06:41:12 --> Router Class Initialized
INFO - 2017-08-21 06:41:12 --> Output Class Initialized
INFO - 2017-08-21 06:41:12 --> Security Class Initialized
DEBUG - 2017-08-21 06:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:41:12 --> Input Class Initialized
INFO - 2017-08-21 06:41:12 --> Language Class Initialized
ERROR - 2017-08-21 06:41:12 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 06:41:44 --> Config Class Initialized
INFO - 2017-08-21 06:41:44 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:41:44 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:41:44 --> Utf8 Class Initialized
INFO - 2017-08-21 06:41:44 --> URI Class Initialized
INFO - 2017-08-21 06:41:44 --> Router Class Initialized
INFO - 2017-08-21 06:41:44 --> Output Class Initialized
INFO - 2017-08-21 06:41:44 --> Security Class Initialized
DEBUG - 2017-08-21 06:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:41:44 --> Input Class Initialized
INFO - 2017-08-21 06:41:44 --> Language Class Initialized
INFO - 2017-08-21 06:41:44 --> Loader Class Initialized
INFO - 2017-08-21 06:41:44 --> Helper loaded: url_helper
INFO - 2017-08-21 06:41:44 --> Helper loaded: file_helper
INFO - 2017-08-21 06:41:44 --> Database Driver Class Initialized
INFO - 2017-08-21 06:41:44 --> Email Class Initialized
DEBUG - 2017-08-21 06:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:41:44 --> Table Class Initialized
INFO - 2017-08-21 06:41:44 --> Controller Class Initialized
INFO - 2017-08-21 06:41:44 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:41:44 --> The path to the image is not correct.
INFO - 2017-08-21 06:41:44 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:41:44 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 82
ERROR - 2017-08-21 06:41:44 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 82
INFO - 2017-08-21 06:41:53 --> Config Class Initialized
INFO - 2017-08-21 06:41:53 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:41:53 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:41:53 --> Utf8 Class Initialized
INFO - 2017-08-21 06:41:54 --> URI Class Initialized
INFO - 2017-08-21 06:41:54 --> Router Class Initialized
INFO - 2017-08-21 06:41:54 --> Output Class Initialized
INFO - 2017-08-21 06:41:54 --> Security Class Initialized
DEBUG - 2017-08-21 06:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:41:54 --> Input Class Initialized
INFO - 2017-08-21 06:41:54 --> Language Class Initialized
INFO - 2017-08-21 06:41:54 --> Loader Class Initialized
INFO - 2017-08-21 06:41:54 --> Helper loaded: url_helper
INFO - 2017-08-21 06:41:54 --> Helper loaded: file_helper
INFO - 2017-08-21 06:41:54 --> Database Driver Class Initialized
INFO - 2017-08-21 06:41:54 --> Email Class Initialized
DEBUG - 2017-08-21 06:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:41:54 --> Table Class Initialized
INFO - 2017-08-21 06:41:54 --> Controller Class Initialized
INFO - 2017-08-21 06:41:54 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:41:54 --> The path to the image is not correct.
INFO - 2017-08-21 06:41:54 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:41:54 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 82
ERROR - 2017-08-21 06:41:54 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 82
INFO - 2017-08-21 06:42:04 --> Config Class Initialized
INFO - 2017-08-21 06:42:04 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:42:04 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:42:04 --> Utf8 Class Initialized
INFO - 2017-08-21 06:42:04 --> URI Class Initialized
INFO - 2017-08-21 06:42:04 --> Router Class Initialized
INFO - 2017-08-21 06:42:04 --> Output Class Initialized
INFO - 2017-08-21 06:42:04 --> Security Class Initialized
DEBUG - 2017-08-21 06:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:42:04 --> Input Class Initialized
INFO - 2017-08-21 06:42:04 --> Language Class Initialized
INFO - 2017-08-21 06:42:04 --> Loader Class Initialized
INFO - 2017-08-21 06:42:04 --> Helper loaded: url_helper
INFO - 2017-08-21 06:42:04 --> Helper loaded: file_helper
INFO - 2017-08-21 06:42:04 --> Database Driver Class Initialized
INFO - 2017-08-21 06:42:04 --> Email Class Initialized
DEBUG - 2017-08-21 06:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:42:04 --> Table Class Initialized
INFO - 2017-08-21 06:42:04 --> Controller Class Initialized
INFO - 2017-08-21 06:42:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:42:04 --> Final output sent to browser
DEBUG - 2017-08-21 06:42:04 --> Total execution time: 0.1836
INFO - 2017-08-21 06:42:05 --> Config Class Initialized
INFO - 2017-08-21 06:42:05 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:42:05 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:42:05 --> Utf8 Class Initialized
INFO - 2017-08-21 06:42:05 --> URI Class Initialized
INFO - 2017-08-21 06:42:05 --> Router Class Initialized
INFO - 2017-08-21 06:42:05 --> Output Class Initialized
INFO - 2017-08-21 06:42:05 --> Security Class Initialized
DEBUG - 2017-08-21 06:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:42:05 --> Input Class Initialized
INFO - 2017-08-21 06:42:05 --> Language Class Initialized
ERROR - 2017-08-21 06:42:05 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 06:42:11 --> Config Class Initialized
INFO - 2017-08-21 06:42:11 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:42:11 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:42:11 --> Utf8 Class Initialized
INFO - 2017-08-21 06:42:11 --> URI Class Initialized
INFO - 2017-08-21 06:42:11 --> Router Class Initialized
INFO - 2017-08-21 06:42:11 --> Output Class Initialized
INFO - 2017-08-21 06:42:11 --> Security Class Initialized
DEBUG - 2017-08-21 06:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:42:11 --> Input Class Initialized
INFO - 2017-08-21 06:42:11 --> Language Class Initialized
INFO - 2017-08-21 06:42:11 --> Loader Class Initialized
INFO - 2017-08-21 06:42:11 --> Helper loaded: url_helper
INFO - 2017-08-21 06:42:11 --> Helper loaded: file_helper
INFO - 2017-08-21 06:42:11 --> Database Driver Class Initialized
INFO - 2017-08-21 06:42:11 --> Email Class Initialized
DEBUG - 2017-08-21 06:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:42:11 --> Table Class Initialized
INFO - 2017-08-21 06:42:11 --> Controller Class Initialized
INFO - 2017-08-21 06:42:11 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:42:11 --> The path to the image is not correct.
INFO - 2017-08-21 06:42:11 --> Image Lib Class Initialized
INFO - 2017-08-21 06:42:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:42:11 --> Final output sent to browser
DEBUG - 2017-08-21 06:42:11 --> Total execution time: 0.1939
INFO - 2017-08-21 06:42:11 --> Config Class Initialized
INFO - 2017-08-21 06:42:11 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:42:11 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:42:11 --> Utf8 Class Initialized
INFO - 2017-08-21 06:42:11 --> URI Class Initialized
INFO - 2017-08-21 06:42:11 --> Router Class Initialized
INFO - 2017-08-21 06:42:11 --> Output Class Initialized
INFO - 2017-08-21 06:42:11 --> Security Class Initialized
DEBUG - 2017-08-21 06:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:42:11 --> Input Class Initialized
INFO - 2017-08-21 06:42:11 --> Language Class Initialized
ERROR - 2017-08-21 06:42:11 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 06:42:14 --> Config Class Initialized
INFO - 2017-08-21 06:42:14 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:42:14 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:42:14 --> Utf8 Class Initialized
INFO - 2017-08-21 06:42:14 --> URI Class Initialized
INFO - 2017-08-21 06:42:14 --> Router Class Initialized
INFO - 2017-08-21 06:42:14 --> Output Class Initialized
INFO - 2017-08-21 06:42:14 --> Security Class Initialized
DEBUG - 2017-08-21 06:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:42:14 --> Input Class Initialized
INFO - 2017-08-21 06:42:14 --> Language Class Initialized
INFO - 2017-08-21 06:42:14 --> Loader Class Initialized
INFO - 2017-08-21 06:42:14 --> Helper loaded: url_helper
INFO - 2017-08-21 06:42:14 --> Helper loaded: file_helper
INFO - 2017-08-21 06:42:14 --> Database Driver Class Initialized
INFO - 2017-08-21 06:42:14 --> Email Class Initialized
DEBUG - 2017-08-21 06:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:42:14 --> Table Class Initialized
INFO - 2017-08-21 06:42:14 --> Controller Class Initialized
INFO - 2017-08-21 06:42:14 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:42:14 --> The path to the image is not correct.
INFO - 2017-08-21 06:42:14 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:42:14 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 82
ERROR - 2017-08-21 06:42:14 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 82
INFO - 2017-08-21 06:42:24 --> Config Class Initialized
INFO - 2017-08-21 06:42:24 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:42:24 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:42:24 --> Utf8 Class Initialized
INFO - 2017-08-21 06:42:24 --> URI Class Initialized
INFO - 2017-08-21 06:42:24 --> Router Class Initialized
INFO - 2017-08-21 06:42:24 --> Output Class Initialized
INFO - 2017-08-21 06:42:24 --> Security Class Initialized
DEBUG - 2017-08-21 06:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:42:24 --> Input Class Initialized
INFO - 2017-08-21 06:42:24 --> Language Class Initialized
INFO - 2017-08-21 06:42:24 --> Loader Class Initialized
INFO - 2017-08-21 06:42:24 --> Helper loaded: url_helper
INFO - 2017-08-21 06:42:24 --> Helper loaded: file_helper
INFO - 2017-08-21 06:42:24 --> Database Driver Class Initialized
INFO - 2017-08-21 06:42:24 --> Email Class Initialized
DEBUG - 2017-08-21 06:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:42:24 --> Table Class Initialized
INFO - 2017-08-21 06:42:24 --> Controller Class Initialized
INFO - 2017-08-21 06:42:24 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:42:24 --> The path to the image is not correct.
INFO - 2017-08-21 06:42:24 --> Image Lib Class Initialized
INFO - 2017-08-21 06:42:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:42:24 --> Final output sent to browser
DEBUG - 2017-08-21 06:42:24 --> Total execution time: 0.2023
INFO - 2017-08-21 06:42:24 --> Config Class Initialized
INFO - 2017-08-21 06:42:24 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:42:24 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:42:24 --> Utf8 Class Initialized
INFO - 2017-08-21 06:42:24 --> URI Class Initialized
INFO - 2017-08-21 06:42:24 --> Router Class Initialized
INFO - 2017-08-21 06:42:24 --> Output Class Initialized
INFO - 2017-08-21 06:42:24 --> Security Class Initialized
DEBUG - 2017-08-21 06:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:42:24 --> Input Class Initialized
INFO - 2017-08-21 06:42:24 --> Language Class Initialized
ERROR - 2017-08-21 06:42:24 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 06:42:44 --> Config Class Initialized
INFO - 2017-08-21 06:42:44 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:42:44 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:42:44 --> Utf8 Class Initialized
INFO - 2017-08-21 06:42:44 --> URI Class Initialized
INFO - 2017-08-21 06:42:44 --> Router Class Initialized
INFO - 2017-08-21 06:42:44 --> Output Class Initialized
INFO - 2017-08-21 06:42:44 --> Security Class Initialized
DEBUG - 2017-08-21 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:42:44 --> Input Class Initialized
INFO - 2017-08-21 06:42:44 --> Language Class Initialized
INFO - 2017-08-21 06:42:44 --> Loader Class Initialized
INFO - 2017-08-21 06:42:44 --> Helper loaded: url_helper
INFO - 2017-08-21 06:42:44 --> Helper loaded: file_helper
INFO - 2017-08-21 06:42:44 --> Database Driver Class Initialized
INFO - 2017-08-21 06:42:44 --> Email Class Initialized
DEBUG - 2017-08-21 06:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:42:44 --> Table Class Initialized
INFO - 2017-08-21 06:42:44 --> Controller Class Initialized
INFO - 2017-08-21 06:42:44 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:42:44 --> The path to the image is not correct.
INFO - 2017-08-21 06:42:44 --> Image Lib Class Initialized
INFO - 2017-08-21 06:42:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:42:44 --> Final output sent to browser
DEBUG - 2017-08-21 06:42:44 --> Total execution time: 0.1977
INFO - 2017-08-21 06:42:44 --> Config Class Initialized
INFO - 2017-08-21 06:42:44 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:42:44 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:42:44 --> Utf8 Class Initialized
INFO - 2017-08-21 06:42:44 --> URI Class Initialized
INFO - 2017-08-21 06:42:44 --> Router Class Initialized
INFO - 2017-08-21 06:42:44 --> Output Class Initialized
INFO - 2017-08-21 06:42:44 --> Security Class Initialized
DEBUG - 2017-08-21 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:42:44 --> Input Class Initialized
INFO - 2017-08-21 06:42:44 --> Language Class Initialized
ERROR - 2017-08-21 06:42:44 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 06:43:04 --> Config Class Initialized
INFO - 2017-08-21 06:43:04 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:43:04 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:43:04 --> Utf8 Class Initialized
INFO - 2017-08-21 06:43:04 --> URI Class Initialized
INFO - 2017-08-21 06:43:04 --> Router Class Initialized
INFO - 2017-08-21 06:43:04 --> Output Class Initialized
INFO - 2017-08-21 06:43:04 --> Security Class Initialized
DEBUG - 2017-08-21 06:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:43:04 --> Input Class Initialized
INFO - 2017-08-21 06:43:04 --> Language Class Initialized
INFO - 2017-08-21 06:43:04 --> Loader Class Initialized
INFO - 2017-08-21 06:43:05 --> Helper loaded: url_helper
INFO - 2017-08-21 06:43:05 --> Helper loaded: file_helper
INFO - 2017-08-21 06:43:05 --> Database Driver Class Initialized
INFO - 2017-08-21 06:43:05 --> Email Class Initialized
DEBUG - 2017-08-21 06:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:43:05 --> Table Class Initialized
INFO - 2017-08-21 06:43:05 --> Controller Class Initialized
INFO - 2017-08-21 06:43:05 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:43:05 --> The path to the image is not correct.
INFO - 2017-08-21 06:43:05 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:43:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\biokimia\application\views\Article.php 218
INFO - 2017-08-21 06:43:05 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:43:05 --> Final output sent to browser
DEBUG - 2017-08-21 06:43:05 --> Total execution time: 0.2044
INFO - 2017-08-21 06:43:05 --> Config Class Initialized
INFO - 2017-08-21 06:43:05 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:43:05 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:43:05 --> Utf8 Class Initialized
INFO - 2017-08-21 06:43:05 --> URI Class Initialized
INFO - 2017-08-21 06:43:05 --> Router Class Initialized
INFO - 2017-08-21 06:43:05 --> Output Class Initialized
INFO - 2017-08-21 06:43:05 --> Security Class Initialized
DEBUG - 2017-08-21 06:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:43:05 --> Input Class Initialized
INFO - 2017-08-21 06:43:05 --> Language Class Initialized
ERROR - 2017-08-21 06:43:05 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 06:43:44 --> Config Class Initialized
INFO - 2017-08-21 06:43:44 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:43:44 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:43:44 --> Utf8 Class Initialized
INFO - 2017-08-21 06:43:44 --> URI Class Initialized
INFO - 2017-08-21 06:43:44 --> Router Class Initialized
INFO - 2017-08-21 06:43:44 --> Output Class Initialized
INFO - 2017-08-21 06:43:44 --> Security Class Initialized
DEBUG - 2017-08-21 06:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:43:44 --> Input Class Initialized
INFO - 2017-08-21 06:43:44 --> Language Class Initialized
INFO - 2017-08-21 06:43:44 --> Loader Class Initialized
INFO - 2017-08-21 06:43:44 --> Helper loaded: url_helper
INFO - 2017-08-21 06:43:44 --> Helper loaded: file_helper
INFO - 2017-08-21 06:43:44 --> Database Driver Class Initialized
INFO - 2017-08-21 06:43:44 --> Email Class Initialized
DEBUG - 2017-08-21 06:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:43:44 --> Table Class Initialized
INFO - 2017-08-21 06:43:44 --> Controller Class Initialized
INFO - 2017-08-21 06:43:44 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:43:44 --> The path to the image is not correct.
INFO - 2017-08-21 06:43:44 --> Image Lib Class Initialized
INFO - 2017-08-21 06:43:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:43:44 --> Final output sent to browser
DEBUG - 2017-08-21 06:43:44 --> Total execution time: 0.1982
INFO - 2017-08-21 06:43:44 --> Config Class Initialized
INFO - 2017-08-21 06:43:44 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:43:44 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:43:44 --> Utf8 Class Initialized
INFO - 2017-08-21 06:43:44 --> URI Class Initialized
INFO - 2017-08-21 06:43:44 --> Router Class Initialized
INFO - 2017-08-21 06:43:44 --> Output Class Initialized
INFO - 2017-08-21 06:43:44 --> Security Class Initialized
DEBUG - 2017-08-21 06:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:43:44 --> Input Class Initialized
INFO - 2017-08-21 06:43:44 --> Language Class Initialized
ERROR - 2017-08-21 06:43:44 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 06:43:47 --> Config Class Initialized
INFO - 2017-08-21 06:43:47 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:43:47 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:43:47 --> Utf8 Class Initialized
INFO - 2017-08-21 06:43:47 --> URI Class Initialized
INFO - 2017-08-21 06:43:47 --> Router Class Initialized
INFO - 2017-08-21 06:43:47 --> Output Class Initialized
INFO - 2017-08-21 06:43:47 --> Security Class Initialized
DEBUG - 2017-08-21 06:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:43:47 --> Input Class Initialized
INFO - 2017-08-21 06:43:47 --> Language Class Initialized
INFO - 2017-08-21 06:43:47 --> Loader Class Initialized
INFO - 2017-08-21 06:43:47 --> Helper loaded: url_helper
INFO - 2017-08-21 06:43:47 --> Helper loaded: file_helper
INFO - 2017-08-21 06:43:47 --> Database Driver Class Initialized
INFO - 2017-08-21 06:43:47 --> Email Class Initialized
DEBUG - 2017-08-21 06:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:43:47 --> Table Class Initialized
INFO - 2017-08-21 06:43:47 --> Controller Class Initialized
INFO - 2017-08-21 06:43:47 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 06:43:47 --> The path to the image is not correct.
INFO - 2017-08-21 06:43:47 --> Image Lib Class Initialized
ERROR - 2017-08-21 06:43:47 --> Severity: Notice --> Undefined property: CI_Loader::$image_lib C:\xampp\htdocs\biokimia\application\views\Article.php 82
ERROR - 2017-08-21 06:43:47 --> Severity: Error --> Call to a member function resize() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 82
INFO - 2017-08-21 06:44:51 --> Config Class Initialized
INFO - 2017-08-21 06:44:51 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:44:51 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:44:51 --> Utf8 Class Initialized
INFO - 2017-08-21 06:44:51 --> URI Class Initialized
INFO - 2017-08-21 06:44:51 --> Router Class Initialized
INFO - 2017-08-21 06:44:51 --> Output Class Initialized
INFO - 2017-08-21 06:44:51 --> Security Class Initialized
DEBUG - 2017-08-21 06:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:44:51 --> Input Class Initialized
INFO - 2017-08-21 06:44:51 --> Language Class Initialized
INFO - 2017-08-21 06:44:51 --> Loader Class Initialized
INFO - 2017-08-21 06:44:51 --> Helper loaded: url_helper
INFO - 2017-08-21 06:44:51 --> Helper loaded: file_helper
INFO - 2017-08-21 06:44:51 --> Database Driver Class Initialized
INFO - 2017-08-21 06:44:51 --> Email Class Initialized
DEBUG - 2017-08-21 06:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:44:51 --> Table Class Initialized
INFO - 2017-08-21 06:44:51 --> Controller Class Initialized
INFO - 2017-08-21 06:44:51 --> Image Lib Class Initialized
DEBUG - 2017-08-21 06:44:51 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2017-08-21 06:44:51 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:44:51 --> Final output sent to browser
DEBUG - 2017-08-21 06:44:51 --> Total execution time: 0.2052
INFO - 2017-08-21 06:44:51 --> Config Class Initialized
INFO - 2017-08-21 06:44:51 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:44:51 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:44:51 --> Utf8 Class Initialized
INFO - 2017-08-21 06:44:51 --> URI Class Initialized
INFO - 2017-08-21 06:44:51 --> Router Class Initialized
INFO - 2017-08-21 06:44:51 --> Output Class Initialized
INFO - 2017-08-21 06:44:51 --> Security Class Initialized
DEBUG - 2017-08-21 06:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:44:51 --> Input Class Initialized
INFO - 2017-08-21 06:44:51 --> Language Class Initialized
ERROR - 2017-08-21 06:44:51 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 06:44:54 --> Config Class Initialized
INFO - 2017-08-21 06:44:54 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:44:54 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:44:54 --> Utf8 Class Initialized
INFO - 2017-08-21 06:44:54 --> URI Class Initialized
INFO - 2017-08-21 06:44:54 --> Router Class Initialized
INFO - 2017-08-21 06:44:54 --> Output Class Initialized
INFO - 2017-08-21 06:44:54 --> Security Class Initialized
DEBUG - 2017-08-21 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:44:54 --> Input Class Initialized
INFO - 2017-08-21 06:44:54 --> Language Class Initialized
INFO - 2017-08-21 06:44:54 --> Loader Class Initialized
INFO - 2017-08-21 06:44:54 --> Helper loaded: url_helper
INFO - 2017-08-21 06:44:54 --> Helper loaded: file_helper
INFO - 2017-08-21 06:44:54 --> Database Driver Class Initialized
INFO - 2017-08-21 06:44:54 --> Email Class Initialized
DEBUG - 2017-08-21 06:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:44:54 --> Table Class Initialized
INFO - 2017-08-21 06:44:54 --> Controller Class Initialized
INFO - 2017-08-21 06:44:54 --> Image Lib Class Initialized
DEBUG - 2017-08-21 06:44:54 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2017-08-21 06:44:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:44:54 --> Final output sent to browser
DEBUG - 2017-08-21 06:44:54 --> Total execution time: 0.1950
INFO - 2017-08-21 06:44:54 --> Config Class Initialized
INFO - 2017-08-21 06:44:54 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:44:54 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:44:54 --> Utf8 Class Initialized
INFO - 2017-08-21 06:44:54 --> URI Class Initialized
INFO - 2017-08-21 06:44:54 --> Router Class Initialized
INFO - 2017-08-21 06:44:54 --> Output Class Initialized
INFO - 2017-08-21 06:44:54 --> Security Class Initialized
DEBUG - 2017-08-21 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:44:54 --> Input Class Initialized
INFO - 2017-08-21 06:44:54 --> Language Class Initialized
ERROR - 2017-08-21 06:44:54 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 06:45:13 --> Config Class Initialized
INFO - 2017-08-21 06:45:13 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:45:13 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:45:13 --> Utf8 Class Initialized
INFO - 2017-08-21 06:45:13 --> URI Class Initialized
INFO - 2017-08-21 06:45:13 --> Router Class Initialized
INFO - 2017-08-21 06:45:13 --> Output Class Initialized
INFO - 2017-08-21 06:45:13 --> Security Class Initialized
DEBUG - 2017-08-21 06:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:45:13 --> Input Class Initialized
INFO - 2017-08-21 06:45:13 --> Language Class Initialized
INFO - 2017-08-21 06:45:13 --> Loader Class Initialized
INFO - 2017-08-21 06:45:13 --> Helper loaded: url_helper
INFO - 2017-08-21 06:45:13 --> Helper loaded: file_helper
INFO - 2017-08-21 06:45:13 --> Database Driver Class Initialized
INFO - 2017-08-21 06:45:13 --> Email Class Initialized
DEBUG - 2017-08-21 06:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:45:13 --> Table Class Initialized
INFO - 2017-08-21 06:45:13 --> Controller Class Initialized
INFO - 2017-08-21 06:45:13 --> Image Lib Class Initialized
DEBUG - 2017-08-21 06:45:13 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2017-08-21 06:45:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:45:13 --> Final output sent to browser
DEBUG - 2017-08-21 06:45:13 --> Total execution time: 0.1909
INFO - 2017-08-21 06:45:13 --> Config Class Initialized
INFO - 2017-08-21 06:45:13 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:45:14 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:45:14 --> Utf8 Class Initialized
INFO - 2017-08-21 06:45:14 --> URI Class Initialized
INFO - 2017-08-21 06:45:14 --> Router Class Initialized
INFO - 2017-08-21 06:45:14 --> Output Class Initialized
INFO - 2017-08-21 06:45:14 --> Security Class Initialized
DEBUG - 2017-08-21 06:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:45:14 --> Input Class Initialized
INFO - 2017-08-21 06:45:14 --> Language Class Initialized
ERROR - 2017-08-21 06:45:14 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 06:45:16 --> Config Class Initialized
INFO - 2017-08-21 06:45:16 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:45:16 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:45:16 --> Utf8 Class Initialized
INFO - 2017-08-21 06:45:16 --> URI Class Initialized
INFO - 2017-08-21 06:45:16 --> Router Class Initialized
INFO - 2017-08-21 06:45:16 --> Output Class Initialized
INFO - 2017-08-21 06:45:16 --> Security Class Initialized
DEBUG - 2017-08-21 06:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:45:16 --> Input Class Initialized
INFO - 2017-08-21 06:45:16 --> Language Class Initialized
INFO - 2017-08-21 06:45:16 --> Loader Class Initialized
INFO - 2017-08-21 06:45:16 --> Helper loaded: url_helper
INFO - 2017-08-21 06:45:16 --> Helper loaded: file_helper
INFO - 2017-08-21 06:45:16 --> Database Driver Class Initialized
INFO - 2017-08-21 06:45:16 --> Email Class Initialized
DEBUG - 2017-08-21 06:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 06:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 06:45:16 --> Table Class Initialized
INFO - 2017-08-21 06:45:16 --> Controller Class Initialized
INFO - 2017-08-21 06:45:16 --> Image Lib Class Initialized
DEBUG - 2017-08-21 06:45:16 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2017-08-21 06:45:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 06:45:16 --> Final output sent to browser
DEBUG - 2017-08-21 06:45:16 --> Total execution time: 0.2052
INFO - 2017-08-21 06:45:16 --> Config Class Initialized
INFO - 2017-08-21 06:45:16 --> Hooks Class Initialized
DEBUG - 2017-08-21 06:45:16 --> UTF-8 Support Enabled
INFO - 2017-08-21 06:45:16 --> Utf8 Class Initialized
INFO - 2017-08-21 06:45:16 --> URI Class Initialized
INFO - 2017-08-21 06:45:16 --> Router Class Initialized
INFO - 2017-08-21 06:45:16 --> Output Class Initialized
INFO - 2017-08-21 06:45:16 --> Security Class Initialized
DEBUG - 2017-08-21 06:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 06:45:16 --> Input Class Initialized
INFO - 2017-08-21 06:45:16 --> Language Class Initialized
ERROR - 2017-08-21 06:45:16 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:00:51 --> Config Class Initialized
INFO - 2017-08-21 07:00:52 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:00:52 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:00:52 --> Utf8 Class Initialized
INFO - 2017-08-21 07:00:52 --> URI Class Initialized
INFO - 2017-08-21 07:00:52 --> Router Class Initialized
INFO - 2017-08-21 07:00:52 --> Output Class Initialized
INFO - 2017-08-21 07:00:52 --> Security Class Initialized
DEBUG - 2017-08-21 07:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:00:52 --> Input Class Initialized
INFO - 2017-08-21 07:00:52 --> Language Class Initialized
INFO - 2017-08-21 07:00:52 --> Loader Class Initialized
INFO - 2017-08-21 07:00:52 --> Helper loaded: url_helper
INFO - 2017-08-21 07:00:52 --> Helper loaded: file_helper
INFO - 2017-08-21 07:00:52 --> Database Driver Class Initialized
INFO - 2017-08-21 07:00:52 --> Email Class Initialized
DEBUG - 2017-08-21 07:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:00:52 --> Table Class Initialized
INFO - 2017-08-21 07:00:52 --> Controller Class Initialized
INFO - 2017-08-21 07:00:52 --> Image Lib Class Initialized
DEBUG - 2017-08-21 07:00:52 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2017-08-21 07:00:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:00:52 --> Final output sent to browser
DEBUG - 2017-08-21 07:00:52 --> Total execution time: 0.2282
INFO - 2017-08-21 07:00:52 --> Config Class Initialized
INFO - 2017-08-21 07:00:52 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:00:52 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:00:52 --> Utf8 Class Initialized
INFO - 2017-08-21 07:00:52 --> URI Class Initialized
INFO - 2017-08-21 07:00:52 --> Router Class Initialized
INFO - 2017-08-21 07:00:52 --> Output Class Initialized
INFO - 2017-08-21 07:00:52 --> Security Class Initialized
DEBUG - 2017-08-21 07:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:00:52 --> Input Class Initialized
INFO - 2017-08-21 07:00:52 --> Language Class Initialized
ERROR - 2017-08-21 07:00:52 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:01:15 --> Config Class Initialized
INFO - 2017-08-21 07:01:15 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:01:15 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:01:15 --> Utf8 Class Initialized
INFO - 2017-08-21 07:01:15 --> URI Class Initialized
INFO - 2017-08-21 07:01:15 --> Router Class Initialized
INFO - 2017-08-21 07:01:15 --> Output Class Initialized
INFO - 2017-08-21 07:01:15 --> Security Class Initialized
DEBUG - 2017-08-21 07:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:01:15 --> Input Class Initialized
INFO - 2017-08-21 07:01:15 --> Language Class Initialized
INFO - 2017-08-21 07:01:15 --> Loader Class Initialized
INFO - 2017-08-21 07:01:15 --> Helper loaded: url_helper
INFO - 2017-08-21 07:01:15 --> Helper loaded: file_helper
INFO - 2017-08-21 07:01:15 --> Database Driver Class Initialized
INFO - 2017-08-21 07:01:15 --> Email Class Initialized
DEBUG - 2017-08-21 07:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:01:15 --> Table Class Initialized
INFO - 2017-08-21 07:01:15 --> Controller Class Initialized
INFO - 2017-08-21 07:01:15 --> Image Lib Class Initialized
DEBUG - 2017-08-21 07:01:15 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2017-08-21 07:01:15 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:01:15 --> Final output sent to browser
DEBUG - 2017-08-21 07:01:15 --> Total execution time: 0.2045
INFO - 2017-08-21 07:01:15 --> Config Class Initialized
INFO - 2017-08-21 07:01:15 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:01:15 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:01:15 --> Utf8 Class Initialized
INFO - 2017-08-21 07:01:15 --> URI Class Initialized
INFO - 2017-08-21 07:01:15 --> Router Class Initialized
INFO - 2017-08-21 07:01:15 --> Output Class Initialized
INFO - 2017-08-21 07:01:15 --> Security Class Initialized
DEBUG - 2017-08-21 07:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:01:16 --> Input Class Initialized
INFO - 2017-08-21 07:01:16 --> Language Class Initialized
ERROR - 2017-08-21 07:01:16 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:01:24 --> Config Class Initialized
INFO - 2017-08-21 07:01:24 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:01:24 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:01:24 --> Utf8 Class Initialized
INFO - 2017-08-21 07:01:24 --> URI Class Initialized
INFO - 2017-08-21 07:01:24 --> Router Class Initialized
INFO - 2017-08-21 07:01:24 --> Output Class Initialized
INFO - 2017-08-21 07:01:24 --> Security Class Initialized
DEBUG - 2017-08-21 07:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:01:24 --> Input Class Initialized
INFO - 2017-08-21 07:01:24 --> Language Class Initialized
INFO - 2017-08-21 07:01:24 --> Loader Class Initialized
INFO - 2017-08-21 07:01:24 --> Helper loaded: url_helper
INFO - 2017-08-21 07:01:24 --> Helper loaded: file_helper
INFO - 2017-08-21 07:01:24 --> Database Driver Class Initialized
INFO - 2017-08-21 07:01:24 --> Email Class Initialized
DEBUG - 2017-08-21 07:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:01:24 --> Table Class Initialized
INFO - 2017-08-21 07:01:24 --> Controller Class Initialized
INFO - 2017-08-21 07:01:24 --> Image Lib Class Initialized
DEBUG - 2017-08-21 07:01:24 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2017-08-21 07:01:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:01:24 --> Final output sent to browser
DEBUG - 2017-08-21 07:01:24 --> Total execution time: 0.1974
INFO - 2017-08-21 07:01:24 --> Config Class Initialized
INFO - 2017-08-21 07:01:24 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:01:24 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:01:24 --> Utf8 Class Initialized
INFO - 2017-08-21 07:01:24 --> URI Class Initialized
INFO - 2017-08-21 07:01:24 --> Router Class Initialized
INFO - 2017-08-21 07:01:24 --> Output Class Initialized
INFO - 2017-08-21 07:01:24 --> Security Class Initialized
DEBUG - 2017-08-21 07:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:01:24 --> Input Class Initialized
INFO - 2017-08-21 07:01:24 --> Language Class Initialized
ERROR - 2017-08-21 07:01:24 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:02:06 --> Config Class Initialized
INFO - 2017-08-21 07:02:06 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:02:06 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:02:06 --> Utf8 Class Initialized
INFO - 2017-08-21 07:02:06 --> URI Class Initialized
INFO - 2017-08-21 07:02:06 --> Router Class Initialized
INFO - 2017-08-21 07:02:06 --> Output Class Initialized
INFO - 2017-08-21 07:02:06 --> Security Class Initialized
DEBUG - 2017-08-21 07:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:02:06 --> Input Class Initialized
INFO - 2017-08-21 07:02:06 --> Language Class Initialized
INFO - 2017-08-21 07:02:06 --> Loader Class Initialized
INFO - 2017-08-21 07:02:06 --> Helper loaded: url_helper
INFO - 2017-08-21 07:02:06 --> Helper loaded: file_helper
INFO - 2017-08-21 07:02:06 --> Database Driver Class Initialized
INFO - 2017-08-21 07:02:06 --> Email Class Initialized
DEBUG - 2017-08-21 07:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:02:06 --> Table Class Initialized
INFO - 2017-08-21 07:02:06 --> Controller Class Initialized
INFO - 2017-08-21 07:02:06 --> Image Lib Class Initialized
DEBUG - 2017-08-21 07:02:06 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2017-08-21 07:02:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:02:06 --> Final output sent to browser
DEBUG - 2017-08-21 07:02:06 --> Total execution time: 0.1991
INFO - 2017-08-21 07:02:07 --> Config Class Initialized
INFO - 2017-08-21 07:02:07 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:02:07 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:02:07 --> Utf8 Class Initialized
INFO - 2017-08-21 07:02:07 --> URI Class Initialized
INFO - 2017-08-21 07:02:07 --> Router Class Initialized
INFO - 2017-08-21 07:02:07 --> Output Class Initialized
INFO - 2017-08-21 07:02:07 --> Security Class Initialized
DEBUG - 2017-08-21 07:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:02:07 --> Input Class Initialized
INFO - 2017-08-21 07:02:07 --> Language Class Initialized
ERROR - 2017-08-21 07:02:07 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:03:37 --> Config Class Initialized
INFO - 2017-08-21 07:03:37 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:03:37 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:03:37 --> Utf8 Class Initialized
INFO - 2017-08-21 07:03:37 --> URI Class Initialized
INFO - 2017-08-21 07:03:37 --> Router Class Initialized
INFO - 2017-08-21 07:03:37 --> Output Class Initialized
INFO - 2017-08-21 07:03:37 --> Security Class Initialized
DEBUG - 2017-08-21 07:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:03:37 --> Input Class Initialized
INFO - 2017-08-21 07:03:37 --> Language Class Initialized
INFO - 2017-08-21 07:03:37 --> Loader Class Initialized
INFO - 2017-08-21 07:03:37 --> Helper loaded: url_helper
INFO - 2017-08-21 07:03:37 --> Helper loaded: file_helper
INFO - 2017-08-21 07:03:37 --> Database Driver Class Initialized
INFO - 2017-08-21 07:03:37 --> Email Class Initialized
DEBUG - 2017-08-21 07:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:03:37 --> Table Class Initialized
INFO - 2017-08-21 07:03:37 --> Controller Class Initialized
INFO - 2017-08-21 07:03:37 --> Image Lib Class Initialized
INFO - 2017-08-21 07:03:37 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 07:03:37 --> The path to the image is not correct.
ERROR - 2017-08-21 07:03:37 --> Your server does not support the GD function required to process this type of image.
INFO - 2017-08-21 07:03:37 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:03:37 --> Final output sent to browser
DEBUG - 2017-08-21 07:03:37 --> Total execution time: 0.2299
INFO - 2017-08-21 07:03:37 --> Config Class Initialized
INFO - 2017-08-21 07:03:37 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:03:37 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:03:37 --> Utf8 Class Initialized
INFO - 2017-08-21 07:03:37 --> URI Class Initialized
INFO - 2017-08-21 07:03:37 --> Router Class Initialized
INFO - 2017-08-21 07:03:37 --> Output Class Initialized
INFO - 2017-08-21 07:03:37 --> Security Class Initialized
DEBUG - 2017-08-21 07:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:03:37 --> Input Class Initialized
INFO - 2017-08-21 07:03:37 --> Language Class Initialized
ERROR - 2017-08-21 07:03:37 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:04:19 --> Config Class Initialized
INFO - 2017-08-21 07:04:19 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:04:19 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:04:19 --> Utf8 Class Initialized
INFO - 2017-08-21 07:04:19 --> URI Class Initialized
INFO - 2017-08-21 07:04:19 --> Router Class Initialized
INFO - 2017-08-21 07:04:19 --> Output Class Initialized
INFO - 2017-08-21 07:04:19 --> Security Class Initialized
DEBUG - 2017-08-21 07:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:04:19 --> Input Class Initialized
INFO - 2017-08-21 07:04:19 --> Language Class Initialized
INFO - 2017-08-21 07:04:19 --> Loader Class Initialized
INFO - 2017-08-21 07:04:19 --> Helper loaded: url_helper
INFO - 2017-08-21 07:04:19 --> Helper loaded: file_helper
INFO - 2017-08-21 07:04:19 --> Database Driver Class Initialized
INFO - 2017-08-21 07:04:19 --> Email Class Initialized
DEBUG - 2017-08-21 07:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:04:19 --> Table Class Initialized
INFO - 2017-08-21 07:04:19 --> Controller Class Initialized
INFO - 2017-08-21 07:04:19 --> Image Lib Class Initialized
INFO - 2017-08-21 07:04:19 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 07:04:19 --> The path to the image is not correct.
ERROR - 2017-08-21 07:04:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2017-08-21 07:04:19 --> Severity: Notice --> Undefined property: CI_Loader::$upload C:\xampp\htdocs\biokimia\application\views\Article.php 83
ERROR - 2017-08-21 07:04:19 --> Severity: Error --> Call to a member function display_errors() on a non-object C:\xampp\htdocs\biokimia\application\views\Article.php 83
INFO - 2017-08-21 07:04:31 --> Config Class Initialized
INFO - 2017-08-21 07:04:31 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:04:31 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:04:31 --> Utf8 Class Initialized
INFO - 2017-08-21 07:04:31 --> URI Class Initialized
INFO - 2017-08-21 07:04:31 --> Router Class Initialized
INFO - 2017-08-21 07:04:31 --> Output Class Initialized
INFO - 2017-08-21 07:04:31 --> Security Class Initialized
DEBUG - 2017-08-21 07:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:04:31 --> Input Class Initialized
INFO - 2017-08-21 07:04:31 --> Language Class Initialized
INFO - 2017-08-21 07:04:31 --> Loader Class Initialized
INFO - 2017-08-21 07:04:31 --> Helper loaded: url_helper
INFO - 2017-08-21 07:04:31 --> Helper loaded: file_helper
INFO - 2017-08-21 07:04:31 --> Database Driver Class Initialized
INFO - 2017-08-21 07:04:31 --> Email Class Initialized
DEBUG - 2017-08-21 07:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:04:31 --> Table Class Initialized
INFO - 2017-08-21 07:04:31 --> Controller Class Initialized
INFO - 2017-08-21 07:04:31 --> Image Lib Class Initialized
INFO - 2017-08-21 07:04:31 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 07:04:31 --> The path to the image is not correct.
ERROR - 2017-08-21 07:04:31 --> Your server does not support the GD function required to process this type of image.
INFO - 2017-08-21 07:04:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:04:31 --> Final output sent to browser
DEBUG - 2017-08-21 07:04:31 --> Total execution time: 0.2196
INFO - 2017-08-21 07:04:31 --> Config Class Initialized
INFO - 2017-08-21 07:04:31 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:04:31 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:04:31 --> Utf8 Class Initialized
INFO - 2017-08-21 07:04:31 --> URI Class Initialized
INFO - 2017-08-21 07:04:31 --> Router Class Initialized
INFO - 2017-08-21 07:04:31 --> Output Class Initialized
INFO - 2017-08-21 07:04:31 --> Security Class Initialized
DEBUG - 2017-08-21 07:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:04:31 --> Input Class Initialized
INFO - 2017-08-21 07:04:31 --> Language Class Initialized
ERROR - 2017-08-21 07:04:31 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:05:15 --> Config Class Initialized
INFO - 2017-08-21 07:05:15 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:05:15 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:05:15 --> Utf8 Class Initialized
INFO - 2017-08-21 07:05:15 --> URI Class Initialized
INFO - 2017-08-21 07:05:15 --> Router Class Initialized
INFO - 2017-08-21 07:05:15 --> Output Class Initialized
INFO - 2017-08-21 07:05:15 --> Security Class Initialized
DEBUG - 2017-08-21 07:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:05:15 --> Input Class Initialized
INFO - 2017-08-21 07:05:15 --> Language Class Initialized
INFO - 2017-08-21 07:05:15 --> Loader Class Initialized
INFO - 2017-08-21 07:05:15 --> Helper loaded: url_helper
INFO - 2017-08-21 07:05:15 --> Helper loaded: file_helper
INFO - 2017-08-21 07:05:15 --> Database Driver Class Initialized
INFO - 2017-08-21 07:05:15 --> Email Class Initialized
DEBUG - 2017-08-21 07:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:05:15 --> Table Class Initialized
INFO - 2017-08-21 07:05:15 --> Controller Class Initialized
INFO - 2017-08-21 07:05:15 --> Image Lib Class Initialized
INFO - 2017-08-21 07:05:15 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 07:05:15 --> The path to the image is not correct.
ERROR - 2017-08-21 07:05:15 --> Your server does not support the GD function required to process this type of image.
INFO - 2017-08-21 07:05:15 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:05:15 --> Final output sent to browser
DEBUG - 2017-08-21 07:05:15 --> Total execution time: 0.2288
INFO - 2017-08-21 07:05:15 --> Config Class Initialized
INFO - 2017-08-21 07:05:15 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:05:15 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:05:15 --> Utf8 Class Initialized
INFO - 2017-08-21 07:05:15 --> URI Class Initialized
INFO - 2017-08-21 07:05:15 --> Router Class Initialized
INFO - 2017-08-21 07:05:15 --> Output Class Initialized
INFO - 2017-08-21 07:05:15 --> Security Class Initialized
DEBUG - 2017-08-21 07:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:05:15 --> Input Class Initialized
INFO - 2017-08-21 07:05:15 --> Language Class Initialized
ERROR - 2017-08-21 07:05:15 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:05:28 --> Config Class Initialized
INFO - 2017-08-21 07:05:28 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:05:28 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:05:28 --> Utf8 Class Initialized
INFO - 2017-08-21 07:05:28 --> URI Class Initialized
INFO - 2017-08-21 07:05:28 --> Router Class Initialized
INFO - 2017-08-21 07:05:28 --> Output Class Initialized
INFO - 2017-08-21 07:05:28 --> Security Class Initialized
DEBUG - 2017-08-21 07:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:05:28 --> Input Class Initialized
INFO - 2017-08-21 07:05:28 --> Language Class Initialized
INFO - 2017-08-21 07:05:28 --> Loader Class Initialized
INFO - 2017-08-21 07:05:28 --> Helper loaded: url_helper
INFO - 2017-08-21 07:05:28 --> Helper loaded: file_helper
INFO - 2017-08-21 07:05:28 --> Database Driver Class Initialized
INFO - 2017-08-21 07:05:28 --> Email Class Initialized
DEBUG - 2017-08-21 07:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:05:28 --> Table Class Initialized
INFO - 2017-08-21 07:05:28 --> Controller Class Initialized
INFO - 2017-08-21 07:05:28 --> Image Lib Class Initialized
INFO - 2017-08-21 07:05:28 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-08-21 07:05:28 --> The path to the image is not correct.
ERROR - 2017-08-21 07:05:28 --> Your server does not support the GD function required to process this type of image.
INFO - 2017-08-21 07:05:28 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:05:28 --> Final output sent to browser
DEBUG - 2017-08-21 07:05:28 --> Total execution time: 0.2181
INFO - 2017-08-21 07:05:28 --> Config Class Initialized
INFO - 2017-08-21 07:05:29 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:05:29 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:05:29 --> Utf8 Class Initialized
INFO - 2017-08-21 07:05:29 --> URI Class Initialized
INFO - 2017-08-21 07:05:29 --> Router Class Initialized
INFO - 2017-08-21 07:05:29 --> Output Class Initialized
INFO - 2017-08-21 07:05:29 --> Security Class Initialized
DEBUG - 2017-08-21 07:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:05:29 --> Input Class Initialized
INFO - 2017-08-21 07:05:29 --> Language Class Initialized
ERROR - 2017-08-21 07:05:29 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:05:52 --> Config Class Initialized
INFO - 2017-08-21 07:05:52 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:05:52 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:05:52 --> Utf8 Class Initialized
INFO - 2017-08-21 07:05:52 --> URI Class Initialized
INFO - 2017-08-21 07:05:52 --> Router Class Initialized
INFO - 2017-08-21 07:05:52 --> Output Class Initialized
INFO - 2017-08-21 07:05:52 --> Security Class Initialized
DEBUG - 2017-08-21 07:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:05:52 --> Input Class Initialized
INFO - 2017-08-21 07:05:52 --> Language Class Initialized
INFO - 2017-08-21 07:05:52 --> Loader Class Initialized
INFO - 2017-08-21 07:05:52 --> Helper loaded: url_helper
INFO - 2017-08-21 07:05:52 --> Helper loaded: file_helper
INFO - 2017-08-21 07:05:52 --> Database Driver Class Initialized
INFO - 2017-08-21 07:05:52 --> Email Class Initialized
DEBUG - 2017-08-21 07:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:05:53 --> Table Class Initialized
INFO - 2017-08-21 07:05:53 --> Controller Class Initialized
INFO - 2017-08-21 07:05:53 --> Image Lib Class Initialized
INFO - 2017-08-21 07:05:53 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:05:53 --> Final output sent to browser
DEBUG - 2017-08-21 07:05:53 --> Total execution time: 0.3084
INFO - 2017-08-21 07:05:53 --> Config Class Initialized
INFO - 2017-08-21 07:05:53 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:05:53 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:05:53 --> Utf8 Class Initialized
INFO - 2017-08-21 07:05:53 --> URI Class Initialized
INFO - 2017-08-21 07:05:53 --> Router Class Initialized
INFO - 2017-08-21 07:05:53 --> Output Class Initialized
INFO - 2017-08-21 07:05:53 --> Security Class Initialized
DEBUG - 2017-08-21 07:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:05:53 --> Input Class Initialized
INFO - 2017-08-21 07:05:53 --> Language Class Initialized
ERROR - 2017-08-21 07:05:53 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:06:31 --> Config Class Initialized
INFO - 2017-08-21 07:06:31 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:06:31 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:06:31 --> Utf8 Class Initialized
INFO - 2017-08-21 07:06:31 --> URI Class Initialized
INFO - 2017-08-21 07:06:31 --> Router Class Initialized
INFO - 2017-08-21 07:06:31 --> Output Class Initialized
INFO - 2017-08-21 07:06:31 --> Security Class Initialized
DEBUG - 2017-08-21 07:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:06:31 --> Input Class Initialized
INFO - 2017-08-21 07:06:31 --> Language Class Initialized
INFO - 2017-08-21 07:06:31 --> Loader Class Initialized
INFO - 2017-08-21 07:06:31 --> Helper loaded: url_helper
INFO - 2017-08-21 07:06:31 --> Helper loaded: file_helper
INFO - 2017-08-21 07:06:31 --> Database Driver Class Initialized
INFO - 2017-08-21 07:06:31 --> Email Class Initialized
DEBUG - 2017-08-21 07:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:06:31 --> Table Class Initialized
INFO - 2017-08-21 07:06:31 --> Controller Class Initialized
INFO - 2017-08-21 07:06:31 --> Image Lib Class Initialized
INFO - 2017-08-21 07:06:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:06:31 --> Final output sent to browser
DEBUG - 2017-08-21 07:06:31 --> Total execution time: 0.3108
INFO - 2017-08-21 07:06:32 --> Config Class Initialized
INFO - 2017-08-21 07:06:32 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:06:32 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:06:32 --> Utf8 Class Initialized
INFO - 2017-08-21 07:06:32 --> URI Class Initialized
INFO - 2017-08-21 07:06:32 --> Router Class Initialized
INFO - 2017-08-21 07:06:32 --> Output Class Initialized
INFO - 2017-08-21 07:06:32 --> Security Class Initialized
DEBUG - 2017-08-21 07:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:06:32 --> Input Class Initialized
INFO - 2017-08-21 07:06:32 --> Language Class Initialized
ERROR - 2017-08-21 07:06:32 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:06:44 --> Config Class Initialized
INFO - 2017-08-21 07:06:44 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:06:44 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:06:44 --> Utf8 Class Initialized
INFO - 2017-08-21 07:06:44 --> URI Class Initialized
INFO - 2017-08-21 07:06:44 --> Router Class Initialized
INFO - 2017-08-21 07:06:44 --> Output Class Initialized
INFO - 2017-08-21 07:06:44 --> Security Class Initialized
DEBUG - 2017-08-21 07:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:06:44 --> Input Class Initialized
INFO - 2017-08-21 07:06:44 --> Language Class Initialized
INFO - 2017-08-21 07:06:44 --> Loader Class Initialized
INFO - 2017-08-21 07:06:44 --> Helper loaded: url_helper
INFO - 2017-08-21 07:06:44 --> Helper loaded: file_helper
INFO - 2017-08-21 07:06:44 --> Database Driver Class Initialized
INFO - 2017-08-21 07:06:44 --> Email Class Initialized
DEBUG - 2017-08-21 07:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:06:44 --> Table Class Initialized
INFO - 2017-08-21 07:06:44 --> Controller Class Initialized
INFO - 2017-08-21 07:06:44 --> Image Lib Class Initialized
INFO - 2017-08-21 07:06:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:06:45 --> Final output sent to browser
DEBUG - 2017-08-21 07:06:45 --> Total execution time: 0.4448
INFO - 2017-08-21 07:06:45 --> Config Class Initialized
INFO - 2017-08-21 07:06:45 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:06:45 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:06:45 --> Utf8 Class Initialized
INFO - 2017-08-21 07:06:45 --> URI Class Initialized
INFO - 2017-08-21 07:06:45 --> Router Class Initialized
INFO - 2017-08-21 07:06:45 --> Output Class Initialized
INFO - 2017-08-21 07:06:45 --> Security Class Initialized
DEBUG - 2017-08-21 07:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:06:45 --> Input Class Initialized
INFO - 2017-08-21 07:06:45 --> Language Class Initialized
ERROR - 2017-08-21 07:06:45 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:07:12 --> Config Class Initialized
INFO - 2017-08-21 07:07:12 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:07:12 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:07:12 --> Utf8 Class Initialized
INFO - 2017-08-21 07:07:12 --> URI Class Initialized
INFO - 2017-08-21 07:07:12 --> Router Class Initialized
INFO - 2017-08-21 07:07:12 --> Output Class Initialized
INFO - 2017-08-21 07:07:12 --> Security Class Initialized
DEBUG - 2017-08-21 07:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:07:12 --> Input Class Initialized
INFO - 2017-08-21 07:07:12 --> Language Class Initialized
INFO - 2017-08-21 07:07:12 --> Loader Class Initialized
INFO - 2017-08-21 07:07:12 --> Helper loaded: url_helper
INFO - 2017-08-21 07:07:12 --> Helper loaded: file_helper
INFO - 2017-08-21 07:07:12 --> Database Driver Class Initialized
INFO - 2017-08-21 07:07:12 --> Email Class Initialized
DEBUG - 2017-08-21 07:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:07:12 --> Table Class Initialized
INFO - 2017-08-21 07:07:12 --> Controller Class Initialized
INFO - 2017-08-21 07:07:12 --> Image Lib Class Initialized
INFO - 2017-08-21 07:07:12 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:07:12 --> Final output sent to browser
DEBUG - 2017-08-21 07:07:12 --> Total execution time: 0.2813
INFO - 2017-08-21 07:07:12 --> Config Class Initialized
INFO - 2017-08-21 07:07:12 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:07:12 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:07:12 --> Utf8 Class Initialized
INFO - 2017-08-21 07:07:12 --> URI Class Initialized
INFO - 2017-08-21 07:07:12 --> Router Class Initialized
INFO - 2017-08-21 07:07:12 --> Output Class Initialized
INFO - 2017-08-21 07:07:12 --> Security Class Initialized
DEBUG - 2017-08-21 07:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:07:12 --> Input Class Initialized
INFO - 2017-08-21 07:07:12 --> Language Class Initialized
ERROR - 2017-08-21 07:07:12 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:07:35 --> Config Class Initialized
INFO - 2017-08-21 07:07:35 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:07:35 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:07:35 --> Utf8 Class Initialized
INFO - 2017-08-21 07:07:35 --> URI Class Initialized
INFO - 2017-08-21 07:07:35 --> Router Class Initialized
INFO - 2017-08-21 07:07:35 --> Output Class Initialized
INFO - 2017-08-21 07:07:35 --> Security Class Initialized
DEBUG - 2017-08-21 07:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:07:35 --> Input Class Initialized
INFO - 2017-08-21 07:07:35 --> Language Class Initialized
INFO - 2017-08-21 07:07:35 --> Loader Class Initialized
INFO - 2017-08-21 07:07:35 --> Helper loaded: url_helper
INFO - 2017-08-21 07:07:35 --> Helper loaded: file_helper
INFO - 2017-08-21 07:07:35 --> Database Driver Class Initialized
INFO - 2017-08-21 07:07:35 --> Email Class Initialized
DEBUG - 2017-08-21 07:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:07:35 --> Table Class Initialized
INFO - 2017-08-21 07:07:35 --> Controller Class Initialized
INFO - 2017-08-21 07:07:35 --> Image Lib Class Initialized
INFO - 2017-08-21 07:07:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:07:35 --> Final output sent to browser
DEBUG - 2017-08-21 07:07:35 --> Total execution time: 0.3816
INFO - 2017-08-21 07:07:36 --> Config Class Initialized
INFO - 2017-08-21 07:07:36 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:07:36 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:07:36 --> Utf8 Class Initialized
INFO - 2017-08-21 07:07:36 --> URI Class Initialized
INFO - 2017-08-21 07:07:36 --> Router Class Initialized
INFO - 2017-08-21 07:07:36 --> Output Class Initialized
INFO - 2017-08-21 07:07:36 --> Security Class Initialized
DEBUG - 2017-08-21 07:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:07:36 --> Input Class Initialized
INFO - 2017-08-21 07:07:36 --> Language Class Initialized
ERROR - 2017-08-21 07:07:36 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:07:55 --> Config Class Initialized
INFO - 2017-08-21 07:07:55 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:07:55 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:07:55 --> Utf8 Class Initialized
INFO - 2017-08-21 07:07:55 --> URI Class Initialized
INFO - 2017-08-21 07:07:55 --> Router Class Initialized
INFO - 2017-08-21 07:07:55 --> Output Class Initialized
INFO - 2017-08-21 07:07:55 --> Security Class Initialized
DEBUG - 2017-08-21 07:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:07:55 --> Input Class Initialized
INFO - 2017-08-21 07:07:55 --> Language Class Initialized
INFO - 2017-08-21 07:07:55 --> Loader Class Initialized
INFO - 2017-08-21 07:07:55 --> Helper loaded: url_helper
INFO - 2017-08-21 07:07:55 --> Helper loaded: file_helper
INFO - 2017-08-21 07:07:55 --> Database Driver Class Initialized
INFO - 2017-08-21 07:07:55 --> Email Class Initialized
DEBUG - 2017-08-21 07:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:07:55 --> Table Class Initialized
INFO - 2017-08-21 07:07:55 --> Controller Class Initialized
INFO - 2017-08-21 07:07:55 --> Image Lib Class Initialized
INFO - 2017-08-21 07:07:55 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:07:55 --> Final output sent to browser
DEBUG - 2017-08-21 07:07:55 --> Total execution time: 0.3998
INFO - 2017-08-21 07:07:55 --> Config Class Initialized
INFO - 2017-08-21 07:07:55 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:07:55 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:07:55 --> Utf8 Class Initialized
INFO - 2017-08-21 07:07:55 --> URI Class Initialized
INFO - 2017-08-21 07:07:55 --> Router Class Initialized
INFO - 2017-08-21 07:07:56 --> Output Class Initialized
INFO - 2017-08-21 07:07:56 --> Security Class Initialized
DEBUG - 2017-08-21 07:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:07:56 --> Input Class Initialized
INFO - 2017-08-21 07:07:56 --> Language Class Initialized
ERROR - 2017-08-21 07:07:56 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 07:10:27 --> Config Class Initialized
INFO - 2017-08-21 07:10:27 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:10:27 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:10:27 --> Utf8 Class Initialized
INFO - 2017-08-21 07:10:27 --> URI Class Initialized
INFO - 2017-08-21 07:10:27 --> Router Class Initialized
INFO - 2017-08-21 07:10:27 --> Output Class Initialized
INFO - 2017-08-21 07:10:27 --> Security Class Initialized
DEBUG - 2017-08-21 07:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:10:27 --> Input Class Initialized
INFO - 2017-08-21 07:10:27 --> Language Class Initialized
INFO - 2017-08-21 07:10:27 --> Loader Class Initialized
INFO - 2017-08-21 07:10:27 --> Helper loaded: url_helper
INFO - 2017-08-21 07:10:27 --> Helper loaded: file_helper
INFO - 2017-08-21 07:10:27 --> Database Driver Class Initialized
INFO - 2017-08-21 07:10:27 --> Email Class Initialized
DEBUG - 2017-08-21 07:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 07:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 07:10:27 --> Table Class Initialized
INFO - 2017-08-21 07:10:27 --> Controller Class Initialized
INFO - 2017-08-21 07:10:27 --> Image Lib Class Initialized
INFO - 2017-08-21 07:10:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 07:10:27 --> Final output sent to browser
DEBUG - 2017-08-21 07:10:27 --> Total execution time: 0.6040
INFO - 2017-08-21 07:10:27 --> Config Class Initialized
INFO - 2017-08-21 07:10:27 --> Hooks Class Initialized
DEBUG - 2017-08-21 07:10:27 --> UTF-8 Support Enabled
INFO - 2017-08-21 07:10:27 --> Utf8 Class Initialized
INFO - 2017-08-21 07:10:27 --> URI Class Initialized
INFO - 2017-08-21 07:10:27 --> Router Class Initialized
INFO - 2017-08-21 07:10:27 --> Output Class Initialized
INFO - 2017-08-21 07:10:27 --> Security Class Initialized
DEBUG - 2017-08-21 07:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 07:10:28 --> Input Class Initialized
INFO - 2017-08-21 07:10:28 --> Language Class Initialized
ERROR - 2017-08-21 07:10:28 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-21 08:05:29 --> Config Class Initialized
INFO - 2017-08-21 08:05:30 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:05:30 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:05:30 --> Utf8 Class Initialized
INFO - 2017-08-21 08:05:30 --> URI Class Initialized
INFO - 2017-08-21 08:05:30 --> Router Class Initialized
INFO - 2017-08-21 08:05:30 --> Output Class Initialized
INFO - 2017-08-21 08:05:30 --> Security Class Initialized
DEBUG - 2017-08-21 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:05:30 --> Input Class Initialized
INFO - 2017-08-21 08:05:30 --> Language Class Initialized
INFO - 2017-08-21 08:05:30 --> Loader Class Initialized
INFO - 2017-08-21 08:05:30 --> Helper loaded: url_helper
INFO - 2017-08-21 08:05:30 --> Helper loaded: file_helper
INFO - 2017-08-21 08:05:30 --> Database Driver Class Initialized
INFO - 2017-08-21 08:05:30 --> Email Class Initialized
DEBUG - 2017-08-21 08:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:05:30 --> Table Class Initialized
INFO - 2017-08-21 08:05:30 --> Controller Class Initialized
INFO - 2017-08-21 08:05:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:05:30 --> Final output sent to browser
DEBUG - 2017-08-21 08:05:30 --> Total execution time: 0.2632
INFO - 2017-08-21 08:22:49 --> Config Class Initialized
INFO - 2017-08-21 08:22:49 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:22:49 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:22:49 --> Utf8 Class Initialized
INFO - 2017-08-21 08:22:49 --> URI Class Initialized
INFO - 2017-08-21 08:22:49 --> Router Class Initialized
INFO - 2017-08-21 08:22:49 --> Output Class Initialized
INFO - 2017-08-21 08:22:49 --> Security Class Initialized
DEBUG - 2017-08-21 08:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:22:49 --> Input Class Initialized
INFO - 2017-08-21 08:22:49 --> Language Class Initialized
INFO - 2017-08-21 08:22:49 --> Loader Class Initialized
INFO - 2017-08-21 08:22:49 --> Helper loaded: url_helper
INFO - 2017-08-21 08:22:49 --> Helper loaded: file_helper
INFO - 2017-08-21 08:22:49 --> Database Driver Class Initialized
INFO - 2017-08-21 08:22:49 --> Email Class Initialized
DEBUG - 2017-08-21 08:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:22:49 --> Table Class Initialized
INFO - 2017-08-21 08:22:49 --> Controller Class Initialized
INFO - 2017-08-21 08:22:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:22:49 --> Final output sent to browser
DEBUG - 2017-08-21 08:22:49 --> Total execution time: 0.2089
INFO - 2017-08-21 08:22:51 --> Config Class Initialized
INFO - 2017-08-21 08:22:51 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:22:51 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:22:51 --> Utf8 Class Initialized
INFO - 2017-08-21 08:22:51 --> URI Class Initialized
INFO - 2017-08-21 08:22:51 --> Router Class Initialized
INFO - 2017-08-21 08:22:51 --> Output Class Initialized
INFO - 2017-08-21 08:22:51 --> Security Class Initialized
DEBUG - 2017-08-21 08:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:22:51 --> Input Class Initialized
INFO - 2017-08-21 08:22:51 --> Language Class Initialized
INFO - 2017-08-21 08:22:51 --> Loader Class Initialized
INFO - 2017-08-21 08:22:51 --> Helper loaded: url_helper
INFO - 2017-08-21 08:22:51 --> Helper loaded: file_helper
INFO - 2017-08-21 08:22:51 --> Database Driver Class Initialized
INFO - 2017-08-21 08:22:51 --> Email Class Initialized
DEBUG - 2017-08-21 08:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:22:51 --> Table Class Initialized
INFO - 2017-08-21 08:22:51 --> Controller Class Initialized
INFO - 2017-08-21 08:22:51 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:22:51 --> Final output sent to browser
DEBUG - 2017-08-21 08:22:51 --> Total execution time: 0.1963
INFO - 2017-08-21 08:23:28 --> Config Class Initialized
INFO - 2017-08-21 08:23:28 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:23:28 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:23:28 --> Utf8 Class Initialized
INFO - 2017-08-21 08:23:28 --> URI Class Initialized
INFO - 2017-08-21 08:23:28 --> Router Class Initialized
INFO - 2017-08-21 08:23:28 --> Output Class Initialized
INFO - 2017-08-21 08:23:28 --> Security Class Initialized
DEBUG - 2017-08-21 08:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:23:28 --> Input Class Initialized
INFO - 2017-08-21 08:23:28 --> Language Class Initialized
INFO - 2017-08-21 08:23:28 --> Loader Class Initialized
INFO - 2017-08-21 08:23:28 --> Helper loaded: url_helper
INFO - 2017-08-21 08:23:28 --> Helper loaded: file_helper
INFO - 2017-08-21 08:23:28 --> Database Driver Class Initialized
INFO - 2017-08-21 08:23:28 --> Email Class Initialized
DEBUG - 2017-08-21 08:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:23:28 --> Table Class Initialized
INFO - 2017-08-21 08:23:28 --> Controller Class Initialized
INFO - 2017-08-21 08:23:28 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:23:28 --> Final output sent to browser
DEBUG - 2017-08-21 08:23:28 --> Total execution time: 0.2030
INFO - 2017-08-21 08:23:32 --> Config Class Initialized
INFO - 2017-08-21 08:23:32 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:23:32 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:23:32 --> Utf8 Class Initialized
INFO - 2017-08-21 08:23:32 --> URI Class Initialized
INFO - 2017-08-21 08:23:32 --> Router Class Initialized
INFO - 2017-08-21 08:23:32 --> Output Class Initialized
INFO - 2017-08-21 08:23:32 --> Security Class Initialized
DEBUG - 2017-08-21 08:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:23:32 --> Input Class Initialized
INFO - 2017-08-21 08:23:32 --> Language Class Initialized
INFO - 2017-08-21 08:23:32 --> Loader Class Initialized
INFO - 2017-08-21 08:23:32 --> Helper loaded: url_helper
INFO - 2017-08-21 08:23:32 --> Helper loaded: file_helper
INFO - 2017-08-21 08:23:32 --> Database Driver Class Initialized
INFO - 2017-08-21 08:23:32 --> Email Class Initialized
DEBUG - 2017-08-21 08:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:23:32 --> Table Class Initialized
INFO - 2017-08-21 08:23:32 --> Controller Class Initialized
INFO - 2017-08-21 08:23:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:23:32 --> Final output sent to browser
DEBUG - 2017-08-21 08:23:32 --> Total execution time: 0.2043
INFO - 2017-08-21 08:25:12 --> Config Class Initialized
INFO - 2017-08-21 08:25:12 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:25:12 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:25:12 --> Utf8 Class Initialized
INFO - 2017-08-21 08:25:12 --> URI Class Initialized
INFO - 2017-08-21 08:25:12 --> Router Class Initialized
INFO - 2017-08-21 08:25:12 --> Output Class Initialized
INFO - 2017-08-21 08:25:12 --> Security Class Initialized
DEBUG - 2017-08-21 08:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:25:12 --> Input Class Initialized
INFO - 2017-08-21 08:25:12 --> Language Class Initialized
INFO - 2017-08-21 08:25:12 --> Loader Class Initialized
INFO - 2017-08-21 08:25:12 --> Helper loaded: url_helper
INFO - 2017-08-21 08:25:12 --> Helper loaded: file_helper
INFO - 2017-08-21 08:25:12 --> Database Driver Class Initialized
INFO - 2017-08-21 08:25:12 --> Email Class Initialized
DEBUG - 2017-08-21 08:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:25:12 --> Table Class Initialized
INFO - 2017-08-21 08:25:12 --> Controller Class Initialized
INFO - 2017-08-21 08:25:12 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:25:12 --> Final output sent to browser
DEBUG - 2017-08-21 08:25:12 --> Total execution time: 0.1951
INFO - 2017-08-21 08:25:15 --> Config Class Initialized
INFO - 2017-08-21 08:25:15 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:25:15 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:25:15 --> Utf8 Class Initialized
INFO - 2017-08-21 08:25:15 --> URI Class Initialized
INFO - 2017-08-21 08:25:15 --> Router Class Initialized
INFO - 2017-08-21 08:25:15 --> Output Class Initialized
INFO - 2017-08-21 08:25:15 --> Security Class Initialized
DEBUG - 2017-08-21 08:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:25:15 --> Input Class Initialized
INFO - 2017-08-21 08:25:15 --> Language Class Initialized
INFO - 2017-08-21 08:25:15 --> Loader Class Initialized
INFO - 2017-08-21 08:25:15 --> Helper loaded: url_helper
INFO - 2017-08-21 08:25:16 --> Helper loaded: file_helper
INFO - 2017-08-21 08:25:16 --> Database Driver Class Initialized
INFO - 2017-08-21 08:25:16 --> Email Class Initialized
DEBUG - 2017-08-21 08:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:25:16 --> Table Class Initialized
INFO - 2017-08-21 08:25:16 --> Controller Class Initialized
INFO - 2017-08-21 08:25:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:25:16 --> Final output sent to browser
DEBUG - 2017-08-21 08:25:16 --> Total execution time: 0.2005
INFO - 2017-08-21 08:25:31 --> Config Class Initialized
INFO - 2017-08-21 08:25:31 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:25:31 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:25:31 --> Utf8 Class Initialized
INFO - 2017-08-21 08:25:31 --> URI Class Initialized
INFO - 2017-08-21 08:25:31 --> Router Class Initialized
INFO - 2017-08-21 08:25:31 --> Output Class Initialized
INFO - 2017-08-21 08:25:31 --> Security Class Initialized
DEBUG - 2017-08-21 08:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:25:31 --> Input Class Initialized
INFO - 2017-08-21 08:25:31 --> Language Class Initialized
INFO - 2017-08-21 08:25:31 --> Loader Class Initialized
INFO - 2017-08-21 08:25:31 --> Helper loaded: url_helper
INFO - 2017-08-21 08:25:31 --> Helper loaded: file_helper
INFO - 2017-08-21 08:25:32 --> Database Driver Class Initialized
INFO - 2017-08-21 08:25:32 --> Email Class Initialized
DEBUG - 2017-08-21 08:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:25:32 --> Table Class Initialized
INFO - 2017-08-21 08:25:32 --> Controller Class Initialized
INFO - 2017-08-21 08:25:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:25:32 --> Final output sent to browser
DEBUG - 2017-08-21 08:25:32 --> Total execution time: 0.2004
INFO - 2017-08-21 08:25:43 --> Config Class Initialized
INFO - 2017-08-21 08:25:43 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:25:43 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:25:43 --> Utf8 Class Initialized
INFO - 2017-08-21 08:25:43 --> URI Class Initialized
INFO - 2017-08-21 08:25:43 --> Router Class Initialized
INFO - 2017-08-21 08:25:43 --> Output Class Initialized
INFO - 2017-08-21 08:25:43 --> Security Class Initialized
DEBUG - 2017-08-21 08:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:25:43 --> Input Class Initialized
INFO - 2017-08-21 08:25:43 --> Language Class Initialized
INFO - 2017-08-21 08:25:43 --> Loader Class Initialized
INFO - 2017-08-21 08:25:43 --> Helper loaded: url_helper
INFO - 2017-08-21 08:25:43 --> Helper loaded: file_helper
INFO - 2017-08-21 08:25:43 --> Database Driver Class Initialized
INFO - 2017-08-21 08:25:43 --> Email Class Initialized
DEBUG - 2017-08-21 08:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:25:43 --> Table Class Initialized
INFO - 2017-08-21 08:25:43 --> Controller Class Initialized
INFO - 2017-08-21 08:25:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:25:43 --> Final output sent to browser
DEBUG - 2017-08-21 08:25:43 --> Total execution time: 0.2048
INFO - 2017-08-21 08:25:48 --> Config Class Initialized
INFO - 2017-08-21 08:25:48 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:25:48 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:25:48 --> Utf8 Class Initialized
INFO - 2017-08-21 08:25:48 --> URI Class Initialized
INFO - 2017-08-21 08:25:48 --> Router Class Initialized
INFO - 2017-08-21 08:25:48 --> Output Class Initialized
INFO - 2017-08-21 08:25:48 --> Security Class Initialized
DEBUG - 2017-08-21 08:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:25:48 --> Input Class Initialized
INFO - 2017-08-21 08:25:48 --> Language Class Initialized
INFO - 2017-08-21 08:25:48 --> Loader Class Initialized
INFO - 2017-08-21 08:25:48 --> Helper loaded: url_helper
INFO - 2017-08-21 08:25:48 --> Helper loaded: file_helper
INFO - 2017-08-21 08:25:48 --> Database Driver Class Initialized
INFO - 2017-08-21 08:25:48 --> Email Class Initialized
DEBUG - 2017-08-21 08:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:25:48 --> Table Class Initialized
INFO - 2017-08-21 08:25:48 --> Controller Class Initialized
INFO - 2017-08-21 08:25:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:25:48 --> Final output sent to browser
DEBUG - 2017-08-21 08:25:48 --> Total execution time: 0.2047
INFO - 2017-08-21 08:25:57 --> Config Class Initialized
INFO - 2017-08-21 08:25:57 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:25:57 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:25:57 --> Utf8 Class Initialized
INFO - 2017-08-21 08:25:57 --> URI Class Initialized
INFO - 2017-08-21 08:25:57 --> Router Class Initialized
INFO - 2017-08-21 08:25:57 --> Output Class Initialized
INFO - 2017-08-21 08:25:57 --> Security Class Initialized
DEBUG - 2017-08-21 08:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:25:57 --> Input Class Initialized
INFO - 2017-08-21 08:25:57 --> Language Class Initialized
INFO - 2017-08-21 08:25:57 --> Loader Class Initialized
INFO - 2017-08-21 08:25:57 --> Helper loaded: url_helper
INFO - 2017-08-21 08:25:57 --> Helper loaded: file_helper
INFO - 2017-08-21 08:25:57 --> Database Driver Class Initialized
INFO - 2017-08-21 08:25:57 --> Email Class Initialized
DEBUG - 2017-08-21 08:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:25:57 --> Table Class Initialized
INFO - 2017-08-21 08:25:57 --> Controller Class Initialized
INFO - 2017-08-21 08:25:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:25:57 --> Final output sent to browser
DEBUG - 2017-08-21 08:25:57 --> Total execution time: 0.1986
INFO - 2017-08-21 08:36:18 --> Config Class Initialized
INFO - 2017-08-21 08:36:18 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:36:18 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:36:18 --> Utf8 Class Initialized
INFO - 2017-08-21 08:36:18 --> URI Class Initialized
INFO - 2017-08-21 08:36:18 --> Router Class Initialized
INFO - 2017-08-21 08:36:18 --> Output Class Initialized
INFO - 2017-08-21 08:36:18 --> Security Class Initialized
DEBUG - 2017-08-21 08:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:36:18 --> Input Class Initialized
INFO - 2017-08-21 08:36:18 --> Language Class Initialized
INFO - 2017-08-21 08:36:18 --> Loader Class Initialized
INFO - 2017-08-21 08:36:18 --> Helper loaded: url_helper
INFO - 2017-08-21 08:36:18 --> Helper loaded: file_helper
INFO - 2017-08-21 08:36:18 --> Database Driver Class Initialized
INFO - 2017-08-21 08:36:18 --> Email Class Initialized
DEBUG - 2017-08-21 08:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:36:18 --> Table Class Initialized
INFO - 2017-08-21 08:36:18 --> Controller Class Initialized
INFO - 2017-08-21 08:36:18 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:36:18 --> Final output sent to browser
DEBUG - 2017-08-21 08:36:18 --> Total execution time: 0.2348
INFO - 2017-08-21 08:37:41 --> Config Class Initialized
INFO - 2017-08-21 08:37:41 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:37:41 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:37:41 --> Utf8 Class Initialized
INFO - 2017-08-21 08:37:41 --> URI Class Initialized
INFO - 2017-08-21 08:37:41 --> Router Class Initialized
INFO - 2017-08-21 08:37:41 --> Output Class Initialized
INFO - 2017-08-21 08:37:41 --> Security Class Initialized
DEBUG - 2017-08-21 08:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:37:41 --> Input Class Initialized
INFO - 2017-08-21 08:37:41 --> Language Class Initialized
INFO - 2017-08-21 08:37:41 --> Loader Class Initialized
INFO - 2017-08-21 08:37:41 --> Helper loaded: url_helper
INFO - 2017-08-21 08:37:41 --> Helper loaded: file_helper
INFO - 2017-08-21 08:37:41 --> Database Driver Class Initialized
INFO - 2017-08-21 08:37:41 --> Email Class Initialized
DEBUG - 2017-08-21 08:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:37:41 --> Table Class Initialized
INFO - 2017-08-21 08:37:41 --> Controller Class Initialized
INFO - 2017-08-21 08:37:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:37:41 --> Final output sent to browser
DEBUG - 2017-08-21 08:37:41 --> Total execution time: 0.1972
INFO - 2017-08-21 08:40:54 --> Config Class Initialized
INFO - 2017-08-21 08:40:54 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:40:54 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:40:54 --> Utf8 Class Initialized
INFO - 2017-08-21 08:40:54 --> URI Class Initialized
INFO - 2017-08-21 08:40:54 --> Router Class Initialized
INFO - 2017-08-21 08:40:54 --> Output Class Initialized
INFO - 2017-08-21 08:40:54 --> Security Class Initialized
DEBUG - 2017-08-21 08:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:40:54 --> Input Class Initialized
INFO - 2017-08-21 08:40:54 --> Language Class Initialized
INFO - 2017-08-21 08:40:54 --> Loader Class Initialized
INFO - 2017-08-21 08:40:54 --> Helper loaded: url_helper
INFO - 2017-08-21 08:40:54 --> Helper loaded: file_helper
INFO - 2017-08-21 08:40:55 --> Database Driver Class Initialized
INFO - 2017-08-21 08:40:55 --> Email Class Initialized
DEBUG - 2017-08-21 08:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:40:55 --> Table Class Initialized
INFO - 2017-08-21 08:40:55 --> Controller Class Initialized
INFO - 2017-08-21 08:40:55 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:40:55 --> Final output sent to browser
DEBUG - 2017-08-21 08:40:55 --> Total execution time: 0.2209
INFO - 2017-08-21 08:41:14 --> Config Class Initialized
INFO - 2017-08-21 08:41:14 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:41:14 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:41:14 --> Utf8 Class Initialized
INFO - 2017-08-21 08:41:14 --> URI Class Initialized
INFO - 2017-08-21 08:41:14 --> Router Class Initialized
INFO - 2017-08-21 08:41:14 --> Output Class Initialized
INFO - 2017-08-21 08:41:14 --> Security Class Initialized
DEBUG - 2017-08-21 08:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:41:14 --> Input Class Initialized
INFO - 2017-08-21 08:41:14 --> Language Class Initialized
INFO - 2017-08-21 08:41:14 --> Loader Class Initialized
INFO - 2017-08-21 08:41:14 --> Helper loaded: url_helper
INFO - 2017-08-21 08:41:14 --> Helper loaded: file_helper
INFO - 2017-08-21 08:41:14 --> Database Driver Class Initialized
INFO - 2017-08-21 08:41:14 --> Email Class Initialized
DEBUG - 2017-08-21 08:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:41:14 --> Table Class Initialized
INFO - 2017-08-21 08:41:14 --> Controller Class Initialized
INFO - 2017-08-21 08:41:14 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:41:14 --> Final output sent to browser
DEBUG - 2017-08-21 08:41:14 --> Total execution time: 0.2139
INFO - 2017-08-21 08:41:48 --> Config Class Initialized
INFO - 2017-08-21 08:41:49 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:41:49 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:41:49 --> Utf8 Class Initialized
INFO - 2017-08-21 08:41:49 --> URI Class Initialized
INFO - 2017-08-21 08:41:49 --> Router Class Initialized
INFO - 2017-08-21 08:41:49 --> Output Class Initialized
INFO - 2017-08-21 08:41:49 --> Security Class Initialized
DEBUG - 2017-08-21 08:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:41:49 --> Input Class Initialized
INFO - 2017-08-21 08:41:49 --> Language Class Initialized
INFO - 2017-08-21 08:41:49 --> Loader Class Initialized
INFO - 2017-08-21 08:41:49 --> Helper loaded: url_helper
INFO - 2017-08-21 08:41:49 --> Helper loaded: file_helper
INFO - 2017-08-21 08:41:49 --> Database Driver Class Initialized
INFO - 2017-08-21 08:41:49 --> Email Class Initialized
DEBUG - 2017-08-21 08:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:41:49 --> Table Class Initialized
INFO - 2017-08-21 08:41:49 --> Controller Class Initialized
INFO - 2017-08-21 08:41:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:41:49 --> Final output sent to browser
DEBUG - 2017-08-21 08:41:49 --> Total execution time: 0.2152
INFO - 2017-08-21 08:44:05 --> Config Class Initialized
INFO - 2017-08-21 08:44:05 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:44:05 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:44:05 --> Utf8 Class Initialized
INFO - 2017-08-21 08:44:05 --> URI Class Initialized
INFO - 2017-08-21 08:44:05 --> Router Class Initialized
INFO - 2017-08-21 08:44:05 --> Output Class Initialized
INFO - 2017-08-21 08:44:05 --> Security Class Initialized
DEBUG - 2017-08-21 08:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:44:06 --> Input Class Initialized
INFO - 2017-08-21 08:44:06 --> Language Class Initialized
INFO - 2017-08-21 08:44:06 --> Loader Class Initialized
INFO - 2017-08-21 08:44:06 --> Helper loaded: url_helper
INFO - 2017-08-21 08:44:06 --> Helper loaded: file_helper
INFO - 2017-08-21 08:44:06 --> Database Driver Class Initialized
INFO - 2017-08-21 08:44:06 --> Email Class Initialized
DEBUG - 2017-08-21 08:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:44:06 --> Table Class Initialized
INFO - 2017-08-21 08:44:06 --> Controller Class Initialized
INFO - 2017-08-21 08:44:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:44:06 --> Final output sent to browser
DEBUG - 2017-08-21 08:44:06 --> Total execution time: 0.2139
INFO - 2017-08-21 08:47:25 --> Config Class Initialized
INFO - 2017-08-21 08:47:25 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:47:25 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:47:25 --> Utf8 Class Initialized
INFO - 2017-08-21 08:47:25 --> URI Class Initialized
INFO - 2017-08-21 08:47:25 --> Router Class Initialized
INFO - 2017-08-21 08:47:25 --> Output Class Initialized
INFO - 2017-08-21 08:47:26 --> Security Class Initialized
DEBUG - 2017-08-21 08:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:47:26 --> Input Class Initialized
INFO - 2017-08-21 08:47:26 --> Language Class Initialized
INFO - 2017-08-21 08:47:26 --> Loader Class Initialized
INFO - 2017-08-21 08:47:26 --> Helper loaded: url_helper
INFO - 2017-08-21 08:47:26 --> Helper loaded: file_helper
INFO - 2017-08-21 08:47:26 --> Database Driver Class Initialized
INFO - 2017-08-21 08:47:26 --> Email Class Initialized
DEBUG - 2017-08-21 08:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:47:26 --> Table Class Initialized
INFO - 2017-08-21 08:47:26 --> Controller Class Initialized
INFO - 2017-08-21 08:47:26 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:47:26 --> Final output sent to browser
DEBUG - 2017-08-21 08:47:26 --> Total execution time: 0.2060
INFO - 2017-08-21 08:47:59 --> Config Class Initialized
INFO - 2017-08-21 08:47:59 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:47:59 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:47:59 --> Utf8 Class Initialized
INFO - 2017-08-21 08:47:59 --> URI Class Initialized
INFO - 2017-08-21 08:47:59 --> Router Class Initialized
INFO - 2017-08-21 08:47:59 --> Output Class Initialized
INFO - 2017-08-21 08:47:59 --> Security Class Initialized
DEBUG - 2017-08-21 08:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:47:59 --> Input Class Initialized
INFO - 2017-08-21 08:47:59 --> Language Class Initialized
INFO - 2017-08-21 08:47:59 --> Loader Class Initialized
INFO - 2017-08-21 08:47:59 --> Helper loaded: url_helper
INFO - 2017-08-21 08:47:59 --> Helper loaded: file_helper
INFO - 2017-08-21 08:47:59 --> Database Driver Class Initialized
INFO - 2017-08-21 08:47:59 --> Email Class Initialized
DEBUG - 2017-08-21 08:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:47:59 --> Table Class Initialized
INFO - 2017-08-21 08:47:59 --> Controller Class Initialized
INFO - 2017-08-21 08:47:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:47:59 --> Final output sent to browser
DEBUG - 2017-08-21 08:47:59 --> Total execution time: 0.2088
INFO - 2017-08-21 08:48:04 --> Config Class Initialized
INFO - 2017-08-21 08:48:04 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:48:04 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:48:04 --> Utf8 Class Initialized
INFO - 2017-08-21 08:48:04 --> URI Class Initialized
INFO - 2017-08-21 08:48:04 --> Router Class Initialized
INFO - 2017-08-21 08:48:04 --> Output Class Initialized
INFO - 2017-08-21 08:48:04 --> Security Class Initialized
DEBUG - 2017-08-21 08:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:48:04 --> Input Class Initialized
INFO - 2017-08-21 08:48:04 --> Language Class Initialized
INFO - 2017-08-21 08:48:04 --> Loader Class Initialized
INFO - 2017-08-21 08:48:04 --> Helper loaded: url_helper
INFO - 2017-08-21 08:48:04 --> Helper loaded: file_helper
INFO - 2017-08-21 08:48:04 --> Database Driver Class Initialized
INFO - 2017-08-21 08:48:04 --> Email Class Initialized
DEBUG - 2017-08-21 08:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:48:04 --> Table Class Initialized
INFO - 2017-08-21 08:48:04 --> Controller Class Initialized
INFO - 2017-08-21 08:48:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:48:04 --> Final output sent to browser
DEBUG - 2017-08-21 08:48:04 --> Total execution time: 0.2121
INFO - 2017-08-21 08:48:11 --> Config Class Initialized
INFO - 2017-08-21 08:48:11 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:48:11 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:48:11 --> Utf8 Class Initialized
INFO - 2017-08-21 08:48:11 --> URI Class Initialized
INFO - 2017-08-21 08:48:11 --> Router Class Initialized
INFO - 2017-08-21 08:48:11 --> Output Class Initialized
INFO - 2017-08-21 08:48:11 --> Security Class Initialized
DEBUG - 2017-08-21 08:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:48:11 --> Input Class Initialized
INFO - 2017-08-21 08:48:11 --> Language Class Initialized
INFO - 2017-08-21 08:48:11 --> Loader Class Initialized
INFO - 2017-08-21 08:48:11 --> Helper loaded: url_helper
INFO - 2017-08-21 08:48:11 --> Helper loaded: file_helper
INFO - 2017-08-21 08:48:11 --> Database Driver Class Initialized
INFO - 2017-08-21 08:48:11 --> Email Class Initialized
DEBUG - 2017-08-21 08:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:48:11 --> Table Class Initialized
INFO - 2017-08-21 08:48:11 --> Controller Class Initialized
INFO - 2017-08-21 08:48:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:48:11 --> Final output sent to browser
DEBUG - 2017-08-21 08:48:11 --> Total execution time: 0.2104
INFO - 2017-08-21 08:48:26 --> Config Class Initialized
INFO - 2017-08-21 08:48:26 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:48:26 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:48:26 --> Utf8 Class Initialized
INFO - 2017-08-21 08:48:26 --> URI Class Initialized
INFO - 2017-08-21 08:48:26 --> Router Class Initialized
INFO - 2017-08-21 08:48:26 --> Output Class Initialized
INFO - 2017-08-21 08:48:26 --> Security Class Initialized
DEBUG - 2017-08-21 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:48:27 --> Input Class Initialized
INFO - 2017-08-21 08:48:27 --> Language Class Initialized
INFO - 2017-08-21 08:48:27 --> Loader Class Initialized
INFO - 2017-08-21 08:48:27 --> Helper loaded: url_helper
INFO - 2017-08-21 08:48:27 --> Helper loaded: file_helper
INFO - 2017-08-21 08:48:27 --> Database Driver Class Initialized
INFO - 2017-08-21 08:48:27 --> Email Class Initialized
DEBUG - 2017-08-21 08:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:48:27 --> Table Class Initialized
INFO - 2017-08-21 08:48:27 --> Controller Class Initialized
INFO - 2017-08-21 08:48:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:48:27 --> Final output sent to browser
DEBUG - 2017-08-21 08:48:27 --> Total execution time: 0.2081
INFO - 2017-08-21 08:48:28 --> Config Class Initialized
INFO - 2017-08-21 08:48:28 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:48:28 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:48:28 --> Utf8 Class Initialized
INFO - 2017-08-21 08:48:28 --> URI Class Initialized
INFO - 2017-08-21 08:48:28 --> Router Class Initialized
INFO - 2017-08-21 08:48:28 --> Output Class Initialized
INFO - 2017-08-21 08:48:28 --> Security Class Initialized
DEBUG - 2017-08-21 08:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:48:28 --> Input Class Initialized
INFO - 2017-08-21 08:48:28 --> Language Class Initialized
INFO - 2017-08-21 08:48:28 --> Loader Class Initialized
INFO - 2017-08-21 08:48:28 --> Helper loaded: url_helper
INFO - 2017-08-21 08:48:28 --> Helper loaded: file_helper
INFO - 2017-08-21 08:48:28 --> Database Driver Class Initialized
INFO - 2017-08-21 08:48:28 --> Email Class Initialized
DEBUG - 2017-08-21 08:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:48:28 --> Table Class Initialized
INFO - 2017-08-21 08:48:28 --> Controller Class Initialized
INFO - 2017-08-21 08:48:28 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:48:28 --> Final output sent to browser
DEBUG - 2017-08-21 08:48:28 --> Total execution time: 0.2168
INFO - 2017-08-21 08:48:41 --> Config Class Initialized
INFO - 2017-08-21 08:48:41 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:48:41 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:48:41 --> Utf8 Class Initialized
INFO - 2017-08-21 08:48:41 --> URI Class Initialized
INFO - 2017-08-21 08:48:41 --> Router Class Initialized
INFO - 2017-08-21 08:48:41 --> Output Class Initialized
INFO - 2017-08-21 08:48:41 --> Security Class Initialized
DEBUG - 2017-08-21 08:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:48:41 --> Input Class Initialized
INFO - 2017-08-21 08:48:41 --> Language Class Initialized
INFO - 2017-08-21 08:48:41 --> Loader Class Initialized
INFO - 2017-08-21 08:48:41 --> Helper loaded: url_helper
INFO - 2017-08-21 08:48:41 --> Helper loaded: file_helper
INFO - 2017-08-21 08:48:41 --> Database Driver Class Initialized
INFO - 2017-08-21 08:48:41 --> Email Class Initialized
DEBUG - 2017-08-21 08:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:48:41 --> Table Class Initialized
INFO - 2017-08-21 08:48:41 --> Controller Class Initialized
INFO - 2017-08-21 08:48:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:48:41 --> Final output sent to browser
DEBUG - 2017-08-21 08:48:41 --> Total execution time: 0.2133
INFO - 2017-08-21 08:53:16 --> Config Class Initialized
INFO - 2017-08-21 08:53:16 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:53:16 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:53:16 --> Utf8 Class Initialized
INFO - 2017-08-21 08:53:16 --> URI Class Initialized
INFO - 2017-08-21 08:53:16 --> Router Class Initialized
INFO - 2017-08-21 08:53:16 --> Output Class Initialized
INFO - 2017-08-21 08:53:16 --> Security Class Initialized
DEBUG - 2017-08-21 08:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:53:16 --> Input Class Initialized
INFO - 2017-08-21 08:53:16 --> Language Class Initialized
INFO - 2017-08-21 08:53:16 --> Loader Class Initialized
INFO - 2017-08-21 08:53:16 --> Helper loaded: url_helper
INFO - 2017-08-21 08:53:16 --> Helper loaded: file_helper
INFO - 2017-08-21 08:53:16 --> Database Driver Class Initialized
INFO - 2017-08-21 08:53:16 --> Email Class Initialized
DEBUG - 2017-08-21 08:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:53:17 --> Table Class Initialized
INFO - 2017-08-21 08:53:17 --> Controller Class Initialized
INFO - 2017-08-21 08:53:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:53:17 --> Final output sent to browser
DEBUG - 2017-08-21 08:53:17 --> Total execution time: 0.2278
INFO - 2017-08-21 08:53:40 --> Config Class Initialized
INFO - 2017-08-21 08:53:40 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:53:40 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:53:40 --> Utf8 Class Initialized
INFO - 2017-08-21 08:53:40 --> URI Class Initialized
INFO - 2017-08-21 08:53:40 --> Router Class Initialized
INFO - 2017-08-21 08:53:40 --> Output Class Initialized
INFO - 2017-08-21 08:53:40 --> Security Class Initialized
DEBUG - 2017-08-21 08:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:53:40 --> Input Class Initialized
INFO - 2017-08-21 08:53:40 --> Language Class Initialized
INFO - 2017-08-21 08:53:40 --> Loader Class Initialized
INFO - 2017-08-21 08:53:40 --> Helper loaded: url_helper
INFO - 2017-08-21 08:53:40 --> Helper loaded: file_helper
INFO - 2017-08-21 08:53:40 --> Database Driver Class Initialized
INFO - 2017-08-21 08:53:40 --> Email Class Initialized
DEBUG - 2017-08-21 08:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:53:40 --> Table Class Initialized
INFO - 2017-08-21 08:53:40 --> Controller Class Initialized
INFO - 2017-08-21 08:53:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:53:40 --> Final output sent to browser
DEBUG - 2017-08-21 08:53:40 --> Total execution time: 0.2110
INFO - 2017-08-21 08:56:48 --> Config Class Initialized
INFO - 2017-08-21 08:56:48 --> Hooks Class Initialized
DEBUG - 2017-08-21 08:56:48 --> UTF-8 Support Enabled
INFO - 2017-08-21 08:56:48 --> Utf8 Class Initialized
INFO - 2017-08-21 08:56:48 --> URI Class Initialized
INFO - 2017-08-21 08:56:48 --> Router Class Initialized
INFO - 2017-08-21 08:56:48 --> Output Class Initialized
INFO - 2017-08-21 08:56:48 --> Security Class Initialized
DEBUG - 2017-08-21 08:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 08:56:48 --> Input Class Initialized
INFO - 2017-08-21 08:56:48 --> Language Class Initialized
INFO - 2017-08-21 08:56:49 --> Loader Class Initialized
INFO - 2017-08-21 08:56:49 --> Helper loaded: url_helper
INFO - 2017-08-21 08:56:49 --> Helper loaded: file_helper
INFO - 2017-08-21 08:56:49 --> Database Driver Class Initialized
INFO - 2017-08-21 08:56:49 --> Email Class Initialized
DEBUG - 2017-08-21 08:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 08:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 08:56:49 --> Table Class Initialized
INFO - 2017-08-21 08:56:49 --> Controller Class Initialized
INFO - 2017-08-21 08:56:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 08:56:49 --> Final output sent to browser
DEBUG - 2017-08-21 08:56:49 --> Total execution time: 0.2875
INFO - 2017-08-21 09:26:09 --> Config Class Initialized
INFO - 2017-08-21 09:26:09 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:26:09 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:26:09 --> Utf8 Class Initialized
INFO - 2017-08-21 09:26:09 --> URI Class Initialized
INFO - 2017-08-21 09:26:09 --> Router Class Initialized
INFO - 2017-08-21 09:26:09 --> Output Class Initialized
INFO - 2017-08-21 09:26:09 --> Security Class Initialized
DEBUG - 2017-08-21 09:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:26:09 --> Input Class Initialized
INFO - 2017-08-21 09:26:09 --> Language Class Initialized
INFO - 2017-08-21 09:26:09 --> Loader Class Initialized
INFO - 2017-08-21 09:26:09 --> Helper loaded: url_helper
INFO - 2017-08-21 09:26:09 --> Helper loaded: file_helper
INFO - 2017-08-21 09:26:09 --> Database Driver Class Initialized
INFO - 2017-08-21 09:26:09 --> Email Class Initialized
DEBUG - 2017-08-21 09:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:26:09 --> Table Class Initialized
INFO - 2017-08-21 09:26:09 --> Controller Class Initialized
INFO - 2017-08-21 09:26:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:26:09 --> Final output sent to browser
DEBUG - 2017-08-21 09:26:09 --> Total execution time: 0.2642
INFO - 2017-08-21 09:27:42 --> Config Class Initialized
INFO - 2017-08-21 09:27:42 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:27:42 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:27:42 --> Utf8 Class Initialized
INFO - 2017-08-21 09:27:42 --> URI Class Initialized
INFO - 2017-08-21 09:27:42 --> Router Class Initialized
INFO - 2017-08-21 09:27:42 --> Output Class Initialized
INFO - 2017-08-21 09:27:42 --> Security Class Initialized
DEBUG - 2017-08-21 09:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:27:42 --> Input Class Initialized
INFO - 2017-08-21 09:27:42 --> Language Class Initialized
INFO - 2017-08-21 09:27:42 --> Loader Class Initialized
INFO - 2017-08-21 09:27:42 --> Helper loaded: url_helper
INFO - 2017-08-21 09:27:42 --> Helper loaded: file_helper
INFO - 2017-08-21 09:27:42 --> Database Driver Class Initialized
INFO - 2017-08-21 09:27:42 --> Email Class Initialized
DEBUG - 2017-08-21 09:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:27:42 --> Table Class Initialized
INFO - 2017-08-21 09:27:42 --> Controller Class Initialized
INFO - 2017-08-21 09:27:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:27:42 --> Final output sent to browser
DEBUG - 2017-08-21 09:27:42 --> Total execution time: 0.2166
INFO - 2017-08-21 09:27:47 --> Config Class Initialized
INFO - 2017-08-21 09:27:47 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:27:47 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:27:47 --> Utf8 Class Initialized
INFO - 2017-08-21 09:27:47 --> URI Class Initialized
INFO - 2017-08-21 09:27:47 --> Router Class Initialized
INFO - 2017-08-21 09:27:47 --> Output Class Initialized
INFO - 2017-08-21 09:27:47 --> Security Class Initialized
DEBUG - 2017-08-21 09:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:27:47 --> Input Class Initialized
INFO - 2017-08-21 09:27:47 --> Language Class Initialized
INFO - 2017-08-21 09:27:47 --> Loader Class Initialized
INFO - 2017-08-21 09:27:47 --> Helper loaded: url_helper
INFO - 2017-08-21 09:27:47 --> Helper loaded: file_helper
INFO - 2017-08-21 09:27:47 --> Database Driver Class Initialized
INFO - 2017-08-21 09:27:47 --> Email Class Initialized
DEBUG - 2017-08-21 09:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:27:47 --> Table Class Initialized
INFO - 2017-08-21 09:27:47 --> Controller Class Initialized
INFO - 2017-08-21 09:27:47 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:27:47 --> Final output sent to browser
DEBUG - 2017-08-21 09:27:47 --> Total execution time: 0.2144
INFO - 2017-08-21 09:28:34 --> Config Class Initialized
INFO - 2017-08-21 09:28:34 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:28:34 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:28:34 --> Utf8 Class Initialized
INFO - 2017-08-21 09:28:34 --> URI Class Initialized
INFO - 2017-08-21 09:28:34 --> Router Class Initialized
INFO - 2017-08-21 09:28:34 --> Output Class Initialized
INFO - 2017-08-21 09:28:34 --> Security Class Initialized
DEBUG - 2017-08-21 09:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:28:34 --> Input Class Initialized
INFO - 2017-08-21 09:28:34 --> Language Class Initialized
INFO - 2017-08-21 09:28:34 --> Loader Class Initialized
INFO - 2017-08-21 09:28:34 --> Helper loaded: url_helper
INFO - 2017-08-21 09:28:34 --> Helper loaded: file_helper
INFO - 2017-08-21 09:28:34 --> Database Driver Class Initialized
INFO - 2017-08-21 09:28:34 --> Email Class Initialized
DEBUG - 2017-08-21 09:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:28:34 --> Table Class Initialized
INFO - 2017-08-21 09:28:34 --> Controller Class Initialized
INFO - 2017-08-21 09:28:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:28:34 --> Final output sent to browser
DEBUG - 2017-08-21 09:28:34 --> Total execution time: 0.2035
INFO - 2017-08-21 09:28:43 --> Config Class Initialized
INFO - 2017-08-21 09:28:43 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:28:43 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:28:43 --> Utf8 Class Initialized
INFO - 2017-08-21 09:28:43 --> URI Class Initialized
INFO - 2017-08-21 09:28:43 --> Router Class Initialized
INFO - 2017-08-21 09:28:43 --> Output Class Initialized
INFO - 2017-08-21 09:28:43 --> Security Class Initialized
DEBUG - 2017-08-21 09:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:28:43 --> Input Class Initialized
INFO - 2017-08-21 09:28:43 --> Language Class Initialized
INFO - 2017-08-21 09:28:43 --> Loader Class Initialized
INFO - 2017-08-21 09:28:43 --> Helper loaded: url_helper
INFO - 2017-08-21 09:28:43 --> Helper loaded: file_helper
INFO - 2017-08-21 09:28:43 --> Database Driver Class Initialized
INFO - 2017-08-21 09:28:43 --> Email Class Initialized
DEBUG - 2017-08-21 09:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:28:43 --> Table Class Initialized
INFO - 2017-08-21 09:28:43 --> Controller Class Initialized
INFO - 2017-08-21 09:28:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:28:43 --> Final output sent to browser
DEBUG - 2017-08-21 09:28:43 --> Total execution time: 0.2089
INFO - 2017-08-21 09:29:16 --> Config Class Initialized
INFO - 2017-08-21 09:29:16 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:29:16 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:29:16 --> Utf8 Class Initialized
INFO - 2017-08-21 09:29:16 --> URI Class Initialized
INFO - 2017-08-21 09:29:16 --> Router Class Initialized
INFO - 2017-08-21 09:29:16 --> Output Class Initialized
INFO - 2017-08-21 09:29:16 --> Security Class Initialized
DEBUG - 2017-08-21 09:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:29:16 --> Input Class Initialized
INFO - 2017-08-21 09:29:16 --> Language Class Initialized
INFO - 2017-08-21 09:29:16 --> Loader Class Initialized
INFO - 2017-08-21 09:29:16 --> Helper loaded: url_helper
INFO - 2017-08-21 09:29:16 --> Helper loaded: file_helper
INFO - 2017-08-21 09:29:16 --> Database Driver Class Initialized
INFO - 2017-08-21 09:29:16 --> Email Class Initialized
DEBUG - 2017-08-21 09:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:29:16 --> Table Class Initialized
INFO - 2017-08-21 09:29:16 --> Controller Class Initialized
INFO - 2017-08-21 09:29:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:29:16 --> Final output sent to browser
DEBUG - 2017-08-21 09:29:16 --> Total execution time: 0.2187
INFO - 2017-08-21 09:29:25 --> Config Class Initialized
INFO - 2017-08-21 09:29:25 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:29:25 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:29:25 --> Utf8 Class Initialized
INFO - 2017-08-21 09:29:25 --> URI Class Initialized
INFO - 2017-08-21 09:29:25 --> Router Class Initialized
INFO - 2017-08-21 09:29:25 --> Output Class Initialized
INFO - 2017-08-21 09:29:25 --> Security Class Initialized
DEBUG - 2017-08-21 09:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:29:25 --> Input Class Initialized
INFO - 2017-08-21 09:29:25 --> Language Class Initialized
INFO - 2017-08-21 09:29:25 --> Loader Class Initialized
INFO - 2017-08-21 09:29:25 --> Helper loaded: url_helper
INFO - 2017-08-21 09:29:25 --> Helper loaded: file_helper
INFO - 2017-08-21 09:29:25 --> Database Driver Class Initialized
INFO - 2017-08-21 09:29:25 --> Email Class Initialized
DEBUG - 2017-08-21 09:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:29:25 --> Table Class Initialized
INFO - 2017-08-21 09:29:25 --> Controller Class Initialized
INFO - 2017-08-21 09:29:25 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:29:25 --> Final output sent to browser
DEBUG - 2017-08-21 09:29:25 --> Total execution time: 0.2102
INFO - 2017-08-21 09:35:10 --> Config Class Initialized
INFO - 2017-08-21 09:35:10 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:35:10 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:35:10 --> Utf8 Class Initialized
INFO - 2017-08-21 09:35:10 --> URI Class Initialized
INFO - 2017-08-21 09:35:10 --> Router Class Initialized
INFO - 2017-08-21 09:35:10 --> Output Class Initialized
INFO - 2017-08-21 09:35:10 --> Security Class Initialized
DEBUG - 2017-08-21 09:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:35:10 --> Input Class Initialized
INFO - 2017-08-21 09:35:10 --> Language Class Initialized
INFO - 2017-08-21 09:35:10 --> Loader Class Initialized
INFO - 2017-08-21 09:35:10 --> Helper loaded: url_helper
INFO - 2017-08-21 09:35:10 --> Helper loaded: file_helper
INFO - 2017-08-21 09:35:10 --> Database Driver Class Initialized
INFO - 2017-08-21 09:35:10 --> Email Class Initialized
DEBUG - 2017-08-21 09:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:35:10 --> Table Class Initialized
INFO - 2017-08-21 09:35:10 --> Controller Class Initialized
INFO - 2017-08-21 09:35:10 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:35:10 --> Final output sent to browser
DEBUG - 2017-08-21 09:35:10 --> Total execution time: 0.2078
INFO - 2017-08-21 09:35:45 --> Config Class Initialized
INFO - 2017-08-21 09:35:45 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:35:45 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:35:45 --> Utf8 Class Initialized
INFO - 2017-08-21 09:35:45 --> URI Class Initialized
INFO - 2017-08-21 09:35:45 --> Router Class Initialized
INFO - 2017-08-21 09:35:45 --> Output Class Initialized
INFO - 2017-08-21 09:35:45 --> Security Class Initialized
DEBUG - 2017-08-21 09:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:35:45 --> Input Class Initialized
INFO - 2017-08-21 09:35:45 --> Language Class Initialized
INFO - 2017-08-21 09:35:45 --> Loader Class Initialized
INFO - 2017-08-21 09:35:45 --> Helper loaded: url_helper
INFO - 2017-08-21 09:35:45 --> Helper loaded: file_helper
INFO - 2017-08-21 09:35:45 --> Database Driver Class Initialized
INFO - 2017-08-21 09:35:45 --> Email Class Initialized
DEBUG - 2017-08-21 09:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:35:45 --> Table Class Initialized
INFO - 2017-08-21 09:35:45 --> Controller Class Initialized
INFO - 2017-08-21 09:35:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:35:45 --> Final output sent to browser
DEBUG - 2017-08-21 09:35:45 --> Total execution time: 0.2212
INFO - 2017-08-21 09:36:22 --> Config Class Initialized
INFO - 2017-08-21 09:36:22 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:36:22 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:36:22 --> Utf8 Class Initialized
INFO - 2017-08-21 09:36:22 --> URI Class Initialized
INFO - 2017-08-21 09:36:22 --> Router Class Initialized
INFO - 2017-08-21 09:36:22 --> Output Class Initialized
INFO - 2017-08-21 09:36:22 --> Security Class Initialized
DEBUG - 2017-08-21 09:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:36:22 --> Input Class Initialized
INFO - 2017-08-21 09:36:22 --> Language Class Initialized
INFO - 2017-08-21 09:36:22 --> Loader Class Initialized
INFO - 2017-08-21 09:36:23 --> Helper loaded: url_helper
INFO - 2017-08-21 09:36:23 --> Helper loaded: file_helper
INFO - 2017-08-21 09:36:23 --> Database Driver Class Initialized
INFO - 2017-08-21 09:36:23 --> Email Class Initialized
DEBUG - 2017-08-21 09:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:36:23 --> Table Class Initialized
INFO - 2017-08-21 09:36:23 --> Controller Class Initialized
INFO - 2017-08-21 09:36:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:36:23 --> Final output sent to browser
DEBUG - 2017-08-21 09:36:23 --> Total execution time: 0.2090
INFO - 2017-08-21 09:36:40 --> Config Class Initialized
INFO - 2017-08-21 09:36:40 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:36:40 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:36:40 --> Utf8 Class Initialized
INFO - 2017-08-21 09:36:40 --> URI Class Initialized
INFO - 2017-08-21 09:36:40 --> Router Class Initialized
INFO - 2017-08-21 09:36:40 --> Output Class Initialized
INFO - 2017-08-21 09:36:40 --> Security Class Initialized
DEBUG - 2017-08-21 09:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:36:40 --> Input Class Initialized
INFO - 2017-08-21 09:36:40 --> Language Class Initialized
INFO - 2017-08-21 09:36:40 --> Loader Class Initialized
INFO - 2017-08-21 09:36:40 --> Helper loaded: url_helper
INFO - 2017-08-21 09:36:40 --> Helper loaded: file_helper
INFO - 2017-08-21 09:36:40 --> Database Driver Class Initialized
INFO - 2017-08-21 09:36:40 --> Email Class Initialized
DEBUG - 2017-08-21 09:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:36:40 --> Table Class Initialized
INFO - 2017-08-21 09:36:40 --> Controller Class Initialized
INFO - 2017-08-21 09:36:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:36:40 --> Final output sent to browser
DEBUG - 2017-08-21 09:36:40 --> Total execution time: 0.2181
INFO - 2017-08-21 09:36:41 --> Config Class Initialized
INFO - 2017-08-21 09:36:41 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:36:41 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:36:41 --> Utf8 Class Initialized
INFO - 2017-08-21 09:36:42 --> URI Class Initialized
INFO - 2017-08-21 09:36:42 --> Router Class Initialized
INFO - 2017-08-21 09:36:42 --> Output Class Initialized
INFO - 2017-08-21 09:36:42 --> Security Class Initialized
DEBUG - 2017-08-21 09:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:36:42 --> Input Class Initialized
INFO - 2017-08-21 09:36:42 --> Language Class Initialized
INFO - 2017-08-21 09:36:42 --> Loader Class Initialized
INFO - 2017-08-21 09:36:42 --> Helper loaded: url_helper
INFO - 2017-08-21 09:36:42 --> Helper loaded: file_helper
INFO - 2017-08-21 09:36:42 --> Database Driver Class Initialized
INFO - 2017-08-21 09:36:42 --> Email Class Initialized
DEBUG - 2017-08-21 09:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:36:42 --> Table Class Initialized
INFO - 2017-08-21 09:36:42 --> Controller Class Initialized
INFO - 2017-08-21 09:36:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:36:42 --> Final output sent to browser
DEBUG - 2017-08-21 09:36:42 --> Total execution time: 0.2079
INFO - 2017-08-21 09:36:49 --> Config Class Initialized
INFO - 2017-08-21 09:36:49 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:36:49 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:36:49 --> Utf8 Class Initialized
INFO - 2017-08-21 09:36:49 --> URI Class Initialized
INFO - 2017-08-21 09:36:49 --> Router Class Initialized
INFO - 2017-08-21 09:36:49 --> Output Class Initialized
INFO - 2017-08-21 09:36:49 --> Security Class Initialized
DEBUG - 2017-08-21 09:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:36:49 --> Input Class Initialized
INFO - 2017-08-21 09:36:49 --> Language Class Initialized
INFO - 2017-08-21 09:36:49 --> Loader Class Initialized
INFO - 2017-08-21 09:36:49 --> Helper loaded: url_helper
INFO - 2017-08-21 09:36:49 --> Helper loaded: file_helper
INFO - 2017-08-21 09:36:49 --> Database Driver Class Initialized
INFO - 2017-08-21 09:36:49 --> Email Class Initialized
DEBUG - 2017-08-21 09:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:36:49 --> Table Class Initialized
INFO - 2017-08-21 09:36:49 --> Controller Class Initialized
INFO - 2017-08-21 09:36:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:36:49 --> Final output sent to browser
DEBUG - 2017-08-21 09:36:49 --> Total execution time: 0.2147
INFO - 2017-08-21 09:38:38 --> Config Class Initialized
INFO - 2017-08-21 09:38:38 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:38:38 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:38:38 --> Utf8 Class Initialized
INFO - 2017-08-21 09:38:38 --> URI Class Initialized
INFO - 2017-08-21 09:38:38 --> Router Class Initialized
INFO - 2017-08-21 09:38:38 --> Output Class Initialized
INFO - 2017-08-21 09:38:38 --> Security Class Initialized
DEBUG - 2017-08-21 09:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:38:38 --> Input Class Initialized
INFO - 2017-08-21 09:38:38 --> Language Class Initialized
INFO - 2017-08-21 09:38:38 --> Loader Class Initialized
INFO - 2017-08-21 09:38:38 --> Helper loaded: url_helper
INFO - 2017-08-21 09:38:38 --> Helper loaded: file_helper
INFO - 2017-08-21 09:38:38 --> Database Driver Class Initialized
INFO - 2017-08-21 09:38:38 --> Email Class Initialized
DEBUG - 2017-08-21 09:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:38:38 --> Table Class Initialized
INFO - 2017-08-21 09:38:38 --> Controller Class Initialized
INFO - 2017-08-21 09:38:38 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:38:38 --> Final output sent to browser
DEBUG - 2017-08-21 09:38:38 --> Total execution time: 0.2207
INFO - 2017-08-21 09:38:39 --> Config Class Initialized
INFO - 2017-08-21 09:38:40 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:38:40 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:38:40 --> Utf8 Class Initialized
INFO - 2017-08-21 09:38:40 --> URI Class Initialized
INFO - 2017-08-21 09:38:40 --> Router Class Initialized
INFO - 2017-08-21 09:38:40 --> Output Class Initialized
INFO - 2017-08-21 09:38:40 --> Security Class Initialized
DEBUG - 2017-08-21 09:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:38:40 --> Input Class Initialized
INFO - 2017-08-21 09:38:40 --> Language Class Initialized
INFO - 2017-08-21 09:38:40 --> Loader Class Initialized
INFO - 2017-08-21 09:38:40 --> Helper loaded: url_helper
INFO - 2017-08-21 09:38:40 --> Helper loaded: file_helper
INFO - 2017-08-21 09:38:40 --> Database Driver Class Initialized
INFO - 2017-08-21 09:38:40 --> Email Class Initialized
DEBUG - 2017-08-21 09:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:38:40 --> Table Class Initialized
INFO - 2017-08-21 09:38:40 --> Controller Class Initialized
INFO - 2017-08-21 09:38:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:38:40 --> Final output sent to browser
DEBUG - 2017-08-21 09:38:40 --> Total execution time: 0.2199
INFO - 2017-08-21 09:38:44 --> Config Class Initialized
INFO - 2017-08-21 09:38:44 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:38:44 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:38:44 --> Utf8 Class Initialized
INFO - 2017-08-21 09:38:44 --> URI Class Initialized
INFO - 2017-08-21 09:38:44 --> Router Class Initialized
INFO - 2017-08-21 09:38:44 --> Output Class Initialized
INFO - 2017-08-21 09:38:44 --> Security Class Initialized
DEBUG - 2017-08-21 09:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:38:44 --> Input Class Initialized
INFO - 2017-08-21 09:38:44 --> Language Class Initialized
INFO - 2017-08-21 09:38:44 --> Loader Class Initialized
INFO - 2017-08-21 09:38:44 --> Helper loaded: url_helper
INFO - 2017-08-21 09:38:44 --> Helper loaded: file_helper
INFO - 2017-08-21 09:38:44 --> Database Driver Class Initialized
INFO - 2017-08-21 09:38:44 --> Email Class Initialized
DEBUG - 2017-08-21 09:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:38:44 --> Table Class Initialized
INFO - 2017-08-21 09:38:44 --> Controller Class Initialized
INFO - 2017-08-21 09:38:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:38:44 --> Final output sent to browser
DEBUG - 2017-08-21 09:38:44 --> Total execution time: 0.2149
INFO - 2017-08-21 09:40:38 --> Config Class Initialized
INFO - 2017-08-21 09:40:38 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:40:38 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:40:38 --> Utf8 Class Initialized
INFO - 2017-08-21 09:40:38 --> URI Class Initialized
INFO - 2017-08-21 09:40:38 --> Router Class Initialized
INFO - 2017-08-21 09:40:38 --> Output Class Initialized
INFO - 2017-08-21 09:40:38 --> Security Class Initialized
DEBUG - 2017-08-21 09:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:40:38 --> Input Class Initialized
INFO - 2017-08-21 09:40:38 --> Language Class Initialized
INFO - 2017-08-21 09:40:38 --> Loader Class Initialized
INFO - 2017-08-21 09:40:38 --> Helper loaded: url_helper
INFO - 2017-08-21 09:40:38 --> Helper loaded: file_helper
INFO - 2017-08-21 09:40:38 --> Database Driver Class Initialized
INFO - 2017-08-21 09:40:38 --> Email Class Initialized
DEBUG - 2017-08-21 09:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:40:38 --> Table Class Initialized
INFO - 2017-08-21 09:40:38 --> Controller Class Initialized
INFO - 2017-08-21 09:40:38 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:40:38 --> Final output sent to browser
DEBUG - 2017-08-21 09:40:38 --> Total execution time: 0.2374
INFO - 2017-08-21 09:40:42 --> Config Class Initialized
INFO - 2017-08-21 09:40:42 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:40:42 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:40:42 --> Utf8 Class Initialized
INFO - 2017-08-21 09:40:42 --> URI Class Initialized
INFO - 2017-08-21 09:40:42 --> Router Class Initialized
INFO - 2017-08-21 09:40:42 --> Output Class Initialized
INFO - 2017-08-21 09:40:42 --> Security Class Initialized
DEBUG - 2017-08-21 09:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:40:42 --> Input Class Initialized
INFO - 2017-08-21 09:40:42 --> Language Class Initialized
INFO - 2017-08-21 09:40:42 --> Loader Class Initialized
INFO - 2017-08-21 09:40:42 --> Helper loaded: url_helper
INFO - 2017-08-21 09:40:42 --> Helper loaded: file_helper
INFO - 2017-08-21 09:40:42 --> Database Driver Class Initialized
INFO - 2017-08-21 09:40:42 --> Email Class Initialized
DEBUG - 2017-08-21 09:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:40:42 --> Table Class Initialized
INFO - 2017-08-21 09:40:42 --> Controller Class Initialized
INFO - 2017-08-21 09:40:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:40:42 --> Final output sent to browser
DEBUG - 2017-08-21 09:40:42 --> Total execution time: 0.2225
INFO - 2017-08-21 09:40:50 --> Config Class Initialized
INFO - 2017-08-21 09:40:50 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:40:50 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:40:50 --> Utf8 Class Initialized
INFO - 2017-08-21 09:40:50 --> URI Class Initialized
INFO - 2017-08-21 09:40:50 --> Router Class Initialized
INFO - 2017-08-21 09:40:50 --> Output Class Initialized
INFO - 2017-08-21 09:40:50 --> Security Class Initialized
DEBUG - 2017-08-21 09:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:40:50 --> Input Class Initialized
INFO - 2017-08-21 09:40:50 --> Language Class Initialized
INFO - 2017-08-21 09:40:50 --> Loader Class Initialized
INFO - 2017-08-21 09:40:50 --> Helper loaded: url_helper
INFO - 2017-08-21 09:40:50 --> Helper loaded: file_helper
INFO - 2017-08-21 09:40:50 --> Database Driver Class Initialized
INFO - 2017-08-21 09:40:50 --> Email Class Initialized
DEBUG - 2017-08-21 09:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:40:50 --> Table Class Initialized
INFO - 2017-08-21 09:40:50 --> Controller Class Initialized
INFO - 2017-08-21 09:40:50 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:40:50 --> Final output sent to browser
DEBUG - 2017-08-21 09:40:50 --> Total execution time: 0.2205
INFO - 2017-08-21 09:42:51 --> Config Class Initialized
INFO - 2017-08-21 09:42:51 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:42:51 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:42:51 --> Utf8 Class Initialized
INFO - 2017-08-21 09:42:51 --> URI Class Initialized
INFO - 2017-08-21 09:42:51 --> Router Class Initialized
INFO - 2017-08-21 09:42:51 --> Output Class Initialized
INFO - 2017-08-21 09:42:51 --> Security Class Initialized
DEBUG - 2017-08-21 09:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:42:51 --> Input Class Initialized
INFO - 2017-08-21 09:42:51 --> Language Class Initialized
INFO - 2017-08-21 09:42:51 --> Loader Class Initialized
INFO - 2017-08-21 09:42:51 --> Helper loaded: url_helper
INFO - 2017-08-21 09:42:51 --> Helper loaded: file_helper
INFO - 2017-08-21 09:42:51 --> Database Driver Class Initialized
INFO - 2017-08-21 09:42:51 --> Email Class Initialized
DEBUG - 2017-08-21 09:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:42:51 --> Table Class Initialized
INFO - 2017-08-21 09:42:51 --> Controller Class Initialized
INFO - 2017-08-21 09:42:51 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:42:51 --> Final output sent to browser
DEBUG - 2017-08-21 09:42:51 --> Total execution time: 0.2216
INFO - 2017-08-21 09:43:01 --> Config Class Initialized
INFO - 2017-08-21 09:43:01 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:43:01 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:43:01 --> Utf8 Class Initialized
INFO - 2017-08-21 09:43:01 --> URI Class Initialized
INFO - 2017-08-21 09:43:01 --> Router Class Initialized
INFO - 2017-08-21 09:43:01 --> Output Class Initialized
INFO - 2017-08-21 09:43:01 --> Security Class Initialized
DEBUG - 2017-08-21 09:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:43:01 --> Input Class Initialized
INFO - 2017-08-21 09:43:01 --> Language Class Initialized
INFO - 2017-08-21 09:43:01 --> Loader Class Initialized
INFO - 2017-08-21 09:43:01 --> Helper loaded: url_helper
INFO - 2017-08-21 09:43:01 --> Helper loaded: file_helper
INFO - 2017-08-21 09:43:01 --> Database Driver Class Initialized
INFO - 2017-08-21 09:43:01 --> Email Class Initialized
DEBUG - 2017-08-21 09:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:43:01 --> Table Class Initialized
INFO - 2017-08-21 09:43:01 --> Controller Class Initialized
INFO - 2017-08-21 09:43:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:43:01 --> Final output sent to browser
DEBUG - 2017-08-21 09:43:01 --> Total execution time: 0.2155
INFO - 2017-08-21 09:43:01 --> Config Class Initialized
INFO - 2017-08-21 09:43:01 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:43:01 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:43:01 --> Utf8 Class Initialized
INFO - 2017-08-21 09:43:01 --> URI Class Initialized
INFO - 2017-08-21 09:43:01 --> Router Class Initialized
INFO - 2017-08-21 09:43:01 --> Output Class Initialized
INFO - 2017-08-21 09:43:01 --> Security Class Initialized
DEBUG - 2017-08-21 09:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:43:01 --> Input Class Initialized
INFO - 2017-08-21 09:43:01 --> Language Class Initialized
INFO - 2017-08-21 09:43:01 --> Loader Class Initialized
INFO - 2017-08-21 09:43:01 --> Helper loaded: url_helper
INFO - 2017-08-21 09:43:01 --> Helper loaded: file_helper
INFO - 2017-08-21 09:43:01 --> Database Driver Class Initialized
INFO - 2017-08-21 09:43:02 --> Email Class Initialized
DEBUG - 2017-08-21 09:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:43:02 --> Table Class Initialized
INFO - 2017-08-21 09:43:02 --> Controller Class Initialized
INFO - 2017-08-21 09:43:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:43:02 --> Final output sent to browser
DEBUG - 2017-08-21 09:43:02 --> Total execution time: 0.2418
INFO - 2017-08-21 09:43:16 --> Config Class Initialized
INFO - 2017-08-21 09:43:16 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:43:16 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:43:16 --> Utf8 Class Initialized
INFO - 2017-08-21 09:43:16 --> URI Class Initialized
INFO - 2017-08-21 09:43:16 --> Router Class Initialized
INFO - 2017-08-21 09:43:16 --> Output Class Initialized
INFO - 2017-08-21 09:43:16 --> Security Class Initialized
DEBUG - 2017-08-21 09:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:43:16 --> Input Class Initialized
INFO - 2017-08-21 09:43:16 --> Language Class Initialized
INFO - 2017-08-21 09:43:16 --> Loader Class Initialized
INFO - 2017-08-21 09:43:16 --> Helper loaded: url_helper
INFO - 2017-08-21 09:43:16 --> Helper loaded: file_helper
INFO - 2017-08-21 09:43:16 --> Database Driver Class Initialized
INFO - 2017-08-21 09:43:16 --> Email Class Initialized
DEBUG - 2017-08-21 09:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:43:16 --> Table Class Initialized
INFO - 2017-08-21 09:43:16 --> Controller Class Initialized
INFO - 2017-08-21 09:43:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:43:16 --> Final output sent to browser
DEBUG - 2017-08-21 09:43:16 --> Total execution time: 0.2302
INFO - 2017-08-21 09:43:27 --> Config Class Initialized
INFO - 2017-08-21 09:43:27 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:43:27 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:43:27 --> Utf8 Class Initialized
INFO - 2017-08-21 09:43:27 --> URI Class Initialized
INFO - 2017-08-21 09:43:27 --> Router Class Initialized
INFO - 2017-08-21 09:43:27 --> Output Class Initialized
INFO - 2017-08-21 09:43:27 --> Security Class Initialized
DEBUG - 2017-08-21 09:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:43:27 --> Input Class Initialized
INFO - 2017-08-21 09:43:27 --> Language Class Initialized
INFO - 2017-08-21 09:43:27 --> Loader Class Initialized
INFO - 2017-08-21 09:43:27 --> Helper loaded: url_helper
INFO - 2017-08-21 09:43:27 --> Helper loaded: file_helper
INFO - 2017-08-21 09:43:27 --> Database Driver Class Initialized
INFO - 2017-08-21 09:43:27 --> Email Class Initialized
DEBUG - 2017-08-21 09:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:43:27 --> Table Class Initialized
INFO - 2017-08-21 09:43:27 --> Controller Class Initialized
INFO - 2017-08-21 09:43:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:43:27 --> Final output sent to browser
DEBUG - 2017-08-21 09:43:27 --> Total execution time: 0.2264
INFO - 2017-08-21 09:43:27 --> Config Class Initialized
INFO - 2017-08-21 09:43:27 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:43:27 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:43:27 --> Utf8 Class Initialized
INFO - 2017-08-21 09:43:28 --> URI Class Initialized
INFO - 2017-08-21 09:43:28 --> Router Class Initialized
INFO - 2017-08-21 09:43:28 --> Output Class Initialized
INFO - 2017-08-21 09:43:28 --> Security Class Initialized
DEBUG - 2017-08-21 09:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:43:28 --> Input Class Initialized
INFO - 2017-08-21 09:43:28 --> Language Class Initialized
INFO - 2017-08-21 09:43:28 --> Loader Class Initialized
INFO - 2017-08-21 09:43:28 --> Helper loaded: url_helper
INFO - 2017-08-21 09:43:28 --> Helper loaded: file_helper
INFO - 2017-08-21 09:43:28 --> Database Driver Class Initialized
INFO - 2017-08-21 09:43:28 --> Email Class Initialized
DEBUG - 2017-08-21 09:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:43:28 --> Table Class Initialized
INFO - 2017-08-21 09:43:28 --> Controller Class Initialized
INFO - 2017-08-21 09:43:28 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:43:28 --> Final output sent to browser
DEBUG - 2017-08-21 09:43:28 --> Total execution time: 0.2345
INFO - 2017-08-21 09:43:35 --> Config Class Initialized
INFO - 2017-08-21 09:43:35 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:43:35 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:43:35 --> Utf8 Class Initialized
INFO - 2017-08-21 09:43:35 --> URI Class Initialized
INFO - 2017-08-21 09:43:35 --> Router Class Initialized
INFO - 2017-08-21 09:43:35 --> Output Class Initialized
INFO - 2017-08-21 09:43:35 --> Security Class Initialized
DEBUG - 2017-08-21 09:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:43:35 --> Input Class Initialized
INFO - 2017-08-21 09:43:35 --> Language Class Initialized
INFO - 2017-08-21 09:43:35 --> Loader Class Initialized
INFO - 2017-08-21 09:43:35 --> Helper loaded: url_helper
INFO - 2017-08-21 09:43:35 --> Helper loaded: file_helper
INFO - 2017-08-21 09:43:35 --> Database Driver Class Initialized
INFO - 2017-08-21 09:43:35 --> Email Class Initialized
DEBUG - 2017-08-21 09:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:43:35 --> Table Class Initialized
INFO - 2017-08-21 09:43:35 --> Controller Class Initialized
INFO - 2017-08-21 09:43:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:43:35 --> Final output sent to browser
DEBUG - 2017-08-21 09:43:35 --> Total execution time: 0.2193
INFO - 2017-08-21 09:44:33 --> Config Class Initialized
INFO - 2017-08-21 09:44:33 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:44:33 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:44:33 --> Utf8 Class Initialized
INFO - 2017-08-21 09:44:33 --> URI Class Initialized
INFO - 2017-08-21 09:44:33 --> Router Class Initialized
INFO - 2017-08-21 09:44:33 --> Output Class Initialized
INFO - 2017-08-21 09:44:33 --> Security Class Initialized
DEBUG - 2017-08-21 09:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:44:33 --> Input Class Initialized
INFO - 2017-08-21 09:44:33 --> Language Class Initialized
INFO - 2017-08-21 09:44:33 --> Loader Class Initialized
INFO - 2017-08-21 09:44:33 --> Helper loaded: url_helper
INFO - 2017-08-21 09:44:33 --> Helper loaded: file_helper
INFO - 2017-08-21 09:44:33 --> Database Driver Class Initialized
INFO - 2017-08-21 09:44:33 --> Email Class Initialized
DEBUG - 2017-08-21 09:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:44:33 --> Table Class Initialized
INFO - 2017-08-21 09:44:33 --> Controller Class Initialized
INFO - 2017-08-21 09:44:33 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:44:33 --> Final output sent to browser
DEBUG - 2017-08-21 09:44:33 --> Total execution time: 0.2229
INFO - 2017-08-21 09:44:40 --> Config Class Initialized
INFO - 2017-08-21 09:44:40 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:44:40 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:44:40 --> Utf8 Class Initialized
INFO - 2017-08-21 09:44:40 --> URI Class Initialized
INFO - 2017-08-21 09:44:40 --> Router Class Initialized
INFO - 2017-08-21 09:44:40 --> Output Class Initialized
INFO - 2017-08-21 09:44:40 --> Security Class Initialized
DEBUG - 2017-08-21 09:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:44:40 --> Input Class Initialized
INFO - 2017-08-21 09:44:40 --> Language Class Initialized
INFO - 2017-08-21 09:44:40 --> Loader Class Initialized
INFO - 2017-08-21 09:44:40 --> Helper loaded: url_helper
INFO - 2017-08-21 09:44:40 --> Helper loaded: file_helper
INFO - 2017-08-21 09:44:40 --> Database Driver Class Initialized
INFO - 2017-08-21 09:44:40 --> Email Class Initialized
DEBUG - 2017-08-21 09:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:44:41 --> Table Class Initialized
INFO - 2017-08-21 09:44:41 --> Controller Class Initialized
INFO - 2017-08-21 09:44:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:44:41 --> Final output sent to browser
DEBUG - 2017-08-21 09:44:41 --> Total execution time: 0.2269
INFO - 2017-08-21 09:45:01 --> Config Class Initialized
INFO - 2017-08-21 09:45:01 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:45:01 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:45:01 --> Utf8 Class Initialized
INFO - 2017-08-21 09:45:01 --> URI Class Initialized
INFO - 2017-08-21 09:45:01 --> Router Class Initialized
INFO - 2017-08-21 09:45:01 --> Output Class Initialized
INFO - 2017-08-21 09:45:01 --> Security Class Initialized
DEBUG - 2017-08-21 09:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:45:01 --> Input Class Initialized
INFO - 2017-08-21 09:45:01 --> Language Class Initialized
INFO - 2017-08-21 09:45:01 --> Loader Class Initialized
INFO - 2017-08-21 09:45:01 --> Helper loaded: url_helper
INFO - 2017-08-21 09:45:01 --> Helper loaded: file_helper
INFO - 2017-08-21 09:45:01 --> Database Driver Class Initialized
INFO - 2017-08-21 09:45:01 --> Email Class Initialized
DEBUG - 2017-08-21 09:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:45:01 --> Table Class Initialized
INFO - 2017-08-21 09:45:01 --> Controller Class Initialized
INFO - 2017-08-21 09:45:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:45:01 --> Final output sent to browser
DEBUG - 2017-08-21 09:45:01 --> Total execution time: 0.2301
INFO - 2017-08-21 09:45:29 --> Config Class Initialized
INFO - 2017-08-21 09:45:29 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:45:29 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:45:29 --> Utf8 Class Initialized
INFO - 2017-08-21 09:45:29 --> URI Class Initialized
INFO - 2017-08-21 09:45:29 --> Router Class Initialized
INFO - 2017-08-21 09:45:29 --> Output Class Initialized
INFO - 2017-08-21 09:45:29 --> Security Class Initialized
DEBUG - 2017-08-21 09:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:45:29 --> Input Class Initialized
INFO - 2017-08-21 09:45:29 --> Language Class Initialized
INFO - 2017-08-21 09:45:29 --> Loader Class Initialized
INFO - 2017-08-21 09:45:29 --> Helper loaded: url_helper
INFO - 2017-08-21 09:45:29 --> Helper loaded: file_helper
INFO - 2017-08-21 09:45:29 --> Database Driver Class Initialized
INFO - 2017-08-21 09:45:29 --> Email Class Initialized
DEBUG - 2017-08-21 09:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:45:29 --> Table Class Initialized
INFO - 2017-08-21 09:45:29 --> Controller Class Initialized
INFO - 2017-08-21 09:45:29 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:45:29 --> Final output sent to browser
DEBUG - 2017-08-21 09:45:29 --> Total execution time: 0.2265
INFO - 2017-08-21 09:45:49 --> Config Class Initialized
INFO - 2017-08-21 09:45:49 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:45:49 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:45:49 --> Utf8 Class Initialized
INFO - 2017-08-21 09:45:49 --> URI Class Initialized
INFO - 2017-08-21 09:45:49 --> Router Class Initialized
INFO - 2017-08-21 09:45:49 --> Output Class Initialized
INFO - 2017-08-21 09:45:49 --> Security Class Initialized
DEBUG - 2017-08-21 09:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:45:49 --> Input Class Initialized
INFO - 2017-08-21 09:45:49 --> Language Class Initialized
INFO - 2017-08-21 09:45:49 --> Loader Class Initialized
INFO - 2017-08-21 09:45:49 --> Helper loaded: url_helper
INFO - 2017-08-21 09:45:49 --> Helper loaded: file_helper
INFO - 2017-08-21 09:45:49 --> Database Driver Class Initialized
INFO - 2017-08-21 09:45:49 --> Email Class Initialized
DEBUG - 2017-08-21 09:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:45:49 --> Table Class Initialized
INFO - 2017-08-21 09:45:49 --> Controller Class Initialized
INFO - 2017-08-21 09:45:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:45:49 --> Final output sent to browser
DEBUG - 2017-08-21 09:45:49 --> Total execution time: 0.2167
INFO - 2017-08-21 09:45:56 --> Config Class Initialized
INFO - 2017-08-21 09:45:56 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:45:56 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:45:56 --> Utf8 Class Initialized
INFO - 2017-08-21 09:45:56 --> URI Class Initialized
INFO - 2017-08-21 09:45:56 --> Router Class Initialized
INFO - 2017-08-21 09:45:56 --> Output Class Initialized
INFO - 2017-08-21 09:45:56 --> Security Class Initialized
DEBUG - 2017-08-21 09:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:45:56 --> Input Class Initialized
INFO - 2017-08-21 09:45:56 --> Language Class Initialized
INFO - 2017-08-21 09:45:56 --> Loader Class Initialized
INFO - 2017-08-21 09:45:56 --> Helper loaded: url_helper
INFO - 2017-08-21 09:45:56 --> Helper loaded: file_helper
INFO - 2017-08-21 09:45:56 --> Database Driver Class Initialized
INFO - 2017-08-21 09:45:56 --> Email Class Initialized
DEBUG - 2017-08-21 09:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:45:56 --> Table Class Initialized
INFO - 2017-08-21 09:45:56 --> Controller Class Initialized
INFO - 2017-08-21 09:45:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:45:56 --> Final output sent to browser
DEBUG - 2017-08-21 09:45:56 --> Total execution time: 0.2176
INFO - 2017-08-21 09:46:11 --> Config Class Initialized
INFO - 2017-08-21 09:46:11 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:46:11 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:46:11 --> Utf8 Class Initialized
INFO - 2017-08-21 09:46:11 --> URI Class Initialized
INFO - 2017-08-21 09:46:11 --> Router Class Initialized
INFO - 2017-08-21 09:46:11 --> Output Class Initialized
INFO - 2017-08-21 09:46:11 --> Security Class Initialized
DEBUG - 2017-08-21 09:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:46:11 --> Input Class Initialized
INFO - 2017-08-21 09:46:11 --> Language Class Initialized
INFO - 2017-08-21 09:46:11 --> Loader Class Initialized
INFO - 2017-08-21 09:46:11 --> Helper loaded: url_helper
INFO - 2017-08-21 09:46:11 --> Helper loaded: file_helper
INFO - 2017-08-21 09:46:11 --> Database Driver Class Initialized
INFO - 2017-08-21 09:46:11 --> Email Class Initialized
DEBUG - 2017-08-21 09:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:46:11 --> Table Class Initialized
INFO - 2017-08-21 09:46:11 --> Controller Class Initialized
INFO - 2017-08-21 09:46:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:46:11 --> Final output sent to browser
DEBUG - 2017-08-21 09:46:11 --> Total execution time: 0.2195
INFO - 2017-08-21 09:49:03 --> Config Class Initialized
INFO - 2017-08-21 09:49:03 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:49:03 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:49:03 --> Utf8 Class Initialized
INFO - 2017-08-21 09:49:03 --> URI Class Initialized
INFO - 2017-08-21 09:49:03 --> Router Class Initialized
INFO - 2017-08-21 09:49:04 --> Output Class Initialized
INFO - 2017-08-21 09:49:04 --> Security Class Initialized
DEBUG - 2017-08-21 09:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:49:04 --> Input Class Initialized
INFO - 2017-08-21 09:49:04 --> Language Class Initialized
INFO - 2017-08-21 09:49:04 --> Loader Class Initialized
INFO - 2017-08-21 09:49:04 --> Helper loaded: url_helper
INFO - 2017-08-21 09:49:04 --> Helper loaded: file_helper
INFO - 2017-08-21 09:49:04 --> Database Driver Class Initialized
INFO - 2017-08-21 09:49:04 --> Email Class Initialized
DEBUG - 2017-08-21 09:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:49:04 --> Table Class Initialized
INFO - 2017-08-21 09:49:04 --> Controller Class Initialized
INFO - 2017-08-21 09:49:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:49:04 --> Final output sent to browser
DEBUG - 2017-08-21 09:49:04 --> Total execution time: 0.2450
INFO - 2017-08-21 09:51:21 --> Config Class Initialized
INFO - 2017-08-21 09:51:21 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:51:21 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:51:21 --> Utf8 Class Initialized
INFO - 2017-08-21 09:51:21 --> URI Class Initialized
INFO - 2017-08-21 09:51:21 --> Router Class Initialized
INFO - 2017-08-21 09:51:21 --> Output Class Initialized
INFO - 2017-08-21 09:51:21 --> Security Class Initialized
DEBUG - 2017-08-21 09:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:51:21 --> Input Class Initialized
INFO - 2017-08-21 09:51:21 --> Language Class Initialized
INFO - 2017-08-21 09:51:21 --> Loader Class Initialized
INFO - 2017-08-21 09:51:21 --> Helper loaded: url_helper
INFO - 2017-08-21 09:51:21 --> Helper loaded: file_helper
INFO - 2017-08-21 09:51:21 --> Database Driver Class Initialized
INFO - 2017-08-21 09:51:21 --> Email Class Initialized
DEBUG - 2017-08-21 09:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:51:21 --> Table Class Initialized
INFO - 2017-08-21 09:51:21 --> Controller Class Initialized
INFO - 2017-08-21 09:51:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:51:21 --> Final output sent to browser
DEBUG - 2017-08-21 09:51:21 --> Total execution time: 0.2605
INFO - 2017-08-21 09:58:23 --> Config Class Initialized
INFO - 2017-08-21 09:58:23 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:58:23 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:58:23 --> Utf8 Class Initialized
INFO - 2017-08-21 09:58:23 --> URI Class Initialized
INFO - 2017-08-21 09:58:23 --> Router Class Initialized
INFO - 2017-08-21 09:58:23 --> Output Class Initialized
INFO - 2017-08-21 09:58:23 --> Security Class Initialized
DEBUG - 2017-08-21 09:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:58:23 --> Input Class Initialized
INFO - 2017-08-21 09:58:23 --> Language Class Initialized
INFO - 2017-08-21 09:58:23 --> Loader Class Initialized
INFO - 2017-08-21 09:58:23 --> Helper loaded: url_helper
INFO - 2017-08-21 09:58:23 --> Helper loaded: file_helper
INFO - 2017-08-21 09:58:23 --> Database Driver Class Initialized
INFO - 2017-08-21 09:58:23 --> Email Class Initialized
DEBUG - 2017-08-21 09:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:58:23 --> Table Class Initialized
INFO - 2017-08-21 09:58:23 --> Controller Class Initialized
INFO - 2017-08-21 09:58:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:58:23 --> Final output sent to browser
DEBUG - 2017-08-21 09:58:24 --> Total execution time: 0.2338
INFO - 2017-08-21 09:58:45 --> Config Class Initialized
INFO - 2017-08-21 09:58:45 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:58:45 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:58:45 --> Utf8 Class Initialized
INFO - 2017-08-21 09:58:45 --> URI Class Initialized
INFO - 2017-08-21 09:58:45 --> Router Class Initialized
INFO - 2017-08-21 09:58:45 --> Output Class Initialized
INFO - 2017-08-21 09:58:45 --> Security Class Initialized
DEBUG - 2017-08-21 09:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:58:45 --> Input Class Initialized
INFO - 2017-08-21 09:58:45 --> Language Class Initialized
INFO - 2017-08-21 09:58:45 --> Loader Class Initialized
INFO - 2017-08-21 09:58:45 --> Helper loaded: url_helper
INFO - 2017-08-21 09:58:45 --> Helper loaded: file_helper
INFO - 2017-08-21 09:58:45 --> Database Driver Class Initialized
INFO - 2017-08-21 09:58:45 --> Email Class Initialized
DEBUG - 2017-08-21 09:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:58:45 --> Table Class Initialized
INFO - 2017-08-21 09:58:45 --> Controller Class Initialized
INFO - 2017-08-21 09:58:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:58:45 --> Final output sent to browser
DEBUG - 2017-08-21 09:58:45 --> Total execution time: 0.2226
INFO - 2017-08-21 09:59:43 --> Config Class Initialized
INFO - 2017-08-21 09:59:43 --> Hooks Class Initialized
DEBUG - 2017-08-21 09:59:43 --> UTF-8 Support Enabled
INFO - 2017-08-21 09:59:43 --> Utf8 Class Initialized
INFO - 2017-08-21 09:59:43 --> URI Class Initialized
INFO - 2017-08-21 09:59:43 --> Router Class Initialized
INFO - 2017-08-21 09:59:43 --> Output Class Initialized
INFO - 2017-08-21 09:59:43 --> Security Class Initialized
DEBUG - 2017-08-21 09:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 09:59:43 --> Input Class Initialized
INFO - 2017-08-21 09:59:43 --> Language Class Initialized
INFO - 2017-08-21 09:59:43 --> Loader Class Initialized
INFO - 2017-08-21 09:59:43 --> Helper loaded: url_helper
INFO - 2017-08-21 09:59:43 --> Helper loaded: file_helper
INFO - 2017-08-21 09:59:43 --> Database Driver Class Initialized
INFO - 2017-08-21 09:59:43 --> Email Class Initialized
DEBUG - 2017-08-21 09:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 09:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 09:59:43 --> Table Class Initialized
INFO - 2017-08-21 09:59:43 --> Controller Class Initialized
INFO - 2017-08-21 09:59:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 09:59:43 --> Final output sent to browser
DEBUG - 2017-08-21 09:59:43 --> Total execution time: 0.2188
INFO - 2017-08-21 10:00:02 --> Config Class Initialized
INFO - 2017-08-21 10:00:02 --> Hooks Class Initialized
DEBUG - 2017-08-21 10:00:02 --> UTF-8 Support Enabled
INFO - 2017-08-21 10:00:02 --> Utf8 Class Initialized
INFO - 2017-08-21 10:00:02 --> URI Class Initialized
INFO - 2017-08-21 10:00:02 --> Router Class Initialized
INFO - 2017-08-21 10:00:02 --> Output Class Initialized
INFO - 2017-08-21 10:00:02 --> Security Class Initialized
DEBUG - 2017-08-21 10:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 10:00:02 --> Input Class Initialized
INFO - 2017-08-21 10:00:02 --> Language Class Initialized
INFO - 2017-08-21 10:00:02 --> Loader Class Initialized
INFO - 2017-08-21 10:00:02 --> Helper loaded: url_helper
INFO - 2017-08-21 10:00:02 --> Helper loaded: file_helper
INFO - 2017-08-21 10:00:02 --> Database Driver Class Initialized
INFO - 2017-08-21 10:00:02 --> Email Class Initialized
DEBUG - 2017-08-21 10:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 10:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 10:00:02 --> Table Class Initialized
INFO - 2017-08-21 10:00:02 --> Controller Class Initialized
INFO - 2017-08-21 10:00:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 10:00:02 --> Final output sent to browser
DEBUG - 2017-08-21 10:00:02 --> Total execution time: 0.2498
INFO - 2017-08-21 10:00:17 --> Config Class Initialized
INFO - 2017-08-21 10:00:17 --> Hooks Class Initialized
DEBUG - 2017-08-21 10:00:17 --> UTF-8 Support Enabled
INFO - 2017-08-21 10:00:17 --> Utf8 Class Initialized
INFO - 2017-08-21 10:00:17 --> URI Class Initialized
INFO - 2017-08-21 10:00:17 --> Router Class Initialized
INFO - 2017-08-21 10:00:17 --> Output Class Initialized
INFO - 2017-08-21 10:00:17 --> Security Class Initialized
DEBUG - 2017-08-21 10:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 10:00:17 --> Input Class Initialized
INFO - 2017-08-21 10:00:17 --> Language Class Initialized
INFO - 2017-08-21 10:00:17 --> Loader Class Initialized
INFO - 2017-08-21 10:00:17 --> Helper loaded: url_helper
INFO - 2017-08-21 10:00:17 --> Helper loaded: file_helper
INFO - 2017-08-21 10:00:17 --> Database Driver Class Initialized
INFO - 2017-08-21 10:00:17 --> Email Class Initialized
DEBUG - 2017-08-21 10:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 10:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 10:00:17 --> Table Class Initialized
INFO - 2017-08-21 10:00:17 --> Controller Class Initialized
INFO - 2017-08-21 10:00:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 10:00:17 --> Final output sent to browser
DEBUG - 2017-08-21 10:00:17 --> Total execution time: 0.2169
INFO - 2017-08-21 10:00:19 --> Config Class Initialized
INFO - 2017-08-21 10:00:19 --> Hooks Class Initialized
DEBUG - 2017-08-21 10:00:19 --> UTF-8 Support Enabled
INFO - 2017-08-21 10:00:19 --> Utf8 Class Initialized
INFO - 2017-08-21 10:00:19 --> URI Class Initialized
INFO - 2017-08-21 10:00:19 --> Router Class Initialized
INFO - 2017-08-21 10:00:19 --> Output Class Initialized
INFO - 2017-08-21 10:00:19 --> Security Class Initialized
DEBUG - 2017-08-21 10:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 10:00:19 --> Input Class Initialized
INFO - 2017-08-21 10:00:19 --> Language Class Initialized
INFO - 2017-08-21 10:00:19 --> Loader Class Initialized
INFO - 2017-08-21 10:00:19 --> Helper loaded: url_helper
INFO - 2017-08-21 10:00:19 --> Helper loaded: file_helper
INFO - 2017-08-21 10:00:19 --> Database Driver Class Initialized
INFO - 2017-08-21 10:00:19 --> Email Class Initialized
DEBUG - 2017-08-21 10:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 10:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 10:00:19 --> Table Class Initialized
INFO - 2017-08-21 10:00:19 --> Controller Class Initialized
INFO - 2017-08-21 10:00:19 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 10:00:19 --> Final output sent to browser
DEBUG - 2017-08-21 10:00:19 --> Total execution time: 0.2288
INFO - 2017-08-21 10:00:37 --> Config Class Initialized
INFO - 2017-08-21 10:00:37 --> Hooks Class Initialized
DEBUG - 2017-08-21 10:00:37 --> UTF-8 Support Enabled
INFO - 2017-08-21 10:00:37 --> Utf8 Class Initialized
INFO - 2017-08-21 10:00:37 --> URI Class Initialized
INFO - 2017-08-21 10:00:38 --> Router Class Initialized
INFO - 2017-08-21 10:00:38 --> Output Class Initialized
INFO - 2017-08-21 10:00:38 --> Security Class Initialized
DEBUG - 2017-08-21 10:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 10:00:38 --> Input Class Initialized
INFO - 2017-08-21 10:00:38 --> Language Class Initialized
INFO - 2017-08-21 10:00:38 --> Loader Class Initialized
INFO - 2017-08-21 10:00:38 --> Helper loaded: url_helper
INFO - 2017-08-21 10:00:38 --> Helper loaded: file_helper
INFO - 2017-08-21 10:00:38 --> Database Driver Class Initialized
INFO - 2017-08-21 10:00:38 --> Email Class Initialized
DEBUG - 2017-08-21 10:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 10:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 10:00:38 --> Table Class Initialized
INFO - 2017-08-21 10:00:38 --> Controller Class Initialized
INFO - 2017-08-21 10:00:38 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 10:00:38 --> Final output sent to browser
DEBUG - 2017-08-21 10:00:38 --> Total execution time: 0.2312
INFO - 2017-08-21 10:00:54 --> Config Class Initialized
INFO - 2017-08-21 10:00:54 --> Hooks Class Initialized
DEBUG - 2017-08-21 10:00:54 --> UTF-8 Support Enabled
INFO - 2017-08-21 10:00:54 --> Utf8 Class Initialized
INFO - 2017-08-21 10:00:54 --> URI Class Initialized
INFO - 2017-08-21 10:00:54 --> Router Class Initialized
INFO - 2017-08-21 10:00:54 --> Output Class Initialized
INFO - 2017-08-21 10:00:54 --> Security Class Initialized
DEBUG - 2017-08-21 10:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 10:00:54 --> Input Class Initialized
INFO - 2017-08-21 10:00:54 --> Language Class Initialized
INFO - 2017-08-21 10:00:54 --> Loader Class Initialized
INFO - 2017-08-21 10:00:54 --> Helper loaded: url_helper
INFO - 2017-08-21 10:00:54 --> Helper loaded: file_helper
INFO - 2017-08-21 10:00:54 --> Database Driver Class Initialized
INFO - 2017-08-21 10:00:54 --> Email Class Initialized
DEBUG - 2017-08-21 10:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 10:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 10:00:54 --> Table Class Initialized
INFO - 2017-08-21 10:00:54 --> Controller Class Initialized
INFO - 2017-08-21 10:00:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 10:00:54 --> Final output sent to browser
DEBUG - 2017-08-21 10:00:54 --> Total execution time: 0.2198
INFO - 2017-08-21 10:01:04 --> Config Class Initialized
INFO - 2017-08-21 10:01:04 --> Hooks Class Initialized
DEBUG - 2017-08-21 10:01:04 --> UTF-8 Support Enabled
INFO - 2017-08-21 10:01:04 --> Utf8 Class Initialized
INFO - 2017-08-21 10:01:04 --> URI Class Initialized
INFO - 2017-08-21 10:01:04 --> Router Class Initialized
INFO - 2017-08-21 10:01:04 --> Output Class Initialized
INFO - 2017-08-21 10:01:04 --> Security Class Initialized
DEBUG - 2017-08-21 10:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 10:01:04 --> Input Class Initialized
INFO - 2017-08-21 10:01:04 --> Language Class Initialized
INFO - 2017-08-21 10:01:04 --> Loader Class Initialized
INFO - 2017-08-21 10:01:04 --> Helper loaded: url_helper
INFO - 2017-08-21 10:01:04 --> Helper loaded: file_helper
INFO - 2017-08-21 10:01:04 --> Database Driver Class Initialized
INFO - 2017-08-21 10:01:04 --> Email Class Initialized
DEBUG - 2017-08-21 10:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 10:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 10:01:04 --> Table Class Initialized
INFO - 2017-08-21 10:01:04 --> Controller Class Initialized
INFO - 2017-08-21 10:01:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 10:01:04 --> Final output sent to browser
DEBUG - 2017-08-21 10:01:04 --> Total execution time: 0.2320
INFO - 2017-08-21 10:03:05 --> Config Class Initialized
INFO - 2017-08-21 10:03:05 --> Hooks Class Initialized
DEBUG - 2017-08-21 10:03:05 --> UTF-8 Support Enabled
INFO - 2017-08-21 10:03:05 --> Utf8 Class Initialized
INFO - 2017-08-21 10:03:05 --> URI Class Initialized
INFO - 2017-08-21 10:03:05 --> Router Class Initialized
INFO - 2017-08-21 10:03:05 --> Output Class Initialized
INFO - 2017-08-21 10:03:05 --> Security Class Initialized
DEBUG - 2017-08-21 10:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 10:03:05 --> Input Class Initialized
INFO - 2017-08-21 10:03:05 --> Language Class Initialized
INFO - 2017-08-21 10:03:05 --> Loader Class Initialized
INFO - 2017-08-21 10:03:05 --> Helper loaded: url_helper
INFO - 2017-08-21 10:03:05 --> Helper loaded: file_helper
INFO - 2017-08-21 10:03:05 --> Database Driver Class Initialized
INFO - 2017-08-21 10:03:05 --> Email Class Initialized
DEBUG - 2017-08-21 10:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 10:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 10:03:05 --> Table Class Initialized
INFO - 2017-08-21 10:03:05 --> Controller Class Initialized
INFO - 2017-08-21 10:03:05 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 10:03:05 --> Final output sent to browser
DEBUG - 2017-08-21 10:03:05 --> Total execution time: 0.2360
INFO - 2017-08-21 10:56:09 --> Config Class Initialized
INFO - 2017-08-21 10:56:09 --> Hooks Class Initialized
DEBUG - 2017-08-21 10:56:09 --> UTF-8 Support Enabled
INFO - 2017-08-21 10:56:09 --> Utf8 Class Initialized
INFO - 2017-08-21 10:56:09 --> URI Class Initialized
INFO - 2017-08-21 10:56:09 --> Router Class Initialized
INFO - 2017-08-21 10:56:09 --> Output Class Initialized
INFO - 2017-08-21 10:56:09 --> Security Class Initialized
DEBUG - 2017-08-21 10:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 10:56:09 --> Input Class Initialized
INFO - 2017-08-21 10:56:09 --> Language Class Initialized
INFO - 2017-08-21 10:56:09 --> Loader Class Initialized
INFO - 2017-08-21 10:56:09 --> Helper loaded: url_helper
INFO - 2017-08-21 10:56:09 --> Helper loaded: file_helper
INFO - 2017-08-21 10:56:09 --> Database Driver Class Initialized
INFO - 2017-08-21 10:56:09 --> Email Class Initialized
DEBUG - 2017-08-21 10:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 10:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 10:56:09 --> Table Class Initialized
INFO - 2017-08-21 10:56:09 --> Controller Class Initialized
INFO - 2017-08-21 10:56:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 10:56:09 --> Final output sent to browser
DEBUG - 2017-08-21 10:56:09 --> Total execution time: 0.2421
INFO - 2017-08-21 12:29:06 --> Config Class Initialized
INFO - 2017-08-21 12:29:06 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:29:06 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:29:06 --> Utf8 Class Initialized
INFO - 2017-08-21 12:29:06 --> URI Class Initialized
INFO - 2017-08-21 12:29:06 --> Router Class Initialized
INFO - 2017-08-21 12:29:06 --> Output Class Initialized
INFO - 2017-08-21 12:29:06 --> Security Class Initialized
DEBUG - 2017-08-21 12:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:29:06 --> Input Class Initialized
INFO - 2017-08-21 12:29:07 --> Language Class Initialized
INFO - 2017-08-21 12:29:07 --> Loader Class Initialized
INFO - 2017-08-21 12:29:07 --> Helper loaded: url_helper
INFO - 2017-08-21 12:29:07 --> Helper loaded: file_helper
INFO - 2017-08-21 12:29:07 --> Database Driver Class Initialized
INFO - 2017-08-21 12:29:07 --> Email Class Initialized
DEBUG - 2017-08-21 12:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:29:07 --> Table Class Initialized
INFO - 2017-08-21 12:29:07 --> Controller Class Initialized
INFO - 2017-08-21 12:29:07 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:29:07 --> Final output sent to browser
DEBUG - 2017-08-21 12:29:07 --> Total execution time: 1.3833
INFO - 2017-08-21 12:29:11 --> Config Class Initialized
INFO - 2017-08-21 12:29:11 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:29:11 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:29:11 --> Utf8 Class Initialized
INFO - 2017-08-21 12:29:11 --> URI Class Initialized
INFO - 2017-08-21 12:29:11 --> Router Class Initialized
INFO - 2017-08-21 12:29:11 --> Output Class Initialized
INFO - 2017-08-21 12:29:11 --> Security Class Initialized
DEBUG - 2017-08-21 12:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:29:11 --> Input Class Initialized
INFO - 2017-08-21 12:29:11 --> Language Class Initialized
INFO - 2017-08-21 12:29:11 --> Loader Class Initialized
INFO - 2017-08-21 12:29:11 --> Helper loaded: url_helper
INFO - 2017-08-21 12:29:11 --> Helper loaded: file_helper
INFO - 2017-08-21 12:29:11 --> Database Driver Class Initialized
INFO - 2017-08-21 12:29:11 --> Email Class Initialized
DEBUG - 2017-08-21 12:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:29:11 --> Table Class Initialized
INFO - 2017-08-21 12:29:11 --> Controller Class Initialized
INFO - 2017-08-21 12:29:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:29:11 --> Final output sent to browser
DEBUG - 2017-08-21 12:29:11 --> Total execution time: 0.2370
INFO - 2017-08-21 12:29:30 --> Config Class Initialized
INFO - 2017-08-21 12:29:30 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:29:30 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:29:30 --> Utf8 Class Initialized
INFO - 2017-08-21 12:29:30 --> URI Class Initialized
INFO - 2017-08-21 12:29:30 --> Router Class Initialized
INFO - 2017-08-21 12:29:30 --> Output Class Initialized
INFO - 2017-08-21 12:29:30 --> Security Class Initialized
DEBUG - 2017-08-21 12:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:29:30 --> Input Class Initialized
INFO - 2017-08-21 12:29:30 --> Language Class Initialized
INFO - 2017-08-21 12:29:30 --> Loader Class Initialized
INFO - 2017-08-21 12:29:30 --> Helper loaded: url_helper
INFO - 2017-08-21 12:29:30 --> Helper loaded: file_helper
INFO - 2017-08-21 12:29:30 --> Database Driver Class Initialized
INFO - 2017-08-21 12:29:30 --> Email Class Initialized
DEBUG - 2017-08-21 12:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:29:30 --> Table Class Initialized
INFO - 2017-08-21 12:29:30 --> Controller Class Initialized
INFO - 2017-08-21 12:29:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:29:30 --> Final output sent to browser
DEBUG - 2017-08-21 12:29:30 --> Total execution time: 0.2371
INFO - 2017-08-21 12:31:36 --> Config Class Initialized
INFO - 2017-08-21 12:31:36 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:31:36 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:31:36 --> Utf8 Class Initialized
INFO - 2017-08-21 12:31:36 --> URI Class Initialized
INFO - 2017-08-21 12:31:36 --> Router Class Initialized
INFO - 2017-08-21 12:31:36 --> Output Class Initialized
INFO - 2017-08-21 12:31:36 --> Security Class Initialized
DEBUG - 2017-08-21 12:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:31:36 --> Input Class Initialized
INFO - 2017-08-21 12:31:36 --> Language Class Initialized
INFO - 2017-08-21 12:31:36 --> Loader Class Initialized
INFO - 2017-08-21 12:31:36 --> Helper loaded: url_helper
INFO - 2017-08-21 12:31:36 --> Helper loaded: file_helper
INFO - 2017-08-21 12:31:36 --> Database Driver Class Initialized
INFO - 2017-08-21 12:31:36 --> Email Class Initialized
DEBUG - 2017-08-21 12:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:31:37 --> Table Class Initialized
INFO - 2017-08-21 12:31:37 --> Controller Class Initialized
INFO - 2017-08-21 12:31:37 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:31:37 --> Final output sent to browser
DEBUG - 2017-08-21 12:31:37 --> Total execution time: 0.2370
INFO - 2017-08-21 12:31:46 --> Config Class Initialized
INFO - 2017-08-21 12:31:46 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:31:46 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:31:46 --> Utf8 Class Initialized
INFO - 2017-08-21 12:31:46 --> URI Class Initialized
INFO - 2017-08-21 12:31:46 --> Router Class Initialized
INFO - 2017-08-21 12:31:46 --> Output Class Initialized
INFO - 2017-08-21 12:31:46 --> Security Class Initialized
DEBUG - 2017-08-21 12:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:31:46 --> Input Class Initialized
INFO - 2017-08-21 12:31:46 --> Language Class Initialized
INFO - 2017-08-21 12:31:46 --> Loader Class Initialized
INFO - 2017-08-21 12:31:46 --> Helper loaded: url_helper
INFO - 2017-08-21 12:31:46 --> Helper loaded: file_helper
INFO - 2017-08-21 12:31:46 --> Database Driver Class Initialized
INFO - 2017-08-21 12:31:46 --> Email Class Initialized
DEBUG - 2017-08-21 12:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:31:46 --> Table Class Initialized
INFO - 2017-08-21 12:31:46 --> Controller Class Initialized
INFO - 2017-08-21 12:31:46 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:31:46 --> Final output sent to browser
DEBUG - 2017-08-21 12:31:46 --> Total execution time: 0.2367
INFO - 2017-08-21 12:31:54 --> Config Class Initialized
INFO - 2017-08-21 12:31:54 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:31:54 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:31:54 --> Utf8 Class Initialized
INFO - 2017-08-21 12:31:54 --> URI Class Initialized
INFO - 2017-08-21 12:31:54 --> Router Class Initialized
INFO - 2017-08-21 12:31:54 --> Output Class Initialized
INFO - 2017-08-21 12:31:54 --> Security Class Initialized
DEBUG - 2017-08-21 12:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:31:54 --> Input Class Initialized
INFO - 2017-08-21 12:31:54 --> Language Class Initialized
INFO - 2017-08-21 12:31:54 --> Loader Class Initialized
INFO - 2017-08-21 12:31:55 --> Helper loaded: url_helper
INFO - 2017-08-21 12:31:55 --> Helper loaded: file_helper
INFO - 2017-08-21 12:31:55 --> Database Driver Class Initialized
INFO - 2017-08-21 12:31:55 --> Email Class Initialized
DEBUG - 2017-08-21 12:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:31:55 --> Table Class Initialized
INFO - 2017-08-21 12:31:55 --> Controller Class Initialized
INFO - 2017-08-21 12:31:55 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:31:55 --> Final output sent to browser
DEBUG - 2017-08-21 12:31:55 --> Total execution time: 0.2471
INFO - 2017-08-21 12:32:00 --> Config Class Initialized
INFO - 2017-08-21 12:32:00 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:32:00 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:32:00 --> Utf8 Class Initialized
INFO - 2017-08-21 12:32:00 --> URI Class Initialized
INFO - 2017-08-21 12:32:00 --> Router Class Initialized
INFO - 2017-08-21 12:32:00 --> Output Class Initialized
INFO - 2017-08-21 12:32:00 --> Security Class Initialized
DEBUG - 2017-08-21 12:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:32:00 --> Input Class Initialized
INFO - 2017-08-21 12:32:00 --> Language Class Initialized
INFO - 2017-08-21 12:32:00 --> Loader Class Initialized
INFO - 2017-08-21 12:32:00 --> Helper loaded: url_helper
INFO - 2017-08-21 12:32:00 --> Helper loaded: file_helper
INFO - 2017-08-21 12:32:00 --> Database Driver Class Initialized
INFO - 2017-08-21 12:32:00 --> Email Class Initialized
DEBUG - 2017-08-21 12:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:32:00 --> Table Class Initialized
INFO - 2017-08-21 12:32:00 --> Controller Class Initialized
INFO - 2017-08-21 12:32:00 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:32:00 --> Final output sent to browser
DEBUG - 2017-08-21 12:32:00 --> Total execution time: 0.2335
INFO - 2017-08-21 12:32:04 --> Config Class Initialized
INFO - 2017-08-21 12:32:04 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:32:04 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:32:04 --> Utf8 Class Initialized
INFO - 2017-08-21 12:32:04 --> URI Class Initialized
INFO - 2017-08-21 12:32:04 --> Router Class Initialized
INFO - 2017-08-21 12:32:04 --> Output Class Initialized
INFO - 2017-08-21 12:32:04 --> Security Class Initialized
DEBUG - 2017-08-21 12:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:32:04 --> Input Class Initialized
INFO - 2017-08-21 12:32:04 --> Language Class Initialized
INFO - 2017-08-21 12:32:04 --> Loader Class Initialized
INFO - 2017-08-21 12:32:04 --> Helper loaded: url_helper
INFO - 2017-08-21 12:32:04 --> Helper loaded: file_helper
INFO - 2017-08-21 12:32:04 --> Database Driver Class Initialized
INFO - 2017-08-21 12:32:04 --> Email Class Initialized
DEBUG - 2017-08-21 12:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:32:04 --> Table Class Initialized
INFO - 2017-08-21 12:32:04 --> Controller Class Initialized
INFO - 2017-08-21 12:32:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:32:04 --> Final output sent to browser
DEBUG - 2017-08-21 12:32:04 --> Total execution time: 0.2425
INFO - 2017-08-21 12:35:10 --> Config Class Initialized
INFO - 2017-08-21 12:35:10 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:35:10 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:35:10 --> Utf8 Class Initialized
INFO - 2017-08-21 12:35:10 --> URI Class Initialized
INFO - 2017-08-21 12:35:10 --> Router Class Initialized
INFO - 2017-08-21 12:35:10 --> Output Class Initialized
INFO - 2017-08-21 12:35:10 --> Security Class Initialized
DEBUG - 2017-08-21 12:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:35:10 --> Input Class Initialized
INFO - 2017-08-21 12:35:10 --> Language Class Initialized
INFO - 2017-08-21 12:35:10 --> Loader Class Initialized
INFO - 2017-08-21 12:35:10 --> Helper loaded: url_helper
INFO - 2017-08-21 12:35:10 --> Helper loaded: file_helper
INFO - 2017-08-21 12:35:10 --> Database Driver Class Initialized
INFO - 2017-08-21 12:35:11 --> Email Class Initialized
DEBUG - 2017-08-21 12:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:35:11 --> Table Class Initialized
INFO - 2017-08-21 12:35:11 --> Controller Class Initialized
INFO - 2017-08-21 12:35:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:35:11 --> Final output sent to browser
DEBUG - 2017-08-21 12:35:11 --> Total execution time: 0.2540
INFO - 2017-08-21 12:35:18 --> Config Class Initialized
INFO - 2017-08-21 12:35:18 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:35:18 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:35:18 --> Utf8 Class Initialized
INFO - 2017-08-21 12:35:18 --> URI Class Initialized
INFO - 2017-08-21 12:35:18 --> Router Class Initialized
INFO - 2017-08-21 12:35:18 --> Output Class Initialized
INFO - 2017-08-21 12:35:18 --> Security Class Initialized
DEBUG - 2017-08-21 12:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:35:18 --> Input Class Initialized
INFO - 2017-08-21 12:35:18 --> Language Class Initialized
INFO - 2017-08-21 12:35:18 --> Loader Class Initialized
INFO - 2017-08-21 12:35:18 --> Helper loaded: url_helper
INFO - 2017-08-21 12:35:18 --> Helper loaded: file_helper
INFO - 2017-08-21 12:35:18 --> Database Driver Class Initialized
INFO - 2017-08-21 12:35:18 --> Email Class Initialized
DEBUG - 2017-08-21 12:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:35:18 --> Table Class Initialized
INFO - 2017-08-21 12:35:18 --> Controller Class Initialized
INFO - 2017-08-21 12:35:18 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:35:18 --> Final output sent to browser
DEBUG - 2017-08-21 12:35:18 --> Total execution time: 0.2349
INFO - 2017-08-21 12:35:20 --> Config Class Initialized
INFO - 2017-08-21 12:35:21 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:35:21 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:35:21 --> Utf8 Class Initialized
INFO - 2017-08-21 12:35:21 --> URI Class Initialized
INFO - 2017-08-21 12:35:21 --> Router Class Initialized
INFO - 2017-08-21 12:35:21 --> Output Class Initialized
INFO - 2017-08-21 12:35:21 --> Security Class Initialized
DEBUG - 2017-08-21 12:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:35:21 --> Input Class Initialized
INFO - 2017-08-21 12:35:21 --> Language Class Initialized
INFO - 2017-08-21 12:35:21 --> Loader Class Initialized
INFO - 2017-08-21 12:35:21 --> Helper loaded: url_helper
INFO - 2017-08-21 12:35:21 --> Helper loaded: file_helper
INFO - 2017-08-21 12:35:21 --> Database Driver Class Initialized
INFO - 2017-08-21 12:35:21 --> Email Class Initialized
DEBUG - 2017-08-21 12:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:35:21 --> Table Class Initialized
INFO - 2017-08-21 12:35:21 --> Controller Class Initialized
INFO - 2017-08-21 12:35:21 --> Image Lib Class Initialized
ERROR - 2017-08-21 12:35:21 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\views\Article.php 218
INFO - 2017-08-21 12:35:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\article.php
INFO - 2017-08-21 12:35:21 --> Final output sent to browser
DEBUG - 2017-08-21 12:35:21 --> Total execution time: 0.5226
INFO - 2017-08-21 12:35:22 --> Config Class Initialized
INFO - 2017-08-21 12:35:22 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:35:22 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:35:22 --> Utf8 Class Initialized
INFO - 2017-08-21 12:35:22 --> URI Class Initialized
INFO - 2017-08-21 12:35:22 --> Router Class Initialized
INFO - 2017-08-21 12:35:22 --> Output Class Initialized
INFO - 2017-08-21 12:35:22 --> Security Class Initialized
DEBUG - 2017-08-21 12:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:35:22 --> Input Class Initialized
INFO - 2017-08-21 12:35:22 --> Language Class Initialized
INFO - 2017-08-21 12:35:22 --> Loader Class Initialized
INFO - 2017-08-21 12:35:22 --> Helper loaded: url_helper
INFO - 2017-08-21 12:35:22 --> Helper loaded: file_helper
INFO - 2017-08-21 12:35:22 --> Database Driver Class Initialized
INFO - 2017-08-21 12:35:23 --> Email Class Initialized
DEBUG - 2017-08-21 12:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:35:23 --> Table Class Initialized
INFO - 2017-08-21 12:35:23 --> Controller Class Initialized
INFO - 2017-08-21 12:35:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:35:23 --> Final output sent to browser
DEBUG - 2017-08-21 12:35:23 --> Total execution time: 0.2550
INFO - 2017-08-21 12:35:30 --> Config Class Initialized
INFO - 2017-08-21 12:35:30 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:35:30 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:35:30 --> Utf8 Class Initialized
INFO - 2017-08-21 12:35:30 --> URI Class Initialized
INFO - 2017-08-21 12:35:30 --> Router Class Initialized
INFO - 2017-08-21 12:35:30 --> Output Class Initialized
INFO - 2017-08-21 12:35:30 --> Security Class Initialized
DEBUG - 2017-08-21 12:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:35:30 --> Input Class Initialized
INFO - 2017-08-21 12:35:30 --> Language Class Initialized
INFO - 2017-08-21 12:35:30 --> Loader Class Initialized
INFO - 2017-08-21 12:35:30 --> Helper loaded: url_helper
INFO - 2017-08-21 12:35:30 --> Helper loaded: file_helper
INFO - 2017-08-21 12:35:30 --> Database Driver Class Initialized
INFO - 2017-08-21 12:35:30 --> Email Class Initialized
DEBUG - 2017-08-21 12:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:35:30 --> Table Class Initialized
INFO - 2017-08-21 12:35:30 --> Controller Class Initialized
INFO - 2017-08-21 12:35:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:35:30 --> Final output sent to browser
DEBUG - 2017-08-21 12:35:30 --> Total execution time: 0.2435
INFO - 2017-08-21 12:37:59 --> Config Class Initialized
INFO - 2017-08-21 12:37:59 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:37:59 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:37:59 --> Utf8 Class Initialized
INFO - 2017-08-21 12:37:59 --> URI Class Initialized
INFO - 2017-08-21 12:37:59 --> Router Class Initialized
INFO - 2017-08-21 12:37:59 --> Output Class Initialized
INFO - 2017-08-21 12:37:59 --> Security Class Initialized
DEBUG - 2017-08-21 12:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:37:59 --> Input Class Initialized
INFO - 2017-08-21 12:37:59 --> Language Class Initialized
INFO - 2017-08-21 12:37:59 --> Loader Class Initialized
INFO - 2017-08-21 12:37:59 --> Helper loaded: url_helper
INFO - 2017-08-21 12:37:59 --> Helper loaded: file_helper
INFO - 2017-08-21 12:37:59 --> Database Driver Class Initialized
INFO - 2017-08-21 12:37:59 --> Email Class Initialized
DEBUG - 2017-08-21 12:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:37:59 --> Table Class Initialized
INFO - 2017-08-21 12:37:59 --> Controller Class Initialized
INFO - 2017-08-21 12:37:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:37:59 --> Final output sent to browser
DEBUG - 2017-08-21 12:37:59 --> Total execution time: 0.2344
INFO - 2017-08-21 12:39:06 --> Config Class Initialized
INFO - 2017-08-21 12:39:06 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:39:06 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:39:06 --> Utf8 Class Initialized
INFO - 2017-08-21 12:39:06 --> URI Class Initialized
INFO - 2017-08-21 12:39:06 --> Router Class Initialized
INFO - 2017-08-21 12:39:06 --> Output Class Initialized
INFO - 2017-08-21 12:39:06 --> Security Class Initialized
DEBUG - 2017-08-21 12:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:39:06 --> Input Class Initialized
INFO - 2017-08-21 12:39:06 --> Language Class Initialized
INFO - 2017-08-21 12:39:06 --> Loader Class Initialized
INFO - 2017-08-21 12:39:06 --> Helper loaded: url_helper
INFO - 2017-08-21 12:39:06 --> Helper loaded: file_helper
INFO - 2017-08-21 12:39:06 --> Database Driver Class Initialized
INFO - 2017-08-21 12:39:06 --> Email Class Initialized
DEBUG - 2017-08-21 12:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:39:06 --> Table Class Initialized
INFO - 2017-08-21 12:39:06 --> Controller Class Initialized
INFO - 2017-08-21 12:39:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:39:06 --> Final output sent to browser
DEBUG - 2017-08-21 12:39:06 --> Total execution time: 0.2339
INFO - 2017-08-21 12:40:12 --> Config Class Initialized
INFO - 2017-08-21 12:40:12 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:40:12 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:40:12 --> Utf8 Class Initialized
INFO - 2017-08-21 12:40:12 --> URI Class Initialized
INFO - 2017-08-21 12:40:12 --> Router Class Initialized
INFO - 2017-08-21 12:40:12 --> Output Class Initialized
INFO - 2017-08-21 12:40:12 --> Security Class Initialized
DEBUG - 2017-08-21 12:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:40:12 --> Input Class Initialized
INFO - 2017-08-21 12:40:12 --> Language Class Initialized
INFO - 2017-08-21 12:40:12 --> Loader Class Initialized
INFO - 2017-08-21 12:40:12 --> Helper loaded: url_helper
INFO - 2017-08-21 12:40:12 --> Helper loaded: file_helper
INFO - 2017-08-21 12:40:12 --> Database Driver Class Initialized
INFO - 2017-08-21 12:40:12 --> Email Class Initialized
DEBUG - 2017-08-21 12:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:40:12 --> Table Class Initialized
INFO - 2017-08-21 12:40:12 --> Controller Class Initialized
INFO - 2017-08-21 12:40:12 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:40:12 --> Final output sent to browser
DEBUG - 2017-08-21 12:40:12 --> Total execution time: 0.2329
INFO - 2017-08-21 12:40:38 --> Config Class Initialized
INFO - 2017-08-21 12:40:38 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:40:38 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:40:38 --> Utf8 Class Initialized
INFO - 2017-08-21 12:40:38 --> URI Class Initialized
INFO - 2017-08-21 12:40:38 --> Router Class Initialized
INFO - 2017-08-21 12:40:38 --> Output Class Initialized
INFO - 2017-08-21 12:40:38 --> Security Class Initialized
DEBUG - 2017-08-21 12:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:40:38 --> Input Class Initialized
INFO - 2017-08-21 12:40:38 --> Language Class Initialized
INFO - 2017-08-21 12:40:38 --> Loader Class Initialized
INFO - 2017-08-21 12:40:38 --> Helper loaded: url_helper
INFO - 2017-08-21 12:40:38 --> Helper loaded: file_helper
INFO - 2017-08-21 12:40:38 --> Database Driver Class Initialized
INFO - 2017-08-21 12:40:38 --> Email Class Initialized
DEBUG - 2017-08-21 12:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:40:38 --> Table Class Initialized
INFO - 2017-08-21 12:40:38 --> Controller Class Initialized
INFO - 2017-08-21 12:40:38 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:40:38 --> Final output sent to browser
DEBUG - 2017-08-21 12:40:38 --> Total execution time: 0.2322
INFO - 2017-08-21 12:41:30 --> Config Class Initialized
INFO - 2017-08-21 12:41:30 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:41:30 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:41:30 --> Utf8 Class Initialized
INFO - 2017-08-21 12:41:30 --> URI Class Initialized
INFO - 2017-08-21 12:41:30 --> Router Class Initialized
INFO - 2017-08-21 12:41:30 --> Output Class Initialized
INFO - 2017-08-21 12:41:30 --> Security Class Initialized
DEBUG - 2017-08-21 12:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:41:30 --> Input Class Initialized
INFO - 2017-08-21 12:41:30 --> Language Class Initialized
INFO - 2017-08-21 12:41:30 --> Loader Class Initialized
INFO - 2017-08-21 12:41:30 --> Helper loaded: url_helper
INFO - 2017-08-21 12:41:31 --> Helper loaded: file_helper
INFO - 2017-08-21 12:41:31 --> Database Driver Class Initialized
INFO - 2017-08-21 12:41:31 --> Email Class Initialized
DEBUG - 2017-08-21 12:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:41:31 --> Table Class Initialized
INFO - 2017-08-21 12:41:31 --> Controller Class Initialized
INFO - 2017-08-21 12:41:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:41:31 --> Final output sent to browser
DEBUG - 2017-08-21 12:41:31 --> Total execution time: 0.2404
INFO - 2017-08-21 12:41:36 --> Config Class Initialized
INFO - 2017-08-21 12:41:36 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:41:36 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:41:36 --> Utf8 Class Initialized
INFO - 2017-08-21 12:41:36 --> URI Class Initialized
INFO - 2017-08-21 12:41:36 --> Router Class Initialized
INFO - 2017-08-21 12:41:36 --> Output Class Initialized
INFO - 2017-08-21 12:41:36 --> Security Class Initialized
DEBUG - 2017-08-21 12:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:41:36 --> Input Class Initialized
INFO - 2017-08-21 12:41:36 --> Language Class Initialized
INFO - 2017-08-21 12:41:36 --> Loader Class Initialized
INFO - 2017-08-21 12:41:36 --> Helper loaded: url_helper
INFO - 2017-08-21 12:41:36 --> Helper loaded: file_helper
INFO - 2017-08-21 12:41:36 --> Database Driver Class Initialized
INFO - 2017-08-21 12:41:36 --> Email Class Initialized
DEBUG - 2017-08-21 12:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:41:36 --> Table Class Initialized
INFO - 2017-08-21 12:41:36 --> Controller Class Initialized
INFO - 2017-08-21 12:41:36 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:41:36 --> Final output sent to browser
DEBUG - 2017-08-21 12:41:36 --> Total execution time: 0.2465
INFO - 2017-08-21 12:41:39 --> Config Class Initialized
INFO - 2017-08-21 12:41:39 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:41:39 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:41:39 --> Utf8 Class Initialized
INFO - 2017-08-21 12:41:39 --> URI Class Initialized
INFO - 2017-08-21 12:41:39 --> Router Class Initialized
INFO - 2017-08-21 12:41:39 --> Output Class Initialized
INFO - 2017-08-21 12:41:39 --> Security Class Initialized
DEBUG - 2017-08-21 12:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:41:39 --> Input Class Initialized
INFO - 2017-08-21 12:41:39 --> Language Class Initialized
INFO - 2017-08-21 12:41:40 --> Loader Class Initialized
INFO - 2017-08-21 12:41:40 --> Helper loaded: url_helper
INFO - 2017-08-21 12:41:40 --> Helper loaded: file_helper
INFO - 2017-08-21 12:41:40 --> Database Driver Class Initialized
INFO - 2017-08-21 12:41:40 --> Email Class Initialized
DEBUG - 2017-08-21 12:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:41:40 --> Table Class Initialized
INFO - 2017-08-21 12:41:40 --> Controller Class Initialized
INFO - 2017-08-21 12:41:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:41:40 --> Final output sent to browser
DEBUG - 2017-08-21 12:41:40 --> Total execution time: 0.2399
INFO - 2017-08-21 12:41:54 --> Config Class Initialized
INFO - 2017-08-21 12:41:54 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:41:54 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:41:54 --> Utf8 Class Initialized
INFO - 2017-08-21 12:41:54 --> URI Class Initialized
INFO - 2017-08-21 12:41:54 --> Router Class Initialized
INFO - 2017-08-21 12:41:54 --> Output Class Initialized
INFO - 2017-08-21 12:41:54 --> Security Class Initialized
DEBUG - 2017-08-21 12:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:41:54 --> Input Class Initialized
INFO - 2017-08-21 12:41:54 --> Language Class Initialized
INFO - 2017-08-21 12:41:54 --> Loader Class Initialized
INFO - 2017-08-21 12:41:54 --> Helper loaded: url_helper
INFO - 2017-08-21 12:41:54 --> Helper loaded: file_helper
INFO - 2017-08-21 12:41:54 --> Database Driver Class Initialized
INFO - 2017-08-21 12:41:54 --> Email Class Initialized
DEBUG - 2017-08-21 12:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:41:54 --> Table Class Initialized
INFO - 2017-08-21 12:41:54 --> Controller Class Initialized
INFO - 2017-08-21 12:41:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:41:54 --> Final output sent to browser
DEBUG - 2017-08-21 12:41:54 --> Total execution time: 0.2420
INFO - 2017-08-21 12:42:00 --> Config Class Initialized
INFO - 2017-08-21 12:42:00 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:42:00 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:42:00 --> Utf8 Class Initialized
INFO - 2017-08-21 12:42:00 --> URI Class Initialized
INFO - 2017-08-21 12:42:00 --> Router Class Initialized
INFO - 2017-08-21 12:42:00 --> Output Class Initialized
INFO - 2017-08-21 12:42:00 --> Security Class Initialized
DEBUG - 2017-08-21 12:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:42:01 --> Input Class Initialized
INFO - 2017-08-21 12:42:01 --> Language Class Initialized
INFO - 2017-08-21 12:42:01 --> Loader Class Initialized
INFO - 2017-08-21 12:42:01 --> Helper loaded: url_helper
INFO - 2017-08-21 12:42:01 --> Helper loaded: file_helper
INFO - 2017-08-21 12:42:01 --> Database Driver Class Initialized
INFO - 2017-08-21 12:42:01 --> Email Class Initialized
DEBUG - 2017-08-21 12:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:42:01 --> Table Class Initialized
INFO - 2017-08-21 12:42:01 --> Controller Class Initialized
INFO - 2017-08-21 12:42:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:42:01 --> Final output sent to browser
DEBUG - 2017-08-21 12:42:01 --> Total execution time: 0.2406
INFO - 2017-08-21 12:42:43 --> Config Class Initialized
INFO - 2017-08-21 12:42:43 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:42:43 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:42:43 --> Utf8 Class Initialized
INFO - 2017-08-21 12:42:43 --> URI Class Initialized
INFO - 2017-08-21 12:42:43 --> Router Class Initialized
INFO - 2017-08-21 12:42:43 --> Output Class Initialized
INFO - 2017-08-21 12:42:43 --> Security Class Initialized
DEBUG - 2017-08-21 12:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:42:43 --> Input Class Initialized
INFO - 2017-08-21 12:42:43 --> Language Class Initialized
INFO - 2017-08-21 12:42:43 --> Loader Class Initialized
INFO - 2017-08-21 12:42:43 --> Helper loaded: url_helper
INFO - 2017-08-21 12:42:43 --> Helper loaded: file_helper
INFO - 2017-08-21 12:42:43 --> Database Driver Class Initialized
INFO - 2017-08-21 12:42:43 --> Email Class Initialized
DEBUG - 2017-08-21 12:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:42:43 --> Table Class Initialized
INFO - 2017-08-21 12:42:43 --> Controller Class Initialized
INFO - 2017-08-21 12:42:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:42:43 --> Final output sent to browser
DEBUG - 2017-08-21 12:42:43 --> Total execution time: 0.2464
INFO - 2017-08-21 12:44:00 --> Config Class Initialized
INFO - 2017-08-21 12:44:00 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:44:00 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:44:00 --> Utf8 Class Initialized
INFO - 2017-08-21 12:44:00 --> URI Class Initialized
INFO - 2017-08-21 12:44:00 --> Router Class Initialized
INFO - 2017-08-21 12:44:00 --> Output Class Initialized
INFO - 2017-08-21 12:44:00 --> Security Class Initialized
DEBUG - 2017-08-21 12:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:44:00 --> Input Class Initialized
INFO - 2017-08-21 12:44:00 --> Language Class Initialized
INFO - 2017-08-21 12:44:00 --> Loader Class Initialized
INFO - 2017-08-21 12:44:00 --> Helper loaded: url_helper
INFO - 2017-08-21 12:44:00 --> Helper loaded: file_helper
INFO - 2017-08-21 12:44:00 --> Database Driver Class Initialized
INFO - 2017-08-21 12:44:00 --> Email Class Initialized
DEBUG - 2017-08-21 12:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:44:00 --> Table Class Initialized
INFO - 2017-08-21 12:44:00 --> Controller Class Initialized
INFO - 2017-08-21 12:44:00 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:44:00 --> Final output sent to browser
DEBUG - 2017-08-21 12:44:00 --> Total execution time: 0.2451
INFO - 2017-08-21 12:44:23 --> Config Class Initialized
INFO - 2017-08-21 12:44:23 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:44:23 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:44:23 --> Utf8 Class Initialized
INFO - 2017-08-21 12:44:23 --> URI Class Initialized
INFO - 2017-08-21 12:44:23 --> Router Class Initialized
INFO - 2017-08-21 12:44:23 --> Output Class Initialized
INFO - 2017-08-21 12:44:23 --> Security Class Initialized
DEBUG - 2017-08-21 12:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:44:23 --> Input Class Initialized
INFO - 2017-08-21 12:44:23 --> Language Class Initialized
INFO - 2017-08-21 12:44:23 --> Loader Class Initialized
INFO - 2017-08-21 12:44:23 --> Helper loaded: url_helper
INFO - 2017-08-21 12:44:23 --> Helper loaded: file_helper
INFO - 2017-08-21 12:44:23 --> Database Driver Class Initialized
INFO - 2017-08-21 12:44:23 --> Email Class Initialized
DEBUG - 2017-08-21 12:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:44:23 --> Table Class Initialized
INFO - 2017-08-21 12:44:23 --> Controller Class Initialized
INFO - 2017-08-21 12:44:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:44:23 --> Final output sent to browser
DEBUG - 2017-08-21 12:44:23 --> Total execution time: 0.2428
INFO - 2017-08-21 12:46:55 --> Config Class Initialized
INFO - 2017-08-21 12:46:55 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:46:55 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:46:55 --> Utf8 Class Initialized
INFO - 2017-08-21 12:46:55 --> URI Class Initialized
INFO - 2017-08-21 12:46:56 --> Router Class Initialized
INFO - 2017-08-21 12:46:56 --> Output Class Initialized
INFO - 2017-08-21 12:46:56 --> Security Class Initialized
DEBUG - 2017-08-21 12:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:46:56 --> Input Class Initialized
INFO - 2017-08-21 12:46:56 --> Language Class Initialized
INFO - 2017-08-21 12:46:56 --> Loader Class Initialized
INFO - 2017-08-21 12:46:56 --> Helper loaded: url_helper
INFO - 2017-08-21 12:46:56 --> Helper loaded: file_helper
INFO - 2017-08-21 12:46:56 --> Database Driver Class Initialized
INFO - 2017-08-21 12:46:56 --> Email Class Initialized
DEBUG - 2017-08-21 12:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:46:56 --> Table Class Initialized
INFO - 2017-08-21 12:46:56 --> Controller Class Initialized
INFO - 2017-08-21 12:46:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:46:56 --> Final output sent to browser
DEBUG - 2017-08-21 12:46:56 --> Total execution time: 0.2823
INFO - 2017-08-21 12:49:51 --> Config Class Initialized
INFO - 2017-08-21 12:49:51 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:49:51 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:49:51 --> Utf8 Class Initialized
INFO - 2017-08-21 12:49:51 --> URI Class Initialized
INFO - 2017-08-21 12:49:51 --> Router Class Initialized
INFO - 2017-08-21 12:49:51 --> Output Class Initialized
INFO - 2017-08-21 12:49:51 --> Security Class Initialized
DEBUG - 2017-08-21 12:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:49:51 --> Input Class Initialized
INFO - 2017-08-21 12:49:51 --> Language Class Initialized
INFO - 2017-08-21 12:49:51 --> Loader Class Initialized
INFO - 2017-08-21 12:49:51 --> Helper loaded: url_helper
INFO - 2017-08-21 12:49:51 --> Helper loaded: file_helper
INFO - 2017-08-21 12:49:51 --> Database Driver Class Initialized
INFO - 2017-08-21 12:49:51 --> Email Class Initialized
DEBUG - 2017-08-21 12:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:49:52 --> Table Class Initialized
INFO - 2017-08-21 12:49:52 --> Controller Class Initialized
INFO - 2017-08-21 12:49:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:49:52 --> Final output sent to browser
DEBUG - 2017-08-21 12:49:52 --> Total execution time: 0.2485
INFO - 2017-08-21 12:49:55 --> Config Class Initialized
INFO - 2017-08-21 12:49:55 --> Hooks Class Initialized
DEBUG - 2017-08-21 12:49:55 --> UTF-8 Support Enabled
INFO - 2017-08-21 12:49:55 --> Utf8 Class Initialized
INFO - 2017-08-21 12:49:55 --> URI Class Initialized
INFO - 2017-08-21 12:49:55 --> Router Class Initialized
INFO - 2017-08-21 12:49:55 --> Output Class Initialized
INFO - 2017-08-21 12:49:55 --> Security Class Initialized
DEBUG - 2017-08-21 12:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-21 12:49:55 --> Input Class Initialized
INFO - 2017-08-21 12:49:55 --> Language Class Initialized
INFO - 2017-08-21 12:49:55 --> Loader Class Initialized
INFO - 2017-08-21 12:49:55 --> Helper loaded: url_helper
INFO - 2017-08-21 12:49:55 --> Helper loaded: file_helper
INFO - 2017-08-21 12:49:55 --> Database Driver Class Initialized
INFO - 2017-08-21 12:49:55 --> Email Class Initialized
DEBUG - 2017-08-21 12:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-21 12:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-21 12:49:56 --> Table Class Initialized
INFO - 2017-08-21 12:49:56 --> Controller Class Initialized
INFO - 2017-08-21 12:49:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-21 12:49:56 --> Final output sent to browser
DEBUG - 2017-08-21 12:49:56 --> Total execution time: 0.2540
