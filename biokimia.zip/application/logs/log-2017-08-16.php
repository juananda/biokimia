<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-16 08:22:33 --> Config Class Initialized
INFO - 2017-08-16 08:22:33 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:22:33 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:22:33 --> Utf8 Class Initialized
INFO - 2017-08-16 08:22:33 --> URI Class Initialized
INFO - 2017-08-16 08:22:33 --> Router Class Initialized
INFO - 2017-08-16 08:22:33 --> Output Class Initialized
INFO - 2017-08-16 08:22:33 --> Security Class Initialized
DEBUG - 2017-08-16 08:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:22:33 --> Input Class Initialized
INFO - 2017-08-16 08:22:33 --> Language Class Initialized
INFO - 2017-08-16 08:22:33 --> Loader Class Initialized
INFO - 2017-08-16 08:22:34 --> Helper loaded: url_helper
INFO - 2017-08-16 08:22:34 --> Helper loaded: file_helper
INFO - 2017-08-16 08:22:34 --> Database Driver Class Initialized
INFO - 2017-08-16 08:22:34 --> Email Class Initialized
DEBUG - 2017-08-16 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:22:34 --> Table Class Initialized
INFO - 2017-08-16 08:22:34 --> Controller Class Initialized
DEBUG - 2017-08-16 08:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-16 08:22:34 --> Helper loaded: form_helper
INFO - 2017-08-16 08:22:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-16 08:22:34 --> Final output sent to browser
DEBUG - 2017-08-16 08:22:34 --> Total execution time: 1.1871
INFO - 2017-08-16 08:22:44 --> Config Class Initialized
INFO - 2017-08-16 08:22:44 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:22:44 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:22:44 --> Utf8 Class Initialized
INFO - 2017-08-16 08:22:44 --> URI Class Initialized
INFO - 2017-08-16 08:22:44 --> Router Class Initialized
INFO - 2017-08-16 08:22:44 --> Output Class Initialized
INFO - 2017-08-16 08:22:44 --> Security Class Initialized
DEBUG - 2017-08-16 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:22:44 --> Input Class Initialized
INFO - 2017-08-16 08:22:44 --> Language Class Initialized
INFO - 2017-08-16 08:22:44 --> Loader Class Initialized
INFO - 2017-08-16 08:22:44 --> Helper loaded: url_helper
INFO - 2017-08-16 08:22:44 --> Helper loaded: file_helper
INFO - 2017-08-16 08:22:44 --> Database Driver Class Initialized
INFO - 2017-08-16 08:22:44 --> Email Class Initialized
DEBUG - 2017-08-16 08:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:22:44 --> Table Class Initialized
INFO - 2017-08-16 08:22:44 --> Controller Class Initialized
DEBUG - 2017-08-16 08:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-16 08:22:44 --> Helper loaded: form_helper
DEBUG - 2017-08-16 08:22:44 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-16 08:22:45 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-16 08:22:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-16 08:22:45 --> Final output sent to browser
DEBUG - 2017-08-16 08:22:45 --> Total execution time: 1.3022
INFO - 2017-08-16 08:22:56 --> Config Class Initialized
INFO - 2017-08-16 08:22:56 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:22:56 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:22:57 --> Utf8 Class Initialized
INFO - 2017-08-16 08:22:57 --> URI Class Initialized
INFO - 2017-08-16 08:22:57 --> Router Class Initialized
INFO - 2017-08-16 08:22:57 --> Output Class Initialized
INFO - 2017-08-16 08:22:57 --> Security Class Initialized
DEBUG - 2017-08-16 08:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:22:57 --> Input Class Initialized
INFO - 2017-08-16 08:22:57 --> Language Class Initialized
INFO - 2017-08-16 08:22:57 --> Loader Class Initialized
INFO - 2017-08-16 08:22:57 --> Helper loaded: url_helper
INFO - 2017-08-16 08:22:57 --> Helper loaded: file_helper
INFO - 2017-08-16 08:22:57 --> Database Driver Class Initialized
INFO - 2017-08-16 08:22:57 --> Email Class Initialized
DEBUG - 2017-08-16 08:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:22:57 --> Table Class Initialized
INFO - 2017-08-16 08:22:57 --> Controller Class Initialized
DEBUG - 2017-08-16 08:22:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-16 08:22:57 --> Helper loaded: form_helper
DEBUG - 2017-08-16 08:22:57 --> Email class already loaded. Second attempt ignored.
INFO - 2017-08-16 08:22:57 --> Language file loaded: language/english/email_lang.php
INFO - 2017-08-16 08:22:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-16 08:22:57 --> Final output sent to browser
DEBUG - 2017-08-16 08:22:57 --> Total execution time: 0.2392
INFO - 2017-08-16 08:25:48 --> Config Class Initialized
INFO - 2017-08-16 08:25:48 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:25:48 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:25:48 --> Utf8 Class Initialized
INFO - 2017-08-16 08:25:48 --> URI Class Initialized
DEBUG - 2017-08-16 08:25:48 --> No URI present. Default controller set.
INFO - 2017-08-16 08:25:48 --> Router Class Initialized
INFO - 2017-08-16 08:25:48 --> Output Class Initialized
INFO - 2017-08-16 08:25:48 --> Security Class Initialized
DEBUG - 2017-08-16 08:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:25:48 --> Input Class Initialized
INFO - 2017-08-16 08:25:48 --> Language Class Initialized
INFO - 2017-08-16 08:25:48 --> Loader Class Initialized
INFO - 2017-08-16 08:25:48 --> Helper loaded: url_helper
INFO - 2017-08-16 08:25:48 --> Helper loaded: file_helper
INFO - 2017-08-16 08:25:48 --> Database Driver Class Initialized
INFO - 2017-08-16 08:25:48 --> Email Class Initialized
DEBUG - 2017-08-16 08:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:25:48 --> Table Class Initialized
INFO - 2017-08-16 08:25:48 --> Controller Class Initialized
INFO - 2017-08-16 08:25:48 --> Model Class Initialized
INFO - 2017-08-16 08:25:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:25:48 --> Final output sent to browser
DEBUG - 2017-08-16 08:25:48 --> Total execution time: 0.4724
INFO - 2017-08-16 08:26:32 --> Config Class Initialized
INFO - 2017-08-16 08:26:32 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:26:32 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:26:32 --> Utf8 Class Initialized
INFO - 2017-08-16 08:26:32 --> URI Class Initialized
INFO - 2017-08-16 08:26:32 --> Router Class Initialized
INFO - 2017-08-16 08:26:32 --> Output Class Initialized
INFO - 2017-08-16 08:26:32 --> Security Class Initialized
DEBUG - 2017-08-16 08:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:26:32 --> Input Class Initialized
INFO - 2017-08-16 08:26:32 --> Language Class Initialized
INFO - 2017-08-16 08:26:32 --> Loader Class Initialized
INFO - 2017-08-16 08:26:32 --> Helper loaded: url_helper
INFO - 2017-08-16 08:26:32 --> Helper loaded: file_helper
INFO - 2017-08-16 08:26:32 --> Database Driver Class Initialized
INFO - 2017-08-16 08:26:32 --> Email Class Initialized
DEBUG - 2017-08-16 08:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:26:32 --> Table Class Initialized
INFO - 2017-08-16 08:26:32 --> Controller Class Initialized
INFO - 2017-08-16 08:26:32 --> Helper loaded: form_helper
INFO - 2017-08-16 08:26:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-16 08:26:32 --> Final output sent to browser
DEBUG - 2017-08-16 08:26:32 --> Total execution time: 0.2073
INFO - 2017-08-16 08:26:41 --> Config Class Initialized
INFO - 2017-08-16 08:26:41 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:26:41 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:26:41 --> Utf8 Class Initialized
INFO - 2017-08-16 08:26:41 --> URI Class Initialized
INFO - 2017-08-16 08:26:41 --> Router Class Initialized
INFO - 2017-08-16 08:26:42 --> Output Class Initialized
INFO - 2017-08-16 08:26:42 --> Security Class Initialized
DEBUG - 2017-08-16 08:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:26:42 --> Input Class Initialized
INFO - 2017-08-16 08:26:42 --> Language Class Initialized
INFO - 2017-08-16 08:26:42 --> Loader Class Initialized
INFO - 2017-08-16 08:26:42 --> Helper loaded: url_helper
INFO - 2017-08-16 08:26:42 --> Helper loaded: file_helper
INFO - 2017-08-16 08:26:42 --> Database Driver Class Initialized
INFO - 2017-08-16 08:26:42 --> Email Class Initialized
DEBUG - 2017-08-16 08:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:26:42 --> Table Class Initialized
INFO - 2017-08-16 08:26:42 --> Controller Class Initialized
INFO - 2017-08-16 08:26:42 --> Helper loaded: form_helper
INFO - 2017-08-16 08:26:42 --> Upload Class Initialized
INFO - 2017-08-16 08:26:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_success.php
INFO - 2017-08-16 08:26:42 --> Final output sent to browser
DEBUG - 2017-08-16 08:26:42 --> Total execution time: 0.2776
INFO - 2017-08-16 08:34:43 --> Config Class Initialized
INFO - 2017-08-16 08:34:43 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:34:43 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:34:43 --> Utf8 Class Initialized
INFO - 2017-08-16 08:34:43 --> URI Class Initialized
INFO - 2017-08-16 08:34:43 --> Router Class Initialized
INFO - 2017-08-16 08:34:43 --> Output Class Initialized
INFO - 2017-08-16 08:34:43 --> Security Class Initialized
DEBUG - 2017-08-16 08:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:34:43 --> Input Class Initialized
INFO - 2017-08-16 08:34:43 --> Language Class Initialized
INFO - 2017-08-16 08:34:43 --> Loader Class Initialized
INFO - 2017-08-16 08:34:43 --> Helper loaded: url_helper
INFO - 2017-08-16 08:34:43 --> Helper loaded: file_helper
INFO - 2017-08-16 08:34:43 --> Database Driver Class Initialized
INFO - 2017-08-16 08:34:43 --> Email Class Initialized
DEBUG - 2017-08-16 08:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:34:43 --> Table Class Initialized
INFO - 2017-08-16 08:34:43 --> Controller Class Initialized
INFO - 2017-08-16 08:34:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:34:43 --> Final output sent to browser
DEBUG - 2017-08-16 08:34:43 --> Total execution time: 0.1805
INFO - 2017-08-16 08:34:54 --> Config Class Initialized
INFO - 2017-08-16 08:34:54 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:34:54 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:34:54 --> Utf8 Class Initialized
INFO - 2017-08-16 08:34:54 --> URI Class Initialized
INFO - 2017-08-16 08:34:54 --> Router Class Initialized
INFO - 2017-08-16 08:34:54 --> Output Class Initialized
INFO - 2017-08-16 08:34:54 --> Security Class Initialized
DEBUG - 2017-08-16 08:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:34:54 --> Input Class Initialized
INFO - 2017-08-16 08:34:54 --> Language Class Initialized
INFO - 2017-08-16 08:34:54 --> Loader Class Initialized
INFO - 2017-08-16 08:34:54 --> Helper loaded: url_helper
INFO - 2017-08-16 08:34:54 --> Helper loaded: file_helper
INFO - 2017-08-16 08:34:54 --> Database Driver Class Initialized
INFO - 2017-08-16 08:34:54 --> Email Class Initialized
DEBUG - 2017-08-16 08:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:34:54 --> Table Class Initialized
INFO - 2017-08-16 08:34:54 --> Controller Class Initialized
INFO - 2017-08-16 08:34:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:34:54 --> Final output sent to browser
DEBUG - 2017-08-16 08:34:54 --> Total execution time: 0.1658
INFO - 2017-08-16 08:35:01 --> Config Class Initialized
INFO - 2017-08-16 08:35:01 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:35:01 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:35:01 --> Utf8 Class Initialized
INFO - 2017-08-16 08:35:01 --> URI Class Initialized
INFO - 2017-08-16 08:35:01 --> Router Class Initialized
INFO - 2017-08-16 08:35:01 --> Output Class Initialized
INFO - 2017-08-16 08:35:01 --> Security Class Initialized
DEBUG - 2017-08-16 08:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:35:01 --> Input Class Initialized
INFO - 2017-08-16 08:35:01 --> Language Class Initialized
INFO - 2017-08-16 08:35:01 --> Loader Class Initialized
INFO - 2017-08-16 08:35:01 --> Helper loaded: url_helper
INFO - 2017-08-16 08:35:01 --> Helper loaded: file_helper
INFO - 2017-08-16 08:35:01 --> Database Driver Class Initialized
INFO - 2017-08-16 08:35:01 --> Email Class Initialized
DEBUG - 2017-08-16 08:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:35:01 --> Table Class Initialized
INFO - 2017-08-16 08:35:01 --> Controller Class Initialized
INFO - 2017-08-16 08:35:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:35:01 --> Final output sent to browser
DEBUG - 2017-08-16 08:35:01 --> Total execution time: 0.1724
INFO - 2017-08-16 08:35:21 --> Config Class Initialized
INFO - 2017-08-16 08:35:21 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:35:21 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:35:21 --> Utf8 Class Initialized
INFO - 2017-08-16 08:35:21 --> URI Class Initialized
INFO - 2017-08-16 08:35:21 --> Router Class Initialized
INFO - 2017-08-16 08:35:21 --> Output Class Initialized
INFO - 2017-08-16 08:35:21 --> Security Class Initialized
DEBUG - 2017-08-16 08:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:35:21 --> Input Class Initialized
INFO - 2017-08-16 08:35:21 --> Language Class Initialized
INFO - 2017-08-16 08:35:21 --> Loader Class Initialized
INFO - 2017-08-16 08:35:21 --> Helper loaded: url_helper
INFO - 2017-08-16 08:35:21 --> Helper loaded: file_helper
INFO - 2017-08-16 08:35:21 --> Database Driver Class Initialized
INFO - 2017-08-16 08:35:21 --> Email Class Initialized
DEBUG - 2017-08-16 08:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:35:21 --> Table Class Initialized
INFO - 2017-08-16 08:35:21 --> Controller Class Initialized
INFO - 2017-08-16 08:35:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:35:21 --> Final output sent to browser
DEBUG - 2017-08-16 08:35:21 --> Total execution time: 0.1698
INFO - 2017-08-16 08:35:25 --> Config Class Initialized
INFO - 2017-08-16 08:35:25 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:35:25 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:35:25 --> Utf8 Class Initialized
INFO - 2017-08-16 08:35:25 --> URI Class Initialized
INFO - 2017-08-16 08:35:25 --> Router Class Initialized
INFO - 2017-08-16 08:35:25 --> Output Class Initialized
INFO - 2017-08-16 08:35:25 --> Security Class Initialized
DEBUG - 2017-08-16 08:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:35:25 --> Input Class Initialized
INFO - 2017-08-16 08:35:25 --> Language Class Initialized
INFO - 2017-08-16 08:35:25 --> Loader Class Initialized
INFO - 2017-08-16 08:35:25 --> Helper loaded: url_helper
INFO - 2017-08-16 08:35:25 --> Helper loaded: file_helper
INFO - 2017-08-16 08:35:25 --> Database Driver Class Initialized
INFO - 2017-08-16 08:35:25 --> Email Class Initialized
DEBUG - 2017-08-16 08:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:35:25 --> Table Class Initialized
INFO - 2017-08-16 08:35:25 --> Controller Class Initialized
INFO - 2017-08-16 08:35:25 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:35:25 --> Final output sent to browser
DEBUG - 2017-08-16 08:35:25 --> Total execution time: 0.1776
INFO - 2017-08-16 08:35:30 --> Config Class Initialized
INFO - 2017-08-16 08:35:30 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:35:30 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:35:30 --> Utf8 Class Initialized
INFO - 2017-08-16 08:35:31 --> URI Class Initialized
INFO - 2017-08-16 08:35:31 --> Router Class Initialized
INFO - 2017-08-16 08:35:31 --> Output Class Initialized
INFO - 2017-08-16 08:35:31 --> Security Class Initialized
DEBUG - 2017-08-16 08:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:35:31 --> Input Class Initialized
INFO - 2017-08-16 08:35:31 --> Language Class Initialized
INFO - 2017-08-16 08:35:31 --> Loader Class Initialized
INFO - 2017-08-16 08:35:31 --> Helper loaded: url_helper
INFO - 2017-08-16 08:35:31 --> Helper loaded: file_helper
INFO - 2017-08-16 08:35:31 --> Database Driver Class Initialized
INFO - 2017-08-16 08:35:31 --> Email Class Initialized
DEBUG - 2017-08-16 08:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:35:31 --> Table Class Initialized
INFO - 2017-08-16 08:35:31 --> Controller Class Initialized
INFO - 2017-08-16 08:35:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:35:31 --> Final output sent to browser
DEBUG - 2017-08-16 08:35:31 --> Total execution time: 0.1651
INFO - 2017-08-16 08:35:46 --> Config Class Initialized
INFO - 2017-08-16 08:35:46 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:35:46 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:35:46 --> Utf8 Class Initialized
INFO - 2017-08-16 08:35:46 --> URI Class Initialized
INFO - 2017-08-16 08:35:46 --> Router Class Initialized
INFO - 2017-08-16 08:35:46 --> Output Class Initialized
INFO - 2017-08-16 08:35:46 --> Security Class Initialized
DEBUG - 2017-08-16 08:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:35:46 --> Input Class Initialized
INFO - 2017-08-16 08:35:46 --> Language Class Initialized
INFO - 2017-08-16 08:35:46 --> Loader Class Initialized
INFO - 2017-08-16 08:35:46 --> Helper loaded: url_helper
INFO - 2017-08-16 08:35:46 --> Helper loaded: file_helper
INFO - 2017-08-16 08:35:46 --> Database Driver Class Initialized
INFO - 2017-08-16 08:35:46 --> Email Class Initialized
DEBUG - 2017-08-16 08:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:35:46 --> Table Class Initialized
INFO - 2017-08-16 08:35:46 --> Controller Class Initialized
INFO - 2017-08-16 08:35:46 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:35:46 --> Final output sent to browser
DEBUG - 2017-08-16 08:35:46 --> Total execution time: 0.1650
INFO - 2017-08-16 08:35:47 --> Config Class Initialized
INFO - 2017-08-16 08:35:47 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:35:47 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:35:47 --> Utf8 Class Initialized
INFO - 2017-08-16 08:35:47 --> URI Class Initialized
DEBUG - 2017-08-16 08:35:47 --> No URI present. Default controller set.
INFO - 2017-08-16 08:35:47 --> Router Class Initialized
INFO - 2017-08-16 08:35:47 --> Output Class Initialized
INFO - 2017-08-16 08:35:47 --> Security Class Initialized
DEBUG - 2017-08-16 08:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:35:47 --> Input Class Initialized
INFO - 2017-08-16 08:35:47 --> Language Class Initialized
INFO - 2017-08-16 08:35:47 --> Loader Class Initialized
INFO - 2017-08-16 08:35:47 --> Helper loaded: url_helper
INFO - 2017-08-16 08:35:47 --> Helper loaded: file_helper
INFO - 2017-08-16 08:35:47 --> Database Driver Class Initialized
INFO - 2017-08-16 08:35:47 --> Email Class Initialized
DEBUG - 2017-08-16 08:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:35:47 --> Table Class Initialized
INFO - 2017-08-16 08:35:47 --> Controller Class Initialized
INFO - 2017-08-16 08:35:47 --> Model Class Initialized
INFO - 2017-08-16 08:35:47 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:35:47 --> Final output sent to browser
DEBUG - 2017-08-16 08:35:47 --> Total execution time: 0.1962
INFO - 2017-08-16 08:35:49 --> Config Class Initialized
INFO - 2017-08-16 08:35:49 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:35:49 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:35:49 --> Utf8 Class Initialized
INFO - 2017-08-16 08:35:49 --> URI Class Initialized
INFO - 2017-08-16 08:35:49 --> Router Class Initialized
INFO - 2017-08-16 08:35:49 --> Output Class Initialized
INFO - 2017-08-16 08:35:49 --> Security Class Initialized
DEBUG - 2017-08-16 08:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:35:49 --> Input Class Initialized
INFO - 2017-08-16 08:35:49 --> Language Class Initialized
INFO - 2017-08-16 08:35:49 --> Loader Class Initialized
INFO - 2017-08-16 08:35:49 --> Helper loaded: url_helper
INFO - 2017-08-16 08:35:49 --> Helper loaded: file_helper
INFO - 2017-08-16 08:35:49 --> Database Driver Class Initialized
INFO - 2017-08-16 08:35:49 --> Email Class Initialized
DEBUG - 2017-08-16 08:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:35:49 --> Table Class Initialized
INFO - 2017-08-16 08:35:49 --> Controller Class Initialized
INFO - 2017-08-16 08:35:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:35:49 --> Final output sent to browser
DEBUG - 2017-08-16 08:35:49 --> Total execution time: 0.1805
INFO - 2017-08-16 08:36:09 --> Config Class Initialized
INFO - 2017-08-16 08:36:09 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:36:09 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:36:09 --> Utf8 Class Initialized
INFO - 2017-08-16 08:36:09 --> URI Class Initialized
INFO - 2017-08-16 08:36:09 --> Router Class Initialized
INFO - 2017-08-16 08:36:09 --> Output Class Initialized
INFO - 2017-08-16 08:36:09 --> Security Class Initialized
DEBUG - 2017-08-16 08:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:36:09 --> Input Class Initialized
INFO - 2017-08-16 08:36:09 --> Language Class Initialized
INFO - 2017-08-16 08:36:09 --> Loader Class Initialized
INFO - 2017-08-16 08:36:09 --> Helper loaded: url_helper
INFO - 2017-08-16 08:36:09 --> Helper loaded: file_helper
INFO - 2017-08-16 08:36:09 --> Database Driver Class Initialized
INFO - 2017-08-16 08:36:09 --> Email Class Initialized
DEBUG - 2017-08-16 08:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:36:09 --> Table Class Initialized
INFO - 2017-08-16 08:36:09 --> Controller Class Initialized
INFO - 2017-08-16 08:36:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:36:09 --> Final output sent to browser
DEBUG - 2017-08-16 08:36:09 --> Total execution time: 0.1703
INFO - 2017-08-16 08:36:14 --> Config Class Initialized
INFO - 2017-08-16 08:36:14 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:36:14 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:36:14 --> Utf8 Class Initialized
INFO - 2017-08-16 08:36:14 --> URI Class Initialized
INFO - 2017-08-16 08:36:14 --> Router Class Initialized
INFO - 2017-08-16 08:36:14 --> Output Class Initialized
INFO - 2017-08-16 08:36:14 --> Security Class Initialized
DEBUG - 2017-08-16 08:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:36:14 --> Input Class Initialized
INFO - 2017-08-16 08:36:14 --> Language Class Initialized
INFO - 2017-08-16 08:36:14 --> Loader Class Initialized
INFO - 2017-08-16 08:36:14 --> Helper loaded: url_helper
INFO - 2017-08-16 08:36:14 --> Helper loaded: file_helper
INFO - 2017-08-16 08:36:14 --> Database Driver Class Initialized
INFO - 2017-08-16 08:36:14 --> Email Class Initialized
DEBUG - 2017-08-16 08:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:36:14 --> Table Class Initialized
INFO - 2017-08-16 08:36:14 --> Controller Class Initialized
INFO - 2017-08-16 08:36:14 --> Helper loaded: form_helper
INFO - 2017-08-16 08:36:14 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-16 08:36:14 --> Final output sent to browser
DEBUG - 2017-08-16 08:36:14 --> Total execution time: 0.2136
INFO - 2017-08-16 08:36:15 --> Config Class Initialized
INFO - 2017-08-16 08:36:15 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:36:15 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:36:15 --> Utf8 Class Initialized
INFO - 2017-08-16 08:36:15 --> URI Class Initialized
DEBUG - 2017-08-16 08:36:15 --> No URI present. Default controller set.
INFO - 2017-08-16 08:36:15 --> Router Class Initialized
INFO - 2017-08-16 08:36:15 --> Output Class Initialized
INFO - 2017-08-16 08:36:15 --> Security Class Initialized
DEBUG - 2017-08-16 08:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:36:15 --> Input Class Initialized
INFO - 2017-08-16 08:36:15 --> Language Class Initialized
INFO - 2017-08-16 08:36:15 --> Loader Class Initialized
INFO - 2017-08-16 08:36:16 --> Helper loaded: url_helper
INFO - 2017-08-16 08:36:16 --> Helper loaded: file_helper
INFO - 2017-08-16 08:36:16 --> Database Driver Class Initialized
INFO - 2017-08-16 08:36:16 --> Email Class Initialized
DEBUG - 2017-08-16 08:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:36:16 --> Table Class Initialized
INFO - 2017-08-16 08:36:16 --> Controller Class Initialized
INFO - 2017-08-16 08:36:16 --> Model Class Initialized
INFO - 2017-08-16 08:36:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:36:16 --> Final output sent to browser
DEBUG - 2017-08-16 08:36:16 --> Total execution time: 0.1912
INFO - 2017-08-16 08:36:21 --> Config Class Initialized
INFO - 2017-08-16 08:36:21 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:36:21 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:36:21 --> Utf8 Class Initialized
INFO - 2017-08-16 08:36:21 --> URI Class Initialized
INFO - 2017-08-16 08:36:21 --> Router Class Initialized
INFO - 2017-08-16 08:36:21 --> Output Class Initialized
INFO - 2017-08-16 08:36:21 --> Security Class Initialized
DEBUG - 2017-08-16 08:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:36:21 --> Input Class Initialized
INFO - 2017-08-16 08:36:21 --> Language Class Initialized
INFO - 2017-08-16 08:36:21 --> Loader Class Initialized
INFO - 2017-08-16 08:36:21 --> Helper loaded: url_helper
INFO - 2017-08-16 08:36:21 --> Helper loaded: file_helper
INFO - 2017-08-16 08:36:21 --> Database Driver Class Initialized
INFO - 2017-08-16 08:36:21 --> Email Class Initialized
DEBUG - 2017-08-16 08:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:36:21 --> Table Class Initialized
INFO - 2017-08-16 08:36:21 --> Controller Class Initialized
INFO - 2017-08-16 08:36:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:36:21 --> Final output sent to browser
DEBUG - 2017-08-16 08:36:21 --> Total execution time: 0.1674
INFO - 2017-08-16 08:36:24 --> Config Class Initialized
INFO - 2017-08-16 08:36:24 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:36:24 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:36:24 --> Utf8 Class Initialized
INFO - 2017-08-16 08:36:24 --> URI Class Initialized
INFO - 2017-08-16 08:36:24 --> Router Class Initialized
INFO - 2017-08-16 08:36:24 --> Output Class Initialized
INFO - 2017-08-16 08:36:24 --> Security Class Initialized
DEBUG - 2017-08-16 08:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:36:24 --> Input Class Initialized
INFO - 2017-08-16 08:36:24 --> Language Class Initialized
INFO - 2017-08-16 08:36:24 --> Loader Class Initialized
INFO - 2017-08-16 08:36:24 --> Helper loaded: url_helper
INFO - 2017-08-16 08:36:24 --> Helper loaded: file_helper
INFO - 2017-08-16 08:36:24 --> Database Driver Class Initialized
INFO - 2017-08-16 08:36:24 --> Email Class Initialized
DEBUG - 2017-08-16 08:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:36:24 --> Table Class Initialized
INFO - 2017-08-16 08:36:24 --> Controller Class Initialized
INFO - 2017-08-16 08:36:24 --> Helper loaded: form_helper
INFO - 2017-08-16 08:36:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-16 08:36:24 --> Final output sent to browser
DEBUG - 2017-08-16 08:36:24 --> Total execution time: 0.1886
INFO - 2017-08-16 08:36:25 --> Config Class Initialized
INFO - 2017-08-16 08:36:25 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:36:25 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:36:25 --> Utf8 Class Initialized
INFO - 2017-08-16 08:36:25 --> URI Class Initialized
INFO - 2017-08-16 08:36:25 --> Router Class Initialized
INFO - 2017-08-16 08:36:25 --> Output Class Initialized
INFO - 2017-08-16 08:36:25 --> Security Class Initialized
DEBUG - 2017-08-16 08:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:36:25 --> Input Class Initialized
INFO - 2017-08-16 08:36:25 --> Language Class Initialized
INFO - 2017-08-16 08:36:25 --> Loader Class Initialized
INFO - 2017-08-16 08:36:25 --> Helper loaded: url_helper
INFO - 2017-08-16 08:36:25 --> Helper loaded: file_helper
INFO - 2017-08-16 08:36:25 --> Database Driver Class Initialized
INFO - 2017-08-16 08:36:25 --> Email Class Initialized
DEBUG - 2017-08-16 08:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:36:25 --> Table Class Initialized
INFO - 2017-08-16 08:36:25 --> Controller Class Initialized
INFO - 2017-08-16 08:36:25 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:36:25 --> Final output sent to browser
DEBUG - 2017-08-16 08:36:25 --> Total execution time: 0.1794
INFO - 2017-08-16 08:36:27 --> Config Class Initialized
INFO - 2017-08-16 08:36:27 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:36:27 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:36:27 --> Utf8 Class Initialized
INFO - 2017-08-16 08:36:27 --> URI Class Initialized
INFO - 2017-08-16 08:36:27 --> Router Class Initialized
INFO - 2017-08-16 08:36:27 --> Output Class Initialized
INFO - 2017-08-16 08:36:27 --> Security Class Initialized
DEBUG - 2017-08-16 08:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:36:27 --> Input Class Initialized
INFO - 2017-08-16 08:36:27 --> Language Class Initialized
INFO - 2017-08-16 08:36:27 --> Loader Class Initialized
INFO - 2017-08-16 08:36:27 --> Helper loaded: url_helper
INFO - 2017-08-16 08:36:27 --> Helper loaded: file_helper
INFO - 2017-08-16 08:36:27 --> Database Driver Class Initialized
INFO - 2017-08-16 08:36:27 --> Email Class Initialized
DEBUG - 2017-08-16 08:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:36:27 --> Table Class Initialized
INFO - 2017-08-16 08:36:27 --> Controller Class Initialized
DEBUG - 2017-08-16 08:36:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-16 08:36:27 --> Helper loaded: form_helper
INFO - 2017-08-16 08:36:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\email_form.php
INFO - 2017-08-16 08:36:27 --> Final output sent to browser
DEBUG - 2017-08-16 08:36:27 --> Total execution time: 0.1940
INFO - 2017-08-16 08:36:28 --> Config Class Initialized
INFO - 2017-08-16 08:36:28 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:36:28 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:36:28 --> Utf8 Class Initialized
INFO - 2017-08-16 08:36:28 --> URI Class Initialized
INFO - 2017-08-16 08:36:28 --> Router Class Initialized
INFO - 2017-08-16 08:36:28 --> Output Class Initialized
INFO - 2017-08-16 08:36:28 --> Security Class Initialized
DEBUG - 2017-08-16 08:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:36:28 --> Input Class Initialized
INFO - 2017-08-16 08:36:28 --> Language Class Initialized
INFO - 2017-08-16 08:36:28 --> Loader Class Initialized
INFO - 2017-08-16 08:36:28 --> Helper loaded: url_helper
INFO - 2017-08-16 08:36:28 --> Helper loaded: file_helper
INFO - 2017-08-16 08:36:28 --> Database Driver Class Initialized
INFO - 2017-08-16 08:36:28 --> Email Class Initialized
DEBUG - 2017-08-16 08:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:36:28 --> Table Class Initialized
INFO - 2017-08-16 08:36:29 --> Controller Class Initialized
INFO - 2017-08-16 08:36:29 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:36:29 --> Final output sent to browser
DEBUG - 2017-08-16 08:36:29 --> Total execution time: 0.1858
INFO - 2017-08-16 08:36:30 --> Config Class Initialized
INFO - 2017-08-16 08:36:30 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:36:30 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:36:30 --> Utf8 Class Initialized
INFO - 2017-08-16 08:36:30 --> URI Class Initialized
DEBUG - 2017-08-16 08:36:30 --> No URI present. Default controller set.
INFO - 2017-08-16 08:36:30 --> Router Class Initialized
INFO - 2017-08-16 08:36:30 --> Output Class Initialized
INFO - 2017-08-16 08:36:30 --> Security Class Initialized
DEBUG - 2017-08-16 08:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:36:30 --> Input Class Initialized
INFO - 2017-08-16 08:36:30 --> Language Class Initialized
INFO - 2017-08-16 08:36:30 --> Loader Class Initialized
INFO - 2017-08-16 08:36:30 --> Helper loaded: url_helper
INFO - 2017-08-16 08:36:30 --> Helper loaded: file_helper
INFO - 2017-08-16 08:36:30 --> Database Driver Class Initialized
INFO - 2017-08-16 08:36:30 --> Email Class Initialized
DEBUG - 2017-08-16 08:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:36:30 --> Table Class Initialized
INFO - 2017-08-16 08:36:30 --> Controller Class Initialized
INFO - 2017-08-16 08:36:30 --> Model Class Initialized
INFO - 2017-08-16 08:36:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:36:30 --> Final output sent to browser
DEBUG - 2017-08-16 08:36:30 --> Total execution time: 0.1949
INFO - 2017-08-16 08:36:32 --> Config Class Initialized
INFO - 2017-08-16 08:36:32 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:36:32 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:36:32 --> Utf8 Class Initialized
INFO - 2017-08-16 08:36:32 --> URI Class Initialized
INFO - 2017-08-16 08:36:32 --> Router Class Initialized
INFO - 2017-08-16 08:36:32 --> Output Class Initialized
INFO - 2017-08-16 08:36:32 --> Security Class Initialized
DEBUG - 2017-08-16 08:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:36:32 --> Input Class Initialized
INFO - 2017-08-16 08:36:32 --> Language Class Initialized
INFO - 2017-08-16 08:36:32 --> Loader Class Initialized
INFO - 2017-08-16 08:36:32 --> Helper loaded: url_helper
INFO - 2017-08-16 08:36:32 --> Helper loaded: file_helper
INFO - 2017-08-16 08:36:32 --> Database Driver Class Initialized
INFO - 2017-08-16 08:36:32 --> Email Class Initialized
DEBUG - 2017-08-16 08:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:36:32 --> Table Class Initialized
INFO - 2017-08-16 08:36:32 --> Controller Class Initialized
INFO - 2017-08-16 08:36:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:36:32 --> Final output sent to browser
DEBUG - 2017-08-16 08:36:32 --> Total execution time: 0.1775
INFO - 2017-08-16 08:39:26 --> Config Class Initialized
INFO - 2017-08-16 08:39:26 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:39:26 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:39:26 --> Utf8 Class Initialized
INFO - 2017-08-16 08:39:26 --> URI Class Initialized
INFO - 2017-08-16 08:39:26 --> Router Class Initialized
INFO - 2017-08-16 08:39:26 --> Output Class Initialized
INFO - 2017-08-16 08:39:26 --> Security Class Initialized
DEBUG - 2017-08-16 08:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:39:26 --> Input Class Initialized
INFO - 2017-08-16 08:39:26 --> Language Class Initialized
INFO - 2017-08-16 08:39:26 --> Loader Class Initialized
INFO - 2017-08-16 08:39:26 --> Helper loaded: url_helper
INFO - 2017-08-16 08:39:26 --> Helper loaded: file_helper
INFO - 2017-08-16 08:39:27 --> Database Driver Class Initialized
INFO - 2017-08-16 08:39:27 --> Email Class Initialized
DEBUG - 2017-08-16 08:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:39:27 --> Table Class Initialized
INFO - 2017-08-16 08:39:27 --> Controller Class Initialized
INFO - 2017-08-16 08:39:27 --> Helper loaded: form_helper
INFO - 2017-08-16 08:39:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-16 08:39:27 --> Final output sent to browser
DEBUG - 2017-08-16 08:39:27 --> Total execution time: 0.1834
INFO - 2017-08-16 08:39:30 --> Config Class Initialized
INFO - 2017-08-16 08:39:30 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:39:30 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:39:30 --> Utf8 Class Initialized
INFO - 2017-08-16 08:39:30 --> URI Class Initialized
INFO - 2017-08-16 08:39:30 --> Router Class Initialized
INFO - 2017-08-16 08:39:30 --> Output Class Initialized
INFO - 2017-08-16 08:39:30 --> Security Class Initialized
DEBUG - 2017-08-16 08:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:39:30 --> Input Class Initialized
INFO - 2017-08-16 08:39:30 --> Language Class Initialized
INFO - 2017-08-16 08:39:30 --> Loader Class Initialized
INFO - 2017-08-16 08:39:30 --> Helper loaded: url_helper
INFO - 2017-08-16 08:39:30 --> Helper loaded: file_helper
INFO - 2017-08-16 08:39:30 --> Database Driver Class Initialized
INFO - 2017-08-16 08:39:30 --> Email Class Initialized
DEBUG - 2017-08-16 08:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:39:30 --> Table Class Initialized
INFO - 2017-08-16 08:39:30 --> Controller Class Initialized
INFO - 2017-08-16 08:39:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:39:30 --> Final output sent to browser
DEBUG - 2017-08-16 08:39:30 --> Total execution time: 0.1847
INFO - 2017-08-16 08:39:34 --> Config Class Initialized
INFO - 2017-08-16 08:39:34 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:39:34 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:39:34 --> Utf8 Class Initialized
INFO - 2017-08-16 08:39:34 --> URI Class Initialized
DEBUG - 2017-08-16 08:39:34 --> No URI present. Default controller set.
INFO - 2017-08-16 08:39:34 --> Router Class Initialized
INFO - 2017-08-16 08:39:34 --> Output Class Initialized
INFO - 2017-08-16 08:39:34 --> Security Class Initialized
DEBUG - 2017-08-16 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:39:34 --> Input Class Initialized
INFO - 2017-08-16 08:39:34 --> Language Class Initialized
INFO - 2017-08-16 08:39:34 --> Loader Class Initialized
INFO - 2017-08-16 08:39:34 --> Helper loaded: url_helper
INFO - 2017-08-16 08:39:34 --> Helper loaded: file_helper
INFO - 2017-08-16 08:39:34 --> Database Driver Class Initialized
INFO - 2017-08-16 08:39:34 --> Email Class Initialized
DEBUG - 2017-08-16 08:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:39:34 --> Table Class Initialized
INFO - 2017-08-16 08:39:34 --> Controller Class Initialized
INFO - 2017-08-16 08:39:34 --> Model Class Initialized
INFO - 2017-08-16 08:39:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:39:34 --> Final output sent to browser
DEBUG - 2017-08-16 08:39:34 --> Total execution time: 0.1907
INFO - 2017-08-16 08:39:37 --> Config Class Initialized
INFO - 2017-08-16 08:39:37 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:39:37 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:39:37 --> Utf8 Class Initialized
INFO - 2017-08-16 08:39:37 --> URI Class Initialized
INFO - 2017-08-16 08:39:37 --> Router Class Initialized
INFO - 2017-08-16 08:39:37 --> Output Class Initialized
INFO - 2017-08-16 08:39:37 --> Security Class Initialized
DEBUG - 2017-08-16 08:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:39:37 --> Input Class Initialized
INFO - 2017-08-16 08:39:37 --> Language Class Initialized
INFO - 2017-08-16 08:39:37 --> Loader Class Initialized
INFO - 2017-08-16 08:39:37 --> Helper loaded: url_helper
INFO - 2017-08-16 08:39:37 --> Helper loaded: file_helper
INFO - 2017-08-16 08:39:37 --> Database Driver Class Initialized
INFO - 2017-08-16 08:39:37 --> Email Class Initialized
DEBUG - 2017-08-16 08:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:39:37 --> Table Class Initialized
INFO - 2017-08-16 08:39:37 --> Controller Class Initialized
INFO - 2017-08-16 08:39:37 --> Model Class Initialized
INFO - 2017-08-16 08:39:37 --> Config Class Initialized
INFO - 2017-08-16 08:39:37 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:39:37 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:39:37 --> Utf8 Class Initialized
INFO - 2017-08-16 08:39:37 --> URI Class Initialized
DEBUG - 2017-08-16 08:39:37 --> No URI present. Default controller set.
INFO - 2017-08-16 08:39:37 --> Router Class Initialized
INFO - 2017-08-16 08:39:37 --> Output Class Initialized
INFO - 2017-08-16 08:39:37 --> Security Class Initialized
DEBUG - 2017-08-16 08:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:39:37 --> Input Class Initialized
INFO - 2017-08-16 08:39:37 --> Language Class Initialized
INFO - 2017-08-16 08:39:37 --> Loader Class Initialized
INFO - 2017-08-16 08:39:37 --> Helper loaded: url_helper
INFO - 2017-08-16 08:39:37 --> Helper loaded: file_helper
INFO - 2017-08-16 08:39:37 --> Database Driver Class Initialized
INFO - 2017-08-16 08:39:37 --> Email Class Initialized
DEBUG - 2017-08-16 08:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:39:37 --> Table Class Initialized
INFO - 2017-08-16 08:39:37 --> Controller Class Initialized
INFO - 2017-08-16 08:39:37 --> Model Class Initialized
INFO - 2017-08-16 08:39:37 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:39:37 --> Final output sent to browser
DEBUG - 2017-08-16 08:39:37 --> Total execution time: 0.1984
INFO - 2017-08-16 08:39:38 --> Config Class Initialized
INFO - 2017-08-16 08:39:38 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:39:38 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:39:38 --> Utf8 Class Initialized
INFO - 2017-08-16 08:39:38 --> URI Class Initialized
INFO - 2017-08-16 08:39:38 --> Router Class Initialized
INFO - 2017-08-16 08:39:38 --> Output Class Initialized
INFO - 2017-08-16 08:39:38 --> Security Class Initialized
DEBUG - 2017-08-16 08:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:39:38 --> Input Class Initialized
INFO - 2017-08-16 08:39:38 --> Language Class Initialized
INFO - 2017-08-16 08:39:38 --> Loader Class Initialized
INFO - 2017-08-16 08:39:38 --> Helper loaded: url_helper
INFO - 2017-08-16 08:39:38 --> Helper loaded: file_helper
INFO - 2017-08-16 08:39:38 --> Database Driver Class Initialized
INFO - 2017-08-16 08:39:38 --> Email Class Initialized
DEBUG - 2017-08-16 08:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:39:38 --> Table Class Initialized
INFO - 2017-08-16 08:39:38 --> Controller Class Initialized
INFO - 2017-08-16 08:39:38 --> Model Class Initialized
INFO - 2017-08-16 08:39:38 --> Config Class Initialized
INFO - 2017-08-16 08:39:38 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:39:38 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:39:38 --> Utf8 Class Initialized
INFO - 2017-08-16 08:39:38 --> URI Class Initialized
DEBUG - 2017-08-16 08:39:38 --> No URI present. Default controller set.
INFO - 2017-08-16 08:39:38 --> Router Class Initialized
INFO - 2017-08-16 08:39:38 --> Output Class Initialized
INFO - 2017-08-16 08:39:38 --> Security Class Initialized
DEBUG - 2017-08-16 08:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:39:38 --> Input Class Initialized
INFO - 2017-08-16 08:39:38 --> Language Class Initialized
INFO - 2017-08-16 08:39:39 --> Loader Class Initialized
INFO - 2017-08-16 08:39:39 --> Helper loaded: url_helper
INFO - 2017-08-16 08:39:39 --> Helper loaded: file_helper
INFO - 2017-08-16 08:39:39 --> Database Driver Class Initialized
INFO - 2017-08-16 08:39:39 --> Email Class Initialized
DEBUG - 2017-08-16 08:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:39:39 --> Table Class Initialized
INFO - 2017-08-16 08:39:39 --> Controller Class Initialized
INFO - 2017-08-16 08:39:39 --> Model Class Initialized
INFO - 2017-08-16 08:39:39 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:39:39 --> Final output sent to browser
DEBUG - 2017-08-16 08:39:39 --> Total execution time: 0.2164
INFO - 2017-08-16 08:39:39 --> Config Class Initialized
INFO - 2017-08-16 08:39:39 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:39:39 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:39:39 --> Utf8 Class Initialized
INFO - 2017-08-16 08:39:39 --> URI Class Initialized
INFO - 2017-08-16 08:39:39 --> Router Class Initialized
INFO - 2017-08-16 08:39:39 --> Output Class Initialized
INFO - 2017-08-16 08:39:39 --> Security Class Initialized
DEBUG - 2017-08-16 08:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:39:39 --> Input Class Initialized
INFO - 2017-08-16 08:39:39 --> Language Class Initialized
INFO - 2017-08-16 08:39:39 --> Loader Class Initialized
INFO - 2017-08-16 08:39:39 --> Helper loaded: url_helper
INFO - 2017-08-16 08:39:39 --> Helper loaded: file_helper
INFO - 2017-08-16 08:39:39 --> Database Driver Class Initialized
INFO - 2017-08-16 08:39:40 --> Email Class Initialized
DEBUG - 2017-08-16 08:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:39:40 --> Table Class Initialized
INFO - 2017-08-16 08:39:40 --> Controller Class Initialized
INFO - 2017-08-16 08:39:40 --> Model Class Initialized
INFO - 2017-08-16 08:39:40 --> Config Class Initialized
INFO - 2017-08-16 08:39:40 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:39:40 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:39:40 --> Utf8 Class Initialized
INFO - 2017-08-16 08:39:40 --> URI Class Initialized
DEBUG - 2017-08-16 08:39:40 --> No URI present. Default controller set.
INFO - 2017-08-16 08:39:40 --> Router Class Initialized
INFO - 2017-08-16 08:39:40 --> Output Class Initialized
INFO - 2017-08-16 08:39:40 --> Security Class Initialized
DEBUG - 2017-08-16 08:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:39:40 --> Input Class Initialized
INFO - 2017-08-16 08:39:40 --> Language Class Initialized
INFO - 2017-08-16 08:39:40 --> Loader Class Initialized
INFO - 2017-08-16 08:39:40 --> Helper loaded: url_helper
INFO - 2017-08-16 08:39:40 --> Helper loaded: file_helper
INFO - 2017-08-16 08:39:40 --> Database Driver Class Initialized
INFO - 2017-08-16 08:39:40 --> Email Class Initialized
DEBUG - 2017-08-16 08:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:39:40 --> Table Class Initialized
INFO - 2017-08-16 08:39:40 --> Controller Class Initialized
INFO - 2017-08-16 08:39:40 --> Model Class Initialized
INFO - 2017-08-16 08:39:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:39:40 --> Final output sent to browser
DEBUG - 2017-08-16 08:39:40 --> Total execution time: 0.1807
INFO - 2017-08-16 08:39:41 --> Config Class Initialized
INFO - 2017-08-16 08:39:41 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:39:41 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:39:41 --> Utf8 Class Initialized
INFO - 2017-08-16 08:39:41 --> URI Class Initialized
INFO - 2017-08-16 08:39:41 --> Router Class Initialized
INFO - 2017-08-16 08:39:41 --> Output Class Initialized
INFO - 2017-08-16 08:39:41 --> Security Class Initialized
DEBUG - 2017-08-16 08:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:39:41 --> Input Class Initialized
INFO - 2017-08-16 08:39:41 --> Language Class Initialized
INFO - 2017-08-16 08:39:41 --> Loader Class Initialized
INFO - 2017-08-16 08:39:41 --> Helper loaded: url_helper
INFO - 2017-08-16 08:39:41 --> Helper loaded: file_helper
INFO - 2017-08-16 08:39:41 --> Database Driver Class Initialized
INFO - 2017-08-16 08:39:41 --> Email Class Initialized
DEBUG - 2017-08-16 08:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:39:41 --> Table Class Initialized
INFO - 2017-08-16 08:39:41 --> Controller Class Initialized
INFO - 2017-08-16 08:39:41 --> Model Class Initialized
INFO - 2017-08-16 08:39:41 --> Config Class Initialized
INFO - 2017-08-16 08:39:41 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:39:41 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:39:41 --> Utf8 Class Initialized
INFO - 2017-08-16 08:39:41 --> URI Class Initialized
DEBUG - 2017-08-16 08:39:41 --> No URI present. Default controller set.
INFO - 2017-08-16 08:39:41 --> Router Class Initialized
INFO - 2017-08-16 08:39:41 --> Output Class Initialized
INFO - 2017-08-16 08:39:41 --> Security Class Initialized
DEBUG - 2017-08-16 08:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:39:41 --> Input Class Initialized
INFO - 2017-08-16 08:39:41 --> Language Class Initialized
INFO - 2017-08-16 08:39:41 --> Loader Class Initialized
INFO - 2017-08-16 08:39:41 --> Helper loaded: url_helper
INFO - 2017-08-16 08:39:41 --> Helper loaded: file_helper
INFO - 2017-08-16 08:39:41 --> Database Driver Class Initialized
INFO - 2017-08-16 08:39:41 --> Email Class Initialized
DEBUG - 2017-08-16 08:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:39:41 --> Table Class Initialized
INFO - 2017-08-16 08:39:41 --> Controller Class Initialized
INFO - 2017-08-16 08:39:41 --> Model Class Initialized
INFO - 2017-08-16 08:39:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:39:41 --> Final output sent to browser
DEBUG - 2017-08-16 08:39:41 --> Total execution time: 0.1891
INFO - 2017-08-16 08:39:53 --> Config Class Initialized
INFO - 2017-08-16 08:39:53 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:39:53 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:39:53 --> Utf8 Class Initialized
INFO - 2017-08-16 08:39:53 --> URI Class Initialized
INFO - 2017-08-16 08:39:53 --> Router Class Initialized
INFO - 2017-08-16 08:39:53 --> Output Class Initialized
INFO - 2017-08-16 08:39:53 --> Security Class Initialized
DEBUG - 2017-08-16 08:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:39:53 --> Input Class Initialized
INFO - 2017-08-16 08:39:53 --> Language Class Initialized
INFO - 2017-08-16 08:39:53 --> Loader Class Initialized
INFO - 2017-08-16 08:39:53 --> Helper loaded: url_helper
INFO - 2017-08-16 08:39:53 --> Helper loaded: file_helper
INFO - 2017-08-16 08:39:53 --> Database Driver Class Initialized
INFO - 2017-08-16 08:39:53 --> Email Class Initialized
DEBUG - 2017-08-16 08:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:39:53 --> Table Class Initialized
INFO - 2017-08-16 08:39:53 --> Controller Class Initialized
INFO - 2017-08-16 08:39:53 --> Helper loaded: form_helper
INFO - 2017-08-16 08:39:53 --> File loaded: C:\xampp\htdocs\biokimia\application\views\test.php
INFO - 2017-08-16 08:39:53 --> Final output sent to browser
DEBUG - 2017-08-16 08:39:53 --> Total execution time: 0.1892
INFO - 2017-08-16 08:40:04 --> Config Class Initialized
INFO - 2017-08-16 08:40:04 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:05 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:05 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:05 --> URI Class Initialized
INFO - 2017-08-16 08:40:05 --> Router Class Initialized
INFO - 2017-08-16 08:40:05 --> Output Class Initialized
INFO - 2017-08-16 08:40:05 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:05 --> Input Class Initialized
INFO - 2017-08-16 08:40:05 --> Language Class Initialized
INFO - 2017-08-16 08:40:05 --> Loader Class Initialized
INFO - 2017-08-16 08:40:05 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:05 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:05 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:05 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:05 --> Table Class Initialized
INFO - 2017-08-16 08:40:05 --> Controller Class Initialized
INFO - 2017-08-16 08:40:05 --> Model Class Initialized
INFO - 2017-08-16 08:40:05 --> Config Class Initialized
INFO - 2017-08-16 08:40:05 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:05 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:05 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:05 --> URI Class Initialized
DEBUG - 2017-08-16 08:40:05 --> No URI present. Default controller set.
INFO - 2017-08-16 08:40:05 --> Router Class Initialized
INFO - 2017-08-16 08:40:05 --> Output Class Initialized
INFO - 2017-08-16 08:40:05 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:05 --> Input Class Initialized
INFO - 2017-08-16 08:40:05 --> Language Class Initialized
INFO - 2017-08-16 08:40:05 --> Loader Class Initialized
INFO - 2017-08-16 08:40:05 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:05 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:05 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:05 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:05 --> Table Class Initialized
INFO - 2017-08-16 08:40:05 --> Controller Class Initialized
INFO - 2017-08-16 08:40:05 --> Model Class Initialized
INFO - 2017-08-16 08:40:05 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:40:05 --> Final output sent to browser
DEBUG - 2017-08-16 08:40:05 --> Total execution time: 0.1911
INFO - 2017-08-16 08:40:08 --> Config Class Initialized
INFO - 2017-08-16 08:40:08 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:08 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:08 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:08 --> URI Class Initialized
INFO - 2017-08-16 08:40:08 --> Router Class Initialized
INFO - 2017-08-16 08:40:08 --> Output Class Initialized
INFO - 2017-08-16 08:40:08 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:08 --> Input Class Initialized
INFO - 2017-08-16 08:40:08 --> Language Class Initialized
INFO - 2017-08-16 08:40:08 --> Loader Class Initialized
INFO - 2017-08-16 08:40:08 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:08 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:08 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:08 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:08 --> Table Class Initialized
INFO - 2017-08-16 08:40:08 --> Controller Class Initialized
INFO - 2017-08-16 08:40:08 --> Helper loaded: form_helper
INFO - 2017-08-16 08:40:08 --> File loaded: C:\xampp\htdocs\biokimia\application\views\test.php
INFO - 2017-08-16 08:40:08 --> Final output sent to browser
DEBUG - 2017-08-16 08:40:08 --> Total execution time: 0.2019
INFO - 2017-08-16 08:40:14 --> Config Class Initialized
INFO - 2017-08-16 08:40:14 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:14 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:14 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:14 --> URI Class Initialized
INFO - 2017-08-16 08:40:14 --> Router Class Initialized
INFO - 2017-08-16 08:40:14 --> Output Class Initialized
INFO - 2017-08-16 08:40:14 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:14 --> Input Class Initialized
INFO - 2017-08-16 08:40:14 --> Language Class Initialized
INFO - 2017-08-16 08:40:14 --> Loader Class Initialized
INFO - 2017-08-16 08:40:14 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:14 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:14 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:14 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:14 --> Table Class Initialized
INFO - 2017-08-16 08:40:14 --> Controller Class Initialized
INFO - 2017-08-16 08:40:14 --> Model Class Initialized
INFO - 2017-08-16 08:40:14 --> Config Class Initialized
INFO - 2017-08-16 08:40:14 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:14 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:14 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:14 --> URI Class Initialized
DEBUG - 2017-08-16 08:40:14 --> No URI present. Default controller set.
INFO - 2017-08-16 08:40:14 --> Router Class Initialized
INFO - 2017-08-16 08:40:14 --> Output Class Initialized
INFO - 2017-08-16 08:40:14 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:14 --> Input Class Initialized
INFO - 2017-08-16 08:40:14 --> Language Class Initialized
INFO - 2017-08-16 08:40:14 --> Loader Class Initialized
INFO - 2017-08-16 08:40:14 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:14 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:14 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:14 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:14 --> Table Class Initialized
INFO - 2017-08-16 08:40:14 --> Controller Class Initialized
INFO - 2017-08-16 08:40:14 --> Model Class Initialized
INFO - 2017-08-16 08:40:14 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:40:14 --> Final output sent to browser
DEBUG - 2017-08-16 08:40:14 --> Total execution time: 0.1888
INFO - 2017-08-16 08:40:30 --> Config Class Initialized
INFO - 2017-08-16 08:40:31 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:31 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:31 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:31 --> URI Class Initialized
INFO - 2017-08-16 08:40:31 --> Router Class Initialized
INFO - 2017-08-16 08:40:31 --> Output Class Initialized
INFO - 2017-08-16 08:40:31 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:31 --> Input Class Initialized
INFO - 2017-08-16 08:40:31 --> Language Class Initialized
INFO - 2017-08-16 08:40:31 --> Loader Class Initialized
INFO - 2017-08-16 08:40:31 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:31 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:31 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:31 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:31 --> Table Class Initialized
INFO - 2017-08-16 08:40:31 --> Controller Class Initialized
INFO - 2017-08-16 08:40:31 --> Helper loaded: form_helper
INFO - 2017-08-16 08:40:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\test.php
INFO - 2017-08-16 08:40:31 --> Final output sent to browser
DEBUG - 2017-08-16 08:40:31 --> Total execution time: 0.1946
INFO - 2017-08-16 08:40:34 --> Config Class Initialized
INFO - 2017-08-16 08:40:34 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:34 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:34 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:34 --> URI Class Initialized
INFO - 2017-08-16 08:40:34 --> Router Class Initialized
INFO - 2017-08-16 08:40:34 --> Output Class Initialized
INFO - 2017-08-16 08:40:34 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:34 --> Input Class Initialized
INFO - 2017-08-16 08:40:34 --> Language Class Initialized
INFO - 2017-08-16 08:40:34 --> Loader Class Initialized
INFO - 2017-08-16 08:40:34 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:34 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:34 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:34 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:34 --> Table Class Initialized
INFO - 2017-08-16 08:40:34 --> Controller Class Initialized
INFO - 2017-08-16 08:40:34 --> Model Class Initialized
INFO - 2017-08-16 08:40:34 --> Config Class Initialized
INFO - 2017-08-16 08:40:34 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:34 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:34 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:34 --> URI Class Initialized
DEBUG - 2017-08-16 08:40:34 --> No URI present. Default controller set.
INFO - 2017-08-16 08:40:34 --> Router Class Initialized
INFO - 2017-08-16 08:40:34 --> Output Class Initialized
INFO - 2017-08-16 08:40:34 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:34 --> Input Class Initialized
INFO - 2017-08-16 08:40:34 --> Language Class Initialized
INFO - 2017-08-16 08:40:34 --> Loader Class Initialized
INFO - 2017-08-16 08:40:34 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:34 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:34 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:34 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:34 --> Table Class Initialized
INFO - 2017-08-16 08:40:34 --> Controller Class Initialized
INFO - 2017-08-16 08:40:34 --> Model Class Initialized
INFO - 2017-08-16 08:40:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:40:34 --> Final output sent to browser
DEBUG - 2017-08-16 08:40:34 --> Total execution time: 0.1901
INFO - 2017-08-16 08:40:37 --> Config Class Initialized
INFO - 2017-08-16 08:40:37 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:37 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:37 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:37 --> URI Class Initialized
INFO - 2017-08-16 08:40:37 --> Router Class Initialized
INFO - 2017-08-16 08:40:37 --> Output Class Initialized
INFO - 2017-08-16 08:40:37 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:37 --> Input Class Initialized
INFO - 2017-08-16 08:40:37 --> Language Class Initialized
INFO - 2017-08-16 08:40:37 --> Loader Class Initialized
INFO - 2017-08-16 08:40:37 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:37 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:37 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:37 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:37 --> Table Class Initialized
INFO - 2017-08-16 08:40:37 --> Controller Class Initialized
INFO - 2017-08-16 08:40:37 --> Helper loaded: form_helper
INFO - 2017-08-16 08:40:37 --> File loaded: C:\xampp\htdocs\biokimia\application\views\test.php
INFO - 2017-08-16 08:40:37 --> Final output sent to browser
DEBUG - 2017-08-16 08:40:37 --> Total execution time: 0.1992
INFO - 2017-08-16 08:40:39 --> Config Class Initialized
INFO - 2017-08-16 08:40:39 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:39 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:39 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:39 --> URI Class Initialized
DEBUG - 2017-08-16 08:40:39 --> No URI present. Default controller set.
INFO - 2017-08-16 08:40:39 --> Router Class Initialized
INFO - 2017-08-16 08:40:39 --> Output Class Initialized
INFO - 2017-08-16 08:40:39 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:39 --> Input Class Initialized
INFO - 2017-08-16 08:40:39 --> Language Class Initialized
INFO - 2017-08-16 08:40:39 --> Loader Class Initialized
INFO - 2017-08-16 08:40:39 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:39 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:39 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:39 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:39 --> Table Class Initialized
INFO - 2017-08-16 08:40:39 --> Controller Class Initialized
INFO - 2017-08-16 08:40:39 --> Model Class Initialized
INFO - 2017-08-16 08:40:39 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:40:39 --> Final output sent to browser
DEBUG - 2017-08-16 08:40:39 --> Total execution time: 0.3184
INFO - 2017-08-16 08:40:40 --> Config Class Initialized
INFO - 2017-08-16 08:40:40 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:40 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:40 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:40 --> URI Class Initialized
INFO - 2017-08-16 08:40:40 --> Router Class Initialized
INFO - 2017-08-16 08:40:40 --> Output Class Initialized
INFO - 2017-08-16 08:40:40 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:40 --> Input Class Initialized
INFO - 2017-08-16 08:40:40 --> Language Class Initialized
INFO - 2017-08-16 08:40:40 --> Loader Class Initialized
INFO - 2017-08-16 08:40:40 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:40 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:40 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:40 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:40 --> Table Class Initialized
INFO - 2017-08-16 08:40:40 --> Controller Class Initialized
INFO - 2017-08-16 08:40:40 --> Helper loaded: form_helper
INFO - 2017-08-16 08:40:40 --> File loaded: C:\xampp\htdocs\biokimia\application\views\test.php
INFO - 2017-08-16 08:40:40 --> Final output sent to browser
DEBUG - 2017-08-16 08:40:40 --> Total execution time: 0.2169
INFO - 2017-08-16 08:40:41 --> Config Class Initialized
INFO - 2017-08-16 08:40:41 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:41 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:41 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:41 --> URI Class Initialized
DEBUG - 2017-08-16 08:40:41 --> No URI present. Default controller set.
INFO - 2017-08-16 08:40:41 --> Router Class Initialized
INFO - 2017-08-16 08:40:41 --> Output Class Initialized
INFO - 2017-08-16 08:40:41 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:41 --> Input Class Initialized
INFO - 2017-08-16 08:40:41 --> Language Class Initialized
INFO - 2017-08-16 08:40:41 --> Loader Class Initialized
INFO - 2017-08-16 08:40:41 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:41 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:41 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:41 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:41 --> Table Class Initialized
INFO - 2017-08-16 08:40:41 --> Controller Class Initialized
INFO - 2017-08-16 08:40:41 --> Model Class Initialized
INFO - 2017-08-16 08:40:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:40:41 --> Final output sent to browser
DEBUG - 2017-08-16 08:40:41 --> Total execution time: 0.2094
INFO - 2017-08-16 08:40:42 --> Config Class Initialized
INFO - 2017-08-16 08:40:42 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:42 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:42 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:42 --> URI Class Initialized
INFO - 2017-08-16 08:40:42 --> Router Class Initialized
INFO - 2017-08-16 08:40:42 --> Output Class Initialized
INFO - 2017-08-16 08:40:42 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:42 --> Input Class Initialized
INFO - 2017-08-16 08:40:42 --> Language Class Initialized
INFO - 2017-08-16 08:40:42 --> Loader Class Initialized
INFO - 2017-08-16 08:40:42 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:42 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:42 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:42 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:42 --> Table Class Initialized
INFO - 2017-08-16 08:40:42 --> Controller Class Initialized
INFO - 2017-08-16 08:40:42 --> Helper loaded: form_helper
INFO - 2017-08-16 08:40:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\test.php
INFO - 2017-08-16 08:40:42 --> Final output sent to browser
DEBUG - 2017-08-16 08:40:42 --> Total execution time: 0.2068
INFO - 2017-08-16 08:40:43 --> Config Class Initialized
INFO - 2017-08-16 08:40:43 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:43 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:43 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:43 --> URI Class Initialized
DEBUG - 2017-08-16 08:40:43 --> No URI present. Default controller set.
INFO - 2017-08-16 08:40:43 --> Router Class Initialized
INFO - 2017-08-16 08:40:43 --> Output Class Initialized
INFO - 2017-08-16 08:40:43 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:43 --> Input Class Initialized
INFO - 2017-08-16 08:40:43 --> Language Class Initialized
INFO - 2017-08-16 08:40:43 --> Loader Class Initialized
INFO - 2017-08-16 08:40:43 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:43 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:43 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:43 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:43 --> Table Class Initialized
INFO - 2017-08-16 08:40:43 --> Controller Class Initialized
INFO - 2017-08-16 08:40:43 --> Model Class Initialized
INFO - 2017-08-16 08:40:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-16 08:40:43 --> Final output sent to browser
DEBUG - 2017-08-16 08:40:43 --> Total execution time: 0.2071
INFO - 2017-08-16 08:40:44 --> Config Class Initialized
INFO - 2017-08-16 08:40:44 --> Hooks Class Initialized
DEBUG - 2017-08-16 08:40:44 --> UTF-8 Support Enabled
INFO - 2017-08-16 08:40:44 --> Utf8 Class Initialized
INFO - 2017-08-16 08:40:44 --> URI Class Initialized
INFO - 2017-08-16 08:40:44 --> Router Class Initialized
INFO - 2017-08-16 08:40:44 --> Output Class Initialized
INFO - 2017-08-16 08:40:44 --> Security Class Initialized
DEBUG - 2017-08-16 08:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 08:40:44 --> Input Class Initialized
INFO - 2017-08-16 08:40:44 --> Language Class Initialized
INFO - 2017-08-16 08:40:44 --> Loader Class Initialized
INFO - 2017-08-16 08:40:44 --> Helper loaded: url_helper
INFO - 2017-08-16 08:40:44 --> Helper loaded: file_helper
INFO - 2017-08-16 08:40:44 --> Database Driver Class Initialized
INFO - 2017-08-16 08:40:44 --> Email Class Initialized
DEBUG - 2017-08-16 08:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 08:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 08:40:44 --> Table Class Initialized
INFO - 2017-08-16 08:40:44 --> Controller Class Initialized
INFO - 2017-08-16 08:40:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 08:40:44 --> Final output sent to browser
DEBUG - 2017-08-16 08:40:44 --> Total execution time: 0.1961
INFO - 2017-08-16 09:12:59 --> Config Class Initialized
INFO - 2017-08-16 09:12:59 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:12:59 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:12:59 --> Utf8 Class Initialized
INFO - 2017-08-16 09:12:59 --> URI Class Initialized
INFO - 2017-08-16 09:12:59 --> Router Class Initialized
INFO - 2017-08-16 09:12:59 --> Output Class Initialized
INFO - 2017-08-16 09:12:59 --> Security Class Initialized
DEBUG - 2017-08-16 09:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:12:59 --> Input Class Initialized
INFO - 2017-08-16 09:12:59 --> Language Class Initialized
INFO - 2017-08-16 09:12:59 --> Loader Class Initialized
INFO - 2017-08-16 09:12:59 --> Helper loaded: url_helper
INFO - 2017-08-16 09:12:59 --> Helper loaded: file_helper
INFO - 2017-08-16 09:12:59 --> Database Driver Class Initialized
INFO - 2017-08-16 09:12:59 --> Email Class Initialized
DEBUG - 2017-08-16 09:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:12:59 --> Table Class Initialized
INFO - 2017-08-16 09:12:59 --> Controller Class Initialized
INFO - 2017-08-16 09:12:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 09:12:59 --> Final output sent to browser
DEBUG - 2017-08-16 09:12:59 --> Total execution time: 0.1761
INFO - 2017-08-16 09:13:00 --> Config Class Initialized
INFO - 2017-08-16 09:13:00 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:13:00 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:13:01 --> Utf8 Class Initialized
INFO - 2017-08-16 09:13:01 --> URI Class Initialized
INFO - 2017-08-16 09:13:01 --> Router Class Initialized
INFO - 2017-08-16 09:13:01 --> Output Class Initialized
INFO - 2017-08-16 09:13:01 --> Security Class Initialized
DEBUG - 2017-08-16 09:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:13:01 --> Input Class Initialized
INFO - 2017-08-16 09:13:01 --> Language Class Initialized
INFO - 2017-08-16 09:13:01 --> Loader Class Initialized
INFO - 2017-08-16 09:13:01 --> Helper loaded: url_helper
INFO - 2017-08-16 09:13:01 --> Helper loaded: file_helper
INFO - 2017-08-16 09:13:01 --> Database Driver Class Initialized
INFO - 2017-08-16 09:13:01 --> Email Class Initialized
DEBUG - 2017-08-16 09:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:13:01 --> Table Class Initialized
INFO - 2017-08-16 09:13:01 --> Controller Class Initialized
ERROR - 2017-08-16 09:13:01 --> Unable to load the requested class: Database
INFO - 2017-08-16 09:13:42 --> Config Class Initialized
INFO - 2017-08-16 09:13:42 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:13:42 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:13:42 --> Utf8 Class Initialized
INFO - 2017-08-16 09:13:42 --> URI Class Initialized
INFO - 2017-08-16 09:13:42 --> Router Class Initialized
INFO - 2017-08-16 09:13:42 --> Output Class Initialized
INFO - 2017-08-16 09:13:42 --> Security Class Initialized
DEBUG - 2017-08-16 09:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:13:42 --> Input Class Initialized
INFO - 2017-08-16 09:13:42 --> Language Class Initialized
INFO - 2017-08-16 09:13:42 --> Loader Class Initialized
INFO - 2017-08-16 09:13:42 --> Helper loaded: url_helper
INFO - 2017-08-16 09:13:42 --> Helper loaded: file_helper
INFO - 2017-08-16 09:13:42 --> Database Driver Class Initialized
INFO - 2017-08-16 09:13:42 --> Email Class Initialized
DEBUG - 2017-08-16 09:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:13:42 --> Table Class Initialized
INFO - 2017-08-16 09:13:42 --> Controller Class Initialized
INFO - 2017-08-16 09:13:42 --> Helper loaded: form_helper
INFO - 2017-08-16 09:13:43 --> Form Validation Class Initialized
ERROR - 2017-08-16 09:13:43 --> Severity: Error --> Call to undefined function validation_error() C:\xampp\htdocs\biokimia\application\views\Validation_form.php 10
INFO - 2017-08-16 09:14:24 --> Config Class Initialized
INFO - 2017-08-16 09:14:24 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:14:24 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:14:24 --> Utf8 Class Initialized
INFO - 2017-08-16 09:14:24 --> URI Class Initialized
INFO - 2017-08-16 09:14:24 --> Router Class Initialized
INFO - 2017-08-16 09:14:24 --> Output Class Initialized
INFO - 2017-08-16 09:14:24 --> Security Class Initialized
DEBUG - 2017-08-16 09:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:14:24 --> Input Class Initialized
INFO - 2017-08-16 09:14:24 --> Language Class Initialized
INFO - 2017-08-16 09:14:24 --> Loader Class Initialized
INFO - 2017-08-16 09:14:24 --> Helper loaded: url_helper
INFO - 2017-08-16 09:14:24 --> Helper loaded: file_helper
INFO - 2017-08-16 09:14:24 --> Database Driver Class Initialized
INFO - 2017-08-16 09:14:24 --> Email Class Initialized
DEBUG - 2017-08-16 09:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:14:24 --> Table Class Initialized
INFO - 2017-08-16 09:14:24 --> Controller Class Initialized
INFO - 2017-08-16 09:14:24 --> Helper loaded: form_helper
INFO - 2017-08-16 09:14:24 --> Form Validation Class Initialized
INFO - 2017-08-16 09:14:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:14:24 --> Final output sent to browser
DEBUG - 2017-08-16 09:14:24 --> Total execution time: 0.1931
INFO - 2017-08-16 09:14:56 --> Config Class Initialized
INFO - 2017-08-16 09:14:56 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:14:56 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:14:56 --> Utf8 Class Initialized
INFO - 2017-08-16 09:14:56 --> URI Class Initialized
INFO - 2017-08-16 09:14:56 --> Router Class Initialized
INFO - 2017-08-16 09:14:56 --> Output Class Initialized
INFO - 2017-08-16 09:14:56 --> Security Class Initialized
DEBUG - 2017-08-16 09:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:14:56 --> Input Class Initialized
INFO - 2017-08-16 09:14:56 --> Language Class Initialized
INFO - 2017-08-16 09:14:56 --> Loader Class Initialized
INFO - 2017-08-16 09:14:56 --> Helper loaded: url_helper
INFO - 2017-08-16 09:14:56 --> Helper loaded: file_helper
INFO - 2017-08-16 09:14:56 --> Database Driver Class Initialized
INFO - 2017-08-16 09:14:56 --> Email Class Initialized
DEBUG - 2017-08-16 09:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:14:56 --> Table Class Initialized
INFO - 2017-08-16 09:14:56 --> Controller Class Initialized
INFO - 2017-08-16 09:14:56 --> Helper loaded: form_helper
INFO - 2017-08-16 09:14:56 --> Form Validation Class Initialized
INFO - 2017-08-16 09:14:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:14:56 --> Final output sent to browser
DEBUG - 2017-08-16 09:14:56 --> Total execution time: 0.1939
INFO - 2017-08-16 09:15:02 --> Config Class Initialized
INFO - 2017-08-16 09:15:02 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:15:02 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:15:02 --> Utf8 Class Initialized
INFO - 2017-08-16 09:15:02 --> URI Class Initialized
INFO - 2017-08-16 09:15:02 --> Router Class Initialized
INFO - 2017-08-16 09:15:02 --> Output Class Initialized
INFO - 2017-08-16 09:15:02 --> Security Class Initialized
DEBUG - 2017-08-16 09:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:15:02 --> Input Class Initialized
INFO - 2017-08-16 09:15:02 --> Language Class Initialized
INFO - 2017-08-16 09:15:02 --> Loader Class Initialized
INFO - 2017-08-16 09:15:02 --> Helper loaded: url_helper
INFO - 2017-08-16 09:15:02 --> Helper loaded: file_helper
INFO - 2017-08-16 09:15:02 --> Database Driver Class Initialized
INFO - 2017-08-16 09:15:02 --> Email Class Initialized
DEBUG - 2017-08-16 09:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:15:02 --> Table Class Initialized
INFO - 2017-08-16 09:15:02 --> Controller Class Initialized
INFO - 2017-08-16 09:15:02 --> Helper loaded: form_helper
INFO - 2017-08-16 09:15:02 --> Form Validation Class Initialized
INFO - 2017-08-16 09:15:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:15:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_success.php
INFO - 2017-08-16 09:15:02 --> Final output sent to browser
DEBUG - 2017-08-16 09:15:02 --> Total execution time: 0.2111
INFO - 2017-08-16 09:15:05 --> Config Class Initialized
INFO - 2017-08-16 09:15:05 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:15:05 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:15:05 --> Utf8 Class Initialized
INFO - 2017-08-16 09:15:05 --> URI Class Initialized
INFO - 2017-08-16 09:15:05 --> Router Class Initialized
INFO - 2017-08-16 09:15:05 --> Output Class Initialized
INFO - 2017-08-16 09:15:05 --> Security Class Initialized
DEBUG - 2017-08-16 09:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:15:05 --> Input Class Initialized
INFO - 2017-08-16 09:15:05 --> Language Class Initialized
INFO - 2017-08-16 09:15:05 --> Loader Class Initialized
INFO - 2017-08-16 09:15:05 --> Helper loaded: url_helper
INFO - 2017-08-16 09:15:05 --> Helper loaded: file_helper
INFO - 2017-08-16 09:15:05 --> Database Driver Class Initialized
INFO - 2017-08-16 09:15:05 --> Email Class Initialized
DEBUG - 2017-08-16 09:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:15:05 --> Table Class Initialized
INFO - 2017-08-16 09:15:05 --> Controller Class Initialized
INFO - 2017-08-16 09:15:05 --> Helper loaded: form_helper
INFO - 2017-08-16 09:15:05 --> Form Validation Class Initialized
INFO - 2017-08-16 09:15:05 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:15:05 --> Final output sent to browser
DEBUG - 2017-08-16 09:15:05 --> Total execution time: 0.1911
INFO - 2017-08-16 09:15:07 --> Config Class Initialized
INFO - 2017-08-16 09:15:07 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:15:07 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:15:07 --> Utf8 Class Initialized
INFO - 2017-08-16 09:15:07 --> URI Class Initialized
INFO - 2017-08-16 09:15:07 --> Router Class Initialized
INFO - 2017-08-16 09:15:07 --> Output Class Initialized
INFO - 2017-08-16 09:15:07 --> Security Class Initialized
DEBUG - 2017-08-16 09:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:15:07 --> Input Class Initialized
INFO - 2017-08-16 09:15:07 --> Language Class Initialized
INFO - 2017-08-16 09:15:07 --> Loader Class Initialized
INFO - 2017-08-16 09:15:07 --> Helper loaded: url_helper
INFO - 2017-08-16 09:15:07 --> Helper loaded: file_helper
INFO - 2017-08-16 09:15:07 --> Database Driver Class Initialized
INFO - 2017-08-16 09:15:07 --> Email Class Initialized
DEBUG - 2017-08-16 09:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:15:07 --> Table Class Initialized
INFO - 2017-08-16 09:15:07 --> Controller Class Initialized
INFO - 2017-08-16 09:15:07 --> Helper loaded: form_helper
INFO - 2017-08-16 09:15:07 --> Form Validation Class Initialized
INFO - 2017-08-16 09:15:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:15:07 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_success.php
INFO - 2017-08-16 09:15:07 --> Final output sent to browser
DEBUG - 2017-08-16 09:15:07 --> Total execution time: 0.2023
INFO - 2017-08-16 09:15:11 --> Config Class Initialized
INFO - 2017-08-16 09:15:11 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:15:11 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:15:11 --> Utf8 Class Initialized
INFO - 2017-08-16 09:15:11 --> URI Class Initialized
INFO - 2017-08-16 09:15:11 --> Router Class Initialized
INFO - 2017-08-16 09:15:11 --> Output Class Initialized
INFO - 2017-08-16 09:15:11 --> Security Class Initialized
DEBUG - 2017-08-16 09:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:15:11 --> Input Class Initialized
INFO - 2017-08-16 09:15:11 --> Language Class Initialized
INFO - 2017-08-16 09:15:11 --> Loader Class Initialized
INFO - 2017-08-16 09:15:11 --> Helper loaded: url_helper
INFO - 2017-08-16 09:15:11 --> Helper loaded: file_helper
INFO - 2017-08-16 09:15:11 --> Database Driver Class Initialized
INFO - 2017-08-16 09:15:11 --> Email Class Initialized
DEBUG - 2017-08-16 09:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:15:11 --> Table Class Initialized
INFO - 2017-08-16 09:15:11 --> Controller Class Initialized
INFO - 2017-08-16 09:15:11 --> Helper loaded: form_helper
INFO - 2017-08-16 09:15:11 --> Form Validation Class Initialized
INFO - 2017-08-16 09:15:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:15:11 --> Final output sent to browser
DEBUG - 2017-08-16 09:15:11 --> Total execution time: 0.2015
INFO - 2017-08-16 09:15:16 --> Config Class Initialized
INFO - 2017-08-16 09:15:16 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:15:16 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:15:16 --> Utf8 Class Initialized
INFO - 2017-08-16 09:15:16 --> URI Class Initialized
INFO - 2017-08-16 09:15:16 --> Router Class Initialized
INFO - 2017-08-16 09:15:16 --> Output Class Initialized
INFO - 2017-08-16 09:15:16 --> Security Class Initialized
DEBUG - 2017-08-16 09:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:15:16 --> Input Class Initialized
INFO - 2017-08-16 09:15:16 --> Language Class Initialized
INFO - 2017-08-16 09:15:16 --> Loader Class Initialized
INFO - 2017-08-16 09:15:16 --> Helper loaded: url_helper
INFO - 2017-08-16 09:15:16 --> Helper loaded: file_helper
INFO - 2017-08-16 09:15:16 --> Database Driver Class Initialized
INFO - 2017-08-16 09:15:16 --> Email Class Initialized
DEBUG - 2017-08-16 09:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:15:16 --> Table Class Initialized
INFO - 2017-08-16 09:15:16 --> Controller Class Initialized
INFO - 2017-08-16 09:15:16 --> Helper loaded: form_helper
INFO - 2017-08-16 09:15:16 --> Form Validation Class Initialized
INFO - 2017-08-16 09:15:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:15:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_success.php
INFO - 2017-08-16 09:15:16 --> Final output sent to browser
DEBUG - 2017-08-16 09:15:16 --> Total execution time: 0.2121
INFO - 2017-08-16 09:15:32 --> Config Class Initialized
INFO - 2017-08-16 09:15:32 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:15:32 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:15:32 --> Utf8 Class Initialized
INFO - 2017-08-16 09:15:32 --> URI Class Initialized
INFO - 2017-08-16 09:15:32 --> Router Class Initialized
INFO - 2017-08-16 09:15:32 --> Output Class Initialized
INFO - 2017-08-16 09:15:32 --> Security Class Initialized
DEBUG - 2017-08-16 09:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:15:32 --> Input Class Initialized
INFO - 2017-08-16 09:15:32 --> Language Class Initialized
INFO - 2017-08-16 09:15:32 --> Loader Class Initialized
INFO - 2017-08-16 09:15:32 --> Helper loaded: url_helper
INFO - 2017-08-16 09:15:32 --> Helper loaded: file_helper
INFO - 2017-08-16 09:15:32 --> Database Driver Class Initialized
INFO - 2017-08-16 09:15:32 --> Email Class Initialized
DEBUG - 2017-08-16 09:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:15:32 --> Table Class Initialized
INFO - 2017-08-16 09:15:32 --> Controller Class Initialized
INFO - 2017-08-16 09:15:32 --> Helper loaded: form_helper
INFO - 2017-08-16 09:15:32 --> Form Validation Class Initialized
INFO - 2017-08-16 09:15:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:15:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_success.php
INFO - 2017-08-16 09:15:32 --> Final output sent to browser
DEBUG - 2017-08-16 09:15:32 --> Total execution time: 0.2188
INFO - 2017-08-16 09:15:34 --> Config Class Initialized
INFO - 2017-08-16 09:15:34 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:15:34 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:15:34 --> Utf8 Class Initialized
INFO - 2017-08-16 09:15:34 --> URI Class Initialized
INFO - 2017-08-16 09:15:34 --> Router Class Initialized
INFO - 2017-08-16 09:15:34 --> Output Class Initialized
INFO - 2017-08-16 09:15:34 --> Security Class Initialized
DEBUG - 2017-08-16 09:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:15:34 --> Input Class Initialized
INFO - 2017-08-16 09:15:34 --> Language Class Initialized
INFO - 2017-08-16 09:15:34 --> Loader Class Initialized
INFO - 2017-08-16 09:15:34 --> Helper loaded: url_helper
INFO - 2017-08-16 09:15:34 --> Helper loaded: file_helper
INFO - 2017-08-16 09:15:34 --> Database Driver Class Initialized
INFO - 2017-08-16 09:15:34 --> Email Class Initialized
DEBUG - 2017-08-16 09:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:15:34 --> Table Class Initialized
INFO - 2017-08-16 09:15:34 --> Controller Class Initialized
INFO - 2017-08-16 09:15:34 --> Helper loaded: form_helper
INFO - 2017-08-16 09:15:34 --> Form Validation Class Initialized
INFO - 2017-08-16 09:15:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:15:34 --> Final output sent to browser
DEBUG - 2017-08-16 09:15:34 --> Total execution time: 0.2049
INFO - 2017-08-16 09:15:36 --> Config Class Initialized
INFO - 2017-08-16 09:15:36 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:15:36 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:15:36 --> Utf8 Class Initialized
INFO - 2017-08-16 09:15:36 --> URI Class Initialized
INFO - 2017-08-16 09:15:36 --> Router Class Initialized
INFO - 2017-08-16 09:15:36 --> Output Class Initialized
INFO - 2017-08-16 09:15:36 --> Security Class Initialized
DEBUG - 2017-08-16 09:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:15:36 --> Input Class Initialized
INFO - 2017-08-16 09:15:36 --> Language Class Initialized
INFO - 2017-08-16 09:15:36 --> Loader Class Initialized
INFO - 2017-08-16 09:15:36 --> Helper loaded: url_helper
INFO - 2017-08-16 09:15:36 --> Helper loaded: file_helper
INFO - 2017-08-16 09:15:36 --> Database Driver Class Initialized
INFO - 2017-08-16 09:15:36 --> Email Class Initialized
DEBUG - 2017-08-16 09:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:15:36 --> Table Class Initialized
INFO - 2017-08-16 09:15:36 --> Controller Class Initialized
INFO - 2017-08-16 09:15:36 --> Helper loaded: form_helper
INFO - 2017-08-16 09:15:36 --> Form Validation Class Initialized
INFO - 2017-08-16 09:15:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:15:36 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_success.php
INFO - 2017-08-16 09:15:36 --> Final output sent to browser
DEBUG - 2017-08-16 09:15:36 --> Total execution time: 0.2132
INFO - 2017-08-16 09:15:38 --> Config Class Initialized
INFO - 2017-08-16 09:15:38 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:15:38 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:15:38 --> Utf8 Class Initialized
INFO - 2017-08-16 09:15:38 --> URI Class Initialized
INFO - 2017-08-16 09:15:38 --> Router Class Initialized
INFO - 2017-08-16 09:15:38 --> Output Class Initialized
INFO - 2017-08-16 09:15:38 --> Security Class Initialized
DEBUG - 2017-08-16 09:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:15:38 --> Input Class Initialized
INFO - 2017-08-16 09:15:38 --> Language Class Initialized
INFO - 2017-08-16 09:15:38 --> Loader Class Initialized
INFO - 2017-08-16 09:15:38 --> Helper loaded: url_helper
INFO - 2017-08-16 09:15:38 --> Helper loaded: file_helper
INFO - 2017-08-16 09:15:38 --> Database Driver Class Initialized
INFO - 2017-08-16 09:15:38 --> Email Class Initialized
DEBUG - 2017-08-16 09:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:15:38 --> Table Class Initialized
INFO - 2017-08-16 09:15:38 --> Controller Class Initialized
INFO - 2017-08-16 09:15:38 --> Helper loaded: form_helper
INFO - 2017-08-16 09:15:38 --> Form Validation Class Initialized
INFO - 2017-08-16 09:15:38 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:15:38 --> Final output sent to browser
DEBUG - 2017-08-16 09:15:38 --> Total execution time: 0.2036
INFO - 2017-08-16 09:17:22 --> Config Class Initialized
INFO - 2017-08-16 09:17:22 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:17:22 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:17:22 --> Utf8 Class Initialized
INFO - 2017-08-16 09:17:22 --> URI Class Initialized
INFO - 2017-08-16 09:17:22 --> Router Class Initialized
INFO - 2017-08-16 09:17:22 --> Output Class Initialized
INFO - 2017-08-16 09:17:22 --> Security Class Initialized
DEBUG - 2017-08-16 09:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:17:22 --> Input Class Initialized
INFO - 2017-08-16 09:17:22 --> Language Class Initialized
INFO - 2017-08-16 09:17:22 --> Loader Class Initialized
INFO - 2017-08-16 09:17:22 --> Helper loaded: url_helper
INFO - 2017-08-16 09:17:22 --> Helper loaded: file_helper
INFO - 2017-08-16 09:17:22 --> Database Driver Class Initialized
INFO - 2017-08-16 09:17:22 --> Email Class Initialized
DEBUG - 2017-08-16 09:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:17:22 --> Table Class Initialized
INFO - 2017-08-16 09:17:22 --> Controller Class Initialized
INFO - 2017-08-16 09:17:22 --> Helper loaded: form_helper
INFO - 2017-08-16 09:17:22 --> Form Validation Class Initialized
INFO - 2017-08-16 09:17:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:17:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:17:22 --> Final output sent to browser
DEBUG - 2017-08-16 09:17:22 --> Total execution time: 0.2195
INFO - 2017-08-16 09:17:25 --> Config Class Initialized
INFO - 2017-08-16 09:17:25 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:17:25 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:17:25 --> Utf8 Class Initialized
INFO - 2017-08-16 09:17:25 --> URI Class Initialized
INFO - 2017-08-16 09:17:25 --> Router Class Initialized
INFO - 2017-08-16 09:17:25 --> Output Class Initialized
INFO - 2017-08-16 09:17:25 --> Security Class Initialized
DEBUG - 2017-08-16 09:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:17:25 --> Input Class Initialized
INFO - 2017-08-16 09:17:25 --> Language Class Initialized
INFO - 2017-08-16 09:17:25 --> Loader Class Initialized
INFO - 2017-08-16 09:17:25 --> Helper loaded: url_helper
INFO - 2017-08-16 09:17:25 --> Helper loaded: file_helper
INFO - 2017-08-16 09:17:25 --> Database Driver Class Initialized
INFO - 2017-08-16 09:17:25 --> Email Class Initialized
DEBUG - 2017-08-16 09:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:17:25 --> Table Class Initialized
INFO - 2017-08-16 09:17:25 --> Controller Class Initialized
INFO - 2017-08-16 09:17:25 --> Helper loaded: form_helper
INFO - 2017-08-16 09:17:25 --> Form Validation Class Initialized
INFO - 2017-08-16 09:17:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:17:25 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_success.php
INFO - 2017-08-16 09:17:25 --> Final output sent to browser
DEBUG - 2017-08-16 09:17:25 --> Total execution time: 0.2136
INFO - 2017-08-16 09:17:28 --> Config Class Initialized
INFO - 2017-08-16 09:17:28 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:17:28 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:17:28 --> Utf8 Class Initialized
INFO - 2017-08-16 09:17:28 --> URI Class Initialized
INFO - 2017-08-16 09:17:28 --> Router Class Initialized
INFO - 2017-08-16 09:17:28 --> Output Class Initialized
INFO - 2017-08-16 09:17:28 --> Security Class Initialized
DEBUG - 2017-08-16 09:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:17:28 --> Input Class Initialized
INFO - 2017-08-16 09:17:28 --> Language Class Initialized
INFO - 2017-08-16 09:17:28 --> Loader Class Initialized
INFO - 2017-08-16 09:17:28 --> Helper loaded: url_helper
INFO - 2017-08-16 09:17:28 --> Helper loaded: file_helper
INFO - 2017-08-16 09:17:28 --> Database Driver Class Initialized
INFO - 2017-08-16 09:17:28 --> Email Class Initialized
DEBUG - 2017-08-16 09:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:17:28 --> Table Class Initialized
INFO - 2017-08-16 09:17:28 --> Controller Class Initialized
INFO - 2017-08-16 09:17:28 --> Helper loaded: form_helper
INFO - 2017-08-16 09:17:28 --> Form Validation Class Initialized
INFO - 2017-08-16 09:17:28 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:17:28 --> Final output sent to browser
DEBUG - 2017-08-16 09:17:28 --> Total execution time: 0.2047
INFO - 2017-08-16 09:17:40 --> Config Class Initialized
INFO - 2017-08-16 09:17:40 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:17:40 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:17:40 --> Utf8 Class Initialized
INFO - 2017-08-16 09:17:40 --> URI Class Initialized
INFO - 2017-08-16 09:17:40 --> Router Class Initialized
INFO - 2017-08-16 09:17:40 --> Output Class Initialized
INFO - 2017-08-16 09:17:40 --> Security Class Initialized
DEBUG - 2017-08-16 09:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:17:40 --> Input Class Initialized
INFO - 2017-08-16 09:17:40 --> Language Class Initialized
INFO - 2017-08-16 09:17:40 --> Loader Class Initialized
INFO - 2017-08-16 09:17:40 --> Helper loaded: url_helper
INFO - 2017-08-16 09:17:40 --> Helper loaded: file_helper
INFO - 2017-08-16 09:17:40 --> Database Driver Class Initialized
INFO - 2017-08-16 09:17:40 --> Email Class Initialized
DEBUG - 2017-08-16 09:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:17:40 --> Table Class Initialized
INFO - 2017-08-16 09:17:40 --> Controller Class Initialized
INFO - 2017-08-16 09:17:40 --> Helper loaded: form_helper
INFO - 2017-08-16 09:17:41 --> Form Validation Class Initialized
INFO - 2017-08-16 09:17:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:17:41 --> Final output sent to browser
DEBUG - 2017-08-16 09:17:41 --> Total execution time: 0.1991
INFO - 2017-08-16 09:17:42 --> Config Class Initialized
INFO - 2017-08-16 09:17:42 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:17:42 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:17:42 --> Utf8 Class Initialized
INFO - 2017-08-16 09:17:42 --> URI Class Initialized
INFO - 2017-08-16 09:17:42 --> Router Class Initialized
INFO - 2017-08-16 09:17:42 --> Output Class Initialized
INFO - 2017-08-16 09:17:42 --> Security Class Initialized
DEBUG - 2017-08-16 09:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:17:42 --> Input Class Initialized
INFO - 2017-08-16 09:17:42 --> Language Class Initialized
INFO - 2017-08-16 09:17:42 --> Loader Class Initialized
INFO - 2017-08-16 09:17:42 --> Helper loaded: url_helper
INFO - 2017-08-16 09:17:42 --> Helper loaded: file_helper
INFO - 2017-08-16 09:17:42 --> Database Driver Class Initialized
INFO - 2017-08-16 09:17:42 --> Email Class Initialized
DEBUG - 2017-08-16 09:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:17:42 --> Table Class Initialized
INFO - 2017-08-16 09:17:42 --> Controller Class Initialized
INFO - 2017-08-16 09:17:42 --> Helper loaded: form_helper
INFO - 2017-08-16 09:17:42 --> Form Validation Class Initialized
INFO - 2017-08-16 09:17:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:17:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:17:42 --> Final output sent to browser
DEBUG - 2017-08-16 09:17:42 --> Total execution time: 0.5114
INFO - 2017-08-16 09:19:16 --> Config Class Initialized
INFO - 2017-08-16 09:19:16 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:19:16 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:19:16 --> Utf8 Class Initialized
INFO - 2017-08-16 09:19:16 --> URI Class Initialized
INFO - 2017-08-16 09:19:16 --> Router Class Initialized
INFO - 2017-08-16 09:19:16 --> Output Class Initialized
INFO - 2017-08-16 09:19:16 --> Security Class Initialized
DEBUG - 2017-08-16 09:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:19:16 --> Input Class Initialized
INFO - 2017-08-16 09:19:16 --> Language Class Initialized
INFO - 2017-08-16 09:19:16 --> Loader Class Initialized
INFO - 2017-08-16 09:19:16 --> Helper loaded: url_helper
INFO - 2017-08-16 09:19:16 --> Helper loaded: file_helper
INFO - 2017-08-16 09:19:16 --> Database Driver Class Initialized
INFO - 2017-08-16 09:19:16 --> Email Class Initialized
DEBUG - 2017-08-16 09:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:19:16 --> Table Class Initialized
INFO - 2017-08-16 09:19:16 --> Controller Class Initialized
INFO - 2017-08-16 09:19:16 --> Helper loaded: form_helper
INFO - 2017-08-16 09:19:16 --> Form Validation Class Initialized
INFO - 2017-08-16 09:19:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:19:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:19:16 --> Final output sent to browser
DEBUG - 2017-08-16 09:19:16 --> Total execution time: 0.2155
INFO - 2017-08-16 09:19:21 --> Config Class Initialized
INFO - 2017-08-16 09:19:21 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:19:21 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:19:21 --> Utf8 Class Initialized
INFO - 2017-08-16 09:19:21 --> URI Class Initialized
INFO - 2017-08-16 09:19:21 --> Router Class Initialized
INFO - 2017-08-16 09:19:21 --> Output Class Initialized
INFO - 2017-08-16 09:19:21 --> Security Class Initialized
DEBUG - 2017-08-16 09:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:19:21 --> Input Class Initialized
INFO - 2017-08-16 09:19:21 --> Language Class Initialized
INFO - 2017-08-16 09:19:21 --> Loader Class Initialized
INFO - 2017-08-16 09:19:21 --> Helper loaded: url_helper
INFO - 2017-08-16 09:19:21 --> Helper loaded: file_helper
INFO - 2017-08-16 09:19:21 --> Database Driver Class Initialized
INFO - 2017-08-16 09:19:21 --> Email Class Initialized
DEBUG - 2017-08-16 09:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:19:21 --> Table Class Initialized
INFO - 2017-08-16 09:19:21 --> Controller Class Initialized
INFO - 2017-08-16 09:19:21 --> Helper loaded: form_helper
INFO - 2017-08-16 09:19:21 --> Form Validation Class Initialized
INFO - 2017-08-16 09:19:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:19:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:19:21 --> Final output sent to browser
DEBUG - 2017-08-16 09:19:21 --> Total execution time: 0.2248
INFO - 2017-08-16 09:19:24 --> Config Class Initialized
INFO - 2017-08-16 09:19:24 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:19:24 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:19:24 --> Utf8 Class Initialized
INFO - 2017-08-16 09:19:24 --> URI Class Initialized
INFO - 2017-08-16 09:19:24 --> Router Class Initialized
INFO - 2017-08-16 09:19:24 --> Output Class Initialized
INFO - 2017-08-16 09:19:24 --> Security Class Initialized
DEBUG - 2017-08-16 09:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:19:24 --> Input Class Initialized
INFO - 2017-08-16 09:19:24 --> Language Class Initialized
INFO - 2017-08-16 09:19:24 --> Loader Class Initialized
INFO - 2017-08-16 09:19:24 --> Helper loaded: url_helper
INFO - 2017-08-16 09:19:24 --> Helper loaded: file_helper
INFO - 2017-08-16 09:19:24 --> Database Driver Class Initialized
INFO - 2017-08-16 09:19:24 --> Email Class Initialized
DEBUG - 2017-08-16 09:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:19:24 --> Table Class Initialized
INFO - 2017-08-16 09:19:24 --> Controller Class Initialized
INFO - 2017-08-16 09:19:24 --> Helper loaded: form_helper
INFO - 2017-08-16 09:19:24 --> Form Validation Class Initialized
INFO - 2017-08-16 09:19:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:19:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:19:24 --> Final output sent to browser
DEBUG - 2017-08-16 09:19:24 --> Total execution time: 0.2164
INFO - 2017-08-16 09:19:26 --> Config Class Initialized
INFO - 2017-08-16 09:19:26 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:19:26 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:19:26 --> Utf8 Class Initialized
INFO - 2017-08-16 09:19:26 --> URI Class Initialized
INFO - 2017-08-16 09:19:26 --> Router Class Initialized
INFO - 2017-08-16 09:19:26 --> Output Class Initialized
INFO - 2017-08-16 09:19:26 --> Security Class Initialized
DEBUG - 2017-08-16 09:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:19:26 --> Input Class Initialized
INFO - 2017-08-16 09:19:26 --> Language Class Initialized
INFO - 2017-08-16 09:19:26 --> Loader Class Initialized
INFO - 2017-08-16 09:19:26 --> Helper loaded: url_helper
INFO - 2017-08-16 09:19:26 --> Helper loaded: file_helper
INFO - 2017-08-16 09:19:26 --> Database Driver Class Initialized
INFO - 2017-08-16 09:19:26 --> Email Class Initialized
DEBUG - 2017-08-16 09:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:19:26 --> Table Class Initialized
INFO - 2017-08-16 09:19:26 --> Controller Class Initialized
INFO - 2017-08-16 09:19:26 --> Helper loaded: form_helper
INFO - 2017-08-16 09:19:26 --> Form Validation Class Initialized
INFO - 2017-08-16 09:19:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:19:26 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:19:26 --> Final output sent to browser
DEBUG - 2017-08-16 09:19:26 --> Total execution time: 0.2164
INFO - 2017-08-16 09:19:52 --> Config Class Initialized
INFO - 2017-08-16 09:19:52 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:19:52 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:19:52 --> Utf8 Class Initialized
INFO - 2017-08-16 09:19:52 --> URI Class Initialized
INFO - 2017-08-16 09:19:52 --> Router Class Initialized
INFO - 2017-08-16 09:19:52 --> Output Class Initialized
INFO - 2017-08-16 09:19:52 --> Security Class Initialized
DEBUG - 2017-08-16 09:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:19:52 --> Input Class Initialized
INFO - 2017-08-16 09:19:52 --> Language Class Initialized
INFO - 2017-08-16 09:19:52 --> Loader Class Initialized
INFO - 2017-08-16 09:19:52 --> Helper loaded: url_helper
INFO - 2017-08-16 09:19:52 --> Helper loaded: file_helper
INFO - 2017-08-16 09:19:52 --> Database Driver Class Initialized
INFO - 2017-08-16 09:19:52 --> Email Class Initialized
DEBUG - 2017-08-16 09:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:19:52 --> Table Class Initialized
INFO - 2017-08-16 09:19:52 --> Controller Class Initialized
INFO - 2017-08-16 09:19:52 --> Helper loaded: form_helper
INFO - 2017-08-16 09:19:52 --> Form Validation Class Initialized
INFO - 2017-08-16 09:19:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:19:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:19:52 --> Final output sent to browser
DEBUG - 2017-08-16 09:19:52 --> Total execution time: 0.2186
INFO - 2017-08-16 09:20:13 --> Config Class Initialized
INFO - 2017-08-16 09:20:13 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:20:13 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:20:13 --> Utf8 Class Initialized
INFO - 2017-08-16 09:20:13 --> URI Class Initialized
INFO - 2017-08-16 09:20:13 --> Router Class Initialized
INFO - 2017-08-16 09:20:13 --> Output Class Initialized
INFO - 2017-08-16 09:20:13 --> Security Class Initialized
DEBUG - 2017-08-16 09:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:20:13 --> Input Class Initialized
INFO - 2017-08-16 09:20:13 --> Language Class Initialized
INFO - 2017-08-16 09:20:13 --> Loader Class Initialized
INFO - 2017-08-16 09:20:13 --> Helper loaded: url_helper
INFO - 2017-08-16 09:20:14 --> Helper loaded: file_helper
INFO - 2017-08-16 09:20:14 --> Database Driver Class Initialized
INFO - 2017-08-16 09:20:14 --> Email Class Initialized
DEBUG - 2017-08-16 09:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:20:14 --> Table Class Initialized
INFO - 2017-08-16 09:20:14 --> Controller Class Initialized
INFO - 2017-08-16 09:20:14 --> Helper loaded: form_helper
INFO - 2017-08-16 09:20:14 --> Form Validation Class Initialized
INFO - 2017-08-16 09:20:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:20:14 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:20:14 --> Final output sent to browser
DEBUG - 2017-08-16 09:20:14 --> Total execution time: 0.5160
INFO - 2017-08-16 09:20:22 --> Config Class Initialized
INFO - 2017-08-16 09:20:22 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:20:22 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:20:22 --> Utf8 Class Initialized
INFO - 2017-08-16 09:20:22 --> URI Class Initialized
INFO - 2017-08-16 09:20:22 --> Router Class Initialized
INFO - 2017-08-16 09:20:22 --> Output Class Initialized
INFO - 2017-08-16 09:20:22 --> Security Class Initialized
DEBUG - 2017-08-16 09:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:20:22 --> Input Class Initialized
INFO - 2017-08-16 09:20:22 --> Language Class Initialized
INFO - 2017-08-16 09:20:22 --> Loader Class Initialized
INFO - 2017-08-16 09:20:22 --> Helper loaded: url_helper
INFO - 2017-08-16 09:20:22 --> Helper loaded: file_helper
INFO - 2017-08-16 09:20:22 --> Database Driver Class Initialized
INFO - 2017-08-16 09:20:22 --> Email Class Initialized
DEBUG - 2017-08-16 09:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:20:22 --> Table Class Initialized
INFO - 2017-08-16 09:20:22 --> Controller Class Initialized
INFO - 2017-08-16 09:20:22 --> Helper loaded: form_helper
INFO - 2017-08-16 09:20:22 --> Form Validation Class Initialized
INFO - 2017-08-16 09:20:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:20:22 --> Final output sent to browser
DEBUG - 2017-08-16 09:20:22 --> Total execution time: 0.2326
INFO - 2017-08-16 09:20:28 --> Config Class Initialized
INFO - 2017-08-16 09:20:28 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:20:28 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:20:28 --> Utf8 Class Initialized
INFO - 2017-08-16 09:20:28 --> URI Class Initialized
INFO - 2017-08-16 09:20:28 --> Router Class Initialized
INFO - 2017-08-16 09:20:28 --> Output Class Initialized
INFO - 2017-08-16 09:20:28 --> Security Class Initialized
DEBUG - 2017-08-16 09:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:20:28 --> Input Class Initialized
INFO - 2017-08-16 09:20:28 --> Language Class Initialized
ERROR - 2017-08-16 09:20:28 --> 404 Page Not Found: Homt/index
INFO - 2017-08-16 09:20:32 --> Config Class Initialized
INFO - 2017-08-16 09:20:32 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:20:32 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:20:32 --> Utf8 Class Initialized
INFO - 2017-08-16 09:20:32 --> URI Class Initialized
INFO - 2017-08-16 09:20:32 --> Router Class Initialized
INFO - 2017-08-16 09:20:32 --> Output Class Initialized
INFO - 2017-08-16 09:20:32 --> Security Class Initialized
DEBUG - 2017-08-16 09:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:20:32 --> Input Class Initialized
INFO - 2017-08-16 09:20:32 --> Language Class Initialized
INFO - 2017-08-16 09:20:32 --> Loader Class Initialized
INFO - 2017-08-16 09:20:32 --> Helper loaded: url_helper
INFO - 2017-08-16 09:20:32 --> Helper loaded: file_helper
INFO - 2017-08-16 09:20:32 --> Database Driver Class Initialized
INFO - 2017-08-16 09:20:32 --> Email Class Initialized
DEBUG - 2017-08-16 09:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:20:32 --> Table Class Initialized
INFO - 2017-08-16 09:20:32 --> Controller Class Initialized
INFO - 2017-08-16 09:20:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 09:20:32 --> Final output sent to browser
DEBUG - 2017-08-16 09:20:32 --> Total execution time: 0.2039
INFO - 2017-08-16 09:20:34 --> Config Class Initialized
INFO - 2017-08-16 09:20:34 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:20:34 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:20:34 --> Utf8 Class Initialized
INFO - 2017-08-16 09:20:34 --> URI Class Initialized
INFO - 2017-08-16 09:20:34 --> Router Class Initialized
INFO - 2017-08-16 09:20:34 --> Output Class Initialized
INFO - 2017-08-16 09:20:34 --> Security Class Initialized
DEBUG - 2017-08-16 09:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:20:34 --> Input Class Initialized
INFO - 2017-08-16 09:20:34 --> Language Class Initialized
INFO - 2017-08-16 09:20:34 --> Loader Class Initialized
INFO - 2017-08-16 09:20:34 --> Helper loaded: url_helper
INFO - 2017-08-16 09:20:34 --> Helper loaded: file_helper
INFO - 2017-08-16 09:20:34 --> Database Driver Class Initialized
INFO - 2017-08-16 09:20:34 --> Email Class Initialized
DEBUG - 2017-08-16 09:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:20:34 --> Table Class Initialized
INFO - 2017-08-16 09:20:34 --> Controller Class Initialized
INFO - 2017-08-16 09:20:34 --> Helper loaded: form_helper
INFO - 2017-08-16 09:20:34 --> Form Validation Class Initialized
INFO - 2017-08-16 09:20:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:20:34 --> Final output sent to browser
DEBUG - 2017-08-16 09:20:34 --> Total execution time: 0.2066
INFO - 2017-08-16 09:20:44 --> Config Class Initialized
INFO - 2017-08-16 09:20:45 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:20:45 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:20:45 --> Utf8 Class Initialized
INFO - 2017-08-16 09:20:45 --> URI Class Initialized
INFO - 2017-08-16 09:20:45 --> Router Class Initialized
INFO - 2017-08-16 09:20:45 --> Output Class Initialized
INFO - 2017-08-16 09:20:45 --> Security Class Initialized
DEBUG - 2017-08-16 09:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:20:45 --> Input Class Initialized
INFO - 2017-08-16 09:20:45 --> Language Class Initialized
INFO - 2017-08-16 09:20:45 --> Loader Class Initialized
INFO - 2017-08-16 09:20:45 --> Helper loaded: url_helper
INFO - 2017-08-16 09:20:45 --> Helper loaded: file_helper
INFO - 2017-08-16 09:20:45 --> Database Driver Class Initialized
INFO - 2017-08-16 09:20:45 --> Email Class Initialized
DEBUG - 2017-08-16 09:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:20:45 --> Table Class Initialized
INFO - 2017-08-16 09:20:45 --> Controller Class Initialized
INFO - 2017-08-16 09:20:45 --> Helper loaded: form_helper
INFO - 2017-08-16 09:20:45 --> Form Validation Class Initialized
INFO - 2017-08-16 09:20:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:20:45 --> Final output sent to browser
DEBUG - 2017-08-16 09:20:45 --> Total execution time: 0.2118
INFO - 2017-08-16 09:20:48 --> Config Class Initialized
INFO - 2017-08-16 09:20:48 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:20:48 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:20:48 --> Utf8 Class Initialized
INFO - 2017-08-16 09:20:48 --> URI Class Initialized
INFO - 2017-08-16 09:20:48 --> Router Class Initialized
INFO - 2017-08-16 09:20:48 --> Output Class Initialized
INFO - 2017-08-16 09:20:48 --> Security Class Initialized
DEBUG - 2017-08-16 09:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:20:48 --> Input Class Initialized
INFO - 2017-08-16 09:20:48 --> Language Class Initialized
INFO - 2017-08-16 09:20:48 --> Loader Class Initialized
INFO - 2017-08-16 09:20:48 --> Helper loaded: url_helper
INFO - 2017-08-16 09:20:48 --> Helper loaded: file_helper
INFO - 2017-08-16 09:20:48 --> Database Driver Class Initialized
INFO - 2017-08-16 09:20:48 --> Email Class Initialized
DEBUG - 2017-08-16 09:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:20:49 --> Table Class Initialized
INFO - 2017-08-16 09:20:49 --> Controller Class Initialized
INFO - 2017-08-16 09:20:49 --> Helper loaded: form_helper
INFO - 2017-08-16 09:20:49 --> Form Validation Class Initialized
INFO - 2017-08-16 09:20:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:20:49 --> Final output sent to browser
DEBUG - 2017-08-16 09:20:49 --> Total execution time: 0.2074
INFO - 2017-08-16 09:20:58 --> Config Class Initialized
INFO - 2017-08-16 09:20:58 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:20:58 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:20:58 --> Utf8 Class Initialized
INFO - 2017-08-16 09:20:58 --> URI Class Initialized
INFO - 2017-08-16 09:20:58 --> Router Class Initialized
INFO - 2017-08-16 09:20:58 --> Output Class Initialized
INFO - 2017-08-16 09:20:58 --> Security Class Initialized
DEBUG - 2017-08-16 09:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:20:58 --> Input Class Initialized
INFO - 2017-08-16 09:20:58 --> Language Class Initialized
INFO - 2017-08-16 09:20:58 --> Loader Class Initialized
INFO - 2017-08-16 09:20:58 --> Helper loaded: url_helper
INFO - 2017-08-16 09:20:58 --> Helper loaded: file_helper
INFO - 2017-08-16 09:20:58 --> Database Driver Class Initialized
INFO - 2017-08-16 09:20:58 --> Email Class Initialized
DEBUG - 2017-08-16 09:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:20:58 --> Table Class Initialized
INFO - 2017-08-16 09:20:58 --> Controller Class Initialized
INFO - 2017-08-16 09:20:58 --> Helper loaded: form_helper
INFO - 2017-08-16 09:20:58 --> Form Validation Class Initialized
INFO - 2017-08-16 09:20:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:20:59 --> Final output sent to browser
DEBUG - 2017-08-16 09:20:59 --> Total execution time: 0.2059
INFO - 2017-08-16 09:21:13 --> Config Class Initialized
INFO - 2017-08-16 09:21:13 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:21:13 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:21:13 --> Utf8 Class Initialized
INFO - 2017-08-16 09:21:13 --> URI Class Initialized
INFO - 2017-08-16 09:21:13 --> Router Class Initialized
INFO - 2017-08-16 09:21:13 --> Output Class Initialized
INFO - 2017-08-16 09:21:13 --> Security Class Initialized
DEBUG - 2017-08-16 09:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:21:13 --> Input Class Initialized
INFO - 2017-08-16 09:21:13 --> Language Class Initialized
INFO - 2017-08-16 09:21:13 --> Loader Class Initialized
INFO - 2017-08-16 09:21:13 --> Helper loaded: url_helper
INFO - 2017-08-16 09:21:13 --> Helper loaded: file_helper
INFO - 2017-08-16 09:21:13 --> Database Driver Class Initialized
INFO - 2017-08-16 09:21:13 --> Email Class Initialized
DEBUG - 2017-08-16 09:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:21:13 --> Table Class Initialized
INFO - 2017-08-16 09:21:13 --> Controller Class Initialized
INFO - 2017-08-16 09:21:13 --> Helper loaded: form_helper
INFO - 2017-08-16 09:21:13 --> Form Validation Class Initialized
INFO - 2017-08-16 09:21:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:21:13 --> Final output sent to browser
DEBUG - 2017-08-16 09:21:13 --> Total execution time: 0.2075
INFO - 2017-08-16 09:21:20 --> Config Class Initialized
INFO - 2017-08-16 09:21:20 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:21:20 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:21:20 --> Utf8 Class Initialized
INFO - 2017-08-16 09:21:20 --> URI Class Initialized
INFO - 2017-08-16 09:21:20 --> Router Class Initialized
INFO - 2017-08-16 09:21:20 --> Output Class Initialized
INFO - 2017-08-16 09:21:20 --> Security Class Initialized
DEBUG - 2017-08-16 09:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:21:20 --> Input Class Initialized
INFO - 2017-08-16 09:21:20 --> Language Class Initialized
INFO - 2017-08-16 09:21:20 --> Loader Class Initialized
INFO - 2017-08-16 09:21:20 --> Helper loaded: url_helper
INFO - 2017-08-16 09:21:20 --> Helper loaded: file_helper
INFO - 2017-08-16 09:21:20 --> Database Driver Class Initialized
INFO - 2017-08-16 09:21:20 --> Email Class Initialized
DEBUG - 2017-08-16 09:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:21:20 --> Table Class Initialized
INFO - 2017-08-16 09:21:20 --> Controller Class Initialized
INFO - 2017-08-16 09:21:20 --> Helper loaded: form_helper
INFO - 2017-08-16 09:21:20 --> Form Validation Class Initialized
INFO - 2017-08-16 09:21:20 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:21:20 --> Final output sent to browser
DEBUG - 2017-08-16 09:21:20 --> Total execution time: 0.2099
INFO - 2017-08-16 09:21:29 --> Config Class Initialized
INFO - 2017-08-16 09:21:29 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:21:29 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:21:29 --> Utf8 Class Initialized
INFO - 2017-08-16 09:21:29 --> URI Class Initialized
INFO - 2017-08-16 09:21:29 --> Router Class Initialized
INFO - 2017-08-16 09:21:29 --> Output Class Initialized
INFO - 2017-08-16 09:21:29 --> Security Class Initialized
DEBUG - 2017-08-16 09:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:21:29 --> Input Class Initialized
INFO - 2017-08-16 09:21:29 --> Language Class Initialized
INFO - 2017-08-16 09:21:29 --> Loader Class Initialized
INFO - 2017-08-16 09:21:29 --> Helper loaded: url_helper
INFO - 2017-08-16 09:21:29 --> Helper loaded: file_helper
INFO - 2017-08-16 09:21:29 --> Database Driver Class Initialized
INFO - 2017-08-16 09:21:29 --> Email Class Initialized
DEBUG - 2017-08-16 09:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:21:29 --> Table Class Initialized
INFO - 2017-08-16 09:21:29 --> Controller Class Initialized
INFO - 2017-08-16 09:21:29 --> Helper loaded: form_helper
INFO - 2017-08-16 09:21:29 --> Form Validation Class Initialized
INFO - 2017-08-16 09:21:29 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:21:29 --> Final output sent to browser
DEBUG - 2017-08-16 09:21:29 --> Total execution time: 0.2092
INFO - 2017-08-16 09:21:58 --> Config Class Initialized
INFO - 2017-08-16 09:21:58 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:21:58 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:21:58 --> Utf8 Class Initialized
INFO - 2017-08-16 09:21:58 --> URI Class Initialized
INFO - 2017-08-16 09:21:58 --> Router Class Initialized
INFO - 2017-08-16 09:21:58 --> Output Class Initialized
INFO - 2017-08-16 09:21:58 --> Security Class Initialized
DEBUG - 2017-08-16 09:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:21:58 --> Input Class Initialized
INFO - 2017-08-16 09:21:58 --> Language Class Initialized
INFO - 2017-08-16 09:21:58 --> Loader Class Initialized
INFO - 2017-08-16 09:21:58 --> Helper loaded: url_helper
INFO - 2017-08-16 09:21:58 --> Helper loaded: file_helper
INFO - 2017-08-16 09:21:58 --> Database Driver Class Initialized
INFO - 2017-08-16 09:21:58 --> Email Class Initialized
DEBUG - 2017-08-16 09:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:21:58 --> Table Class Initialized
INFO - 2017-08-16 09:21:58 --> Controller Class Initialized
INFO - 2017-08-16 09:21:58 --> Helper loaded: form_helper
INFO - 2017-08-16 09:21:58 --> Form Validation Class Initialized
INFO - 2017-08-16 09:21:58 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:21:58 --> Final output sent to browser
DEBUG - 2017-08-16 09:21:58 --> Total execution time: 0.2194
INFO - 2017-08-16 09:22:07 --> Config Class Initialized
INFO - 2017-08-16 09:22:07 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:22:07 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:22:07 --> Utf8 Class Initialized
INFO - 2017-08-16 09:22:07 --> URI Class Initialized
INFO - 2017-08-16 09:22:07 --> Router Class Initialized
INFO - 2017-08-16 09:22:07 --> Output Class Initialized
INFO - 2017-08-16 09:22:07 --> Security Class Initialized
DEBUG - 2017-08-16 09:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:22:07 --> Input Class Initialized
INFO - 2017-08-16 09:22:07 --> Language Class Initialized
INFO - 2017-08-16 09:22:07 --> Loader Class Initialized
INFO - 2017-08-16 09:22:07 --> Helper loaded: url_helper
INFO - 2017-08-16 09:22:07 --> Helper loaded: file_helper
INFO - 2017-08-16 09:22:07 --> Database Driver Class Initialized
INFO - 2017-08-16 09:22:07 --> Email Class Initialized
DEBUG - 2017-08-16 09:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:22:07 --> Table Class Initialized
INFO - 2017-08-16 09:22:07 --> Controller Class Initialized
INFO - 2017-08-16 09:22:07 --> Helper loaded: form_helper
INFO - 2017-08-16 09:22:07 --> Form Validation Class Initialized
INFO - 2017-08-16 09:22:07 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:22:07 --> Final output sent to browser
DEBUG - 2017-08-16 09:22:07 --> Total execution time: 0.2170
INFO - 2017-08-16 09:22:41 --> Config Class Initialized
INFO - 2017-08-16 09:22:41 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:22:41 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:22:41 --> Utf8 Class Initialized
INFO - 2017-08-16 09:22:41 --> URI Class Initialized
INFO - 2017-08-16 09:22:41 --> Router Class Initialized
INFO - 2017-08-16 09:22:41 --> Output Class Initialized
INFO - 2017-08-16 09:22:41 --> Security Class Initialized
DEBUG - 2017-08-16 09:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:22:41 --> Input Class Initialized
INFO - 2017-08-16 09:22:41 --> Language Class Initialized
INFO - 2017-08-16 09:22:41 --> Loader Class Initialized
INFO - 2017-08-16 09:22:41 --> Helper loaded: url_helper
INFO - 2017-08-16 09:22:41 --> Helper loaded: file_helper
INFO - 2017-08-16 09:22:41 --> Database Driver Class Initialized
INFO - 2017-08-16 09:22:41 --> Email Class Initialized
DEBUG - 2017-08-16 09:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:22:41 --> Table Class Initialized
INFO - 2017-08-16 09:22:41 --> Controller Class Initialized
INFO - 2017-08-16 09:22:41 --> Helper loaded: form_helper
INFO - 2017-08-16 09:22:41 --> Form Validation Class Initialized
INFO - 2017-08-16 09:22:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:22:41 --> Final output sent to browser
DEBUG - 2017-08-16 09:22:41 --> Total execution time: 0.2274
INFO - 2017-08-16 09:22:45 --> Config Class Initialized
INFO - 2017-08-16 09:22:45 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:22:45 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:22:45 --> Utf8 Class Initialized
INFO - 2017-08-16 09:22:45 --> URI Class Initialized
INFO - 2017-08-16 09:22:45 --> Router Class Initialized
INFO - 2017-08-16 09:22:45 --> Output Class Initialized
INFO - 2017-08-16 09:22:45 --> Security Class Initialized
DEBUG - 2017-08-16 09:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:22:45 --> Input Class Initialized
INFO - 2017-08-16 09:22:45 --> Language Class Initialized
INFO - 2017-08-16 09:22:45 --> Loader Class Initialized
INFO - 2017-08-16 09:22:45 --> Helper loaded: url_helper
INFO - 2017-08-16 09:22:45 --> Helper loaded: file_helper
INFO - 2017-08-16 09:22:45 --> Database Driver Class Initialized
INFO - 2017-08-16 09:22:45 --> Email Class Initialized
DEBUG - 2017-08-16 09:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:22:46 --> Table Class Initialized
INFO - 2017-08-16 09:22:46 --> Controller Class Initialized
INFO - 2017-08-16 09:22:46 --> Helper loaded: form_helper
INFO - 2017-08-16 09:22:46 --> Form Validation Class Initialized
INFO - 2017-08-16 09:22:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:22:46 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:22:46 --> Final output sent to browser
DEBUG - 2017-08-16 09:22:46 --> Total execution time: 0.2274
INFO - 2017-08-16 09:24:00 --> Config Class Initialized
INFO - 2017-08-16 09:24:00 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:24:00 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:24:00 --> Utf8 Class Initialized
INFO - 2017-08-16 09:24:00 --> URI Class Initialized
INFO - 2017-08-16 09:24:00 --> Router Class Initialized
INFO - 2017-08-16 09:24:00 --> Output Class Initialized
INFO - 2017-08-16 09:24:00 --> Security Class Initialized
DEBUG - 2017-08-16 09:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:24:00 --> Input Class Initialized
INFO - 2017-08-16 09:24:00 --> Language Class Initialized
INFO - 2017-08-16 09:24:00 --> Loader Class Initialized
INFO - 2017-08-16 09:24:00 --> Helper loaded: url_helper
INFO - 2017-08-16 09:24:00 --> Helper loaded: file_helper
INFO - 2017-08-16 09:24:00 --> Database Driver Class Initialized
INFO - 2017-08-16 09:24:00 --> Email Class Initialized
DEBUG - 2017-08-16 09:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:24:00 --> Table Class Initialized
INFO - 2017-08-16 09:24:00 --> Controller Class Initialized
INFO - 2017-08-16 09:24:00 --> Helper loaded: form_helper
INFO - 2017-08-16 09:24:00 --> Form Validation Class Initialized
INFO - 2017-08-16 09:24:00 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:24:00 --> Final output sent to browser
DEBUG - 2017-08-16 09:24:00 --> Total execution time: 0.2187
INFO - 2017-08-16 09:24:03 --> Config Class Initialized
INFO - 2017-08-16 09:24:03 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:24:03 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:24:03 --> Utf8 Class Initialized
INFO - 2017-08-16 09:24:03 --> URI Class Initialized
INFO - 2017-08-16 09:24:03 --> Router Class Initialized
INFO - 2017-08-16 09:24:03 --> Output Class Initialized
INFO - 2017-08-16 09:24:03 --> Security Class Initialized
DEBUG - 2017-08-16 09:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:24:03 --> Input Class Initialized
INFO - 2017-08-16 09:24:03 --> Language Class Initialized
INFO - 2017-08-16 09:24:03 --> Loader Class Initialized
INFO - 2017-08-16 09:24:03 --> Helper loaded: url_helper
INFO - 2017-08-16 09:24:03 --> Helper loaded: file_helper
INFO - 2017-08-16 09:24:03 --> Database Driver Class Initialized
INFO - 2017-08-16 09:24:03 --> Email Class Initialized
DEBUG - 2017-08-16 09:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:24:03 --> Table Class Initialized
INFO - 2017-08-16 09:24:03 --> Controller Class Initialized
INFO - 2017-08-16 09:24:03 --> Helper loaded: form_helper
INFO - 2017-08-16 09:24:03 --> Form Validation Class Initialized
INFO - 2017-08-16 09:24:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:24:03 --> Final output sent to browser
DEBUG - 2017-08-16 09:24:03 --> Total execution time: 0.2102
INFO - 2017-08-16 09:24:05 --> Config Class Initialized
INFO - 2017-08-16 09:24:05 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:24:05 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:24:05 --> Utf8 Class Initialized
INFO - 2017-08-16 09:24:05 --> URI Class Initialized
INFO - 2017-08-16 09:24:05 --> Router Class Initialized
INFO - 2017-08-16 09:24:05 --> Output Class Initialized
INFO - 2017-08-16 09:24:05 --> Security Class Initialized
DEBUG - 2017-08-16 09:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:24:05 --> Input Class Initialized
INFO - 2017-08-16 09:24:05 --> Language Class Initialized
INFO - 2017-08-16 09:24:05 --> Loader Class Initialized
INFO - 2017-08-16 09:24:06 --> Helper loaded: url_helper
INFO - 2017-08-16 09:24:06 --> Helper loaded: file_helper
INFO - 2017-08-16 09:24:06 --> Database Driver Class Initialized
INFO - 2017-08-16 09:24:06 --> Email Class Initialized
DEBUG - 2017-08-16 09:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:24:06 --> Table Class Initialized
INFO - 2017-08-16 09:24:06 --> Controller Class Initialized
INFO - 2017-08-16 09:24:06 --> Helper loaded: form_helper
INFO - 2017-08-16 09:24:06 --> Form Validation Class Initialized
INFO - 2017-08-16 09:24:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:24:06 --> Final output sent to browser
DEBUG - 2017-08-16 09:24:06 --> Total execution time: 0.2209
INFO - 2017-08-16 09:24:08 --> Config Class Initialized
INFO - 2017-08-16 09:24:08 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:24:08 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:24:08 --> Utf8 Class Initialized
INFO - 2017-08-16 09:24:08 --> URI Class Initialized
INFO - 2017-08-16 09:24:08 --> Router Class Initialized
INFO - 2017-08-16 09:24:08 --> Output Class Initialized
INFO - 2017-08-16 09:24:08 --> Security Class Initialized
DEBUG - 2017-08-16 09:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:24:08 --> Input Class Initialized
INFO - 2017-08-16 09:24:08 --> Language Class Initialized
INFO - 2017-08-16 09:24:08 --> Loader Class Initialized
INFO - 2017-08-16 09:24:08 --> Helper loaded: url_helper
INFO - 2017-08-16 09:24:08 --> Helper loaded: file_helper
INFO - 2017-08-16 09:24:08 --> Database Driver Class Initialized
INFO - 2017-08-16 09:24:08 --> Email Class Initialized
DEBUG - 2017-08-16 09:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:24:08 --> Table Class Initialized
INFO - 2017-08-16 09:24:08 --> Controller Class Initialized
INFO - 2017-08-16 09:24:08 --> Helper loaded: form_helper
INFO - 2017-08-16 09:24:08 --> Form Validation Class Initialized
INFO - 2017-08-16 09:24:08 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:24:08 --> Final output sent to browser
DEBUG - 2017-08-16 09:24:08 --> Total execution time: 0.2299
INFO - 2017-08-16 09:24:11 --> Config Class Initialized
INFO - 2017-08-16 09:24:11 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:24:11 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:24:12 --> Utf8 Class Initialized
INFO - 2017-08-16 09:24:12 --> URI Class Initialized
INFO - 2017-08-16 09:24:12 --> Router Class Initialized
INFO - 2017-08-16 09:24:12 --> Output Class Initialized
INFO - 2017-08-16 09:24:12 --> Security Class Initialized
DEBUG - 2017-08-16 09:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:24:12 --> Input Class Initialized
INFO - 2017-08-16 09:24:12 --> Language Class Initialized
INFO - 2017-08-16 09:24:12 --> Loader Class Initialized
INFO - 2017-08-16 09:24:12 --> Helper loaded: url_helper
INFO - 2017-08-16 09:24:12 --> Helper loaded: file_helper
INFO - 2017-08-16 09:24:12 --> Database Driver Class Initialized
INFO - 2017-08-16 09:24:12 --> Email Class Initialized
DEBUG - 2017-08-16 09:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:24:12 --> Table Class Initialized
INFO - 2017-08-16 09:24:12 --> Controller Class Initialized
INFO - 2017-08-16 09:24:12 --> Helper loaded: form_helper
INFO - 2017-08-16 09:24:12 --> Form Validation Class Initialized
INFO - 2017-08-16 09:24:12 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:24:12 --> Final output sent to browser
DEBUG - 2017-08-16 09:24:12 --> Total execution time: 0.2228
INFO - 2017-08-16 09:24:22 --> Config Class Initialized
INFO - 2017-08-16 09:24:22 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:24:22 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:24:22 --> Utf8 Class Initialized
INFO - 2017-08-16 09:24:22 --> URI Class Initialized
INFO - 2017-08-16 09:24:22 --> Router Class Initialized
INFO - 2017-08-16 09:24:22 --> Output Class Initialized
INFO - 2017-08-16 09:24:22 --> Security Class Initialized
DEBUG - 2017-08-16 09:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:24:22 --> Input Class Initialized
INFO - 2017-08-16 09:24:22 --> Language Class Initialized
INFO - 2017-08-16 09:24:22 --> Loader Class Initialized
INFO - 2017-08-16 09:24:22 --> Helper loaded: url_helper
INFO - 2017-08-16 09:24:22 --> Helper loaded: file_helper
INFO - 2017-08-16 09:24:22 --> Database Driver Class Initialized
INFO - 2017-08-16 09:24:22 --> Email Class Initialized
DEBUG - 2017-08-16 09:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:24:22 --> Table Class Initialized
INFO - 2017-08-16 09:24:22 --> Controller Class Initialized
INFO - 2017-08-16 09:24:22 --> Helper loaded: form_helper
INFO - 2017-08-16 09:24:22 --> Form Validation Class Initialized
INFO - 2017-08-16 09:24:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:24:22 --> Final output sent to browser
DEBUG - 2017-08-16 09:24:22 --> Total execution time: 0.2117
INFO - 2017-08-16 09:25:43 --> Config Class Initialized
INFO - 2017-08-16 09:25:43 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:25:43 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:25:43 --> Utf8 Class Initialized
INFO - 2017-08-16 09:25:43 --> URI Class Initialized
INFO - 2017-08-16 09:25:43 --> Router Class Initialized
INFO - 2017-08-16 09:25:43 --> Output Class Initialized
INFO - 2017-08-16 09:25:43 --> Security Class Initialized
DEBUG - 2017-08-16 09:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:25:43 --> Input Class Initialized
INFO - 2017-08-16 09:25:43 --> Language Class Initialized
INFO - 2017-08-16 09:25:43 --> Loader Class Initialized
INFO - 2017-08-16 09:25:43 --> Helper loaded: url_helper
INFO - 2017-08-16 09:25:43 --> Helper loaded: file_helper
INFO - 2017-08-16 09:25:43 --> Database Driver Class Initialized
INFO - 2017-08-16 09:25:43 --> Email Class Initialized
DEBUG - 2017-08-16 09:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:25:43 --> Table Class Initialized
INFO - 2017-08-16 09:25:43 --> Controller Class Initialized
INFO - 2017-08-16 09:25:43 --> Helper loaded: form_helper
INFO - 2017-08-16 09:25:43 --> Form Validation Class Initialized
INFO - 2017-08-16 09:25:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:25:43 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_success.php
INFO - 2017-08-16 09:25:43 --> Final output sent to browser
DEBUG - 2017-08-16 09:25:43 --> Total execution time: 0.2402
INFO - 2017-08-16 09:25:45 --> Config Class Initialized
INFO - 2017-08-16 09:25:45 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:25:45 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:25:45 --> Utf8 Class Initialized
INFO - 2017-08-16 09:25:45 --> URI Class Initialized
INFO - 2017-08-16 09:25:45 --> Router Class Initialized
INFO - 2017-08-16 09:25:45 --> Output Class Initialized
INFO - 2017-08-16 09:25:45 --> Security Class Initialized
DEBUG - 2017-08-16 09:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:25:45 --> Input Class Initialized
INFO - 2017-08-16 09:25:45 --> Language Class Initialized
INFO - 2017-08-16 09:25:45 --> Loader Class Initialized
INFO - 2017-08-16 09:25:45 --> Helper loaded: url_helper
INFO - 2017-08-16 09:25:45 --> Helper loaded: file_helper
INFO - 2017-08-16 09:25:45 --> Database Driver Class Initialized
INFO - 2017-08-16 09:25:45 --> Email Class Initialized
DEBUG - 2017-08-16 09:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:25:45 --> Table Class Initialized
INFO - 2017-08-16 09:25:45 --> Controller Class Initialized
INFO - 2017-08-16 09:25:45 --> Helper loaded: form_helper
INFO - 2017-08-16 09:25:45 --> Form Validation Class Initialized
INFO - 2017-08-16 09:25:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:25:45 --> Final output sent to browser
DEBUG - 2017-08-16 09:25:45 --> Total execution time: 0.2097
INFO - 2017-08-16 09:25:47 --> Config Class Initialized
INFO - 2017-08-16 09:25:47 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:25:47 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:25:47 --> Utf8 Class Initialized
INFO - 2017-08-16 09:25:47 --> URI Class Initialized
INFO - 2017-08-16 09:25:47 --> Router Class Initialized
INFO - 2017-08-16 09:25:47 --> Output Class Initialized
INFO - 2017-08-16 09:25:47 --> Security Class Initialized
DEBUG - 2017-08-16 09:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:25:47 --> Input Class Initialized
INFO - 2017-08-16 09:25:47 --> Language Class Initialized
INFO - 2017-08-16 09:25:47 --> Loader Class Initialized
INFO - 2017-08-16 09:25:47 --> Helper loaded: url_helper
INFO - 2017-08-16 09:25:47 --> Helper loaded: file_helper
INFO - 2017-08-16 09:25:47 --> Database Driver Class Initialized
INFO - 2017-08-16 09:25:47 --> Email Class Initialized
DEBUG - 2017-08-16 09:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:25:47 --> Table Class Initialized
INFO - 2017-08-16 09:25:47 --> Controller Class Initialized
INFO - 2017-08-16 09:25:47 --> Helper loaded: form_helper
INFO - 2017-08-16 09:25:47 --> Form Validation Class Initialized
INFO - 2017-08-16 09:25:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:25:47 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:25:47 --> Final output sent to browser
DEBUG - 2017-08-16 09:25:47 --> Total execution time: 0.2302
INFO - 2017-08-16 09:25:51 --> Config Class Initialized
INFO - 2017-08-16 09:25:51 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:25:51 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:25:51 --> Utf8 Class Initialized
INFO - 2017-08-16 09:25:51 --> URI Class Initialized
INFO - 2017-08-16 09:25:51 --> Router Class Initialized
INFO - 2017-08-16 09:25:51 --> Output Class Initialized
INFO - 2017-08-16 09:25:51 --> Security Class Initialized
DEBUG - 2017-08-16 09:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:25:51 --> Input Class Initialized
INFO - 2017-08-16 09:25:51 --> Language Class Initialized
INFO - 2017-08-16 09:25:51 --> Loader Class Initialized
INFO - 2017-08-16 09:25:51 --> Helper loaded: url_helper
INFO - 2017-08-16 09:25:51 --> Helper loaded: file_helper
INFO - 2017-08-16 09:25:51 --> Database Driver Class Initialized
INFO - 2017-08-16 09:25:51 --> Email Class Initialized
DEBUG - 2017-08-16 09:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:25:51 --> Table Class Initialized
INFO - 2017-08-16 09:25:52 --> Controller Class Initialized
INFO - 2017-08-16 09:25:52 --> Helper loaded: form_helper
INFO - 2017-08-16 09:25:52 --> Form Validation Class Initialized
INFO - 2017-08-16 09:25:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:25:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:25:52 --> Final output sent to browser
DEBUG - 2017-08-16 09:25:52 --> Total execution time: 0.2772
INFO - 2017-08-16 09:25:56 --> Config Class Initialized
INFO - 2017-08-16 09:25:56 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:25:56 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:25:56 --> Utf8 Class Initialized
INFO - 2017-08-16 09:25:56 --> URI Class Initialized
INFO - 2017-08-16 09:25:57 --> Router Class Initialized
INFO - 2017-08-16 09:25:57 --> Output Class Initialized
INFO - 2017-08-16 09:25:57 --> Security Class Initialized
DEBUG - 2017-08-16 09:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:25:57 --> Input Class Initialized
INFO - 2017-08-16 09:25:57 --> Language Class Initialized
INFO - 2017-08-16 09:25:57 --> Loader Class Initialized
INFO - 2017-08-16 09:25:57 --> Helper loaded: url_helper
INFO - 2017-08-16 09:25:57 --> Helper loaded: file_helper
INFO - 2017-08-16 09:25:57 --> Database Driver Class Initialized
INFO - 2017-08-16 09:25:57 --> Email Class Initialized
DEBUG - 2017-08-16 09:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:25:57 --> Table Class Initialized
INFO - 2017-08-16 09:25:57 --> Controller Class Initialized
INFO - 2017-08-16 09:25:57 --> Helper loaded: form_helper
INFO - 2017-08-16 09:25:57 --> Form Validation Class Initialized
INFO - 2017-08-16 09:25:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:25:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_success.php
INFO - 2017-08-16 09:25:57 --> Final output sent to browser
DEBUG - 2017-08-16 09:25:57 --> Total execution time: 0.2479
INFO - 2017-08-16 09:25:59 --> Config Class Initialized
INFO - 2017-08-16 09:25:59 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:25:59 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:25:59 --> Utf8 Class Initialized
INFO - 2017-08-16 09:25:59 --> URI Class Initialized
INFO - 2017-08-16 09:25:59 --> Router Class Initialized
INFO - 2017-08-16 09:25:59 --> Output Class Initialized
INFO - 2017-08-16 09:25:59 --> Security Class Initialized
DEBUG - 2017-08-16 09:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:25:59 --> Input Class Initialized
INFO - 2017-08-16 09:25:59 --> Language Class Initialized
INFO - 2017-08-16 09:25:59 --> Loader Class Initialized
INFO - 2017-08-16 09:25:59 --> Helper loaded: url_helper
INFO - 2017-08-16 09:25:59 --> Helper loaded: file_helper
INFO - 2017-08-16 09:25:59 --> Database Driver Class Initialized
INFO - 2017-08-16 09:25:59 --> Email Class Initialized
DEBUG - 2017-08-16 09:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:25:59 --> Table Class Initialized
INFO - 2017-08-16 09:25:59 --> Controller Class Initialized
INFO - 2017-08-16 09:25:59 --> Helper loaded: form_helper
INFO - 2017-08-16 09:25:59 --> Form Validation Class Initialized
INFO - 2017-08-16 09:25:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:25:59 --> Final output sent to browser
DEBUG - 2017-08-16 09:25:59 --> Total execution time: 0.2242
INFO - 2017-08-16 09:26:02 --> Config Class Initialized
INFO - 2017-08-16 09:26:02 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:26:02 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:26:02 --> Utf8 Class Initialized
INFO - 2017-08-16 09:26:02 --> URI Class Initialized
INFO - 2017-08-16 09:26:02 --> Router Class Initialized
INFO - 2017-08-16 09:26:02 --> Output Class Initialized
INFO - 2017-08-16 09:26:02 --> Security Class Initialized
DEBUG - 2017-08-16 09:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:26:02 --> Input Class Initialized
INFO - 2017-08-16 09:26:03 --> Language Class Initialized
INFO - 2017-08-16 09:26:03 --> Loader Class Initialized
INFO - 2017-08-16 09:26:03 --> Helper loaded: url_helper
INFO - 2017-08-16 09:26:03 --> Helper loaded: file_helper
INFO - 2017-08-16 09:26:03 --> Database Driver Class Initialized
INFO - 2017-08-16 09:26:03 --> Email Class Initialized
DEBUG - 2017-08-16 09:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:26:03 --> Table Class Initialized
INFO - 2017-08-16 09:26:03 --> Controller Class Initialized
INFO - 2017-08-16 09:26:03 --> Helper loaded: form_helper
INFO - 2017-08-16 09:26:03 --> Form Validation Class Initialized
INFO - 2017-08-16 09:26:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:26:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:26:03 --> Final output sent to browser
DEBUG - 2017-08-16 09:26:03 --> Total execution time: 0.2376
INFO - 2017-08-16 09:30:01 --> Config Class Initialized
INFO - 2017-08-16 09:30:01 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:30:01 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:30:01 --> Utf8 Class Initialized
INFO - 2017-08-16 09:30:01 --> URI Class Initialized
INFO - 2017-08-16 09:30:01 --> Router Class Initialized
INFO - 2017-08-16 09:30:01 --> Output Class Initialized
INFO - 2017-08-16 09:30:01 --> Security Class Initialized
DEBUG - 2017-08-16 09:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:30:01 --> Input Class Initialized
INFO - 2017-08-16 09:30:01 --> Language Class Initialized
INFO - 2017-08-16 09:30:01 --> Loader Class Initialized
INFO - 2017-08-16 09:30:01 --> Helper loaded: url_helper
INFO - 2017-08-16 09:30:01 --> Helper loaded: file_helper
INFO - 2017-08-16 09:30:01 --> Database Driver Class Initialized
INFO - 2017-08-16 09:30:01 --> Email Class Initialized
DEBUG - 2017-08-16 09:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:30:01 --> Table Class Initialized
INFO - 2017-08-16 09:30:01 --> Controller Class Initialized
INFO - 2017-08-16 09:30:01 --> Helper loaded: form_helper
INFO - 2017-08-16 09:30:01 --> Form Validation Class Initialized
INFO - 2017-08-16 09:30:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:30:01 --> Final output sent to browser
DEBUG - 2017-08-16 09:30:01 --> Total execution time: 0.2369
INFO - 2017-08-16 09:30:06 --> Config Class Initialized
INFO - 2017-08-16 09:30:06 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:30:06 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:30:06 --> Utf8 Class Initialized
INFO - 2017-08-16 09:30:06 --> URI Class Initialized
INFO - 2017-08-16 09:30:06 --> Router Class Initialized
INFO - 2017-08-16 09:30:06 --> Output Class Initialized
INFO - 2017-08-16 09:30:06 --> Security Class Initialized
DEBUG - 2017-08-16 09:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:30:06 --> Input Class Initialized
INFO - 2017-08-16 09:30:06 --> Language Class Initialized
INFO - 2017-08-16 09:30:06 --> Loader Class Initialized
INFO - 2017-08-16 09:30:06 --> Helper loaded: url_helper
INFO - 2017-08-16 09:30:06 --> Helper loaded: file_helper
INFO - 2017-08-16 09:30:06 --> Database Driver Class Initialized
INFO - 2017-08-16 09:30:06 --> Email Class Initialized
DEBUG - 2017-08-16 09:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:30:06 --> Table Class Initialized
INFO - 2017-08-16 09:30:06 --> Controller Class Initialized
INFO - 2017-08-16 09:30:06 --> Helper loaded: form_helper
INFO - 2017-08-16 09:30:06 --> Form Validation Class Initialized
INFO - 2017-08-16 09:30:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:30:06 --> Final output sent to browser
DEBUG - 2017-08-16 09:30:06 --> Total execution time: 0.2266
INFO - 2017-08-16 09:30:09 --> Config Class Initialized
INFO - 2017-08-16 09:30:09 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:30:09 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:30:09 --> Utf8 Class Initialized
INFO - 2017-08-16 09:30:09 --> URI Class Initialized
INFO - 2017-08-16 09:30:09 --> Router Class Initialized
INFO - 2017-08-16 09:30:09 --> Output Class Initialized
INFO - 2017-08-16 09:30:09 --> Security Class Initialized
DEBUG - 2017-08-16 09:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:30:10 --> Input Class Initialized
INFO - 2017-08-16 09:30:10 --> Language Class Initialized
INFO - 2017-08-16 09:30:10 --> Loader Class Initialized
INFO - 2017-08-16 09:30:10 --> Helper loaded: url_helper
INFO - 2017-08-16 09:30:10 --> Helper loaded: file_helper
INFO - 2017-08-16 09:30:10 --> Database Driver Class Initialized
INFO - 2017-08-16 09:30:10 --> Email Class Initialized
DEBUG - 2017-08-16 09:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:30:10 --> Table Class Initialized
INFO - 2017-08-16 09:30:10 --> Controller Class Initialized
INFO - 2017-08-16 09:30:10 --> Helper loaded: form_helper
INFO - 2017-08-16 09:30:10 --> Form Validation Class Initialized
INFO - 2017-08-16 09:30:10 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:30:10 --> Final output sent to browser
DEBUG - 2017-08-16 09:30:10 --> Total execution time: 0.2281
INFO - 2017-08-16 09:30:36 --> Config Class Initialized
INFO - 2017-08-16 09:30:36 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:30:36 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:30:36 --> Utf8 Class Initialized
INFO - 2017-08-16 09:30:36 --> URI Class Initialized
INFO - 2017-08-16 09:30:36 --> Router Class Initialized
INFO - 2017-08-16 09:30:36 --> Output Class Initialized
INFO - 2017-08-16 09:30:36 --> Security Class Initialized
DEBUG - 2017-08-16 09:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:30:36 --> Input Class Initialized
INFO - 2017-08-16 09:30:36 --> Language Class Initialized
INFO - 2017-08-16 09:30:36 --> Loader Class Initialized
INFO - 2017-08-16 09:30:36 --> Helper loaded: url_helper
INFO - 2017-08-16 09:30:36 --> Helper loaded: file_helper
INFO - 2017-08-16 09:30:36 --> Database Driver Class Initialized
INFO - 2017-08-16 09:30:36 --> Email Class Initialized
DEBUG - 2017-08-16 09:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:30:36 --> Table Class Initialized
INFO - 2017-08-16 09:30:36 --> Controller Class Initialized
INFO - 2017-08-16 09:30:36 --> Helper loaded: form_helper
INFO - 2017-08-16 09:30:36 --> Form Validation Class Initialized
INFO - 2017-08-16 09:30:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:30:36 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:30:36 --> Final output sent to browser
DEBUG - 2017-08-16 09:30:36 --> Total execution time: 0.2416
INFO - 2017-08-16 09:30:39 --> Config Class Initialized
INFO - 2017-08-16 09:30:39 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:30:39 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:30:39 --> Utf8 Class Initialized
INFO - 2017-08-16 09:30:39 --> URI Class Initialized
INFO - 2017-08-16 09:30:39 --> Router Class Initialized
INFO - 2017-08-16 09:30:39 --> Output Class Initialized
INFO - 2017-08-16 09:30:39 --> Security Class Initialized
DEBUG - 2017-08-16 09:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:30:39 --> Input Class Initialized
INFO - 2017-08-16 09:30:39 --> Language Class Initialized
INFO - 2017-08-16 09:30:39 --> Loader Class Initialized
INFO - 2017-08-16 09:30:39 --> Helper loaded: url_helper
INFO - 2017-08-16 09:30:39 --> Helper loaded: file_helper
INFO - 2017-08-16 09:30:39 --> Database Driver Class Initialized
INFO - 2017-08-16 09:30:39 --> Email Class Initialized
DEBUG - 2017-08-16 09:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:30:39 --> Table Class Initialized
INFO - 2017-08-16 09:30:39 --> Controller Class Initialized
INFO - 2017-08-16 09:30:39 --> Helper loaded: form_helper
INFO - 2017-08-16 09:30:39 --> Form Validation Class Initialized
INFO - 2017-08-16 09:30:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:30:39 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:30:39 --> Final output sent to browser
DEBUG - 2017-08-16 09:30:39 --> Total execution time: 0.2442
INFO - 2017-08-16 09:30:51 --> Config Class Initialized
INFO - 2017-08-16 09:30:51 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:30:51 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:30:51 --> Utf8 Class Initialized
INFO - 2017-08-16 09:30:51 --> URI Class Initialized
INFO - 2017-08-16 09:30:51 --> Router Class Initialized
INFO - 2017-08-16 09:30:51 --> Output Class Initialized
INFO - 2017-08-16 09:30:51 --> Security Class Initialized
DEBUG - 2017-08-16 09:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:30:51 --> Input Class Initialized
INFO - 2017-08-16 09:30:51 --> Language Class Initialized
INFO - 2017-08-16 09:30:51 --> Loader Class Initialized
INFO - 2017-08-16 09:30:51 --> Helper loaded: url_helper
INFO - 2017-08-16 09:30:51 --> Helper loaded: file_helper
INFO - 2017-08-16 09:30:51 --> Database Driver Class Initialized
INFO - 2017-08-16 09:30:51 --> Email Class Initialized
DEBUG - 2017-08-16 09:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:30:51 --> Table Class Initialized
INFO - 2017-08-16 09:30:51 --> Controller Class Initialized
INFO - 2017-08-16 09:30:51 --> Helper loaded: form_helper
INFO - 2017-08-16 09:30:51 --> Form Validation Class Initialized
INFO - 2017-08-16 09:30:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:30:51 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:30:51 --> Final output sent to browser
DEBUG - 2017-08-16 09:30:51 --> Total execution time: 0.2448
INFO - 2017-08-16 09:30:54 --> Config Class Initialized
INFO - 2017-08-16 09:30:54 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:30:54 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:30:54 --> Utf8 Class Initialized
INFO - 2017-08-16 09:30:54 --> URI Class Initialized
INFO - 2017-08-16 09:30:54 --> Router Class Initialized
INFO - 2017-08-16 09:30:54 --> Output Class Initialized
INFO - 2017-08-16 09:30:54 --> Security Class Initialized
DEBUG - 2017-08-16 09:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:30:54 --> Input Class Initialized
INFO - 2017-08-16 09:30:54 --> Language Class Initialized
INFO - 2017-08-16 09:30:54 --> Loader Class Initialized
INFO - 2017-08-16 09:30:54 --> Helper loaded: url_helper
INFO - 2017-08-16 09:30:54 --> Helper loaded: file_helper
INFO - 2017-08-16 09:30:54 --> Database Driver Class Initialized
INFO - 2017-08-16 09:30:54 --> Email Class Initialized
DEBUG - 2017-08-16 09:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:30:54 --> Table Class Initialized
INFO - 2017-08-16 09:30:54 --> Controller Class Initialized
INFO - 2017-08-16 09:30:54 --> Helper loaded: form_helper
INFO - 2017-08-16 09:30:54 --> Form Validation Class Initialized
INFO - 2017-08-16 09:30:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:30:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:30:54 --> Final output sent to browser
DEBUG - 2017-08-16 09:30:54 --> Total execution time: 0.2516
INFO - 2017-08-16 09:38:21 --> Config Class Initialized
INFO - 2017-08-16 09:38:21 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:38:21 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:38:21 --> Utf8 Class Initialized
INFO - 2017-08-16 09:38:21 --> URI Class Initialized
INFO - 2017-08-16 09:38:21 --> Router Class Initialized
INFO - 2017-08-16 09:38:21 --> Output Class Initialized
INFO - 2017-08-16 09:38:21 --> Security Class Initialized
DEBUG - 2017-08-16 09:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:38:21 --> Input Class Initialized
INFO - 2017-08-16 09:38:21 --> Language Class Initialized
INFO - 2017-08-16 09:38:21 --> Loader Class Initialized
INFO - 2017-08-16 09:38:21 --> Helper loaded: url_helper
INFO - 2017-08-16 09:38:21 --> Helper loaded: file_helper
INFO - 2017-08-16 09:38:21 --> Database Driver Class Initialized
INFO - 2017-08-16 09:38:21 --> Email Class Initialized
DEBUG - 2017-08-16 09:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:38:21 --> Table Class Initialized
INFO - 2017-08-16 09:38:21 --> Controller Class Initialized
INFO - 2017-08-16 09:38:21 --> Helper loaded: form_helper
INFO - 2017-08-16 09:38:21 --> Form Validation Class Initialized
INFO - 2017-08-16 09:38:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:38:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:38:21 --> Final output sent to browser
DEBUG - 2017-08-16 09:38:21 --> Total execution time: 0.2714
INFO - 2017-08-16 09:38:23 --> Config Class Initialized
INFO - 2017-08-16 09:38:23 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:38:23 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:38:23 --> Utf8 Class Initialized
INFO - 2017-08-16 09:38:23 --> URI Class Initialized
INFO - 2017-08-16 09:38:23 --> Router Class Initialized
INFO - 2017-08-16 09:38:23 --> Output Class Initialized
INFO - 2017-08-16 09:38:23 --> Security Class Initialized
DEBUG - 2017-08-16 09:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:38:23 --> Input Class Initialized
INFO - 2017-08-16 09:38:23 --> Language Class Initialized
INFO - 2017-08-16 09:38:23 --> Loader Class Initialized
INFO - 2017-08-16 09:38:23 --> Helper loaded: url_helper
INFO - 2017-08-16 09:38:23 --> Helper loaded: file_helper
INFO - 2017-08-16 09:38:23 --> Database Driver Class Initialized
INFO - 2017-08-16 09:38:23 --> Email Class Initialized
DEBUG - 2017-08-16 09:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:38:23 --> Table Class Initialized
INFO - 2017-08-16 09:38:23 --> Controller Class Initialized
INFO - 2017-08-16 09:38:23 --> Helper loaded: form_helper
INFO - 2017-08-16 09:38:23 --> Form Validation Class Initialized
INFO - 2017-08-16 09:38:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:38:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:38:23 --> Final output sent to browser
DEBUG - 2017-08-16 09:38:23 --> Total execution time: 0.2392
INFO - 2017-08-16 09:38:27 --> Config Class Initialized
INFO - 2017-08-16 09:38:27 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:38:27 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:38:27 --> Utf8 Class Initialized
INFO - 2017-08-16 09:38:27 --> URI Class Initialized
INFO - 2017-08-16 09:38:27 --> Router Class Initialized
INFO - 2017-08-16 09:38:27 --> Output Class Initialized
INFO - 2017-08-16 09:38:27 --> Security Class Initialized
DEBUG - 2017-08-16 09:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:38:27 --> Input Class Initialized
INFO - 2017-08-16 09:38:27 --> Language Class Initialized
INFO - 2017-08-16 09:38:27 --> Loader Class Initialized
INFO - 2017-08-16 09:38:27 --> Helper loaded: url_helper
INFO - 2017-08-16 09:38:27 --> Helper loaded: file_helper
INFO - 2017-08-16 09:38:27 --> Database Driver Class Initialized
INFO - 2017-08-16 09:38:27 --> Email Class Initialized
DEBUG - 2017-08-16 09:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:38:27 --> Table Class Initialized
INFO - 2017-08-16 09:38:27 --> Controller Class Initialized
INFO - 2017-08-16 09:38:27 --> Helper loaded: form_helper
INFO - 2017-08-16 09:38:27 --> Form Validation Class Initialized
INFO - 2017-08-16 09:38:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:38:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:38:27 --> Final output sent to browser
DEBUG - 2017-08-16 09:38:27 --> Total execution time: 0.2300
INFO - 2017-08-16 09:38:29 --> Config Class Initialized
INFO - 2017-08-16 09:38:29 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:38:29 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:38:29 --> Utf8 Class Initialized
INFO - 2017-08-16 09:38:29 --> URI Class Initialized
INFO - 2017-08-16 09:38:29 --> Router Class Initialized
INFO - 2017-08-16 09:38:29 --> Output Class Initialized
INFO - 2017-08-16 09:38:29 --> Security Class Initialized
DEBUG - 2017-08-16 09:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:38:29 --> Input Class Initialized
INFO - 2017-08-16 09:38:29 --> Language Class Initialized
INFO - 2017-08-16 09:38:29 --> Loader Class Initialized
INFO - 2017-08-16 09:38:29 --> Helper loaded: url_helper
INFO - 2017-08-16 09:38:29 --> Helper loaded: file_helper
INFO - 2017-08-16 09:38:29 --> Database Driver Class Initialized
INFO - 2017-08-16 09:38:29 --> Email Class Initialized
DEBUG - 2017-08-16 09:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:38:29 --> Table Class Initialized
INFO - 2017-08-16 09:38:29 --> Controller Class Initialized
INFO - 2017-08-16 09:38:29 --> Helper loaded: form_helper
INFO - 2017-08-16 09:38:29 --> Form Validation Class Initialized
INFO - 2017-08-16 09:38:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:38:29 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:38:29 --> Final output sent to browser
DEBUG - 2017-08-16 09:38:29 --> Total execution time: 0.2406
INFO - 2017-08-16 09:39:24 --> Config Class Initialized
INFO - 2017-08-16 09:39:24 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:39:24 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:39:24 --> Utf8 Class Initialized
INFO - 2017-08-16 09:39:24 --> URI Class Initialized
INFO - 2017-08-16 09:39:24 --> Router Class Initialized
INFO - 2017-08-16 09:39:24 --> Output Class Initialized
INFO - 2017-08-16 09:39:24 --> Security Class Initialized
DEBUG - 2017-08-16 09:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:39:24 --> Input Class Initialized
INFO - 2017-08-16 09:39:24 --> Language Class Initialized
INFO - 2017-08-16 09:39:24 --> Loader Class Initialized
INFO - 2017-08-16 09:39:24 --> Helper loaded: url_helper
INFO - 2017-08-16 09:39:24 --> Helper loaded: file_helper
INFO - 2017-08-16 09:39:24 --> Database Driver Class Initialized
INFO - 2017-08-16 09:39:24 --> Email Class Initialized
DEBUG - 2017-08-16 09:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:39:24 --> Table Class Initialized
INFO - 2017-08-16 09:39:24 --> Controller Class Initialized
INFO - 2017-08-16 09:39:24 --> Helper loaded: form_helper
INFO - 2017-08-16 09:39:24 --> Form Validation Class Initialized
INFO - 2017-08-16 09:39:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:39:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:39:24 --> Final output sent to browser
DEBUG - 2017-08-16 09:39:24 --> Total execution time: 0.2495
INFO - 2017-08-16 09:39:28 --> Config Class Initialized
INFO - 2017-08-16 09:39:28 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:39:28 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:39:28 --> Utf8 Class Initialized
INFO - 2017-08-16 09:39:28 --> URI Class Initialized
INFO - 2017-08-16 09:39:28 --> Router Class Initialized
INFO - 2017-08-16 09:39:28 --> Output Class Initialized
INFO - 2017-08-16 09:39:28 --> Security Class Initialized
DEBUG - 2017-08-16 09:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:39:28 --> Input Class Initialized
INFO - 2017-08-16 09:39:28 --> Language Class Initialized
INFO - 2017-08-16 09:39:28 --> Loader Class Initialized
INFO - 2017-08-16 09:39:28 --> Helper loaded: url_helper
INFO - 2017-08-16 09:39:28 --> Helper loaded: file_helper
INFO - 2017-08-16 09:39:28 --> Database Driver Class Initialized
INFO - 2017-08-16 09:39:28 --> Email Class Initialized
DEBUG - 2017-08-16 09:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:39:28 --> Table Class Initialized
INFO - 2017-08-16 09:39:28 --> Controller Class Initialized
INFO - 2017-08-16 09:39:28 --> Helper loaded: form_helper
INFO - 2017-08-16 09:39:28 --> Form Validation Class Initialized
INFO - 2017-08-16 09:39:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-08-16 09:39:28 --> Query error: Table 'biokimia.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `email` = '123'
 LIMIT 1
INFO - 2017-08-16 09:39:28 --> Language file loaded: language/english/db_lang.php
INFO - 2017-08-16 09:39:45 --> Config Class Initialized
INFO - 2017-08-16 09:39:45 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:39:45 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:39:45 --> Utf8 Class Initialized
INFO - 2017-08-16 09:39:45 --> URI Class Initialized
INFO - 2017-08-16 09:39:45 --> Router Class Initialized
INFO - 2017-08-16 09:39:45 --> Output Class Initialized
INFO - 2017-08-16 09:39:45 --> Security Class Initialized
DEBUG - 2017-08-16 09:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:39:45 --> Input Class Initialized
INFO - 2017-08-16 09:39:45 --> Language Class Initialized
INFO - 2017-08-16 09:39:45 --> Loader Class Initialized
INFO - 2017-08-16 09:39:45 --> Helper loaded: url_helper
INFO - 2017-08-16 09:39:45 --> Helper loaded: file_helper
INFO - 2017-08-16 09:39:45 --> Database Driver Class Initialized
INFO - 2017-08-16 09:39:45 --> Email Class Initialized
DEBUG - 2017-08-16 09:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:39:45 --> Table Class Initialized
INFO - 2017-08-16 09:39:45 --> Controller Class Initialized
INFO - 2017-08-16 09:39:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 09:39:45 --> Final output sent to browser
DEBUG - 2017-08-16 09:39:45 --> Total execution time: 0.2113
INFO - 2017-08-16 09:39:48 --> Config Class Initialized
INFO - 2017-08-16 09:39:48 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:39:48 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:39:48 --> Utf8 Class Initialized
INFO - 2017-08-16 09:39:48 --> URI Class Initialized
INFO - 2017-08-16 09:39:48 --> Router Class Initialized
INFO - 2017-08-16 09:39:48 --> Output Class Initialized
INFO - 2017-08-16 09:39:48 --> Security Class Initialized
DEBUG - 2017-08-16 09:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:39:48 --> Input Class Initialized
INFO - 2017-08-16 09:39:48 --> Language Class Initialized
INFO - 2017-08-16 09:39:48 --> Loader Class Initialized
INFO - 2017-08-16 09:39:48 --> Helper loaded: url_helper
INFO - 2017-08-16 09:39:48 --> Helper loaded: file_helper
INFO - 2017-08-16 09:39:48 --> Database Driver Class Initialized
INFO - 2017-08-16 09:39:48 --> Email Class Initialized
DEBUG - 2017-08-16 09:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:39:48 --> Table Class Initialized
INFO - 2017-08-16 09:39:48 --> Controller Class Initialized
INFO - 2017-08-16 09:39:48 --> Helper loaded: form_helper
INFO - 2017-08-16 09:39:48 --> Form Validation Class Initialized
INFO - 2017-08-16 09:39:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:39:48 --> Final output sent to browser
DEBUG - 2017-08-16 09:39:48 --> Total execution time: 0.2226
INFO - 2017-08-16 09:39:53 --> Config Class Initialized
INFO - 2017-08-16 09:39:53 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:39:53 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:39:53 --> Utf8 Class Initialized
INFO - 2017-08-16 09:39:53 --> URI Class Initialized
INFO - 2017-08-16 09:39:53 --> Router Class Initialized
INFO - 2017-08-16 09:39:53 --> Output Class Initialized
INFO - 2017-08-16 09:39:53 --> Security Class Initialized
DEBUG - 2017-08-16 09:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:39:53 --> Input Class Initialized
INFO - 2017-08-16 09:39:53 --> Language Class Initialized
INFO - 2017-08-16 09:39:53 --> Loader Class Initialized
INFO - 2017-08-16 09:39:53 --> Helper loaded: url_helper
INFO - 2017-08-16 09:39:53 --> Helper loaded: file_helper
INFO - 2017-08-16 09:39:53 --> Database Driver Class Initialized
INFO - 2017-08-16 09:39:53 --> Email Class Initialized
DEBUG - 2017-08-16 09:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:39:53 --> Table Class Initialized
INFO - 2017-08-16 09:39:53 --> Controller Class Initialized
INFO - 2017-08-16 09:39:53 --> Helper loaded: form_helper
INFO - 2017-08-16 09:39:53 --> Form Validation Class Initialized
INFO - 2017-08-16 09:39:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-08-16 09:39:53 --> Query error: Table 'biokimia.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `email` = 'asdf'
 LIMIT 1
INFO - 2017-08-16 09:39:53 --> Language file loaded: language/english/db_lang.php
INFO - 2017-08-16 09:40:00 --> Config Class Initialized
INFO - 2017-08-16 09:40:00 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:40:00 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:40:00 --> Utf8 Class Initialized
INFO - 2017-08-16 09:40:00 --> URI Class Initialized
INFO - 2017-08-16 09:40:00 --> Router Class Initialized
INFO - 2017-08-16 09:40:00 --> Output Class Initialized
INFO - 2017-08-16 09:40:00 --> Security Class Initialized
DEBUG - 2017-08-16 09:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:40:00 --> Input Class Initialized
INFO - 2017-08-16 09:40:00 --> Language Class Initialized
INFO - 2017-08-16 09:40:00 --> Loader Class Initialized
INFO - 2017-08-16 09:40:00 --> Helper loaded: url_helper
INFO - 2017-08-16 09:40:00 --> Helper loaded: file_helper
INFO - 2017-08-16 09:40:00 --> Database Driver Class Initialized
INFO - 2017-08-16 09:40:00 --> Email Class Initialized
DEBUG - 2017-08-16 09:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:40:00 --> Table Class Initialized
INFO - 2017-08-16 09:40:00 --> Controller Class Initialized
INFO - 2017-08-16 09:40:00 --> Helper loaded: form_helper
INFO - 2017-08-16 09:40:00 --> Form Validation Class Initialized
INFO - 2017-08-16 09:40:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:40:01 --> Final output sent to browser
DEBUG - 2017-08-16 09:40:01 --> Total execution time: 0.2334
INFO - 2017-08-16 09:40:03 --> Config Class Initialized
INFO - 2017-08-16 09:40:03 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:40:03 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:40:03 --> Utf8 Class Initialized
INFO - 2017-08-16 09:40:03 --> URI Class Initialized
INFO - 2017-08-16 09:40:03 --> Router Class Initialized
INFO - 2017-08-16 09:40:03 --> Output Class Initialized
INFO - 2017-08-16 09:40:03 --> Security Class Initialized
DEBUG - 2017-08-16 09:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:40:03 --> Input Class Initialized
INFO - 2017-08-16 09:40:03 --> Language Class Initialized
INFO - 2017-08-16 09:40:03 --> Loader Class Initialized
INFO - 2017-08-16 09:40:03 --> Helper loaded: url_helper
INFO - 2017-08-16 09:40:03 --> Helper loaded: file_helper
INFO - 2017-08-16 09:40:03 --> Database Driver Class Initialized
INFO - 2017-08-16 09:40:03 --> Email Class Initialized
DEBUG - 2017-08-16 09:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:40:03 --> Table Class Initialized
INFO - 2017-08-16 09:40:03 --> Controller Class Initialized
INFO - 2017-08-16 09:40:03 --> Helper loaded: form_helper
INFO - 2017-08-16 09:40:03 --> Form Validation Class Initialized
INFO - 2017-08-16 09:40:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:40:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:40:03 --> Final output sent to browser
DEBUG - 2017-08-16 09:40:03 --> Total execution time: 0.2456
INFO - 2017-08-16 09:40:09 --> Config Class Initialized
INFO - 2017-08-16 09:40:09 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:40:09 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:40:09 --> Utf8 Class Initialized
INFO - 2017-08-16 09:40:09 --> URI Class Initialized
INFO - 2017-08-16 09:40:09 --> Router Class Initialized
INFO - 2017-08-16 09:40:09 --> Output Class Initialized
INFO - 2017-08-16 09:40:09 --> Security Class Initialized
DEBUG - 2017-08-16 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:40:09 --> Input Class Initialized
INFO - 2017-08-16 09:40:09 --> Language Class Initialized
INFO - 2017-08-16 09:40:09 --> Loader Class Initialized
INFO - 2017-08-16 09:40:09 --> Helper loaded: url_helper
INFO - 2017-08-16 09:40:09 --> Helper loaded: file_helper
INFO - 2017-08-16 09:40:09 --> Database Driver Class Initialized
INFO - 2017-08-16 09:40:09 --> Email Class Initialized
DEBUG - 2017-08-16 09:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:40:09 --> Table Class Initialized
INFO - 2017-08-16 09:40:09 --> Controller Class Initialized
INFO - 2017-08-16 09:40:09 --> Helper loaded: form_helper
INFO - 2017-08-16 09:40:09 --> Form Validation Class Initialized
INFO - 2017-08-16 09:40:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-08-16 09:40:09 --> Query error: Table 'biokimia.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `email` = 's'
 LIMIT 1
INFO - 2017-08-16 09:40:09 --> Language file loaded: language/english/db_lang.php
INFO - 2017-08-16 09:41:13 --> Config Class Initialized
INFO - 2017-08-16 09:41:13 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:41:13 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:41:13 --> Utf8 Class Initialized
INFO - 2017-08-16 09:41:13 --> URI Class Initialized
INFO - 2017-08-16 09:41:13 --> Router Class Initialized
INFO - 2017-08-16 09:41:13 --> Output Class Initialized
INFO - 2017-08-16 09:41:13 --> Security Class Initialized
DEBUG - 2017-08-16 09:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:41:13 --> Input Class Initialized
INFO - 2017-08-16 09:41:13 --> Language Class Initialized
INFO - 2017-08-16 09:41:13 --> Loader Class Initialized
INFO - 2017-08-16 09:41:13 --> Helper loaded: url_helper
INFO - 2017-08-16 09:41:13 --> Helper loaded: file_helper
INFO - 2017-08-16 09:41:13 --> Database Driver Class Initialized
INFO - 2017-08-16 09:41:13 --> Email Class Initialized
DEBUG - 2017-08-16 09:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:41:13 --> Table Class Initialized
INFO - 2017-08-16 09:41:13 --> Controller Class Initialized
INFO - 2017-08-16 09:41:13 --> Helper loaded: form_helper
INFO - 2017-08-16 09:41:13 --> Form Validation Class Initialized
INFO - 2017-08-16 09:41:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:41:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:41:13 --> Final output sent to browser
DEBUG - 2017-08-16 09:41:13 --> Total execution time: 0.2555
INFO - 2017-08-16 09:41:34 --> Config Class Initialized
INFO - 2017-08-16 09:41:34 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:41:34 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:41:34 --> Utf8 Class Initialized
INFO - 2017-08-16 09:41:34 --> URI Class Initialized
INFO - 2017-08-16 09:41:34 --> Router Class Initialized
INFO - 2017-08-16 09:41:34 --> Output Class Initialized
INFO - 2017-08-16 09:41:34 --> Security Class Initialized
DEBUG - 2017-08-16 09:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:41:34 --> Input Class Initialized
INFO - 2017-08-16 09:41:34 --> Language Class Initialized
INFO - 2017-08-16 09:41:34 --> Loader Class Initialized
INFO - 2017-08-16 09:41:34 --> Helper loaded: url_helper
INFO - 2017-08-16 09:41:34 --> Helper loaded: file_helper
INFO - 2017-08-16 09:41:34 --> Database Driver Class Initialized
INFO - 2017-08-16 09:41:34 --> Email Class Initialized
DEBUG - 2017-08-16 09:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:41:34 --> Table Class Initialized
INFO - 2017-08-16 09:41:34 --> Controller Class Initialized
INFO - 2017-08-16 09:41:34 --> Helper loaded: form_helper
INFO - 2017-08-16 09:41:34 --> Form Validation Class Initialized
INFO - 2017-08-16 09:41:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:41:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:41:34 --> Final output sent to browser
DEBUG - 2017-08-16 09:41:34 --> Total execution time: 0.2503
INFO - 2017-08-16 09:41:47 --> Config Class Initialized
INFO - 2017-08-16 09:41:47 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:41:47 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:41:47 --> Utf8 Class Initialized
INFO - 2017-08-16 09:41:47 --> URI Class Initialized
INFO - 2017-08-16 09:41:47 --> Router Class Initialized
INFO - 2017-08-16 09:41:47 --> Output Class Initialized
INFO - 2017-08-16 09:41:47 --> Security Class Initialized
DEBUG - 2017-08-16 09:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:41:47 --> Input Class Initialized
INFO - 2017-08-16 09:41:47 --> Language Class Initialized
INFO - 2017-08-16 09:41:47 --> Loader Class Initialized
INFO - 2017-08-16 09:41:47 --> Helper loaded: url_helper
INFO - 2017-08-16 09:41:47 --> Helper loaded: file_helper
INFO - 2017-08-16 09:41:47 --> Database Driver Class Initialized
INFO - 2017-08-16 09:41:47 --> Email Class Initialized
DEBUG - 2017-08-16 09:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:41:47 --> Table Class Initialized
INFO - 2017-08-16 09:41:47 --> Controller Class Initialized
INFO - 2017-08-16 09:41:47 --> Helper loaded: form_helper
INFO - 2017-08-16 09:41:47 --> Form Validation Class Initialized
INFO - 2017-08-16 09:41:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:41:47 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:41:47 --> Final output sent to browser
DEBUG - 2017-08-16 09:41:47 --> Total execution time: 0.2382
INFO - 2017-08-16 09:41:57 --> Config Class Initialized
INFO - 2017-08-16 09:41:57 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:41:57 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:41:57 --> Utf8 Class Initialized
INFO - 2017-08-16 09:41:57 --> URI Class Initialized
INFO - 2017-08-16 09:41:57 --> Router Class Initialized
INFO - 2017-08-16 09:41:57 --> Output Class Initialized
INFO - 2017-08-16 09:41:57 --> Security Class Initialized
DEBUG - 2017-08-16 09:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:41:57 --> Input Class Initialized
INFO - 2017-08-16 09:41:57 --> Language Class Initialized
INFO - 2017-08-16 09:41:57 --> Loader Class Initialized
INFO - 2017-08-16 09:41:57 --> Helper loaded: url_helper
INFO - 2017-08-16 09:41:57 --> Helper loaded: file_helper
INFO - 2017-08-16 09:41:57 --> Database Driver Class Initialized
INFO - 2017-08-16 09:41:57 --> Email Class Initialized
DEBUG - 2017-08-16 09:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:41:57 --> Table Class Initialized
INFO - 2017-08-16 09:41:57 --> Controller Class Initialized
INFO - 2017-08-16 09:41:57 --> Helper loaded: form_helper
INFO - 2017-08-16 09:41:57 --> Form Validation Class Initialized
INFO - 2017-08-16 09:41:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:41:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_success.php
INFO - 2017-08-16 09:41:57 --> Final output sent to browser
DEBUG - 2017-08-16 09:41:57 --> Total execution time: 0.2738
INFO - 2017-08-16 09:41:59 --> Config Class Initialized
INFO - 2017-08-16 09:41:59 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:41:59 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:41:59 --> Utf8 Class Initialized
INFO - 2017-08-16 09:41:59 --> URI Class Initialized
INFO - 2017-08-16 09:41:59 --> Router Class Initialized
INFO - 2017-08-16 09:41:59 --> Output Class Initialized
INFO - 2017-08-16 09:41:59 --> Security Class Initialized
DEBUG - 2017-08-16 09:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:41:59 --> Input Class Initialized
INFO - 2017-08-16 09:41:59 --> Language Class Initialized
INFO - 2017-08-16 09:41:59 --> Loader Class Initialized
INFO - 2017-08-16 09:41:59 --> Helper loaded: url_helper
INFO - 2017-08-16 09:41:59 --> Helper loaded: file_helper
INFO - 2017-08-16 09:41:59 --> Database Driver Class Initialized
INFO - 2017-08-16 09:41:59 --> Email Class Initialized
DEBUG - 2017-08-16 09:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:41:59 --> Table Class Initialized
INFO - 2017-08-16 09:41:59 --> Controller Class Initialized
INFO - 2017-08-16 09:41:59 --> Helper loaded: form_helper
INFO - 2017-08-16 09:41:59 --> Form Validation Class Initialized
INFO - 2017-08-16 09:41:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:41:59 --> Final output sent to browser
DEBUG - 2017-08-16 09:41:59 --> Total execution time: 0.2380
INFO - 2017-08-16 09:42:09 --> Config Class Initialized
INFO - 2017-08-16 09:42:09 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:42:09 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:42:09 --> Utf8 Class Initialized
INFO - 2017-08-16 09:42:09 --> URI Class Initialized
INFO - 2017-08-16 09:42:09 --> Router Class Initialized
INFO - 2017-08-16 09:42:09 --> Output Class Initialized
INFO - 2017-08-16 09:42:09 --> Security Class Initialized
DEBUG - 2017-08-16 09:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:42:09 --> Input Class Initialized
INFO - 2017-08-16 09:42:09 --> Language Class Initialized
INFO - 2017-08-16 09:42:09 --> Loader Class Initialized
INFO - 2017-08-16 09:42:09 --> Helper loaded: url_helper
INFO - 2017-08-16 09:42:09 --> Helper loaded: file_helper
INFO - 2017-08-16 09:42:09 --> Database Driver Class Initialized
INFO - 2017-08-16 09:42:09 --> Email Class Initialized
DEBUG - 2017-08-16 09:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:42:09 --> Table Class Initialized
INFO - 2017-08-16 09:42:09 --> Controller Class Initialized
INFO - 2017-08-16 09:42:09 --> Helper loaded: form_helper
INFO - 2017-08-16 09:42:09 --> Form Validation Class Initialized
INFO - 2017-08-16 09:42:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 09:42:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\validation_form.php
INFO - 2017-08-16 09:42:09 --> Final output sent to browser
DEBUG - 2017-08-16 09:42:09 --> Total execution time: 0.2410
INFO - 2017-08-16 09:42:23 --> Config Class Initialized
INFO - 2017-08-16 09:42:23 --> Hooks Class Initialized
DEBUG - 2017-08-16 09:42:23 --> UTF-8 Support Enabled
INFO - 2017-08-16 09:42:23 --> Utf8 Class Initialized
INFO - 2017-08-16 09:42:23 --> URI Class Initialized
INFO - 2017-08-16 09:42:23 --> Router Class Initialized
INFO - 2017-08-16 09:42:23 --> Output Class Initialized
INFO - 2017-08-16 09:42:23 --> Security Class Initialized
DEBUG - 2017-08-16 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 09:42:23 --> Input Class Initialized
INFO - 2017-08-16 09:42:23 --> Language Class Initialized
INFO - 2017-08-16 09:42:23 --> Loader Class Initialized
INFO - 2017-08-16 09:42:23 --> Helper loaded: url_helper
INFO - 2017-08-16 09:42:23 --> Helper loaded: file_helper
INFO - 2017-08-16 09:42:23 --> Database Driver Class Initialized
INFO - 2017-08-16 09:42:23 --> Email Class Initialized
DEBUG - 2017-08-16 09:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 09:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 09:42:23 --> Table Class Initialized
INFO - 2017-08-16 09:42:23 --> Controller Class Initialized
INFO - 2017-08-16 09:42:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\home.php
INFO - 2017-08-16 09:42:23 --> Final output sent to browser
DEBUG - 2017-08-16 09:42:23 --> Total execution time: 0.2258
