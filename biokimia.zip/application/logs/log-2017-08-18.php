<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-18 04:08:52 --> Config Class Initialized
INFO - 2017-08-18 04:08:52 --> Hooks Class Initialized
DEBUG - 2017-08-18 04:08:53 --> UTF-8 Support Enabled
INFO - 2017-08-18 04:08:53 --> Utf8 Class Initialized
INFO - 2017-08-18 04:08:53 --> URI Class Initialized
DEBUG - 2017-08-18 04:08:53 --> No URI present. Default controller set.
INFO - 2017-08-18 04:08:53 --> Router Class Initialized
INFO - 2017-08-18 04:08:53 --> Output Class Initialized
INFO - 2017-08-18 04:08:53 --> Security Class Initialized
DEBUG - 2017-08-18 04:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 04:08:53 --> Input Class Initialized
INFO - 2017-08-18 04:08:53 --> Language Class Initialized
INFO - 2017-08-18 04:08:53 --> Loader Class Initialized
INFO - 2017-08-18 04:08:53 --> Helper loaded: url_helper
INFO - 2017-08-18 04:08:53 --> Helper loaded: file_helper
INFO - 2017-08-18 04:08:53 --> Database Driver Class Initialized
INFO - 2017-08-18 04:08:53 --> Email Class Initialized
DEBUG - 2017-08-18 04:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 04:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 04:08:53 --> Table Class Initialized
INFO - 2017-08-18 04:08:53 --> Controller Class Initialized
INFO - 2017-08-18 04:08:53 --> Model Class Initialized
INFO - 2017-08-18 04:08:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-18 04:08:54 --> Final output sent to browser
DEBUG - 2017-08-18 04:08:54 --> Total execution time: 1.1227
INFO - 2017-08-18 04:09:01 --> Config Class Initialized
INFO - 2017-08-18 04:09:01 --> Hooks Class Initialized
DEBUG - 2017-08-18 04:09:01 --> UTF-8 Support Enabled
INFO - 2017-08-18 04:09:01 --> Utf8 Class Initialized
INFO - 2017-08-18 04:09:01 --> URI Class Initialized
INFO - 2017-08-18 04:09:01 --> Router Class Initialized
INFO - 2017-08-18 04:09:01 --> Output Class Initialized
INFO - 2017-08-18 04:09:01 --> Security Class Initialized
DEBUG - 2017-08-18 04:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 04:09:01 --> Input Class Initialized
INFO - 2017-08-18 04:09:01 --> Language Class Initialized
INFO - 2017-08-18 04:09:01 --> Loader Class Initialized
INFO - 2017-08-18 04:09:01 --> Helper loaded: url_helper
INFO - 2017-08-18 04:09:01 --> Helper loaded: file_helper
INFO - 2017-08-18 04:09:01 --> Database Driver Class Initialized
INFO - 2017-08-18 04:09:01 --> Email Class Initialized
DEBUG - 2017-08-18 04:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 04:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 04:09:01 --> Table Class Initialized
INFO - 2017-08-18 04:09:01 --> Controller Class Initialized
INFO - 2017-08-18 04:09:01 --> Helper loaded: form_helper
INFO - 2017-08-18 04:09:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\test.php
INFO - 2017-08-18 04:09:01 --> Final output sent to browser
DEBUG - 2017-08-18 04:09:01 --> Total execution time: 0.2311
INFO - 2017-08-18 04:09:07 --> Config Class Initialized
INFO - 2017-08-18 04:09:07 --> Hooks Class Initialized
DEBUG - 2017-08-18 04:09:07 --> UTF-8 Support Enabled
INFO - 2017-08-18 04:09:07 --> Utf8 Class Initialized
INFO - 2017-08-18 04:09:07 --> URI Class Initialized
INFO - 2017-08-18 04:09:07 --> Router Class Initialized
INFO - 2017-08-18 04:09:07 --> Output Class Initialized
INFO - 2017-08-18 04:09:07 --> Security Class Initialized
DEBUG - 2017-08-18 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 04:09:07 --> Input Class Initialized
INFO - 2017-08-18 04:09:07 --> Language Class Initialized
INFO - 2017-08-18 04:09:07 --> Loader Class Initialized
INFO - 2017-08-18 04:09:07 --> Helper loaded: url_helper
INFO - 2017-08-18 04:09:07 --> Helper loaded: file_helper
INFO - 2017-08-18 04:09:07 --> Database Driver Class Initialized
INFO - 2017-08-18 04:09:07 --> Email Class Initialized
DEBUG - 2017-08-18 04:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 04:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 04:09:07 --> Table Class Initialized
INFO - 2017-08-18 04:09:07 --> Controller Class Initialized
INFO - 2017-08-18 04:09:07 --> Model Class Initialized
INFO - 2017-08-18 04:09:07 --> Config Class Initialized
INFO - 2017-08-18 04:09:07 --> Hooks Class Initialized
DEBUG - 2017-08-18 04:09:07 --> UTF-8 Support Enabled
INFO - 2017-08-18 04:09:07 --> Utf8 Class Initialized
INFO - 2017-08-18 04:09:07 --> URI Class Initialized
DEBUG - 2017-08-18 04:09:07 --> No URI present. Default controller set.
INFO - 2017-08-18 04:09:07 --> Router Class Initialized
INFO - 2017-08-18 04:09:07 --> Output Class Initialized
INFO - 2017-08-18 04:09:07 --> Security Class Initialized
DEBUG - 2017-08-18 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 04:09:07 --> Input Class Initialized
INFO - 2017-08-18 04:09:07 --> Language Class Initialized
INFO - 2017-08-18 04:09:07 --> Loader Class Initialized
INFO - 2017-08-18 04:09:07 --> Helper loaded: url_helper
INFO - 2017-08-18 04:09:07 --> Helper loaded: file_helper
INFO - 2017-08-18 04:09:07 --> Database Driver Class Initialized
INFO - 2017-08-18 04:09:07 --> Email Class Initialized
DEBUG - 2017-08-18 04:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 04:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 04:09:07 --> Table Class Initialized
INFO - 2017-08-18 04:09:07 --> Controller Class Initialized
INFO - 2017-08-18 04:09:07 --> Model Class Initialized
INFO - 2017-08-18 04:09:07 --> File loaded: C:\xampp\htdocs\biokimia\application\views\user_view.php
INFO - 2017-08-18 04:09:07 --> Final output sent to browser
DEBUG - 2017-08-18 04:09:07 --> Total execution time: 0.1779
INFO - 2017-08-18 11:25:07 --> Config Class Initialized
INFO - 2017-08-18 11:25:07 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:25:07 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:25:07 --> Utf8 Class Initialized
INFO - 2017-08-18 11:25:07 --> URI Class Initialized
INFO - 2017-08-18 11:25:07 --> Router Class Initialized
INFO - 2017-08-18 11:25:07 --> Output Class Initialized
INFO - 2017-08-18 11:25:07 --> Security Class Initialized
DEBUG - 2017-08-18 11:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:25:07 --> Input Class Initialized
INFO - 2017-08-18 11:25:07 --> Language Class Initialized
INFO - 2017-08-18 11:25:07 --> Loader Class Initialized
INFO - 2017-08-18 11:25:07 --> Helper loaded: url_helper
INFO - 2017-08-18 11:25:07 --> Helper loaded: file_helper
INFO - 2017-08-18 11:25:07 --> Database Driver Class Initialized
INFO - 2017-08-18 11:25:07 --> Email Class Initialized
DEBUG - 2017-08-18 11:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:25:08 --> Table Class Initialized
INFO - 2017-08-18 11:25:08 --> Controller Class Initialized
INFO - 2017-08-18 11:25:08 --> Helper loaded: form_helper
ERROR - 2017-08-18 11:25:08 --> Severity: Parsing Error --> syntax error, unexpected 'class' (T_CLASS), expecting ')' C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php 15
INFO - 2017-08-18 11:25:31 --> Config Class Initialized
INFO - 2017-08-18 11:25:31 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:25:31 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:25:31 --> Utf8 Class Initialized
INFO - 2017-08-18 11:25:31 --> URI Class Initialized
INFO - 2017-08-18 11:25:31 --> Router Class Initialized
INFO - 2017-08-18 11:25:31 --> Output Class Initialized
INFO - 2017-08-18 11:25:31 --> Security Class Initialized
DEBUG - 2017-08-18 11:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:25:31 --> Input Class Initialized
INFO - 2017-08-18 11:25:31 --> Language Class Initialized
INFO - 2017-08-18 11:25:31 --> Loader Class Initialized
INFO - 2017-08-18 11:25:31 --> Helper loaded: url_helper
INFO - 2017-08-18 11:25:31 --> Helper loaded: file_helper
INFO - 2017-08-18 11:25:31 --> Database Driver Class Initialized
INFO - 2017-08-18 11:25:31 --> Email Class Initialized
DEBUG - 2017-08-18 11:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:25:31 --> Table Class Initialized
INFO - 2017-08-18 11:25:31 --> Controller Class Initialized
INFO - 2017-08-18 11:25:31 --> Helper loaded: form_helper
INFO - 2017-08-18 11:25:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:25:31 --> Final output sent to browser
DEBUG - 2017-08-18 11:25:31 --> Total execution time: 0.1713
INFO - 2017-08-18 11:25:31 --> Config Class Initialized
INFO - 2017-08-18 11:25:31 --> Config Class Initialized
INFO - 2017-08-18 11:25:31 --> Config Class Initialized
INFO - 2017-08-18 11:25:31 --> Hooks Class Initialized
INFO - 2017-08-18 11:25:31 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:25:31 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:25:31 --> Config Class Initialized
DEBUG - 2017-08-18 11:25:31 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:25:31 --> Hooks Class Initialized
INFO - 2017-08-18 11:25:31 --> Hooks Class Initialized
INFO - 2017-08-18 11:25:31 --> Utf8 Class Initialized
INFO - 2017-08-18 11:25:31 --> Utf8 Class Initialized
DEBUG - 2017-08-18 11:25:31 --> UTF-8 Support Enabled
DEBUG - 2017-08-18 11:25:31 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:25:31 --> URI Class Initialized
INFO - 2017-08-18 11:25:31 --> URI Class Initialized
INFO - 2017-08-18 11:25:31 --> Utf8 Class Initialized
INFO - 2017-08-18 11:25:31 --> Utf8 Class Initialized
INFO - 2017-08-18 11:25:31 --> Router Class Initialized
INFO - 2017-08-18 11:25:31 --> URI Class Initialized
INFO - 2017-08-18 11:25:31 --> Router Class Initialized
INFO - 2017-08-18 11:25:31 --> URI Class Initialized
INFO - 2017-08-18 11:25:31 --> Output Class Initialized
INFO - 2017-08-18 11:25:31 --> Router Class Initialized
INFO - 2017-08-18 11:25:31 --> Router Class Initialized
INFO - 2017-08-18 11:25:31 --> Output Class Initialized
INFO - 2017-08-18 11:25:31 --> Security Class Initialized
INFO - 2017-08-18 11:25:31 --> Output Class Initialized
INFO - 2017-08-18 11:25:31 --> Security Class Initialized
INFO - 2017-08-18 11:25:31 --> Output Class Initialized
DEBUG - 2017-08-18 11:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:25:31 --> Security Class Initialized
INFO - 2017-08-18 11:25:31 --> Security Class Initialized
INFO - 2017-08-18 11:25:31 --> Input Class Initialized
DEBUG - 2017-08-18 11:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:25:31 --> Input Class Initialized
INFO - 2017-08-18 11:25:31 --> Language Class Initialized
DEBUG - 2017-08-18 11:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-18 11:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:25:31 --> Language Class Initialized
INFO - 2017-08-18 11:25:31 --> Input Class Initialized
INFO - 2017-08-18 11:25:31 --> Input Class Initialized
ERROR - 2017-08-18 11:25:31 --> 404 Page Not Found: Ext/froala-2.6.4
ERROR - 2017-08-18 11:25:31 --> 404 Page Not Found: Ext/froala-2.6.4js
INFO - 2017-08-18 11:25:31 --> Language Class Initialized
INFO - 2017-08-18 11:25:31 --> Language Class Initialized
ERROR - 2017-08-18 11:25:31 --> 404 Page Not Found: Ext/froala-2.6.4
ERROR - 2017-08-18 11:25:31 --> 404 Page Not Found: Ext/froala-2.6.4
INFO - 2017-08-18 11:25:31 --> Config Class Initialized
INFO - 2017-08-18 11:25:31 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:25:31 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:25:31 --> Utf8 Class Initialized
INFO - 2017-08-18 11:25:31 --> URI Class Initialized
INFO - 2017-08-18 11:25:31 --> Router Class Initialized
INFO - 2017-08-18 11:25:31 --> Output Class Initialized
INFO - 2017-08-18 11:25:31 --> Security Class Initialized
DEBUG - 2017-08-18 11:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:25:31 --> Input Class Initialized
INFO - 2017-08-18 11:25:31 --> Language Class Initialized
ERROR - 2017-08-18 11:25:31 --> 404 Page Not Found: Ext/froala-2.6.4
INFO - 2017-08-18 11:25:31 --> Config Class Initialized
INFO - 2017-08-18 11:25:31 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:25:31 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:25:31 --> Utf8 Class Initialized
INFO - 2017-08-18 11:25:31 --> URI Class Initialized
INFO - 2017-08-18 11:25:31 --> Router Class Initialized
INFO - 2017-08-18 11:25:31 --> Output Class Initialized
INFO - 2017-08-18 11:25:31 --> Security Class Initialized
DEBUG - 2017-08-18 11:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:25:32 --> Input Class Initialized
INFO - 2017-08-18 11:25:32 --> Language Class Initialized
ERROR - 2017-08-18 11:25:32 --> 404 Page Not Found: Ext/froala-2.6.4js
INFO - 2017-08-18 11:26:46 --> Config Class Initialized
INFO - 2017-08-18 11:26:46 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:26:46 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:26:46 --> Utf8 Class Initialized
INFO - 2017-08-18 11:26:46 --> URI Class Initialized
INFO - 2017-08-18 11:26:46 --> Router Class Initialized
INFO - 2017-08-18 11:26:46 --> Output Class Initialized
INFO - 2017-08-18 11:26:46 --> Security Class Initialized
DEBUG - 2017-08-18 11:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:26:46 --> Input Class Initialized
INFO - 2017-08-18 11:26:46 --> Language Class Initialized
INFO - 2017-08-18 11:26:46 --> Loader Class Initialized
INFO - 2017-08-18 11:26:46 --> Helper loaded: url_helper
INFO - 2017-08-18 11:26:46 --> Helper loaded: file_helper
INFO - 2017-08-18 11:26:46 --> Database Driver Class Initialized
INFO - 2017-08-18 11:26:46 --> Email Class Initialized
DEBUG - 2017-08-18 11:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:26:46 --> Table Class Initialized
INFO - 2017-08-18 11:26:46 --> Controller Class Initialized
INFO - 2017-08-18 11:26:46 --> Helper loaded: form_helper
INFO - 2017-08-18 11:26:46 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:26:46 --> Final output sent to browser
DEBUG - 2017-08-18 11:26:46 --> Total execution time: 0.1643
INFO - 2017-08-18 11:27:03 --> Config Class Initialized
INFO - 2017-08-18 11:27:03 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:27:03 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:27:03 --> Utf8 Class Initialized
INFO - 2017-08-18 11:27:03 --> URI Class Initialized
INFO - 2017-08-18 11:27:03 --> Router Class Initialized
INFO - 2017-08-18 11:27:03 --> Output Class Initialized
INFO - 2017-08-18 11:27:03 --> Security Class Initialized
DEBUG - 2017-08-18 11:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:27:03 --> Input Class Initialized
INFO - 2017-08-18 11:27:03 --> Language Class Initialized
INFO - 2017-08-18 11:27:03 --> Loader Class Initialized
INFO - 2017-08-18 11:27:03 --> Helper loaded: url_helper
INFO - 2017-08-18 11:27:03 --> Helper loaded: file_helper
INFO - 2017-08-18 11:27:03 --> Database Driver Class Initialized
INFO - 2017-08-18 11:27:03 --> Email Class Initialized
DEBUG - 2017-08-18 11:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:27:03 --> Table Class Initialized
INFO - 2017-08-18 11:27:03 --> Controller Class Initialized
INFO - 2017-08-18 11:27:03 --> Helper loaded: form_helper
INFO - 2017-08-18 11:27:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:27:03 --> Final output sent to browser
DEBUG - 2017-08-18 11:27:03 --> Total execution time: 0.2001
INFO - 2017-08-18 11:27:40 --> Config Class Initialized
INFO - 2017-08-18 11:27:40 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:27:40 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:27:40 --> Utf8 Class Initialized
INFO - 2017-08-18 11:27:40 --> URI Class Initialized
INFO - 2017-08-18 11:27:40 --> Router Class Initialized
INFO - 2017-08-18 11:27:40 --> Output Class Initialized
INFO - 2017-08-18 11:27:40 --> Security Class Initialized
DEBUG - 2017-08-18 11:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:27:40 --> Input Class Initialized
INFO - 2017-08-18 11:27:40 --> Language Class Initialized
INFO - 2017-08-18 11:27:40 --> Loader Class Initialized
INFO - 2017-08-18 11:27:40 --> Helper loaded: url_helper
INFO - 2017-08-18 11:27:40 --> Helper loaded: file_helper
INFO - 2017-08-18 11:27:40 --> Database Driver Class Initialized
INFO - 2017-08-18 11:27:40 --> Email Class Initialized
DEBUG - 2017-08-18 11:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:27:40 --> Table Class Initialized
INFO - 2017-08-18 11:27:40 --> Controller Class Initialized
INFO - 2017-08-18 11:27:40 --> Helper loaded: form_helper
INFO - 2017-08-18 11:27:40 --> Final output sent to browser
DEBUG - 2017-08-18 11:27:40 --> Total execution time: 0.1607
INFO - 2017-08-18 11:27:42 --> Config Class Initialized
INFO - 2017-08-18 11:27:42 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:27:42 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:27:42 --> Utf8 Class Initialized
INFO - 2017-08-18 11:27:42 --> URI Class Initialized
INFO - 2017-08-18 11:27:42 --> Router Class Initialized
INFO - 2017-08-18 11:27:42 --> Output Class Initialized
INFO - 2017-08-18 11:27:42 --> Security Class Initialized
DEBUG - 2017-08-18 11:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:27:42 --> Input Class Initialized
INFO - 2017-08-18 11:27:42 --> Language Class Initialized
INFO - 2017-08-18 11:27:42 --> Loader Class Initialized
INFO - 2017-08-18 11:27:42 --> Helper loaded: url_helper
INFO - 2017-08-18 11:27:42 --> Helper loaded: file_helper
INFO - 2017-08-18 11:27:42 --> Database Driver Class Initialized
INFO - 2017-08-18 11:27:42 --> Email Class Initialized
DEBUG - 2017-08-18 11:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:27:42 --> Table Class Initialized
INFO - 2017-08-18 11:27:42 --> Controller Class Initialized
INFO - 2017-08-18 11:27:42 --> Helper loaded: form_helper
INFO - 2017-08-18 11:27:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:27:42 --> Final output sent to browser
DEBUG - 2017-08-18 11:27:42 --> Total execution time: 0.1726
INFO - 2017-08-18 11:27:46 --> Config Class Initialized
INFO - 2017-08-18 11:27:46 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:27:46 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:27:46 --> Utf8 Class Initialized
INFO - 2017-08-18 11:27:46 --> URI Class Initialized
INFO - 2017-08-18 11:27:46 --> Router Class Initialized
INFO - 2017-08-18 11:27:46 --> Output Class Initialized
INFO - 2017-08-18 11:27:46 --> Security Class Initialized
DEBUG - 2017-08-18 11:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:27:46 --> Input Class Initialized
INFO - 2017-08-18 11:27:46 --> Language Class Initialized
INFO - 2017-08-18 11:27:46 --> Loader Class Initialized
INFO - 2017-08-18 11:27:46 --> Helper loaded: url_helper
INFO - 2017-08-18 11:27:46 --> Helper loaded: file_helper
INFO - 2017-08-18 11:27:46 --> Database Driver Class Initialized
INFO - 2017-08-18 11:27:46 --> Email Class Initialized
DEBUG - 2017-08-18 11:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:27:46 --> Table Class Initialized
INFO - 2017-08-18 11:27:46 --> Controller Class Initialized
INFO - 2017-08-18 11:27:46 --> Helper loaded: form_helper
INFO - 2017-08-18 11:27:46 --> Final output sent to browser
DEBUG - 2017-08-18 11:27:46 --> Total execution time: 0.1599
INFO - 2017-08-18 11:27:48 --> Config Class Initialized
INFO - 2017-08-18 11:27:48 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:27:48 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:27:48 --> Utf8 Class Initialized
INFO - 2017-08-18 11:27:48 --> URI Class Initialized
INFO - 2017-08-18 11:27:48 --> Router Class Initialized
INFO - 2017-08-18 11:27:48 --> Output Class Initialized
INFO - 2017-08-18 11:27:48 --> Security Class Initialized
DEBUG - 2017-08-18 11:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:27:48 --> Input Class Initialized
INFO - 2017-08-18 11:27:48 --> Language Class Initialized
INFO - 2017-08-18 11:27:48 --> Loader Class Initialized
INFO - 2017-08-18 11:27:48 --> Helper loaded: url_helper
INFO - 2017-08-18 11:27:48 --> Helper loaded: file_helper
INFO - 2017-08-18 11:27:48 --> Database Driver Class Initialized
INFO - 2017-08-18 11:27:48 --> Email Class Initialized
DEBUG - 2017-08-18 11:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:27:48 --> Table Class Initialized
INFO - 2017-08-18 11:27:48 --> Controller Class Initialized
INFO - 2017-08-18 11:27:48 --> Helper loaded: form_helper
INFO - 2017-08-18 11:27:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:27:48 --> Final output sent to browser
DEBUG - 2017-08-18 11:27:48 --> Total execution time: 0.1831
INFO - 2017-08-18 11:27:51 --> Config Class Initialized
INFO - 2017-08-18 11:27:51 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:27:51 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:27:51 --> Utf8 Class Initialized
INFO - 2017-08-18 11:27:51 --> URI Class Initialized
INFO - 2017-08-18 11:27:51 --> Router Class Initialized
INFO - 2017-08-18 11:27:51 --> Output Class Initialized
INFO - 2017-08-18 11:27:51 --> Security Class Initialized
DEBUG - 2017-08-18 11:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:27:51 --> Input Class Initialized
INFO - 2017-08-18 11:27:51 --> Language Class Initialized
INFO - 2017-08-18 11:27:51 --> Loader Class Initialized
INFO - 2017-08-18 11:27:51 --> Helper loaded: url_helper
INFO - 2017-08-18 11:27:51 --> Helper loaded: file_helper
INFO - 2017-08-18 11:27:51 --> Database Driver Class Initialized
INFO - 2017-08-18 11:27:51 --> Email Class Initialized
DEBUG - 2017-08-18 11:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:27:51 --> Table Class Initialized
INFO - 2017-08-18 11:27:51 --> Controller Class Initialized
INFO - 2017-08-18 11:27:51 --> Helper loaded: form_helper
INFO - 2017-08-18 11:27:51 --> Final output sent to browser
DEBUG - 2017-08-18 11:27:51 --> Total execution time: 0.1713
INFO - 2017-08-18 11:27:53 --> Config Class Initialized
INFO - 2017-08-18 11:27:53 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:27:53 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:27:53 --> Utf8 Class Initialized
INFO - 2017-08-18 11:27:53 --> URI Class Initialized
INFO - 2017-08-18 11:27:53 --> Router Class Initialized
INFO - 2017-08-18 11:27:53 --> Output Class Initialized
INFO - 2017-08-18 11:27:53 --> Security Class Initialized
DEBUG - 2017-08-18 11:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:27:53 --> Input Class Initialized
INFO - 2017-08-18 11:27:53 --> Language Class Initialized
INFO - 2017-08-18 11:27:53 --> Loader Class Initialized
INFO - 2017-08-18 11:27:53 --> Helper loaded: url_helper
INFO - 2017-08-18 11:27:53 --> Helper loaded: file_helper
INFO - 2017-08-18 11:27:53 --> Database Driver Class Initialized
INFO - 2017-08-18 11:27:53 --> Email Class Initialized
DEBUG - 2017-08-18 11:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:27:53 --> Table Class Initialized
INFO - 2017-08-18 11:27:53 --> Controller Class Initialized
INFO - 2017-08-18 11:27:53 --> Helper loaded: form_helper
INFO - 2017-08-18 11:27:53 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:27:53 --> Final output sent to browser
DEBUG - 2017-08-18 11:27:53 --> Total execution time: 0.1774
INFO - 2017-08-18 11:28:10 --> Config Class Initialized
INFO - 2017-08-18 11:28:10 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:28:10 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:28:10 --> Utf8 Class Initialized
INFO - 2017-08-18 11:28:10 --> URI Class Initialized
INFO - 2017-08-18 11:28:10 --> Router Class Initialized
INFO - 2017-08-18 11:28:10 --> Output Class Initialized
INFO - 2017-08-18 11:28:10 --> Security Class Initialized
DEBUG - 2017-08-18 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:28:10 --> Input Class Initialized
INFO - 2017-08-18 11:28:10 --> Language Class Initialized
INFO - 2017-08-18 11:28:10 --> Loader Class Initialized
INFO - 2017-08-18 11:28:10 --> Helper loaded: url_helper
INFO - 2017-08-18 11:28:10 --> Helper loaded: file_helper
INFO - 2017-08-18 11:28:10 --> Database Driver Class Initialized
INFO - 2017-08-18 11:28:10 --> Email Class Initialized
DEBUG - 2017-08-18 11:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:28:10 --> Table Class Initialized
INFO - 2017-08-18 11:28:10 --> Controller Class Initialized
INFO - 2017-08-18 11:28:10 --> Helper loaded: form_helper
INFO - 2017-08-18 11:28:10 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:28:10 --> Final output sent to browser
DEBUG - 2017-08-18 11:28:10 --> Total execution time: 0.1749
INFO - 2017-08-18 11:28:15 --> Config Class Initialized
INFO - 2017-08-18 11:28:15 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:28:15 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:28:15 --> Utf8 Class Initialized
INFO - 2017-08-18 11:28:15 --> URI Class Initialized
INFO - 2017-08-18 11:28:15 --> Router Class Initialized
INFO - 2017-08-18 11:28:15 --> Output Class Initialized
INFO - 2017-08-18 11:28:15 --> Security Class Initialized
DEBUG - 2017-08-18 11:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:28:15 --> Input Class Initialized
INFO - 2017-08-18 11:28:15 --> Language Class Initialized
INFO - 2017-08-18 11:28:15 --> Loader Class Initialized
INFO - 2017-08-18 11:28:15 --> Helper loaded: url_helper
INFO - 2017-08-18 11:28:15 --> Helper loaded: file_helper
INFO - 2017-08-18 11:28:15 --> Database Driver Class Initialized
INFO - 2017-08-18 11:28:15 --> Email Class Initialized
DEBUG - 2017-08-18 11:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:28:15 --> Table Class Initialized
INFO - 2017-08-18 11:28:15 --> Controller Class Initialized
INFO - 2017-08-18 11:28:15 --> Helper loaded: form_helper
INFO - 2017-08-18 11:28:15 --> Final output sent to browser
DEBUG - 2017-08-18 11:28:15 --> Total execution time: 0.1730
INFO - 2017-08-18 11:28:17 --> Config Class Initialized
INFO - 2017-08-18 11:28:17 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:28:17 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:28:17 --> Utf8 Class Initialized
INFO - 2017-08-18 11:28:17 --> URI Class Initialized
INFO - 2017-08-18 11:28:17 --> Router Class Initialized
INFO - 2017-08-18 11:28:17 --> Output Class Initialized
INFO - 2017-08-18 11:28:17 --> Security Class Initialized
DEBUG - 2017-08-18 11:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:28:18 --> Input Class Initialized
INFO - 2017-08-18 11:28:18 --> Language Class Initialized
INFO - 2017-08-18 11:28:18 --> Loader Class Initialized
INFO - 2017-08-18 11:28:18 --> Helper loaded: url_helper
INFO - 2017-08-18 11:28:18 --> Helper loaded: file_helper
INFO - 2017-08-18 11:28:18 --> Database Driver Class Initialized
INFO - 2017-08-18 11:28:18 --> Email Class Initialized
DEBUG - 2017-08-18 11:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:28:18 --> Table Class Initialized
INFO - 2017-08-18 11:28:18 --> Controller Class Initialized
INFO - 2017-08-18 11:28:18 --> Helper loaded: form_helper
INFO - 2017-08-18 11:28:18 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:28:18 --> Final output sent to browser
DEBUG - 2017-08-18 11:28:18 --> Total execution time: 0.1847
INFO - 2017-08-18 11:28:27 --> Config Class Initialized
INFO - 2017-08-18 11:28:27 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:28:27 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:28:27 --> Utf8 Class Initialized
INFO - 2017-08-18 11:28:27 --> URI Class Initialized
INFO - 2017-08-18 11:28:27 --> Router Class Initialized
INFO - 2017-08-18 11:28:27 --> Output Class Initialized
INFO - 2017-08-18 11:28:27 --> Security Class Initialized
DEBUG - 2017-08-18 11:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:28:27 --> Input Class Initialized
INFO - 2017-08-18 11:28:27 --> Language Class Initialized
INFO - 2017-08-18 11:28:27 --> Loader Class Initialized
INFO - 2017-08-18 11:28:27 --> Helper loaded: url_helper
INFO - 2017-08-18 11:28:27 --> Helper loaded: file_helper
INFO - 2017-08-18 11:28:27 --> Database Driver Class Initialized
INFO - 2017-08-18 11:28:27 --> Email Class Initialized
DEBUG - 2017-08-18 11:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:28:27 --> Table Class Initialized
INFO - 2017-08-18 11:28:27 --> Controller Class Initialized
INFO - 2017-08-18 11:28:27 --> Helper loaded: form_helper
INFO - 2017-08-18 11:28:27 --> Final output sent to browser
DEBUG - 2017-08-18 11:28:27 --> Total execution time: 0.1635
INFO - 2017-08-18 11:28:29 --> Config Class Initialized
INFO - 2017-08-18 11:28:29 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:28:29 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:28:29 --> Utf8 Class Initialized
INFO - 2017-08-18 11:28:29 --> URI Class Initialized
INFO - 2017-08-18 11:28:29 --> Router Class Initialized
INFO - 2017-08-18 11:28:29 --> Output Class Initialized
INFO - 2017-08-18 11:28:29 --> Security Class Initialized
DEBUG - 2017-08-18 11:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:28:29 --> Input Class Initialized
INFO - 2017-08-18 11:28:29 --> Language Class Initialized
INFO - 2017-08-18 11:28:29 --> Loader Class Initialized
INFO - 2017-08-18 11:28:29 --> Helper loaded: url_helper
INFO - 2017-08-18 11:28:29 --> Helper loaded: file_helper
INFO - 2017-08-18 11:28:29 --> Database Driver Class Initialized
INFO - 2017-08-18 11:28:29 --> Email Class Initialized
DEBUG - 2017-08-18 11:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:28:29 --> Table Class Initialized
INFO - 2017-08-18 11:28:29 --> Controller Class Initialized
INFO - 2017-08-18 11:28:29 --> Helper loaded: form_helper
INFO - 2017-08-18 11:28:29 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:28:29 --> Final output sent to browser
DEBUG - 2017-08-18 11:28:29 --> Total execution time: 0.1790
INFO - 2017-08-18 11:28:33 --> Config Class Initialized
INFO - 2017-08-18 11:28:33 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:28:33 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:28:33 --> Utf8 Class Initialized
INFO - 2017-08-18 11:28:33 --> URI Class Initialized
INFO - 2017-08-18 11:28:33 --> Router Class Initialized
INFO - 2017-08-18 11:28:33 --> Output Class Initialized
INFO - 2017-08-18 11:28:33 --> Security Class Initialized
DEBUG - 2017-08-18 11:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:28:33 --> Input Class Initialized
INFO - 2017-08-18 11:28:33 --> Language Class Initialized
INFO - 2017-08-18 11:28:33 --> Loader Class Initialized
INFO - 2017-08-18 11:28:33 --> Helper loaded: url_helper
INFO - 2017-08-18 11:28:33 --> Helper loaded: file_helper
INFO - 2017-08-18 11:28:33 --> Database Driver Class Initialized
INFO - 2017-08-18 11:28:33 --> Email Class Initialized
DEBUG - 2017-08-18 11:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:28:33 --> Table Class Initialized
INFO - 2017-08-18 11:28:33 --> Controller Class Initialized
INFO - 2017-08-18 11:28:33 --> Helper loaded: form_helper
INFO - 2017-08-18 11:28:33 --> Final output sent to browser
DEBUG - 2017-08-18 11:28:33 --> Total execution time: 0.1740
INFO - 2017-08-18 11:28:36 --> Config Class Initialized
INFO - 2017-08-18 11:28:36 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:28:36 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:28:36 --> Utf8 Class Initialized
INFO - 2017-08-18 11:28:36 --> URI Class Initialized
INFO - 2017-08-18 11:28:37 --> Router Class Initialized
INFO - 2017-08-18 11:28:37 --> Output Class Initialized
INFO - 2017-08-18 11:28:37 --> Security Class Initialized
DEBUG - 2017-08-18 11:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:28:37 --> Input Class Initialized
INFO - 2017-08-18 11:28:37 --> Language Class Initialized
INFO - 2017-08-18 11:28:37 --> Loader Class Initialized
INFO - 2017-08-18 11:28:37 --> Helper loaded: url_helper
INFO - 2017-08-18 11:28:37 --> Helper loaded: file_helper
INFO - 2017-08-18 11:28:37 --> Database Driver Class Initialized
INFO - 2017-08-18 11:28:37 --> Email Class Initialized
DEBUG - 2017-08-18 11:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:28:37 --> Table Class Initialized
INFO - 2017-08-18 11:28:37 --> Controller Class Initialized
INFO - 2017-08-18 11:28:37 --> Helper loaded: form_helper
INFO - 2017-08-18 11:28:37 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:28:37 --> Final output sent to browser
DEBUG - 2017-08-18 11:28:37 --> Total execution time: 0.1929
INFO - 2017-08-18 11:28:58 --> Config Class Initialized
INFO - 2017-08-18 11:28:58 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:28:58 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:28:58 --> Utf8 Class Initialized
INFO - 2017-08-18 11:28:58 --> URI Class Initialized
INFO - 2017-08-18 11:28:58 --> Router Class Initialized
INFO - 2017-08-18 11:28:58 --> Output Class Initialized
INFO - 2017-08-18 11:28:58 --> Security Class Initialized
DEBUG - 2017-08-18 11:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:28:58 --> Input Class Initialized
INFO - 2017-08-18 11:28:58 --> Language Class Initialized
INFO - 2017-08-18 11:28:58 --> Loader Class Initialized
INFO - 2017-08-18 11:28:58 --> Helper loaded: url_helper
INFO - 2017-08-18 11:28:58 --> Helper loaded: file_helper
INFO - 2017-08-18 11:28:58 --> Database Driver Class Initialized
INFO - 2017-08-18 11:28:58 --> Email Class Initialized
DEBUG - 2017-08-18 11:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:28:58 --> Table Class Initialized
INFO - 2017-08-18 11:28:58 --> Controller Class Initialized
INFO - 2017-08-18 11:28:58 --> Helper loaded: form_helper
INFO - 2017-08-18 11:28:58 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:28:58 --> Final output sent to browser
DEBUG - 2017-08-18 11:28:58 --> Total execution time: 0.1692
INFO - 2017-08-18 11:29:22 --> Config Class Initialized
INFO - 2017-08-18 11:29:22 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:29:22 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:29:22 --> Utf8 Class Initialized
INFO - 2017-08-18 11:29:22 --> URI Class Initialized
INFO - 2017-08-18 11:29:22 --> Router Class Initialized
INFO - 2017-08-18 11:29:22 --> Output Class Initialized
INFO - 2017-08-18 11:29:22 --> Security Class Initialized
DEBUG - 2017-08-18 11:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:29:22 --> Input Class Initialized
INFO - 2017-08-18 11:29:22 --> Language Class Initialized
INFO - 2017-08-18 11:29:22 --> Loader Class Initialized
INFO - 2017-08-18 11:29:22 --> Helper loaded: url_helper
INFO - 2017-08-18 11:29:22 --> Helper loaded: file_helper
INFO - 2017-08-18 11:29:22 --> Database Driver Class Initialized
INFO - 2017-08-18 11:29:22 --> Email Class Initialized
DEBUG - 2017-08-18 11:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:29:22 --> Table Class Initialized
INFO - 2017-08-18 11:29:22 --> Controller Class Initialized
INFO - 2017-08-18 11:29:22 --> Helper loaded: form_helper
INFO - 2017-08-18 11:29:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:29:22 --> Final output sent to browser
DEBUG - 2017-08-18 11:29:22 --> Total execution time: 0.1821
INFO - 2017-08-18 11:29:28 --> Config Class Initialized
INFO - 2017-08-18 11:29:28 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:29:28 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:29:28 --> Utf8 Class Initialized
INFO - 2017-08-18 11:29:28 --> URI Class Initialized
INFO - 2017-08-18 11:29:28 --> Router Class Initialized
INFO - 2017-08-18 11:29:28 --> Output Class Initialized
INFO - 2017-08-18 11:29:28 --> Security Class Initialized
DEBUG - 2017-08-18 11:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:29:28 --> Input Class Initialized
INFO - 2017-08-18 11:29:28 --> Language Class Initialized
INFO - 2017-08-18 11:29:28 --> Loader Class Initialized
INFO - 2017-08-18 11:29:28 --> Helper loaded: url_helper
INFO - 2017-08-18 11:29:28 --> Helper loaded: file_helper
INFO - 2017-08-18 11:29:28 --> Database Driver Class Initialized
INFO - 2017-08-18 11:29:28 --> Email Class Initialized
DEBUG - 2017-08-18 11:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:29:28 --> Table Class Initialized
INFO - 2017-08-18 11:29:28 --> Controller Class Initialized
INFO - 2017-08-18 11:29:28 --> Helper loaded: form_helper
INFO - 2017-08-18 11:29:28 --> Final output sent to browser
DEBUG - 2017-08-18 11:29:28 --> Total execution time: 0.1656
INFO - 2017-08-18 11:29:31 --> Config Class Initialized
INFO - 2017-08-18 11:29:31 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:29:31 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:29:31 --> Utf8 Class Initialized
INFO - 2017-08-18 11:29:31 --> URI Class Initialized
INFO - 2017-08-18 11:29:31 --> Router Class Initialized
INFO - 2017-08-18 11:29:31 --> Output Class Initialized
INFO - 2017-08-18 11:29:31 --> Security Class Initialized
DEBUG - 2017-08-18 11:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:29:31 --> Input Class Initialized
INFO - 2017-08-18 11:29:31 --> Language Class Initialized
INFO - 2017-08-18 11:29:31 --> Loader Class Initialized
INFO - 2017-08-18 11:29:31 --> Helper loaded: url_helper
INFO - 2017-08-18 11:29:31 --> Helper loaded: file_helper
INFO - 2017-08-18 11:29:31 --> Database Driver Class Initialized
INFO - 2017-08-18 11:29:31 --> Email Class Initialized
DEBUG - 2017-08-18 11:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:29:31 --> Table Class Initialized
INFO - 2017-08-18 11:29:31 --> Controller Class Initialized
INFO - 2017-08-18 11:29:31 --> Helper loaded: form_helper
INFO - 2017-08-18 11:29:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:29:31 --> Final output sent to browser
DEBUG - 2017-08-18 11:29:31 --> Total execution time: 0.1842
INFO - 2017-08-18 11:29:50 --> Config Class Initialized
INFO - 2017-08-18 11:29:50 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:29:50 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:29:50 --> Utf8 Class Initialized
INFO - 2017-08-18 11:29:50 --> URI Class Initialized
INFO - 2017-08-18 11:29:50 --> Router Class Initialized
INFO - 2017-08-18 11:29:50 --> Output Class Initialized
INFO - 2017-08-18 11:29:50 --> Security Class Initialized
DEBUG - 2017-08-18 11:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:29:50 --> Input Class Initialized
INFO - 2017-08-18 11:29:50 --> Language Class Initialized
INFO - 2017-08-18 11:29:50 --> Loader Class Initialized
INFO - 2017-08-18 11:29:50 --> Helper loaded: url_helper
INFO - 2017-08-18 11:29:50 --> Helper loaded: file_helper
INFO - 2017-08-18 11:29:50 --> Database Driver Class Initialized
INFO - 2017-08-18 11:29:50 --> Email Class Initialized
DEBUG - 2017-08-18 11:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:29:50 --> Table Class Initialized
INFO - 2017-08-18 11:29:50 --> Controller Class Initialized
INFO - 2017-08-18 11:29:50 --> Helper loaded: form_helper
INFO - 2017-08-18 11:29:50 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:29:50 --> Final output sent to browser
DEBUG - 2017-08-18 11:29:50 --> Total execution time: 0.1727
INFO - 2017-08-18 11:30:00 --> Config Class Initialized
INFO - 2017-08-18 11:30:00 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:30:00 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:30:00 --> Utf8 Class Initialized
INFO - 2017-08-18 11:30:00 --> URI Class Initialized
INFO - 2017-08-18 11:30:00 --> Router Class Initialized
INFO - 2017-08-18 11:30:00 --> Output Class Initialized
INFO - 2017-08-18 11:30:00 --> Security Class Initialized
DEBUG - 2017-08-18 11:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:30:00 --> Input Class Initialized
INFO - 2017-08-18 11:30:00 --> Language Class Initialized
INFO - 2017-08-18 11:30:00 --> Loader Class Initialized
INFO - 2017-08-18 11:30:00 --> Helper loaded: url_helper
INFO - 2017-08-18 11:30:00 --> Helper loaded: file_helper
INFO - 2017-08-18 11:30:00 --> Database Driver Class Initialized
INFO - 2017-08-18 11:30:00 --> Email Class Initialized
DEBUG - 2017-08-18 11:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:30:01 --> Table Class Initialized
INFO - 2017-08-18 11:30:01 --> Controller Class Initialized
INFO - 2017-08-18 11:30:01 --> Helper loaded: form_helper
INFO - 2017-08-18 11:30:01 --> Final output sent to browser
DEBUG - 2017-08-18 11:30:01 --> Total execution time: 0.1690
INFO - 2017-08-18 11:30:02 --> Config Class Initialized
INFO - 2017-08-18 11:30:02 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:30:02 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:30:02 --> Utf8 Class Initialized
INFO - 2017-08-18 11:30:02 --> URI Class Initialized
INFO - 2017-08-18 11:30:03 --> Router Class Initialized
INFO - 2017-08-18 11:30:03 --> Output Class Initialized
INFO - 2017-08-18 11:30:03 --> Security Class Initialized
DEBUG - 2017-08-18 11:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:30:03 --> Input Class Initialized
INFO - 2017-08-18 11:30:03 --> Language Class Initialized
INFO - 2017-08-18 11:30:03 --> Loader Class Initialized
INFO - 2017-08-18 11:30:03 --> Helper loaded: url_helper
INFO - 2017-08-18 11:30:03 --> Helper loaded: file_helper
INFO - 2017-08-18 11:30:03 --> Database Driver Class Initialized
INFO - 2017-08-18 11:30:03 --> Email Class Initialized
DEBUG - 2017-08-18 11:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:30:03 --> Table Class Initialized
INFO - 2017-08-18 11:30:03 --> Controller Class Initialized
INFO - 2017-08-18 11:30:03 --> Helper loaded: form_helper
INFO - 2017-08-18 11:30:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:30:03 --> Final output sent to browser
DEBUG - 2017-08-18 11:30:03 --> Total execution time: 0.1773
INFO - 2017-08-18 11:30:56 --> Config Class Initialized
INFO - 2017-08-18 11:30:56 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:30:56 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:30:56 --> Utf8 Class Initialized
INFO - 2017-08-18 11:30:56 --> URI Class Initialized
INFO - 2017-08-18 11:30:56 --> Router Class Initialized
INFO - 2017-08-18 11:30:56 --> Output Class Initialized
INFO - 2017-08-18 11:30:56 --> Security Class Initialized
DEBUG - 2017-08-18 11:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:30:56 --> Input Class Initialized
INFO - 2017-08-18 11:30:56 --> Language Class Initialized
INFO - 2017-08-18 11:30:56 --> Loader Class Initialized
INFO - 2017-08-18 11:30:56 --> Helper loaded: url_helper
INFO - 2017-08-18 11:30:56 --> Helper loaded: file_helper
INFO - 2017-08-18 11:30:56 --> Database Driver Class Initialized
INFO - 2017-08-18 11:30:56 --> Email Class Initialized
DEBUG - 2017-08-18 11:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:30:56 --> Table Class Initialized
INFO - 2017-08-18 11:30:56 --> Controller Class Initialized
INFO - 2017-08-18 11:30:56 --> Helper loaded: form_helper
INFO - 2017-08-18 11:30:56 --> Final output sent to browser
DEBUG - 2017-08-18 11:30:56 --> Total execution time: 0.1755
INFO - 2017-08-18 11:31:02 --> Config Class Initialized
INFO - 2017-08-18 11:31:02 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:31:02 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:31:02 --> Utf8 Class Initialized
INFO - 2017-08-18 11:31:02 --> URI Class Initialized
INFO - 2017-08-18 11:31:02 --> Router Class Initialized
INFO - 2017-08-18 11:31:02 --> Output Class Initialized
INFO - 2017-08-18 11:31:02 --> Security Class Initialized
DEBUG - 2017-08-18 11:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:31:02 --> Input Class Initialized
INFO - 2017-08-18 11:31:02 --> Language Class Initialized
INFO - 2017-08-18 11:31:02 --> Loader Class Initialized
INFO - 2017-08-18 11:31:02 --> Helper loaded: url_helper
INFO - 2017-08-18 11:31:02 --> Helper loaded: file_helper
INFO - 2017-08-18 11:31:02 --> Database Driver Class Initialized
INFO - 2017-08-18 11:31:02 --> Email Class Initialized
DEBUG - 2017-08-18 11:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:31:02 --> Table Class Initialized
INFO - 2017-08-18 11:31:02 --> Controller Class Initialized
INFO - 2017-08-18 11:31:02 --> Helper loaded: form_helper
INFO - 2017-08-18 11:31:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:31:02 --> Final output sent to browser
DEBUG - 2017-08-18 11:31:02 --> Total execution time: 0.1803
INFO - 2017-08-18 11:32:41 --> Config Class Initialized
INFO - 2017-08-18 11:32:41 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:32:41 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:32:41 --> Utf8 Class Initialized
INFO - 2017-08-18 11:32:41 --> URI Class Initialized
INFO - 2017-08-18 11:32:41 --> Router Class Initialized
INFO - 2017-08-18 11:32:41 --> Output Class Initialized
INFO - 2017-08-18 11:32:41 --> Security Class Initialized
DEBUG - 2017-08-18 11:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:32:41 --> Input Class Initialized
INFO - 2017-08-18 11:32:41 --> Language Class Initialized
INFO - 2017-08-18 11:32:41 --> Loader Class Initialized
INFO - 2017-08-18 11:32:41 --> Helper loaded: url_helper
INFO - 2017-08-18 11:32:41 --> Helper loaded: file_helper
INFO - 2017-08-18 11:32:41 --> Database Driver Class Initialized
INFO - 2017-08-18 11:32:41 --> Email Class Initialized
DEBUG - 2017-08-18 11:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:32:41 --> Table Class Initialized
INFO - 2017-08-18 11:32:41 --> Controller Class Initialized
INFO - 2017-08-18 11:32:41 --> Helper loaded: form_helper
INFO - 2017-08-18 11:32:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:32:41 --> Final output sent to browser
DEBUG - 2017-08-18 11:32:41 --> Total execution time: 0.1951
INFO - 2017-08-18 11:32:45 --> Config Class Initialized
INFO - 2017-08-18 11:32:45 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:32:45 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:32:45 --> Utf8 Class Initialized
INFO - 2017-08-18 11:32:45 --> URI Class Initialized
INFO - 2017-08-18 11:32:45 --> Router Class Initialized
INFO - 2017-08-18 11:32:45 --> Output Class Initialized
INFO - 2017-08-18 11:32:45 --> Security Class Initialized
DEBUG - 2017-08-18 11:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:32:45 --> Input Class Initialized
INFO - 2017-08-18 11:32:45 --> Language Class Initialized
INFO - 2017-08-18 11:32:45 --> Loader Class Initialized
INFO - 2017-08-18 11:32:45 --> Helper loaded: url_helper
INFO - 2017-08-18 11:32:45 --> Helper loaded: file_helper
INFO - 2017-08-18 11:32:45 --> Database Driver Class Initialized
INFO - 2017-08-18 11:32:45 --> Email Class Initialized
DEBUG - 2017-08-18 11:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:32:45 --> Table Class Initialized
INFO - 2017-08-18 11:32:46 --> Controller Class Initialized
INFO - 2017-08-18 11:32:46 --> Helper loaded: form_helper
INFO - 2017-08-18 11:32:46 --> Final output sent to browser
DEBUG - 2017-08-18 11:32:46 --> Total execution time: 0.1907
INFO - 2017-08-18 11:32:48 --> Config Class Initialized
INFO - 2017-08-18 11:32:48 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:32:48 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:32:48 --> Utf8 Class Initialized
INFO - 2017-08-18 11:32:48 --> URI Class Initialized
INFO - 2017-08-18 11:32:48 --> Router Class Initialized
INFO - 2017-08-18 11:32:48 --> Output Class Initialized
INFO - 2017-08-18 11:32:48 --> Security Class Initialized
DEBUG - 2017-08-18 11:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:32:48 --> Input Class Initialized
INFO - 2017-08-18 11:32:48 --> Language Class Initialized
INFO - 2017-08-18 11:32:48 --> Loader Class Initialized
INFO - 2017-08-18 11:32:48 --> Helper loaded: url_helper
INFO - 2017-08-18 11:32:48 --> Helper loaded: file_helper
INFO - 2017-08-18 11:32:48 --> Database Driver Class Initialized
INFO - 2017-08-18 11:32:48 --> Email Class Initialized
DEBUG - 2017-08-18 11:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:32:48 --> Table Class Initialized
INFO - 2017-08-18 11:32:48 --> Controller Class Initialized
INFO - 2017-08-18 11:32:48 --> Helper loaded: form_helper
INFO - 2017-08-18 11:32:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:32:48 --> Final output sent to browser
DEBUG - 2017-08-18 11:32:48 --> Total execution time: 0.2072
INFO - 2017-08-18 11:33:27 --> Config Class Initialized
INFO - 2017-08-18 11:33:27 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:33:27 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:33:27 --> Utf8 Class Initialized
INFO - 2017-08-18 11:33:27 --> URI Class Initialized
INFO - 2017-08-18 11:33:27 --> Router Class Initialized
INFO - 2017-08-18 11:33:27 --> Output Class Initialized
INFO - 2017-08-18 11:33:27 --> Security Class Initialized
DEBUG - 2017-08-18 11:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:33:27 --> Input Class Initialized
INFO - 2017-08-18 11:33:27 --> Language Class Initialized
INFO - 2017-08-18 11:33:27 --> Loader Class Initialized
INFO - 2017-08-18 11:33:27 --> Helper loaded: url_helper
INFO - 2017-08-18 11:33:27 --> Helper loaded: file_helper
INFO - 2017-08-18 11:33:27 --> Database Driver Class Initialized
INFO - 2017-08-18 11:33:27 --> Email Class Initialized
DEBUG - 2017-08-18 11:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:33:27 --> Table Class Initialized
INFO - 2017-08-18 11:33:27 --> Controller Class Initialized
INFO - 2017-08-18 11:33:27 --> Helper loaded: form_helper
INFO - 2017-08-18 11:33:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:33:27 --> Final output sent to browser
DEBUG - 2017-08-18 11:33:27 --> Total execution time: 0.2338
INFO - 2017-08-18 11:33:31 --> Config Class Initialized
INFO - 2017-08-18 11:33:31 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:33:31 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:33:31 --> Utf8 Class Initialized
INFO - 2017-08-18 11:33:31 --> URI Class Initialized
INFO - 2017-08-18 11:33:31 --> Router Class Initialized
INFO - 2017-08-18 11:33:32 --> Output Class Initialized
INFO - 2017-08-18 11:33:32 --> Security Class Initialized
DEBUG - 2017-08-18 11:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:33:32 --> Input Class Initialized
INFO - 2017-08-18 11:33:32 --> Language Class Initialized
INFO - 2017-08-18 11:33:32 --> Loader Class Initialized
INFO - 2017-08-18 11:33:32 --> Helper loaded: url_helper
INFO - 2017-08-18 11:33:32 --> Helper loaded: file_helper
INFO - 2017-08-18 11:33:32 --> Database Driver Class Initialized
INFO - 2017-08-18 11:33:32 --> Email Class Initialized
DEBUG - 2017-08-18 11:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:33:32 --> Table Class Initialized
INFO - 2017-08-18 11:33:32 --> Controller Class Initialized
INFO - 2017-08-18 11:33:32 --> Helper loaded: form_helper
INFO - 2017-08-18 11:33:32 --> Final output sent to browser
DEBUG - 2017-08-18 11:33:32 --> Total execution time: 0.1804
INFO - 2017-08-18 11:33:34 --> Config Class Initialized
INFO - 2017-08-18 11:33:34 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:33:34 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:33:34 --> Utf8 Class Initialized
INFO - 2017-08-18 11:33:34 --> URI Class Initialized
INFO - 2017-08-18 11:33:34 --> Router Class Initialized
INFO - 2017-08-18 11:33:34 --> Output Class Initialized
INFO - 2017-08-18 11:33:34 --> Security Class Initialized
DEBUG - 2017-08-18 11:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:33:34 --> Input Class Initialized
INFO - 2017-08-18 11:33:34 --> Language Class Initialized
INFO - 2017-08-18 11:33:34 --> Loader Class Initialized
INFO - 2017-08-18 11:33:34 --> Helper loaded: url_helper
INFO - 2017-08-18 11:33:34 --> Helper loaded: file_helper
INFO - 2017-08-18 11:33:34 --> Database Driver Class Initialized
INFO - 2017-08-18 11:33:34 --> Email Class Initialized
DEBUG - 2017-08-18 11:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:33:34 --> Table Class Initialized
INFO - 2017-08-18 11:33:34 --> Controller Class Initialized
INFO - 2017-08-18 11:33:34 --> Helper loaded: form_helper
INFO - 2017-08-18 11:33:34 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:33:34 --> Final output sent to browser
DEBUG - 2017-08-18 11:33:34 --> Total execution time: 0.1934
INFO - 2017-08-18 11:33:39 --> Config Class Initialized
INFO - 2017-08-18 11:33:39 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:33:39 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:33:39 --> Utf8 Class Initialized
INFO - 2017-08-18 11:33:39 --> URI Class Initialized
INFO - 2017-08-18 11:33:39 --> Router Class Initialized
INFO - 2017-08-18 11:33:39 --> Output Class Initialized
INFO - 2017-08-18 11:33:39 --> Security Class Initialized
DEBUG - 2017-08-18 11:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:33:39 --> Input Class Initialized
INFO - 2017-08-18 11:33:39 --> Language Class Initialized
INFO - 2017-08-18 11:33:39 --> Loader Class Initialized
INFO - 2017-08-18 11:33:39 --> Helper loaded: url_helper
INFO - 2017-08-18 11:33:39 --> Helper loaded: file_helper
INFO - 2017-08-18 11:33:39 --> Database Driver Class Initialized
INFO - 2017-08-18 11:33:39 --> Email Class Initialized
DEBUG - 2017-08-18 11:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:33:39 --> Table Class Initialized
INFO - 2017-08-18 11:33:39 --> Controller Class Initialized
INFO - 2017-08-18 11:33:39 --> Helper loaded: form_helper
INFO - 2017-08-18 11:33:39 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:33:39 --> Final output sent to browser
DEBUG - 2017-08-18 11:33:39 --> Total execution time: 0.1879
INFO - 2017-08-18 11:34:30 --> Config Class Initialized
INFO - 2017-08-18 11:34:30 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:34:30 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:34:30 --> Utf8 Class Initialized
INFO - 2017-08-18 11:34:30 --> URI Class Initialized
INFO - 2017-08-18 11:34:30 --> Router Class Initialized
INFO - 2017-08-18 11:34:30 --> Output Class Initialized
INFO - 2017-08-18 11:34:30 --> Security Class Initialized
DEBUG - 2017-08-18 11:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:34:30 --> Input Class Initialized
INFO - 2017-08-18 11:34:30 --> Language Class Initialized
INFO - 2017-08-18 11:34:30 --> Loader Class Initialized
INFO - 2017-08-18 11:34:30 --> Helper loaded: url_helper
INFO - 2017-08-18 11:34:30 --> Helper loaded: file_helper
INFO - 2017-08-18 11:34:30 --> Database Driver Class Initialized
INFO - 2017-08-18 11:34:30 --> Email Class Initialized
DEBUG - 2017-08-18 11:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:34:30 --> Table Class Initialized
INFO - 2017-08-18 11:34:30 --> Controller Class Initialized
INFO - 2017-08-18 11:34:30 --> Helper loaded: form_helper
INFO - 2017-08-18 11:34:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:34:30 --> Final output sent to browser
DEBUG - 2017-08-18 11:34:30 --> Total execution time: 0.1967
INFO - 2017-08-18 11:34:33 --> Config Class Initialized
INFO - 2017-08-18 11:34:33 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:34:33 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:34:33 --> Utf8 Class Initialized
INFO - 2017-08-18 11:34:33 --> URI Class Initialized
INFO - 2017-08-18 11:34:33 --> Router Class Initialized
INFO - 2017-08-18 11:34:33 --> Output Class Initialized
INFO - 2017-08-18 11:34:33 --> Security Class Initialized
DEBUG - 2017-08-18 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:34:33 --> Input Class Initialized
INFO - 2017-08-18 11:34:33 --> Language Class Initialized
INFO - 2017-08-18 11:34:33 --> Loader Class Initialized
INFO - 2017-08-18 11:34:33 --> Helper loaded: url_helper
INFO - 2017-08-18 11:34:33 --> Helper loaded: file_helper
INFO - 2017-08-18 11:34:33 --> Database Driver Class Initialized
INFO - 2017-08-18 11:34:33 --> Email Class Initialized
DEBUG - 2017-08-18 11:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:34:33 --> Table Class Initialized
INFO - 2017-08-18 11:34:33 --> Controller Class Initialized
INFO - 2017-08-18 11:34:33 --> Helper loaded: form_helper
INFO - 2017-08-18 11:34:33 --> Final output sent to browser
DEBUG - 2017-08-18 11:34:33 --> Total execution time: 0.1843
INFO - 2017-08-18 11:34:39 --> Config Class Initialized
INFO - 2017-08-18 11:34:39 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:34:39 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:34:39 --> Utf8 Class Initialized
INFO - 2017-08-18 11:34:39 --> URI Class Initialized
INFO - 2017-08-18 11:34:39 --> Router Class Initialized
INFO - 2017-08-18 11:34:39 --> Output Class Initialized
INFO - 2017-08-18 11:34:39 --> Security Class Initialized
DEBUG - 2017-08-18 11:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:34:39 --> Input Class Initialized
INFO - 2017-08-18 11:34:39 --> Language Class Initialized
INFO - 2017-08-18 11:34:39 --> Loader Class Initialized
INFO - 2017-08-18 11:34:39 --> Helper loaded: url_helper
INFO - 2017-08-18 11:34:39 --> Helper loaded: file_helper
INFO - 2017-08-18 11:34:39 --> Database Driver Class Initialized
INFO - 2017-08-18 11:34:39 --> Email Class Initialized
DEBUG - 2017-08-18 11:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:34:39 --> Table Class Initialized
INFO - 2017-08-18 11:34:39 --> Controller Class Initialized
INFO - 2017-08-18 11:34:39 --> Helper loaded: form_helper
INFO - 2017-08-18 11:34:39 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:34:39 --> Final output sent to browser
DEBUG - 2017-08-18 11:34:39 --> Total execution time: 0.1978
INFO - 2017-08-18 11:38:03 --> Config Class Initialized
INFO - 2017-08-18 11:38:03 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:38:03 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:38:03 --> Utf8 Class Initialized
INFO - 2017-08-18 11:38:03 --> URI Class Initialized
INFO - 2017-08-18 11:38:03 --> Router Class Initialized
INFO - 2017-08-18 11:38:03 --> Output Class Initialized
INFO - 2017-08-18 11:38:03 --> Security Class Initialized
DEBUG - 2017-08-18 11:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:38:03 --> Input Class Initialized
INFO - 2017-08-18 11:38:03 --> Language Class Initialized
INFO - 2017-08-18 11:38:03 --> Loader Class Initialized
INFO - 2017-08-18 11:38:03 --> Helper loaded: url_helper
INFO - 2017-08-18 11:38:03 --> Helper loaded: file_helper
INFO - 2017-08-18 11:38:03 --> Database Driver Class Initialized
INFO - 2017-08-18 11:38:03 --> Email Class Initialized
DEBUG - 2017-08-18 11:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:38:03 --> Table Class Initialized
INFO - 2017-08-18 11:38:03 --> Controller Class Initialized
INFO - 2017-08-18 11:38:03 --> Helper loaded: form_helper
INFO - 2017-08-18 11:38:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:38:03 --> Final output sent to browser
DEBUG - 2017-08-18 11:38:03 --> Total execution time: 0.2436
INFO - 2017-08-18 11:38:11 --> Config Class Initialized
INFO - 2017-08-18 11:38:11 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:38:11 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:38:11 --> Utf8 Class Initialized
INFO - 2017-08-18 11:38:11 --> URI Class Initialized
INFO - 2017-08-18 11:38:11 --> Router Class Initialized
INFO - 2017-08-18 11:38:11 --> Output Class Initialized
INFO - 2017-08-18 11:38:11 --> Security Class Initialized
DEBUG - 2017-08-18 11:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:38:11 --> Input Class Initialized
INFO - 2017-08-18 11:38:11 --> Language Class Initialized
INFO - 2017-08-18 11:38:11 --> Loader Class Initialized
INFO - 2017-08-18 11:38:11 --> Helper loaded: url_helper
INFO - 2017-08-18 11:38:11 --> Helper loaded: file_helper
INFO - 2017-08-18 11:38:11 --> Database Driver Class Initialized
INFO - 2017-08-18 11:38:11 --> Email Class Initialized
DEBUG - 2017-08-18 11:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:38:11 --> Table Class Initialized
INFO - 2017-08-18 11:38:11 --> Controller Class Initialized
INFO - 2017-08-18 11:38:11 --> Helper loaded: form_helper
INFO - 2017-08-18 11:38:11 --> Final output sent to browser
DEBUG - 2017-08-18 11:38:11 --> Total execution time: 0.1894
INFO - 2017-08-18 11:38:23 --> Config Class Initialized
INFO - 2017-08-18 11:38:23 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:38:23 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:38:23 --> Utf8 Class Initialized
INFO - 2017-08-18 11:38:23 --> URI Class Initialized
INFO - 2017-08-18 11:38:23 --> Router Class Initialized
INFO - 2017-08-18 11:38:23 --> Output Class Initialized
INFO - 2017-08-18 11:38:23 --> Security Class Initialized
DEBUG - 2017-08-18 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:38:24 --> Input Class Initialized
INFO - 2017-08-18 11:38:24 --> Language Class Initialized
INFO - 2017-08-18 11:38:24 --> Loader Class Initialized
INFO - 2017-08-18 11:38:24 --> Helper loaded: url_helper
INFO - 2017-08-18 11:38:24 --> Helper loaded: file_helper
INFO - 2017-08-18 11:38:24 --> Database Driver Class Initialized
INFO - 2017-08-18 11:38:24 --> Email Class Initialized
DEBUG - 2017-08-18 11:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:38:24 --> Table Class Initialized
INFO - 2017-08-18 11:38:24 --> Controller Class Initialized
INFO - 2017-08-18 11:38:24 --> Helper loaded: form_helper
INFO - 2017-08-18 11:38:24 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:38:24 --> Final output sent to browser
DEBUG - 2017-08-18 11:38:24 --> Total execution time: 0.2031
INFO - 2017-08-18 11:38:25 --> Config Class Initialized
INFO - 2017-08-18 11:38:25 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:38:25 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:38:25 --> Utf8 Class Initialized
INFO - 2017-08-18 11:38:25 --> URI Class Initialized
INFO - 2017-08-18 11:38:25 --> Router Class Initialized
INFO - 2017-08-18 11:38:25 --> Output Class Initialized
INFO - 2017-08-18 11:38:25 --> Security Class Initialized
DEBUG - 2017-08-18 11:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:38:25 --> Input Class Initialized
INFO - 2017-08-18 11:38:25 --> Language Class Initialized
INFO - 2017-08-18 11:38:25 --> Loader Class Initialized
INFO - 2017-08-18 11:38:25 --> Helper loaded: url_helper
INFO - 2017-08-18 11:38:25 --> Helper loaded: file_helper
INFO - 2017-08-18 11:38:25 --> Database Driver Class Initialized
INFO - 2017-08-18 11:38:25 --> Email Class Initialized
DEBUG - 2017-08-18 11:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:38:25 --> Table Class Initialized
INFO - 2017-08-18 11:38:25 --> Controller Class Initialized
INFO - 2017-08-18 11:38:25 --> Helper loaded: form_helper
INFO - 2017-08-18 11:38:25 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:38:25 --> Final output sent to browser
DEBUG - 2017-08-18 11:38:25 --> Total execution time: 0.1893
INFO - 2017-08-18 11:38:28 --> Config Class Initialized
INFO - 2017-08-18 11:38:28 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:38:28 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:38:28 --> Utf8 Class Initialized
INFO - 2017-08-18 11:38:28 --> URI Class Initialized
INFO - 2017-08-18 11:38:28 --> Router Class Initialized
INFO - 2017-08-18 11:38:28 --> Output Class Initialized
INFO - 2017-08-18 11:38:28 --> Security Class Initialized
DEBUG - 2017-08-18 11:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:38:28 --> Input Class Initialized
INFO - 2017-08-18 11:38:28 --> Language Class Initialized
INFO - 2017-08-18 11:38:28 --> Loader Class Initialized
INFO - 2017-08-18 11:38:28 --> Helper loaded: url_helper
INFO - 2017-08-18 11:38:28 --> Helper loaded: file_helper
INFO - 2017-08-18 11:38:28 --> Database Driver Class Initialized
INFO - 2017-08-18 11:38:28 --> Email Class Initialized
DEBUG - 2017-08-18 11:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:38:28 --> Table Class Initialized
INFO - 2017-08-18 11:38:28 --> Controller Class Initialized
INFO - 2017-08-18 11:38:28 --> Helper loaded: form_helper
INFO - 2017-08-18 11:38:28 --> Final output sent to browser
DEBUG - 2017-08-18 11:38:28 --> Total execution time: 0.1943
INFO - 2017-08-18 11:39:10 --> Config Class Initialized
INFO - 2017-08-18 11:39:10 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:39:10 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:39:10 --> Utf8 Class Initialized
INFO - 2017-08-18 11:39:10 --> URI Class Initialized
INFO - 2017-08-18 11:39:10 --> Router Class Initialized
INFO - 2017-08-18 11:39:10 --> Output Class Initialized
INFO - 2017-08-18 11:39:10 --> Security Class Initialized
DEBUG - 2017-08-18 11:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:39:10 --> Input Class Initialized
INFO - 2017-08-18 11:39:10 --> Language Class Initialized
INFO - 2017-08-18 11:39:11 --> Loader Class Initialized
INFO - 2017-08-18 11:39:11 --> Helper loaded: url_helper
INFO - 2017-08-18 11:39:11 --> Helper loaded: file_helper
INFO - 2017-08-18 11:39:11 --> Database Driver Class Initialized
INFO - 2017-08-18 11:39:11 --> Email Class Initialized
DEBUG - 2017-08-18 11:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:39:11 --> Table Class Initialized
INFO - 2017-08-18 11:39:11 --> Controller Class Initialized
INFO - 2017-08-18 11:39:11 --> Helper loaded: form_helper
INFO - 2017-08-18 11:39:11 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:39:11 --> Final output sent to browser
DEBUG - 2017-08-18 11:39:11 --> Total execution time: 0.2372
INFO - 2017-08-18 11:39:32 --> Config Class Initialized
INFO - 2017-08-18 11:39:32 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:39:32 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:39:32 --> Utf8 Class Initialized
INFO - 2017-08-18 11:39:32 --> URI Class Initialized
INFO - 2017-08-18 11:39:32 --> Router Class Initialized
INFO - 2017-08-18 11:39:32 --> Output Class Initialized
INFO - 2017-08-18 11:39:32 --> Security Class Initialized
DEBUG - 2017-08-18 11:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:39:32 --> Input Class Initialized
INFO - 2017-08-18 11:39:32 --> Language Class Initialized
INFO - 2017-08-18 11:39:32 --> Loader Class Initialized
INFO - 2017-08-18 11:39:32 --> Helper loaded: url_helper
INFO - 2017-08-18 11:39:32 --> Helper loaded: file_helper
INFO - 2017-08-18 11:39:32 --> Database Driver Class Initialized
INFO - 2017-08-18 11:39:32 --> Email Class Initialized
DEBUG - 2017-08-18 11:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:39:32 --> Table Class Initialized
INFO - 2017-08-18 11:39:32 --> Controller Class Initialized
INFO - 2017-08-18 11:39:32 --> Helper loaded: form_helper
INFO - 2017-08-18 11:39:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:39:32 --> Final output sent to browser
INFO - 2017-08-18 11:39:32 --> Config Class Initialized
INFO - 2017-08-18 11:39:32 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:39:32 --> Total execution time: 0.2682
DEBUG - 2017-08-18 11:39:32 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:39:32 --> Utf8 Class Initialized
INFO - 2017-08-18 11:39:32 --> URI Class Initialized
INFO - 2017-08-18 11:39:32 --> Router Class Initialized
INFO - 2017-08-18 11:39:32 --> Output Class Initialized
INFO - 2017-08-18 11:39:32 --> Security Class Initialized
DEBUG - 2017-08-18 11:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:39:32 --> Input Class Initialized
INFO - 2017-08-18 11:39:32 --> Language Class Initialized
INFO - 2017-08-18 11:39:32 --> Loader Class Initialized
INFO - 2017-08-18 11:39:32 --> Helper loaded: url_helper
INFO - 2017-08-18 11:39:32 --> Helper loaded: file_helper
INFO - 2017-08-18 11:39:32 --> Database Driver Class Initialized
INFO - 2017-08-18 11:39:32 --> Email Class Initialized
DEBUG - 2017-08-18 11:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:39:32 --> Table Class Initialized
INFO - 2017-08-18 11:39:32 --> Controller Class Initialized
INFO - 2017-08-18 11:39:32 --> Helper loaded: form_helper
INFO - 2017-08-18 11:39:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:39:32 --> Final output sent to browser
DEBUG - 2017-08-18 11:39:32 --> Total execution time: 0.2215
INFO - 2017-08-18 11:40:16 --> Config Class Initialized
INFO - 2017-08-18 11:40:16 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:40:16 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:40:16 --> Utf8 Class Initialized
INFO - 2017-08-18 11:40:16 --> URI Class Initialized
INFO - 2017-08-18 11:40:16 --> Router Class Initialized
INFO - 2017-08-18 11:40:16 --> Output Class Initialized
INFO - 2017-08-18 11:40:17 --> Security Class Initialized
DEBUG - 2017-08-18 11:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:40:17 --> Input Class Initialized
INFO - 2017-08-18 11:40:17 --> Language Class Initialized
INFO - 2017-08-18 11:40:17 --> Loader Class Initialized
INFO - 2017-08-18 11:40:17 --> Helper loaded: url_helper
INFO - 2017-08-18 11:40:17 --> Helper loaded: file_helper
INFO - 2017-08-18 11:40:17 --> Database Driver Class Initialized
INFO - 2017-08-18 11:40:17 --> Email Class Initialized
DEBUG - 2017-08-18 11:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:40:17 --> Table Class Initialized
INFO - 2017-08-18 11:40:17 --> Controller Class Initialized
INFO - 2017-08-18 11:40:17 --> Helper loaded: form_helper
INFO - 2017-08-18 11:40:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:40:17 --> Final output sent to browser
DEBUG - 2017-08-18 11:40:17 --> Total execution time: 0.2232
INFO - 2017-08-18 11:43:30 --> Config Class Initialized
INFO - 2017-08-18 11:43:30 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:43:30 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:43:30 --> Utf8 Class Initialized
INFO - 2017-08-18 11:43:30 --> URI Class Initialized
INFO - 2017-08-18 11:43:30 --> Router Class Initialized
INFO - 2017-08-18 11:43:30 --> Output Class Initialized
INFO - 2017-08-18 11:43:30 --> Security Class Initialized
DEBUG - 2017-08-18 11:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:43:30 --> Input Class Initialized
INFO - 2017-08-18 11:43:30 --> Language Class Initialized
INFO - 2017-08-18 11:43:30 --> Loader Class Initialized
INFO - 2017-08-18 11:43:30 --> Helper loaded: url_helper
INFO - 2017-08-18 11:43:30 --> Helper loaded: file_helper
INFO - 2017-08-18 11:43:30 --> Database Driver Class Initialized
INFO - 2017-08-18 11:43:30 --> Email Class Initialized
DEBUG - 2017-08-18 11:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:43:30 --> Table Class Initialized
INFO - 2017-08-18 11:43:30 --> Controller Class Initialized
INFO - 2017-08-18 11:43:30 --> Helper loaded: form_helper
INFO - 2017-08-18 11:43:30 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:43:30 --> Final output sent to browser
DEBUG - 2017-08-18 11:43:30 --> Total execution time: 0.2754
INFO - 2017-08-18 11:52:04 --> Config Class Initialized
INFO - 2017-08-18 11:52:04 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:52:04 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:52:04 --> Utf8 Class Initialized
INFO - 2017-08-18 11:52:04 --> URI Class Initialized
INFO - 2017-08-18 11:52:04 --> Router Class Initialized
INFO - 2017-08-18 11:52:04 --> Output Class Initialized
INFO - 2017-08-18 11:52:04 --> Security Class Initialized
DEBUG - 2017-08-18 11:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:52:04 --> Input Class Initialized
INFO - 2017-08-18 11:52:04 --> Language Class Initialized
INFO - 2017-08-18 11:52:04 --> Loader Class Initialized
INFO - 2017-08-18 11:52:04 --> Helper loaded: url_helper
INFO - 2017-08-18 11:52:04 --> Helper loaded: file_helper
INFO - 2017-08-18 11:52:04 --> Database Driver Class Initialized
INFO - 2017-08-18 11:52:04 --> Email Class Initialized
DEBUG - 2017-08-18 11:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:52:04 --> Table Class Initialized
INFO - 2017-08-18 11:52:04 --> Controller Class Initialized
INFO - 2017-08-18 11:52:04 --> Helper loaded: form_helper
INFO - 2017-08-18 11:52:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:52:04 --> Final output sent to browser
DEBUG - 2017-08-18 11:52:04 --> Total execution time: 0.2170
INFO - 2017-08-18 11:53:23 --> Config Class Initialized
INFO - 2017-08-18 11:53:23 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:53:23 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:53:23 --> Utf8 Class Initialized
INFO - 2017-08-18 11:53:23 --> URI Class Initialized
INFO - 2017-08-18 11:53:23 --> Router Class Initialized
INFO - 2017-08-18 11:53:23 --> Output Class Initialized
INFO - 2017-08-18 11:53:23 --> Security Class Initialized
DEBUG - 2017-08-18 11:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:53:23 --> Input Class Initialized
INFO - 2017-08-18 11:53:23 --> Language Class Initialized
INFO - 2017-08-18 11:53:23 --> Loader Class Initialized
INFO - 2017-08-18 11:53:23 --> Helper loaded: url_helper
INFO - 2017-08-18 11:53:23 --> Helper loaded: file_helper
INFO - 2017-08-18 11:53:23 --> Database Driver Class Initialized
INFO - 2017-08-18 11:53:23 --> Email Class Initialized
DEBUG - 2017-08-18 11:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:53:23 --> Table Class Initialized
INFO - 2017-08-18 11:53:23 --> Controller Class Initialized
INFO - 2017-08-18 11:53:23 --> Helper loaded: form_helper
INFO - 2017-08-18 11:53:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:53:23 --> Final output sent to browser
DEBUG - 2017-08-18 11:53:23 --> Total execution time: 0.2412
INFO - 2017-08-18 11:53:52 --> Config Class Initialized
INFO - 2017-08-18 11:53:52 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:53:52 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:53:52 --> Utf8 Class Initialized
INFO - 2017-08-18 11:53:52 --> URI Class Initialized
INFO - 2017-08-18 11:53:52 --> Router Class Initialized
INFO - 2017-08-18 11:53:52 --> Output Class Initialized
INFO - 2017-08-18 11:53:52 --> Security Class Initialized
DEBUG - 2017-08-18 11:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:53:52 --> Input Class Initialized
INFO - 2017-08-18 11:53:52 --> Language Class Initialized
INFO - 2017-08-18 11:53:52 --> Loader Class Initialized
INFO - 2017-08-18 11:53:52 --> Helper loaded: url_helper
INFO - 2017-08-18 11:53:52 --> Helper loaded: file_helper
INFO - 2017-08-18 11:53:52 --> Database Driver Class Initialized
INFO - 2017-08-18 11:53:52 --> Email Class Initialized
DEBUG - 2017-08-18 11:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:53:52 --> Table Class Initialized
INFO - 2017-08-18 11:53:52 --> Controller Class Initialized
INFO - 2017-08-18 11:53:52 --> Helper loaded: form_helper
INFO - 2017-08-18 11:53:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:53:52 --> Final output sent to browser
DEBUG - 2017-08-18 11:53:52 --> Total execution time: 0.2287
INFO - 2017-08-18 11:53:58 --> Config Class Initialized
INFO - 2017-08-18 11:53:58 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:53:58 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:53:58 --> Utf8 Class Initialized
INFO - 2017-08-18 11:53:58 --> URI Class Initialized
INFO - 2017-08-18 11:53:58 --> Router Class Initialized
INFO - 2017-08-18 11:53:58 --> Output Class Initialized
INFO - 2017-08-18 11:53:58 --> Security Class Initialized
DEBUG - 2017-08-18 11:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:53:58 --> Input Class Initialized
INFO - 2017-08-18 11:53:58 --> Language Class Initialized
INFO - 2017-08-18 11:53:58 --> Loader Class Initialized
INFO - 2017-08-18 11:53:58 --> Helper loaded: url_helper
INFO - 2017-08-18 11:53:58 --> Helper loaded: file_helper
INFO - 2017-08-18 11:53:58 --> Database Driver Class Initialized
INFO - 2017-08-18 11:53:58 --> Email Class Initialized
DEBUG - 2017-08-18 11:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:53:58 --> Table Class Initialized
INFO - 2017-08-18 11:53:58 --> Controller Class Initialized
INFO - 2017-08-18 11:53:58 --> Helper loaded: form_helper
INFO - 2017-08-18 11:53:58 --> Upload Class Initialized
INFO - 2017-08-18 11:53:58 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 11:53:58 --> You did not select a file to upload.
INFO - 2017-08-18 11:53:58 --> Final output sent to browser
DEBUG - 2017-08-18 11:53:58 --> Total execution time: 0.3412
INFO - 2017-08-18 11:54:06 --> Config Class Initialized
INFO - 2017-08-18 11:54:06 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:54:06 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:54:06 --> Utf8 Class Initialized
INFO - 2017-08-18 11:54:06 --> URI Class Initialized
INFO - 2017-08-18 11:54:06 --> Router Class Initialized
INFO - 2017-08-18 11:54:06 --> Output Class Initialized
INFO - 2017-08-18 11:54:06 --> Security Class Initialized
DEBUG - 2017-08-18 11:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:54:06 --> Input Class Initialized
INFO - 2017-08-18 11:54:06 --> Language Class Initialized
INFO - 2017-08-18 11:54:06 --> Loader Class Initialized
INFO - 2017-08-18 11:54:06 --> Helper loaded: url_helper
INFO - 2017-08-18 11:54:06 --> Helper loaded: file_helper
INFO - 2017-08-18 11:54:06 --> Database Driver Class Initialized
INFO - 2017-08-18 11:54:06 --> Email Class Initialized
DEBUG - 2017-08-18 11:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:54:06 --> Table Class Initialized
INFO - 2017-08-18 11:54:06 --> Controller Class Initialized
INFO - 2017-08-18 11:54:06 --> Helper loaded: form_helper
INFO - 2017-08-18 11:54:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:54:06 --> Final output sent to browser
DEBUG - 2017-08-18 11:54:06 --> Total execution time: 0.2550
INFO - 2017-08-18 11:54:11 --> Config Class Initialized
INFO - 2017-08-18 11:54:11 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:54:11 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:54:11 --> Utf8 Class Initialized
INFO - 2017-08-18 11:54:11 --> URI Class Initialized
INFO - 2017-08-18 11:54:11 --> Router Class Initialized
INFO - 2017-08-18 11:54:11 --> Output Class Initialized
INFO - 2017-08-18 11:54:11 --> Security Class Initialized
DEBUG - 2017-08-18 11:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:54:11 --> Input Class Initialized
INFO - 2017-08-18 11:54:11 --> Language Class Initialized
ERROR - 2017-08-18 11:54:11 --> 404 Page Not Found: Spost/edit_img
INFO - 2017-08-18 11:54:26 --> Config Class Initialized
INFO - 2017-08-18 11:54:26 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:54:26 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:54:26 --> Utf8 Class Initialized
INFO - 2017-08-18 11:54:26 --> URI Class Initialized
INFO - 2017-08-18 11:54:26 --> Router Class Initialized
INFO - 2017-08-18 11:54:26 --> Output Class Initialized
INFO - 2017-08-18 11:54:26 --> Security Class Initialized
DEBUG - 2017-08-18 11:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:54:26 --> Input Class Initialized
INFO - 2017-08-18 11:54:26 --> Language Class Initialized
INFO - 2017-08-18 11:54:26 --> Loader Class Initialized
INFO - 2017-08-18 11:54:26 --> Helper loaded: url_helper
INFO - 2017-08-18 11:54:26 --> Helper loaded: file_helper
INFO - 2017-08-18 11:54:26 --> Database Driver Class Initialized
INFO - 2017-08-18 11:54:26 --> Email Class Initialized
DEBUG - 2017-08-18 11:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 11:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 11:54:26 --> Table Class Initialized
INFO - 2017-08-18 11:54:27 --> Controller Class Initialized
INFO - 2017-08-18 11:54:27 --> Helper loaded: form_helper
INFO - 2017-08-18 11:54:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 11:54:27 --> Final output sent to browser
DEBUG - 2017-08-18 11:54:27 --> Total execution time: 0.2491
INFO - 2017-08-18 11:54:32 --> Config Class Initialized
INFO - 2017-08-18 11:54:32 --> Hooks Class Initialized
DEBUG - 2017-08-18 11:54:32 --> UTF-8 Support Enabled
INFO - 2017-08-18 11:54:32 --> Utf8 Class Initialized
INFO - 2017-08-18 11:54:32 --> URI Class Initialized
INFO - 2017-08-18 11:54:32 --> Router Class Initialized
INFO - 2017-08-18 11:54:32 --> Output Class Initialized
INFO - 2017-08-18 11:54:32 --> Security Class Initialized
DEBUG - 2017-08-18 11:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 11:54:32 --> Input Class Initialized
INFO - 2017-08-18 11:54:32 --> Language Class Initialized
ERROR - 2017-08-18 11:54:32 --> 404 Page Not Found: Sdaspost/edit_img
INFO - 2017-08-18 12:00:58 --> Config Class Initialized
INFO - 2017-08-18 12:00:58 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:00:58 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:00:58 --> Utf8 Class Initialized
INFO - 2017-08-18 12:00:58 --> URI Class Initialized
INFO - 2017-08-18 12:00:58 --> Router Class Initialized
INFO - 2017-08-18 12:00:58 --> Output Class Initialized
INFO - 2017-08-18 12:00:58 --> Security Class Initialized
DEBUG - 2017-08-18 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:00:58 --> Input Class Initialized
INFO - 2017-08-18 12:00:58 --> Language Class Initialized
INFO - 2017-08-18 12:00:58 --> Loader Class Initialized
INFO - 2017-08-18 12:00:58 --> Helper loaded: url_helper
INFO - 2017-08-18 12:00:58 --> Helper loaded: file_helper
INFO - 2017-08-18 12:00:59 --> Database Driver Class Initialized
INFO - 2017-08-18 12:00:59 --> Email Class Initialized
DEBUG - 2017-08-18 12:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:00:59 --> Table Class Initialized
INFO - 2017-08-18 12:00:59 --> Controller Class Initialized
INFO - 2017-08-18 12:00:59 --> Helper loaded: form_helper
INFO - 2017-08-18 12:00:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:00:59 --> Final output sent to browser
DEBUG - 2017-08-18 12:00:59 --> Total execution time: 0.2568
INFO - 2017-08-18 12:01:07 --> Config Class Initialized
INFO - 2017-08-18 12:01:07 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:01:07 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:01:07 --> Utf8 Class Initialized
INFO - 2017-08-18 12:01:07 --> URI Class Initialized
INFO - 2017-08-18 12:01:07 --> Router Class Initialized
INFO - 2017-08-18 12:01:07 --> Output Class Initialized
INFO - 2017-08-18 12:01:07 --> Security Class Initialized
DEBUG - 2017-08-18 12:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:01:07 --> Input Class Initialized
INFO - 2017-08-18 12:01:07 --> Language Class Initialized
INFO - 2017-08-18 12:01:07 --> Loader Class Initialized
INFO - 2017-08-18 12:01:07 --> Helper loaded: url_helper
INFO - 2017-08-18 12:01:07 --> Helper loaded: file_helper
INFO - 2017-08-18 12:01:07 --> Database Driver Class Initialized
INFO - 2017-08-18 12:01:07 --> Email Class Initialized
DEBUG - 2017-08-18 12:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:01:07 --> Table Class Initialized
INFO - 2017-08-18 12:01:07 --> Controller Class Initialized
INFO - 2017-08-18 12:01:07 --> Helper loaded: form_helper
INFO - 2017-08-18 12:01:07 --> Upload Class Initialized
INFO - 2017-08-18 12:01:07 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 12:01:07 --> You did not select a file to upload.
INFO - 2017-08-18 12:01:07 --> Final output sent to browser
DEBUG - 2017-08-18 12:01:07 --> Total execution time: 0.2550
INFO - 2017-08-18 12:02:10 --> Config Class Initialized
INFO - 2017-08-18 12:02:10 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:02:10 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:02:10 --> Utf8 Class Initialized
INFO - 2017-08-18 12:02:10 --> URI Class Initialized
INFO - 2017-08-18 12:02:10 --> Router Class Initialized
INFO - 2017-08-18 12:02:10 --> Output Class Initialized
INFO - 2017-08-18 12:02:10 --> Security Class Initialized
DEBUG - 2017-08-18 12:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:02:10 --> Input Class Initialized
INFO - 2017-08-18 12:02:10 --> Language Class Initialized
INFO - 2017-08-18 12:02:10 --> Loader Class Initialized
INFO - 2017-08-18 12:02:10 --> Helper loaded: url_helper
INFO - 2017-08-18 12:02:10 --> Helper loaded: file_helper
INFO - 2017-08-18 12:02:10 --> Database Driver Class Initialized
INFO - 2017-08-18 12:02:10 --> Email Class Initialized
DEBUG - 2017-08-18 12:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:02:10 --> Table Class Initialized
INFO - 2017-08-18 12:02:10 --> Controller Class Initialized
INFO - 2017-08-18 12:02:10 --> Helper loaded: form_helper
INFO - 2017-08-18 12:02:10 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:02:10 --> Final output sent to browser
DEBUG - 2017-08-18 12:02:10 --> Total execution time: 0.2249
INFO - 2017-08-18 12:03:20 --> Config Class Initialized
INFO - 2017-08-18 12:03:20 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:03:20 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:03:20 --> Utf8 Class Initialized
INFO - 2017-08-18 12:03:20 --> URI Class Initialized
INFO - 2017-08-18 12:03:20 --> Router Class Initialized
INFO - 2017-08-18 12:03:20 --> Output Class Initialized
INFO - 2017-08-18 12:03:20 --> Security Class Initialized
DEBUG - 2017-08-18 12:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:03:20 --> Input Class Initialized
INFO - 2017-08-18 12:03:20 --> Language Class Initialized
INFO - 2017-08-18 12:03:20 --> Loader Class Initialized
INFO - 2017-08-18 12:03:20 --> Helper loaded: url_helper
INFO - 2017-08-18 12:03:20 --> Helper loaded: file_helper
INFO - 2017-08-18 12:03:20 --> Database Driver Class Initialized
INFO - 2017-08-18 12:03:20 --> Email Class Initialized
DEBUG - 2017-08-18 12:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:03:20 --> Table Class Initialized
INFO - 2017-08-18 12:03:20 --> Controller Class Initialized
INFO - 2017-08-18 12:03:20 --> Helper loaded: form_helper
INFO - 2017-08-18 12:03:20 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:03:20 --> Final output sent to browser
DEBUG - 2017-08-18 12:03:20 --> Total execution time: 0.2287
INFO - 2017-08-18 12:04:22 --> Config Class Initialized
INFO - 2017-08-18 12:04:22 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:04:22 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:04:22 --> Utf8 Class Initialized
INFO - 2017-08-18 12:04:22 --> URI Class Initialized
INFO - 2017-08-18 12:04:22 --> Router Class Initialized
INFO - 2017-08-18 12:04:22 --> Output Class Initialized
INFO - 2017-08-18 12:04:22 --> Security Class Initialized
DEBUG - 2017-08-18 12:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:04:22 --> Input Class Initialized
INFO - 2017-08-18 12:04:22 --> Language Class Initialized
INFO - 2017-08-18 12:04:22 --> Loader Class Initialized
INFO - 2017-08-18 12:04:22 --> Helper loaded: url_helper
INFO - 2017-08-18 12:04:22 --> Helper loaded: file_helper
INFO - 2017-08-18 12:04:22 --> Database Driver Class Initialized
INFO - 2017-08-18 12:04:22 --> Email Class Initialized
DEBUG - 2017-08-18 12:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:04:22 --> Table Class Initialized
INFO - 2017-08-18 12:04:22 --> Controller Class Initialized
INFO - 2017-08-18 12:04:22 --> Helper loaded: form_helper
INFO - 2017-08-18 12:04:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:04:22 --> Final output sent to browser
DEBUG - 2017-08-18 12:04:22 --> Total execution time: 0.2070
INFO - 2017-08-18 12:04:51 --> Config Class Initialized
INFO - 2017-08-18 12:04:51 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:04:51 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:04:51 --> Utf8 Class Initialized
INFO - 2017-08-18 12:04:51 --> URI Class Initialized
INFO - 2017-08-18 12:04:51 --> Router Class Initialized
INFO - 2017-08-18 12:04:52 --> Output Class Initialized
INFO - 2017-08-18 12:04:52 --> Security Class Initialized
DEBUG - 2017-08-18 12:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:04:52 --> Input Class Initialized
INFO - 2017-08-18 12:04:52 --> Language Class Initialized
INFO - 2017-08-18 12:04:52 --> Loader Class Initialized
INFO - 2017-08-18 12:04:52 --> Helper loaded: url_helper
INFO - 2017-08-18 12:04:52 --> Helper loaded: file_helper
INFO - 2017-08-18 12:04:52 --> Database Driver Class Initialized
INFO - 2017-08-18 12:04:52 --> Email Class Initialized
DEBUG - 2017-08-18 12:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:04:52 --> Table Class Initialized
INFO - 2017-08-18 12:04:52 --> Controller Class Initialized
INFO - 2017-08-18 12:04:52 --> Helper loaded: form_helper
INFO - 2017-08-18 12:04:52 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:04:52 --> Final output sent to browser
DEBUG - 2017-08-18 12:04:52 --> Total execution time: 0.2101
INFO - 2017-08-18 12:05:00 --> Config Class Initialized
INFO - 2017-08-18 12:05:00 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:05:00 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:05:00 --> Utf8 Class Initialized
INFO - 2017-08-18 12:05:00 --> URI Class Initialized
INFO - 2017-08-18 12:05:00 --> Router Class Initialized
INFO - 2017-08-18 12:05:01 --> Output Class Initialized
INFO - 2017-08-18 12:05:01 --> Security Class Initialized
DEBUG - 2017-08-18 12:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:05:01 --> Input Class Initialized
INFO - 2017-08-18 12:05:01 --> Language Class Initialized
INFO - 2017-08-18 12:05:01 --> Loader Class Initialized
INFO - 2017-08-18 12:05:01 --> Helper loaded: url_helper
INFO - 2017-08-18 12:05:01 --> Helper loaded: file_helper
INFO - 2017-08-18 12:05:01 --> Database Driver Class Initialized
INFO - 2017-08-18 12:05:01 --> Email Class Initialized
DEBUG - 2017-08-18 12:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:05:01 --> Table Class Initialized
INFO - 2017-08-18 12:05:01 --> Controller Class Initialized
INFO - 2017-08-18 12:05:01 --> Helper loaded: form_helper
INFO - 2017-08-18 12:05:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:05:01 --> Final output sent to browser
DEBUG - 2017-08-18 12:05:01 --> Total execution time: 0.2321
INFO - 2017-08-18 12:05:48 --> Config Class Initialized
INFO - 2017-08-18 12:05:48 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:05:48 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:05:48 --> Utf8 Class Initialized
INFO - 2017-08-18 12:05:48 --> URI Class Initialized
INFO - 2017-08-18 12:05:48 --> Router Class Initialized
INFO - 2017-08-18 12:05:48 --> Output Class Initialized
INFO - 2017-08-18 12:05:48 --> Security Class Initialized
DEBUG - 2017-08-18 12:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:05:49 --> Input Class Initialized
INFO - 2017-08-18 12:05:49 --> Language Class Initialized
INFO - 2017-08-18 12:05:49 --> Loader Class Initialized
INFO - 2017-08-18 12:05:49 --> Helper loaded: url_helper
INFO - 2017-08-18 12:05:49 --> Helper loaded: file_helper
INFO - 2017-08-18 12:05:49 --> Database Driver Class Initialized
INFO - 2017-08-18 12:05:49 --> Email Class Initialized
DEBUG - 2017-08-18 12:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:05:49 --> Table Class Initialized
INFO - 2017-08-18 12:05:49 --> Controller Class Initialized
INFO - 2017-08-18 12:05:49 --> Helper loaded: form_helper
INFO - 2017-08-18 12:05:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:05:49 --> Final output sent to browser
DEBUG - 2017-08-18 12:05:49 --> Total execution time: 0.2144
INFO - 2017-08-18 12:07:03 --> Config Class Initialized
INFO - 2017-08-18 12:07:03 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:07:03 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:07:03 --> Utf8 Class Initialized
INFO - 2017-08-18 12:07:03 --> URI Class Initialized
INFO - 2017-08-18 12:07:03 --> Router Class Initialized
INFO - 2017-08-18 12:07:03 --> Output Class Initialized
INFO - 2017-08-18 12:07:03 --> Security Class Initialized
DEBUG - 2017-08-18 12:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:07:03 --> Input Class Initialized
INFO - 2017-08-18 12:07:03 --> Language Class Initialized
INFO - 2017-08-18 12:07:03 --> Loader Class Initialized
INFO - 2017-08-18 12:07:03 --> Helper loaded: url_helper
INFO - 2017-08-18 12:07:03 --> Helper loaded: file_helper
INFO - 2017-08-18 12:07:03 --> Database Driver Class Initialized
INFO - 2017-08-18 12:07:03 --> Email Class Initialized
DEBUG - 2017-08-18 12:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:07:03 --> Table Class Initialized
INFO - 2017-08-18 12:07:03 --> Controller Class Initialized
INFO - 2017-08-18 12:07:03 --> Helper loaded: form_helper
INFO - 2017-08-18 12:07:03 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:07:03 --> Final output sent to browser
DEBUG - 2017-08-18 12:07:03 --> Total execution time: 0.2128
INFO - 2017-08-18 12:07:10 --> Config Class Initialized
INFO - 2017-08-18 12:07:10 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:07:10 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:07:10 --> Utf8 Class Initialized
INFO - 2017-08-18 12:07:10 --> URI Class Initialized
INFO - 2017-08-18 12:07:10 --> Router Class Initialized
INFO - 2017-08-18 12:07:10 --> Output Class Initialized
INFO - 2017-08-18 12:07:10 --> Security Class Initialized
DEBUG - 2017-08-18 12:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:07:10 --> Input Class Initialized
INFO - 2017-08-18 12:07:10 --> Language Class Initialized
INFO - 2017-08-18 12:07:10 --> Loader Class Initialized
INFO - 2017-08-18 12:07:10 --> Helper loaded: url_helper
INFO - 2017-08-18 12:07:10 --> Helper loaded: file_helper
INFO - 2017-08-18 12:07:10 --> Database Driver Class Initialized
INFO - 2017-08-18 12:07:10 --> Email Class Initialized
DEBUG - 2017-08-18 12:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:07:10 --> Table Class Initialized
INFO - 2017-08-18 12:07:10 --> Controller Class Initialized
INFO - 2017-08-18 12:07:10 --> Helper loaded: form_helper
INFO - 2017-08-18 12:07:10 --> Upload Class Initialized
INFO - 2017-08-18 12:07:10 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 12:07:10 --> You did not select a file to upload.
INFO - 2017-08-18 12:07:10 --> Final output sent to browser
DEBUG - 2017-08-18 12:07:10 --> Total execution time: 0.2524
INFO - 2017-08-18 12:08:41 --> Config Class Initialized
INFO - 2017-08-18 12:08:41 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:08:41 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:08:41 --> Utf8 Class Initialized
INFO - 2017-08-18 12:08:41 --> URI Class Initialized
INFO - 2017-08-18 12:08:41 --> Router Class Initialized
INFO - 2017-08-18 12:08:41 --> Output Class Initialized
INFO - 2017-08-18 12:08:41 --> Security Class Initialized
DEBUG - 2017-08-18 12:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:08:41 --> Input Class Initialized
INFO - 2017-08-18 12:08:41 --> Language Class Initialized
INFO - 2017-08-18 12:08:41 --> Loader Class Initialized
INFO - 2017-08-18 12:08:41 --> Helper loaded: url_helper
INFO - 2017-08-18 12:08:41 --> Helper loaded: file_helper
INFO - 2017-08-18 12:08:41 --> Database Driver Class Initialized
INFO - 2017-08-18 12:08:41 --> Email Class Initialized
DEBUG - 2017-08-18 12:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:08:41 --> Table Class Initialized
INFO - 2017-08-18 12:08:41 --> Controller Class Initialized
INFO - 2017-08-18 12:08:41 --> Helper loaded: form_helper
INFO - 2017-08-18 12:08:41 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:08:41 --> Final output sent to browser
DEBUG - 2017-08-18 12:08:41 --> Total execution time: 0.2337
INFO - 2017-08-18 12:09:31 --> Config Class Initialized
INFO - 2017-08-18 12:09:31 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:09:31 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:09:31 --> Utf8 Class Initialized
INFO - 2017-08-18 12:09:31 --> URI Class Initialized
INFO - 2017-08-18 12:09:31 --> Router Class Initialized
INFO - 2017-08-18 12:09:31 --> Output Class Initialized
INFO - 2017-08-18 12:09:31 --> Security Class Initialized
DEBUG - 2017-08-18 12:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:09:31 --> Input Class Initialized
INFO - 2017-08-18 12:09:31 --> Language Class Initialized
INFO - 2017-08-18 12:09:31 --> Loader Class Initialized
INFO - 2017-08-18 12:09:31 --> Helper loaded: url_helper
INFO - 2017-08-18 12:09:31 --> Helper loaded: file_helper
INFO - 2017-08-18 12:09:31 --> Database Driver Class Initialized
INFO - 2017-08-18 12:09:31 --> Email Class Initialized
DEBUG - 2017-08-18 12:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:09:31 --> Table Class Initialized
INFO - 2017-08-18 12:09:31 --> Controller Class Initialized
INFO - 2017-08-18 12:09:31 --> Helper loaded: form_helper
INFO - 2017-08-18 12:09:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:09:31 --> Final output sent to browser
DEBUG - 2017-08-18 12:09:31 --> Total execution time: 0.2858
INFO - 2017-08-18 12:09:36 --> Config Class Initialized
INFO - 2017-08-18 12:09:36 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:09:36 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:09:36 --> Utf8 Class Initialized
INFO - 2017-08-18 12:09:36 --> URI Class Initialized
INFO - 2017-08-18 12:09:36 --> Router Class Initialized
INFO - 2017-08-18 12:09:36 --> Output Class Initialized
INFO - 2017-08-18 12:09:36 --> Security Class Initialized
DEBUG - 2017-08-18 12:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:09:36 --> Input Class Initialized
INFO - 2017-08-18 12:09:36 --> Language Class Initialized
INFO - 2017-08-18 12:09:36 --> Loader Class Initialized
INFO - 2017-08-18 12:09:36 --> Helper loaded: url_helper
INFO - 2017-08-18 12:09:37 --> Helper loaded: file_helper
INFO - 2017-08-18 12:09:37 --> Database Driver Class Initialized
INFO - 2017-08-18 12:09:37 --> Email Class Initialized
DEBUG - 2017-08-18 12:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:09:37 --> Table Class Initialized
INFO - 2017-08-18 12:09:37 --> Controller Class Initialized
INFO - 2017-08-18 12:09:37 --> Helper loaded: form_helper
INFO - 2017-08-18 12:09:37 --> Upload Class Initialized
INFO - 2017-08-18 12:09:37 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 12:09:37 --> You did not select a file to upload.
INFO - 2017-08-18 12:09:37 --> Final output sent to browser
DEBUG - 2017-08-18 12:09:37 --> Total execution time: 0.2528
INFO - 2017-08-18 12:09:42 --> Config Class Initialized
INFO - 2017-08-18 12:09:42 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:09:42 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:09:42 --> Utf8 Class Initialized
INFO - 2017-08-18 12:09:42 --> URI Class Initialized
INFO - 2017-08-18 12:09:42 --> Router Class Initialized
INFO - 2017-08-18 12:09:42 --> Output Class Initialized
INFO - 2017-08-18 12:09:42 --> Security Class Initialized
DEBUG - 2017-08-18 12:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:09:42 --> Input Class Initialized
INFO - 2017-08-18 12:09:42 --> Language Class Initialized
INFO - 2017-08-18 12:09:42 --> Loader Class Initialized
INFO - 2017-08-18 12:09:42 --> Helper loaded: url_helper
INFO - 2017-08-18 12:09:42 --> Helper loaded: file_helper
INFO - 2017-08-18 12:09:42 --> Database Driver Class Initialized
INFO - 2017-08-18 12:09:42 --> Email Class Initialized
DEBUG - 2017-08-18 12:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:09:42 --> Table Class Initialized
INFO - 2017-08-18 12:09:42 --> Controller Class Initialized
INFO - 2017-08-18 12:09:42 --> Helper loaded: form_helper
INFO - 2017-08-18 12:09:42 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:09:42 --> Final output sent to browser
DEBUG - 2017-08-18 12:09:42 --> Total execution time: 0.2592
INFO - 2017-08-18 12:09:47 --> Config Class Initialized
INFO - 2017-08-18 12:09:47 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:09:47 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:09:47 --> Utf8 Class Initialized
INFO - 2017-08-18 12:09:47 --> URI Class Initialized
INFO - 2017-08-18 12:09:47 --> Router Class Initialized
INFO - 2017-08-18 12:09:47 --> Output Class Initialized
INFO - 2017-08-18 12:09:47 --> Security Class Initialized
DEBUG - 2017-08-18 12:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:09:48 --> Input Class Initialized
INFO - 2017-08-18 12:09:48 --> Language Class Initialized
ERROR - 2017-08-18 12:09:48 --> 404 Page Not Found: Post/edit_im
INFO - 2017-08-18 12:12:57 --> Config Class Initialized
INFO - 2017-08-18 12:12:57 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:12:57 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:12:57 --> Utf8 Class Initialized
INFO - 2017-08-18 12:12:57 --> URI Class Initialized
INFO - 2017-08-18 12:12:57 --> Router Class Initialized
INFO - 2017-08-18 12:12:57 --> Output Class Initialized
INFO - 2017-08-18 12:12:57 --> Security Class Initialized
DEBUG - 2017-08-18 12:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:12:57 --> Input Class Initialized
INFO - 2017-08-18 12:12:57 --> Language Class Initialized
INFO - 2017-08-18 12:12:57 --> Loader Class Initialized
INFO - 2017-08-18 12:12:57 --> Helper loaded: url_helper
INFO - 2017-08-18 12:12:57 --> Helper loaded: file_helper
INFO - 2017-08-18 12:12:57 --> Database Driver Class Initialized
INFO - 2017-08-18 12:12:57 --> Email Class Initialized
DEBUG - 2017-08-18 12:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:12:57 --> Table Class Initialized
INFO - 2017-08-18 12:12:57 --> Controller Class Initialized
INFO - 2017-08-18 12:12:57 --> Helper loaded: form_helper
ERROR - 2017-08-18 12:12:57 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php 27
ERROR - 2017-08-18 12:12:57 --> Severity: Warning --> log() expects at least 1 parameter, 0 given C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php 27
INFO - 2017-08-18 12:12:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:12:57 --> Final output sent to browser
DEBUG - 2017-08-18 12:12:57 --> Total execution time: 0.2746
INFO - 2017-08-18 12:13:12 --> Config Class Initialized
INFO - 2017-08-18 12:13:12 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:13:12 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:13:12 --> Utf8 Class Initialized
INFO - 2017-08-18 12:13:12 --> URI Class Initialized
INFO - 2017-08-18 12:13:12 --> Router Class Initialized
INFO - 2017-08-18 12:13:12 --> Output Class Initialized
INFO - 2017-08-18 12:13:12 --> Security Class Initialized
DEBUG - 2017-08-18 12:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:13:12 --> Input Class Initialized
INFO - 2017-08-18 12:13:12 --> Language Class Initialized
INFO - 2017-08-18 12:13:12 --> Loader Class Initialized
INFO - 2017-08-18 12:13:12 --> Helper loaded: url_helper
INFO - 2017-08-18 12:13:12 --> Helper loaded: file_helper
INFO - 2017-08-18 12:13:12 --> Database Driver Class Initialized
INFO - 2017-08-18 12:13:12 --> Email Class Initialized
DEBUG - 2017-08-18 12:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:13:12 --> Table Class Initialized
INFO - 2017-08-18 12:13:12 --> Controller Class Initialized
INFO - 2017-08-18 12:13:12 --> Helper loaded: form_helper
INFO - 2017-08-18 12:13:12 --> Upload Class Initialized
INFO - 2017-08-18 12:13:12 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 12:13:12 --> You did not select a file to upload.
INFO - 2017-08-18 12:13:12 --> Final output sent to browser
DEBUG - 2017-08-18 12:13:12 --> Total execution time: 0.2847
INFO - 2017-08-18 12:13:43 --> Config Class Initialized
INFO - 2017-08-18 12:13:43 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:13:43 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:13:43 --> Utf8 Class Initialized
INFO - 2017-08-18 12:13:43 --> URI Class Initialized
INFO - 2017-08-18 12:13:43 --> Router Class Initialized
INFO - 2017-08-18 12:13:43 --> Output Class Initialized
INFO - 2017-08-18 12:13:43 --> Security Class Initialized
DEBUG - 2017-08-18 12:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:13:43 --> Input Class Initialized
INFO - 2017-08-18 12:13:43 --> Language Class Initialized
INFO - 2017-08-18 12:13:43 --> Loader Class Initialized
INFO - 2017-08-18 12:13:43 --> Helper loaded: url_helper
INFO - 2017-08-18 12:13:43 --> Helper loaded: file_helper
INFO - 2017-08-18 12:13:43 --> Database Driver Class Initialized
INFO - 2017-08-18 12:13:43 --> Email Class Initialized
DEBUG - 2017-08-18 12:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:13:43 --> Table Class Initialized
INFO - 2017-08-18 12:13:43 --> Controller Class Initialized
INFO - 2017-08-18 12:13:44 --> Helper loaded: form_helper
ERROR - 2017-08-18 12:13:44 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php 27
ERROR - 2017-08-18 12:13:44 --> Severity: Warning --> log() expects at least 1 parameter, 0 given C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php 27
INFO - 2017-08-18 12:13:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:13:44 --> Final output sent to browser
DEBUG - 2017-08-18 12:13:44 --> Total execution time: 0.2367
INFO - 2017-08-18 12:14:37 --> Config Class Initialized
INFO - 2017-08-18 12:14:37 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:14:37 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:14:37 --> Utf8 Class Initialized
INFO - 2017-08-18 12:14:37 --> URI Class Initialized
INFO - 2017-08-18 12:14:37 --> Router Class Initialized
INFO - 2017-08-18 12:14:37 --> Output Class Initialized
INFO - 2017-08-18 12:14:37 --> Security Class Initialized
DEBUG - 2017-08-18 12:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:14:37 --> Input Class Initialized
INFO - 2017-08-18 12:14:37 --> Language Class Initialized
INFO - 2017-08-18 12:14:37 --> Loader Class Initialized
INFO - 2017-08-18 12:14:37 --> Helper loaded: url_helper
INFO - 2017-08-18 12:14:37 --> Helper loaded: file_helper
INFO - 2017-08-18 12:14:37 --> Database Driver Class Initialized
INFO - 2017-08-18 12:14:37 --> Email Class Initialized
DEBUG - 2017-08-18 12:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:14:37 --> Table Class Initialized
INFO - 2017-08-18 12:14:37 --> Controller Class Initialized
INFO - 2017-08-18 12:14:37 --> Helper loaded: form_helper
ERROR - 2017-08-18 12:14:37 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php 27
ERROR - 2017-08-18 12:14:37 --> Severity: Warning --> log() expects at least 1 parameter, 0 given C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php 27
INFO - 2017-08-18 12:14:37 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:14:37 --> Final output sent to browser
DEBUG - 2017-08-18 12:14:37 --> Total execution time: 0.2373
INFO - 2017-08-18 12:16:02 --> Config Class Initialized
INFO - 2017-08-18 12:16:02 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:16:02 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:16:02 --> Utf8 Class Initialized
INFO - 2017-08-18 12:16:02 --> URI Class Initialized
INFO - 2017-08-18 12:16:02 --> Router Class Initialized
INFO - 2017-08-18 12:16:02 --> Output Class Initialized
INFO - 2017-08-18 12:16:02 --> Security Class Initialized
DEBUG - 2017-08-18 12:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:16:02 --> Input Class Initialized
INFO - 2017-08-18 12:16:02 --> Language Class Initialized
INFO - 2017-08-18 12:16:02 --> Loader Class Initialized
INFO - 2017-08-18 12:16:02 --> Helper loaded: url_helper
INFO - 2017-08-18 12:16:02 --> Helper loaded: file_helper
INFO - 2017-08-18 12:16:02 --> Database Driver Class Initialized
INFO - 2017-08-18 12:16:02 --> Email Class Initialized
DEBUG - 2017-08-18 12:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:16:02 --> Table Class Initialized
INFO - 2017-08-18 12:16:02 --> Controller Class Initialized
INFO - 2017-08-18 12:16:02 --> Helper loaded: form_helper
INFO - 2017-08-18 12:16:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:16:02 --> Final output sent to browser
DEBUG - 2017-08-18 12:16:02 --> Total execution time: 0.2590
INFO - 2017-08-18 12:16:11 --> Config Class Initialized
INFO - 2017-08-18 12:16:11 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:16:11 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:16:11 --> Utf8 Class Initialized
INFO - 2017-08-18 12:16:11 --> URI Class Initialized
INFO - 2017-08-18 12:16:11 --> Router Class Initialized
INFO - 2017-08-18 12:16:11 --> Output Class Initialized
INFO - 2017-08-18 12:16:11 --> Security Class Initialized
DEBUG - 2017-08-18 12:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:16:11 --> Input Class Initialized
INFO - 2017-08-18 12:16:11 --> Language Class Initialized
INFO - 2017-08-18 12:16:11 --> Loader Class Initialized
INFO - 2017-08-18 12:16:11 --> Helper loaded: url_helper
INFO - 2017-08-18 12:16:11 --> Helper loaded: file_helper
INFO - 2017-08-18 12:16:11 --> Database Driver Class Initialized
INFO - 2017-08-18 12:16:11 --> Email Class Initialized
DEBUG - 2017-08-18 12:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:16:11 --> Table Class Initialized
INFO - 2017-08-18 12:16:11 --> Controller Class Initialized
INFO - 2017-08-18 12:16:11 --> Helper loaded: form_helper
INFO - 2017-08-18 12:16:11 --> Upload Class Initialized
INFO - 2017-08-18 12:16:11 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 12:16:11 --> You did not select a file to upload.
INFO - 2017-08-18 12:16:11 --> Final output sent to browser
DEBUG - 2017-08-18 12:16:11 --> Total execution time: 0.2992
INFO - 2017-08-18 12:16:48 --> Config Class Initialized
INFO - 2017-08-18 12:16:48 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:16:48 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:16:48 --> Utf8 Class Initialized
INFO - 2017-08-18 12:16:48 --> URI Class Initialized
INFO - 2017-08-18 12:16:48 --> Router Class Initialized
INFO - 2017-08-18 12:16:48 --> Output Class Initialized
INFO - 2017-08-18 12:16:48 --> Security Class Initialized
DEBUG - 2017-08-18 12:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:16:48 --> Input Class Initialized
INFO - 2017-08-18 12:16:48 --> Language Class Initialized
INFO - 2017-08-18 12:16:48 --> Loader Class Initialized
INFO - 2017-08-18 12:16:48 --> Helper loaded: url_helper
INFO - 2017-08-18 12:16:48 --> Helper loaded: file_helper
INFO - 2017-08-18 12:16:48 --> Database Driver Class Initialized
INFO - 2017-08-18 12:16:48 --> Email Class Initialized
DEBUG - 2017-08-18 12:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:16:48 --> Table Class Initialized
INFO - 2017-08-18 12:16:48 --> Controller Class Initialized
INFO - 2017-08-18 12:16:48 --> Helper loaded: form_helper
INFO - 2017-08-18 12:16:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:16:48 --> Final output sent to browser
DEBUG - 2017-08-18 12:16:48 --> Total execution time: 0.2291
INFO - 2017-08-18 12:16:54 --> Config Class Initialized
INFO - 2017-08-18 12:16:54 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:16:54 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:16:54 --> Utf8 Class Initialized
INFO - 2017-08-18 12:16:54 --> URI Class Initialized
INFO - 2017-08-18 12:16:54 --> Router Class Initialized
INFO - 2017-08-18 12:16:54 --> Output Class Initialized
INFO - 2017-08-18 12:16:54 --> Security Class Initialized
DEBUG - 2017-08-18 12:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:16:54 --> Input Class Initialized
INFO - 2017-08-18 12:16:54 --> Language Class Initialized
INFO - 2017-08-18 12:16:54 --> Loader Class Initialized
INFO - 2017-08-18 12:16:54 --> Helper loaded: url_helper
INFO - 2017-08-18 12:16:54 --> Helper loaded: file_helper
INFO - 2017-08-18 12:16:54 --> Database Driver Class Initialized
INFO - 2017-08-18 12:16:54 --> Email Class Initialized
DEBUG - 2017-08-18 12:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:16:54 --> Table Class Initialized
INFO - 2017-08-18 12:16:54 --> Controller Class Initialized
INFO - 2017-08-18 12:16:54 --> Helper loaded: form_helper
INFO - 2017-08-18 12:16:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:16:54 --> Final output sent to browser
DEBUG - 2017-08-18 12:16:54 --> Total execution time: 0.2278
INFO - 2017-08-18 12:17:02 --> Config Class Initialized
INFO - 2017-08-18 12:17:02 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:17:02 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:17:02 --> Utf8 Class Initialized
INFO - 2017-08-18 12:17:02 --> URI Class Initialized
INFO - 2017-08-18 12:17:02 --> Router Class Initialized
INFO - 2017-08-18 12:17:02 --> Output Class Initialized
INFO - 2017-08-18 12:17:02 --> Security Class Initialized
DEBUG - 2017-08-18 12:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:17:02 --> Input Class Initialized
INFO - 2017-08-18 12:17:02 --> Language Class Initialized
INFO - 2017-08-18 12:17:02 --> Loader Class Initialized
INFO - 2017-08-18 12:17:02 --> Helper loaded: url_helper
INFO - 2017-08-18 12:17:02 --> Helper loaded: file_helper
INFO - 2017-08-18 12:17:02 --> Database Driver Class Initialized
INFO - 2017-08-18 12:17:02 --> Email Class Initialized
DEBUG - 2017-08-18 12:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:17:02 --> Table Class Initialized
INFO - 2017-08-18 12:17:02 --> Controller Class Initialized
INFO - 2017-08-18 12:17:02 --> Helper loaded: form_helper
INFO - 2017-08-18 12:17:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:17:02 --> Final output sent to browser
DEBUG - 2017-08-18 12:17:02 --> Total execution time: 0.2889
INFO - 2017-08-18 12:19:21 --> Config Class Initialized
INFO - 2017-08-18 12:19:21 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:19:21 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:19:21 --> Utf8 Class Initialized
INFO - 2017-08-18 12:19:21 --> URI Class Initialized
INFO - 2017-08-18 12:19:21 --> Router Class Initialized
INFO - 2017-08-18 12:19:21 --> Output Class Initialized
INFO - 2017-08-18 12:19:21 --> Security Class Initialized
DEBUG - 2017-08-18 12:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:19:21 --> Config Class Initialized
INFO - 2017-08-18 12:19:21 --> Input Class Initialized
INFO - 2017-08-18 12:19:21 --> Hooks Class Initialized
INFO - 2017-08-18 12:19:21 --> Language Class Initialized
DEBUG - 2017-08-18 12:19:21 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:19:21 --> Loader Class Initialized
INFO - 2017-08-18 12:19:21 --> Utf8 Class Initialized
INFO - 2017-08-18 12:19:21 --> URI Class Initialized
INFO - 2017-08-18 12:19:21 --> Helper loaded: url_helper
INFO - 2017-08-18 12:19:21 --> Router Class Initialized
INFO - 2017-08-18 12:19:21 --> Helper loaded: file_helper
INFO - 2017-08-18 12:19:21 --> Output Class Initialized
INFO - 2017-08-18 12:19:21 --> Database Driver Class Initialized
INFO - 2017-08-18 12:19:21 --> Security Class Initialized
DEBUG - 2017-08-18 12:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:19:21 --> Email Class Initialized
INFO - 2017-08-18 12:19:21 --> Input Class Initialized
INFO - 2017-08-18 12:19:21 --> Language Class Initialized
DEBUG - 2017-08-18 12:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:19:21 --> Loader Class Initialized
INFO - 2017-08-18 12:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:19:21 --> Helper loaded: url_helper
INFO - 2017-08-18 12:19:21 --> Table Class Initialized
INFO - 2017-08-18 12:19:21 --> Helper loaded: file_helper
INFO - 2017-08-18 12:19:21 --> Controller Class Initialized
INFO - 2017-08-18 12:19:21 --> Helper loaded: form_helper
INFO - 2017-08-18 12:19:21 --> Database Driver Class Initialized
INFO - 2017-08-18 12:19:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:19:21 --> Email Class Initialized
INFO - 2017-08-18 12:19:21 --> Final output sent to browser
DEBUG - 2017-08-18 12:19:21 --> Total execution time: 0.3480
DEBUG - 2017-08-18 12:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:19:21 --> Table Class Initialized
INFO - 2017-08-18 12:19:21 --> Controller Class Initialized
INFO - 2017-08-18 12:19:21 --> Helper loaded: form_helper
INFO - 2017-08-18 12:19:21 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:19:21 --> Final output sent to browser
DEBUG - 2017-08-18 12:19:21 --> Total execution time: 0.2986
INFO - 2017-08-18 12:19:22 --> Config Class Initialized
INFO - 2017-08-18 12:19:22 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:19:22 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:19:22 --> Utf8 Class Initialized
INFO - 2017-08-18 12:19:22 --> URI Class Initialized
INFO - 2017-08-18 12:19:22 --> Router Class Initialized
INFO - 2017-08-18 12:19:22 --> Output Class Initialized
INFO - 2017-08-18 12:19:22 --> Security Class Initialized
DEBUG - 2017-08-18 12:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:19:22 --> Input Class Initialized
INFO - 2017-08-18 12:19:22 --> Language Class Initialized
INFO - 2017-08-18 12:19:22 --> Loader Class Initialized
INFO - 2017-08-18 12:19:22 --> Helper loaded: url_helper
INFO - 2017-08-18 12:19:22 --> Helper loaded: file_helper
INFO - 2017-08-18 12:19:22 --> Database Driver Class Initialized
INFO - 2017-08-18 12:19:22 --> Email Class Initialized
DEBUG - 2017-08-18 12:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:19:22 --> Table Class Initialized
INFO - 2017-08-18 12:19:22 --> Controller Class Initialized
INFO - 2017-08-18 12:19:22 --> Helper loaded: form_helper
INFO - 2017-08-18 12:19:22 --> Upload Class Initialized
INFO - 2017-08-18 12:19:22 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 12:19:22 --> You did not select a file to upload.
INFO - 2017-08-18 12:19:22 --> Final output sent to browser
DEBUG - 2017-08-18 12:19:22 --> Total execution time: 0.3077
INFO - 2017-08-18 12:19:24 --> Config Class Initialized
INFO - 2017-08-18 12:19:24 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:19:24 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:19:24 --> Utf8 Class Initialized
INFO - 2017-08-18 12:19:24 --> URI Class Initialized
INFO - 2017-08-18 12:19:24 --> Router Class Initialized
INFO - 2017-08-18 12:19:24 --> Output Class Initialized
INFO - 2017-08-18 12:19:24 --> Security Class Initialized
DEBUG - 2017-08-18 12:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:19:24 --> Input Class Initialized
INFO - 2017-08-18 12:19:24 --> Language Class Initialized
INFO - 2017-08-18 12:19:24 --> Loader Class Initialized
INFO - 2017-08-18 12:19:24 --> Helper loaded: url_helper
INFO - 2017-08-18 12:19:24 --> Helper loaded: file_helper
INFO - 2017-08-18 12:19:24 --> Database Driver Class Initialized
INFO - 2017-08-18 12:19:24 --> Email Class Initialized
DEBUG - 2017-08-18 12:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:19:24 --> Table Class Initialized
INFO - 2017-08-18 12:19:24 --> Controller Class Initialized
INFO - 2017-08-18 12:19:25 --> Helper loaded: form_helper
INFO - 2017-08-18 12:19:25 --> Upload Class Initialized
INFO - 2017-08-18 12:19:25 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 12:19:25 --> You did not select a file to upload.
INFO - 2017-08-18 12:19:25 --> Final output sent to browser
DEBUG - 2017-08-18 12:19:25 --> Total execution time: 0.2392
INFO - 2017-08-18 12:19:56 --> Config Class Initialized
INFO - 2017-08-18 12:19:56 --> Hooks Class Initialized
DEBUG - 2017-08-18 12:19:56 --> UTF-8 Support Enabled
INFO - 2017-08-18 12:19:56 --> Utf8 Class Initialized
INFO - 2017-08-18 12:19:56 --> URI Class Initialized
INFO - 2017-08-18 12:19:56 --> Router Class Initialized
INFO - 2017-08-18 12:19:56 --> Output Class Initialized
INFO - 2017-08-18 12:19:56 --> Security Class Initialized
DEBUG - 2017-08-18 12:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 12:19:56 --> Input Class Initialized
INFO - 2017-08-18 12:19:56 --> Language Class Initialized
INFO - 2017-08-18 12:19:56 --> Loader Class Initialized
INFO - 2017-08-18 12:19:56 --> Helper loaded: url_helper
INFO - 2017-08-18 12:19:56 --> Helper loaded: file_helper
INFO - 2017-08-18 12:19:56 --> Database Driver Class Initialized
INFO - 2017-08-18 12:19:56 --> Email Class Initialized
DEBUG - 2017-08-18 12:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 12:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 12:19:56 --> Table Class Initialized
INFO - 2017-08-18 12:19:56 --> Controller Class Initialized
INFO - 2017-08-18 12:19:56 --> Helper loaded: form_helper
INFO - 2017-08-18 12:19:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 12:19:56 --> Final output sent to browser
DEBUG - 2017-08-18 12:19:56 --> Total execution time: 0.2505
INFO - 2017-08-18 14:36:54 --> Config Class Initialized
INFO - 2017-08-18 14:36:54 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:36:54 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:36:54 --> Utf8 Class Initialized
INFO - 2017-08-18 14:36:54 --> URI Class Initialized
INFO - 2017-08-18 14:36:54 --> Router Class Initialized
INFO - 2017-08-18 14:36:54 --> Output Class Initialized
INFO - 2017-08-18 14:36:54 --> Security Class Initialized
DEBUG - 2017-08-18 14:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:36:55 --> Input Class Initialized
INFO - 2017-08-18 14:36:55 --> Language Class Initialized
INFO - 2017-08-18 14:36:55 --> Loader Class Initialized
INFO - 2017-08-18 14:36:55 --> Helper loaded: url_helper
INFO - 2017-08-18 14:36:55 --> Helper loaded: file_helper
INFO - 2017-08-18 14:36:55 --> Database Driver Class Initialized
INFO - 2017-08-18 14:36:55 --> Email Class Initialized
DEBUG - 2017-08-18 14:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:36:55 --> Table Class Initialized
INFO - 2017-08-18 14:36:55 --> Controller Class Initialized
INFO - 2017-08-18 14:36:55 --> Helper loaded: form_helper
INFO - 2017-08-18 14:36:55 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:36:55 --> Final output sent to browser
DEBUG - 2017-08-18 14:36:55 --> Total execution time: 1.1757
INFO - 2017-08-18 14:37:11 --> Config Class Initialized
INFO - 2017-08-18 14:37:11 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:37:11 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:37:11 --> Utf8 Class Initialized
INFO - 2017-08-18 14:37:11 --> URI Class Initialized
INFO - 2017-08-18 14:37:11 --> Router Class Initialized
INFO - 2017-08-18 14:37:11 --> Output Class Initialized
INFO - 2017-08-18 14:37:11 --> Security Class Initialized
DEBUG - 2017-08-18 14:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:37:11 --> Input Class Initialized
INFO - 2017-08-18 14:37:11 --> Language Class Initialized
INFO - 2017-08-18 14:37:11 --> Loader Class Initialized
INFO - 2017-08-18 14:37:11 --> Helper loaded: url_helper
INFO - 2017-08-18 14:37:11 --> Helper loaded: file_helper
INFO - 2017-08-18 14:37:11 --> Database Driver Class Initialized
INFO - 2017-08-18 14:37:11 --> Email Class Initialized
DEBUG - 2017-08-18 14:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:37:11 --> Table Class Initialized
INFO - 2017-08-18 14:37:11 --> Controller Class Initialized
INFO - 2017-08-18 14:37:11 --> Helper loaded: form_helper
INFO - 2017-08-18 14:37:11 --> Upload Class Initialized
INFO - 2017-08-18 14:37:11 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 14:37:11 --> You did not select a file to upload.
INFO - 2017-08-18 14:37:11 --> Final output sent to browser
DEBUG - 2017-08-18 14:37:11 --> Total execution time: 0.6571
INFO - 2017-08-18 14:37:47 --> Config Class Initialized
INFO - 2017-08-18 14:37:47 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:37:47 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:37:47 --> Utf8 Class Initialized
INFO - 2017-08-18 14:37:47 --> URI Class Initialized
INFO - 2017-08-18 14:37:47 --> Router Class Initialized
INFO - 2017-08-18 14:37:47 --> Output Class Initialized
INFO - 2017-08-18 14:37:47 --> Security Class Initialized
DEBUG - 2017-08-18 14:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:37:47 --> Input Class Initialized
INFO - 2017-08-18 14:37:47 --> Language Class Initialized
INFO - 2017-08-18 14:37:47 --> Loader Class Initialized
INFO - 2017-08-18 14:37:47 --> Helper loaded: url_helper
INFO - 2017-08-18 14:37:47 --> Helper loaded: file_helper
INFO - 2017-08-18 14:37:47 --> Database Driver Class Initialized
INFO - 2017-08-18 14:37:47 --> Email Class Initialized
DEBUG - 2017-08-18 14:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:37:48 --> Table Class Initialized
INFO - 2017-08-18 14:37:48 --> Controller Class Initialized
INFO - 2017-08-18 14:37:48 --> Helper loaded: form_helper
INFO - 2017-08-18 14:37:48 --> Upload Class Initialized
INFO - 2017-08-18 14:37:48 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 14:37:48 --> You did not select a file to upload.
INFO - 2017-08-18 14:37:48 --> Final output sent to browser
DEBUG - 2017-08-18 14:37:48 --> Total execution time: 1.0756
INFO - 2017-08-18 14:40:04 --> Config Class Initialized
INFO - 2017-08-18 14:40:04 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:40:04 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:40:04 --> Utf8 Class Initialized
INFO - 2017-08-18 14:40:04 --> URI Class Initialized
INFO - 2017-08-18 14:40:04 --> Router Class Initialized
INFO - 2017-08-18 14:40:05 --> Output Class Initialized
INFO - 2017-08-18 14:40:05 --> Security Class Initialized
DEBUG - 2017-08-18 14:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:40:05 --> Input Class Initialized
INFO - 2017-08-18 14:40:05 --> Language Class Initialized
INFO - 2017-08-18 14:40:05 --> Loader Class Initialized
INFO - 2017-08-18 14:40:05 --> Helper loaded: url_helper
INFO - 2017-08-18 14:40:05 --> Helper loaded: file_helper
INFO - 2017-08-18 14:40:05 --> Database Driver Class Initialized
INFO - 2017-08-18 14:40:05 --> Email Class Initialized
DEBUG - 2017-08-18 14:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:40:05 --> Table Class Initialized
INFO - 2017-08-18 14:40:05 --> Controller Class Initialized
INFO - 2017-08-18 14:40:05 --> Helper loaded: form_helper
INFO - 2017-08-18 14:40:05 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:40:05 --> Final output sent to browser
DEBUG - 2017-08-18 14:40:05 --> Total execution time: 0.2140
INFO - 2017-08-18 14:40:16 --> Config Class Initialized
INFO - 2017-08-18 14:40:16 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:40:16 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:40:16 --> Utf8 Class Initialized
INFO - 2017-08-18 14:40:16 --> URI Class Initialized
INFO - 2017-08-18 14:40:16 --> Router Class Initialized
INFO - 2017-08-18 14:40:16 --> Output Class Initialized
INFO - 2017-08-18 14:40:16 --> Security Class Initialized
DEBUG - 2017-08-18 14:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:40:16 --> Input Class Initialized
INFO - 2017-08-18 14:40:16 --> Language Class Initialized
INFO - 2017-08-18 14:40:16 --> Loader Class Initialized
INFO - 2017-08-18 14:40:16 --> Helper loaded: url_helper
INFO - 2017-08-18 14:40:16 --> Helper loaded: file_helper
INFO - 2017-08-18 14:40:16 --> Database Driver Class Initialized
INFO - 2017-08-18 14:40:16 --> Email Class Initialized
DEBUG - 2017-08-18 14:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:40:16 --> Table Class Initialized
INFO - 2017-08-18 14:40:16 --> Controller Class Initialized
INFO - 2017-08-18 14:40:16 --> Helper loaded: form_helper
INFO - 2017-08-18 14:40:16 --> Upload Class Initialized
INFO - 2017-08-18 14:40:16 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 14:40:16 --> You did not select a file to upload.
INFO - 2017-08-18 14:40:16 --> Final output sent to browser
DEBUG - 2017-08-18 14:40:16 --> Total execution time: 0.2771
INFO - 2017-08-18 14:40:50 --> Config Class Initialized
INFO - 2017-08-18 14:40:50 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:40:50 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:40:50 --> Utf8 Class Initialized
INFO - 2017-08-18 14:40:50 --> URI Class Initialized
INFO - 2017-08-18 14:40:50 --> Router Class Initialized
INFO - 2017-08-18 14:40:50 --> Output Class Initialized
INFO - 2017-08-18 14:40:50 --> Security Class Initialized
DEBUG - 2017-08-18 14:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:40:50 --> Input Class Initialized
INFO - 2017-08-18 14:40:50 --> Language Class Initialized
INFO - 2017-08-18 14:40:50 --> Loader Class Initialized
INFO - 2017-08-18 14:40:50 --> Helper loaded: url_helper
INFO - 2017-08-18 14:40:50 --> Helper loaded: file_helper
INFO - 2017-08-18 14:40:50 --> Database Driver Class Initialized
INFO - 2017-08-18 14:40:50 --> Email Class Initialized
DEBUG - 2017-08-18 14:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:40:50 --> Table Class Initialized
INFO - 2017-08-18 14:40:50 --> Controller Class Initialized
INFO - 2017-08-18 14:40:50 --> Helper loaded: form_helper
INFO - 2017-08-18 14:40:50 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:40:50 --> Final output sent to browser
DEBUG - 2017-08-18 14:40:50 --> Total execution time: 0.2162
INFO - 2017-08-18 14:40:57 --> Config Class Initialized
INFO - 2017-08-18 14:40:57 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:40:57 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:40:57 --> Utf8 Class Initialized
INFO - 2017-08-18 14:40:57 --> URI Class Initialized
INFO - 2017-08-18 14:40:57 --> Router Class Initialized
INFO - 2017-08-18 14:40:57 --> Output Class Initialized
INFO - 2017-08-18 14:40:57 --> Security Class Initialized
DEBUG - 2017-08-18 14:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:40:57 --> Input Class Initialized
INFO - 2017-08-18 14:40:57 --> Language Class Initialized
INFO - 2017-08-18 14:40:57 --> Loader Class Initialized
INFO - 2017-08-18 14:40:57 --> Helper loaded: url_helper
INFO - 2017-08-18 14:40:57 --> Helper loaded: file_helper
INFO - 2017-08-18 14:40:57 --> Database Driver Class Initialized
INFO - 2017-08-18 14:40:57 --> Email Class Initialized
DEBUG - 2017-08-18 14:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:40:57 --> Table Class Initialized
INFO - 2017-08-18 14:40:57 --> Controller Class Initialized
INFO - 2017-08-18 14:40:57 --> Helper loaded: form_helper
INFO - 2017-08-18 14:40:57 --> Upload Class Initialized
INFO - 2017-08-18 14:40:57 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 14:40:57 --> You did not select a file to upload.
INFO - 2017-08-18 14:40:57 --> Final output sent to browser
DEBUG - 2017-08-18 14:40:57 --> Total execution time: 0.2649
INFO - 2017-08-18 14:41:44 --> Config Class Initialized
INFO - 2017-08-18 14:41:44 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:41:44 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:41:44 --> Utf8 Class Initialized
INFO - 2017-08-18 14:41:44 --> URI Class Initialized
INFO - 2017-08-18 14:41:44 --> Router Class Initialized
INFO - 2017-08-18 14:41:44 --> Output Class Initialized
INFO - 2017-08-18 14:41:44 --> Security Class Initialized
DEBUG - 2017-08-18 14:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:41:44 --> Input Class Initialized
INFO - 2017-08-18 14:41:44 --> Language Class Initialized
INFO - 2017-08-18 14:41:44 --> Loader Class Initialized
INFO - 2017-08-18 14:41:44 --> Helper loaded: url_helper
INFO - 2017-08-18 14:41:44 --> Helper loaded: file_helper
INFO - 2017-08-18 14:41:44 --> Database Driver Class Initialized
INFO - 2017-08-18 14:41:44 --> Email Class Initialized
DEBUG - 2017-08-18 14:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:41:44 --> Table Class Initialized
INFO - 2017-08-18 14:41:44 --> Controller Class Initialized
INFO - 2017-08-18 14:41:44 --> Helper loaded: form_helper
INFO - 2017-08-18 14:41:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:41:44 --> Final output sent to browser
DEBUG - 2017-08-18 14:41:44 --> Total execution time: 0.2677
INFO - 2017-08-18 14:44:59 --> Config Class Initialized
INFO - 2017-08-18 14:44:59 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:44:59 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:44:59 --> Utf8 Class Initialized
INFO - 2017-08-18 14:44:59 --> URI Class Initialized
INFO - 2017-08-18 14:44:59 --> Router Class Initialized
INFO - 2017-08-18 14:44:59 --> Output Class Initialized
INFO - 2017-08-18 14:44:59 --> Security Class Initialized
DEBUG - 2017-08-18 14:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:44:59 --> Input Class Initialized
INFO - 2017-08-18 14:44:59 --> Language Class Initialized
ERROR - 2017-08-18 14:44:59 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 49
INFO - 2017-08-18 14:44:59 --> Loader Class Initialized
INFO - 2017-08-18 14:44:59 --> Helper loaded: url_helper
INFO - 2017-08-18 14:44:59 --> Helper loaded: file_helper
INFO - 2017-08-18 14:44:59 --> Database Driver Class Initialized
INFO - 2017-08-18 14:44:59 --> Email Class Initialized
DEBUG - 2017-08-18 14:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:44:59 --> Table Class Initialized
INFO - 2017-08-18 14:44:59 --> Controller Class Initialized
INFO - 2017-08-18 14:44:59 --> Helper loaded: form_helper
INFO - 2017-08-18 14:44:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:44:59 --> Final output sent to browser
DEBUG - 2017-08-18 14:44:59 --> Total execution time: 0.3198
INFO - 2017-08-18 14:46:12 --> Config Class Initialized
INFO - 2017-08-18 14:46:12 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:46:12 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:46:12 --> Utf8 Class Initialized
INFO - 2017-08-18 14:46:12 --> URI Class Initialized
INFO - 2017-08-18 14:46:12 --> Router Class Initialized
INFO - 2017-08-18 14:46:12 --> Output Class Initialized
INFO - 2017-08-18 14:46:12 --> Security Class Initialized
DEBUG - 2017-08-18 14:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:46:12 --> Input Class Initialized
INFO - 2017-08-18 14:46:12 --> Language Class Initialized
INFO - 2017-08-18 14:46:12 --> Loader Class Initialized
INFO - 2017-08-18 14:46:12 --> Helper loaded: url_helper
INFO - 2017-08-18 14:46:12 --> Helper loaded: file_helper
INFO - 2017-08-18 14:46:12 --> Database Driver Class Initialized
INFO - 2017-08-18 14:46:12 --> Email Class Initialized
DEBUG - 2017-08-18 14:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:46:12 --> Table Class Initialized
INFO - 2017-08-18 14:46:12 --> Controller Class Initialized
INFO - 2017-08-18 14:46:12 --> Helper loaded: form_helper
INFO - 2017-08-18 14:46:12 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:46:12 --> Final output sent to browser
DEBUG - 2017-08-18 14:46:12 --> Total execution time: 0.2213
INFO - 2017-08-18 14:46:38 --> Config Class Initialized
INFO - 2017-08-18 14:46:38 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:46:38 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:46:38 --> Utf8 Class Initialized
INFO - 2017-08-18 14:46:38 --> URI Class Initialized
INFO - 2017-08-18 14:46:38 --> Router Class Initialized
INFO - 2017-08-18 14:46:38 --> Output Class Initialized
INFO - 2017-08-18 14:46:38 --> Security Class Initialized
DEBUG - 2017-08-18 14:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:46:38 --> Input Class Initialized
INFO - 2017-08-18 14:46:38 --> Language Class Initialized
ERROR - 2017-08-18 14:46:38 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 49
INFO - 2017-08-18 14:46:38 --> Loader Class Initialized
INFO - 2017-08-18 14:46:38 --> Helper loaded: url_helper
INFO - 2017-08-18 14:46:38 --> Helper loaded: file_helper
INFO - 2017-08-18 14:46:38 --> Database Driver Class Initialized
INFO - 2017-08-18 14:46:38 --> Email Class Initialized
DEBUG - 2017-08-18 14:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:46:38 --> Table Class Initialized
INFO - 2017-08-18 14:46:38 --> Controller Class Initialized
INFO - 2017-08-18 14:46:38 --> Helper loaded: form_helper
INFO - 2017-08-18 14:46:38 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:46:38 --> Final output sent to browser
DEBUG - 2017-08-18 14:46:38 --> Total execution time: 0.2222
INFO - 2017-08-18 14:46:44 --> Config Class Initialized
INFO - 2017-08-18 14:46:44 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:46:44 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:46:44 --> Utf8 Class Initialized
INFO - 2017-08-18 14:46:44 --> URI Class Initialized
INFO - 2017-08-18 14:46:44 --> Router Class Initialized
INFO - 2017-08-18 14:46:44 --> Output Class Initialized
INFO - 2017-08-18 14:46:44 --> Security Class Initialized
DEBUG - 2017-08-18 14:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:46:44 --> Input Class Initialized
INFO - 2017-08-18 14:46:44 --> Language Class Initialized
ERROR - 2017-08-18 14:46:44 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 49
INFO - 2017-08-18 14:46:45 --> Loader Class Initialized
INFO - 2017-08-18 14:46:45 --> Helper loaded: url_helper
INFO - 2017-08-18 14:46:45 --> Helper loaded: file_helper
INFO - 2017-08-18 14:46:45 --> Database Driver Class Initialized
INFO - 2017-08-18 14:46:45 --> Email Class Initialized
DEBUG - 2017-08-18 14:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:46:45 --> Table Class Initialized
INFO - 2017-08-18 14:46:45 --> Controller Class Initialized
INFO - 2017-08-18 14:46:45 --> Helper loaded: form_helper
INFO - 2017-08-18 14:46:45 --> Upload Class Initialized
INFO - 2017-08-18 14:46:45 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 14:46:45 --> You did not select a file to upload.
INFO - 2017-08-18 14:46:45 --> Final output sent to browser
DEBUG - 2017-08-18 14:46:45 --> Total execution time: 0.2800
INFO - 2017-08-18 14:47:02 --> Config Class Initialized
INFO - 2017-08-18 14:47:02 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:47:02 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:47:02 --> Utf8 Class Initialized
INFO - 2017-08-18 14:47:02 --> URI Class Initialized
INFO - 2017-08-18 14:47:02 --> Router Class Initialized
INFO - 2017-08-18 14:47:02 --> Output Class Initialized
INFO - 2017-08-18 14:47:02 --> Security Class Initialized
DEBUG - 2017-08-18 14:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:47:02 --> Input Class Initialized
INFO - 2017-08-18 14:47:02 --> Language Class Initialized
INFO - 2017-08-18 14:47:02 --> Loader Class Initialized
INFO - 2017-08-18 14:47:02 --> Helper loaded: url_helper
INFO - 2017-08-18 14:47:02 --> Helper loaded: file_helper
INFO - 2017-08-18 14:47:02 --> Database Driver Class Initialized
INFO - 2017-08-18 14:47:02 --> Email Class Initialized
DEBUG - 2017-08-18 14:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:47:02 --> Table Class Initialized
INFO - 2017-08-18 14:47:02 --> Controller Class Initialized
INFO - 2017-08-18 14:47:02 --> Helper loaded: form_helper
INFO - 2017-08-18 14:47:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:47:02 --> Final output sent to browser
DEBUG - 2017-08-18 14:47:02 --> Total execution time: 0.2258
INFO - 2017-08-18 14:47:12 --> Config Class Initialized
INFO - 2017-08-18 14:47:12 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:47:12 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:47:12 --> Utf8 Class Initialized
INFO - 2017-08-18 14:47:12 --> URI Class Initialized
INFO - 2017-08-18 14:47:12 --> Router Class Initialized
INFO - 2017-08-18 14:47:12 --> Output Class Initialized
INFO - 2017-08-18 14:47:12 --> Security Class Initialized
DEBUG - 2017-08-18 14:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:47:12 --> Input Class Initialized
INFO - 2017-08-18 14:47:12 --> Language Class Initialized
ERROR - 2017-08-18 14:47:12 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 49
INFO - 2017-08-18 14:47:12 --> Loader Class Initialized
INFO - 2017-08-18 14:47:12 --> Helper loaded: url_helper
INFO - 2017-08-18 14:47:12 --> Helper loaded: file_helper
INFO - 2017-08-18 14:47:12 --> Database Driver Class Initialized
INFO - 2017-08-18 14:47:13 --> Email Class Initialized
DEBUG - 2017-08-18 14:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:47:13 --> Table Class Initialized
INFO - 2017-08-18 14:47:13 --> Controller Class Initialized
INFO - 2017-08-18 14:47:13 --> Helper loaded: form_helper
INFO - 2017-08-18 14:47:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:47:13 --> Final output sent to browser
DEBUG - 2017-08-18 14:47:13 --> Total execution time: 0.2382
INFO - 2017-08-18 14:47:51 --> Config Class Initialized
INFO - 2017-08-18 14:47:51 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:47:51 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:47:51 --> Utf8 Class Initialized
INFO - 2017-08-18 14:47:51 --> URI Class Initialized
INFO - 2017-08-18 14:47:51 --> Router Class Initialized
INFO - 2017-08-18 14:47:51 --> Output Class Initialized
INFO - 2017-08-18 14:47:51 --> Security Class Initialized
DEBUG - 2017-08-18 14:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:47:51 --> Input Class Initialized
INFO - 2017-08-18 14:47:51 --> Language Class Initialized
INFO - 2017-08-18 14:47:51 --> Loader Class Initialized
INFO - 2017-08-18 14:47:51 --> Helper loaded: url_helper
INFO - 2017-08-18 14:47:51 --> Helper loaded: file_helper
INFO - 2017-08-18 14:47:51 --> Database Driver Class Initialized
INFO - 2017-08-18 14:47:51 --> Email Class Initialized
DEBUG - 2017-08-18 14:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:47:51 --> Table Class Initialized
INFO - 2017-08-18 14:47:51 --> Controller Class Initialized
INFO - 2017-08-18 14:47:51 --> Helper loaded: form_helper
INFO - 2017-08-18 14:47:51 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:47:51 --> Final output sent to browser
DEBUG - 2017-08-18 14:47:51 --> Total execution time: 0.2125
INFO - 2017-08-18 14:48:02 --> Config Class Initialized
INFO - 2017-08-18 14:48:02 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:48:02 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:48:02 --> Utf8 Class Initialized
INFO - 2017-08-18 14:48:02 --> URI Class Initialized
INFO - 2017-08-18 14:48:02 --> Router Class Initialized
INFO - 2017-08-18 14:48:02 --> Output Class Initialized
INFO - 2017-08-18 14:48:02 --> Security Class Initialized
DEBUG - 2017-08-18 14:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:48:02 --> Input Class Initialized
INFO - 2017-08-18 14:48:02 --> Language Class Initialized
INFO - 2017-08-18 14:48:02 --> Loader Class Initialized
INFO - 2017-08-18 14:48:02 --> Helper loaded: url_helper
INFO - 2017-08-18 14:48:02 --> Helper loaded: file_helper
INFO - 2017-08-18 14:48:02 --> Database Driver Class Initialized
INFO - 2017-08-18 14:48:02 --> Email Class Initialized
DEBUG - 2017-08-18 14:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:48:02 --> Table Class Initialized
INFO - 2017-08-18 14:48:02 --> Controller Class Initialized
INFO - 2017-08-18 14:48:02 --> Helper loaded: form_helper
INFO - 2017-08-18 14:48:02 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:48:02 --> Final output sent to browser
DEBUG - 2017-08-18 14:48:02 --> Total execution time: 0.2129
INFO - 2017-08-18 14:48:08 --> Config Class Initialized
INFO - 2017-08-18 14:48:08 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:48:08 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:48:08 --> Utf8 Class Initialized
INFO - 2017-08-18 14:48:08 --> URI Class Initialized
INFO - 2017-08-18 14:48:08 --> Router Class Initialized
INFO - 2017-08-18 14:48:08 --> Output Class Initialized
INFO - 2017-08-18 14:48:08 --> Security Class Initialized
DEBUG - 2017-08-18 14:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:48:08 --> Input Class Initialized
INFO - 2017-08-18 14:48:08 --> Language Class Initialized
INFO - 2017-08-18 14:48:08 --> Loader Class Initialized
INFO - 2017-08-18 14:48:08 --> Helper loaded: url_helper
INFO - 2017-08-18 14:48:08 --> Helper loaded: file_helper
INFO - 2017-08-18 14:48:08 --> Database Driver Class Initialized
INFO - 2017-08-18 14:48:08 --> Email Class Initialized
DEBUG - 2017-08-18 14:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:48:08 --> Table Class Initialized
INFO - 2017-08-18 14:48:08 --> Controller Class Initialized
INFO - 2017-08-18 14:48:08 --> Helper loaded: form_helper
INFO - 2017-08-18 14:48:08 --> Upload Class Initialized
INFO - 2017-08-18 14:48:08 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 14:48:08 --> You did not select a file to upload.
INFO - 2017-08-18 14:48:08 --> Final output sent to browser
DEBUG - 2017-08-18 14:48:08 --> Total execution time: 0.2633
INFO - 2017-08-18 14:48:56 --> Config Class Initialized
INFO - 2017-08-18 14:48:56 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:48:56 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:48:56 --> Utf8 Class Initialized
INFO - 2017-08-18 14:48:56 --> URI Class Initialized
INFO - 2017-08-18 14:48:56 --> Router Class Initialized
INFO - 2017-08-18 14:48:56 --> Output Class Initialized
INFO - 2017-08-18 14:48:56 --> Security Class Initialized
DEBUG - 2017-08-18 14:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:48:56 --> Input Class Initialized
INFO - 2017-08-18 14:48:56 --> Language Class Initialized
ERROR - 2017-08-18 14:48:56 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 51
INFO - 2017-08-18 14:48:56 --> Loader Class Initialized
INFO - 2017-08-18 14:48:56 --> Helper loaded: url_helper
INFO - 2017-08-18 14:48:56 --> Helper loaded: file_helper
INFO - 2017-08-18 14:48:56 --> Database Driver Class Initialized
INFO - 2017-08-18 14:48:56 --> Email Class Initialized
DEBUG - 2017-08-18 14:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:48:56 --> Table Class Initialized
INFO - 2017-08-18 14:48:56 --> Controller Class Initialized
INFO - 2017-08-18 14:48:56 --> Helper loaded: form_helper
INFO - 2017-08-18 14:48:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:48:56 --> Final output sent to browser
DEBUG - 2017-08-18 14:48:56 --> Total execution time: 0.2432
INFO - 2017-08-18 14:49:44 --> Config Class Initialized
INFO - 2017-08-18 14:49:44 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:49:44 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:49:44 --> Utf8 Class Initialized
INFO - 2017-08-18 14:49:44 --> URI Class Initialized
INFO - 2017-08-18 14:49:44 --> Router Class Initialized
INFO - 2017-08-18 14:49:44 --> Output Class Initialized
INFO - 2017-08-18 14:49:44 --> Security Class Initialized
DEBUG - 2017-08-18 14:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:49:45 --> Input Class Initialized
INFO - 2017-08-18 14:49:45 --> Language Class Initialized
ERROR - 2017-08-18 14:49:45 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 47
ERROR - 2017-08-18 14:49:45 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 51
INFO - 2017-08-18 14:49:45 --> Loader Class Initialized
INFO - 2017-08-18 14:49:45 --> Helper loaded: url_helper
INFO - 2017-08-18 14:49:45 --> Helper loaded: file_helper
INFO - 2017-08-18 14:49:45 --> Database Driver Class Initialized
INFO - 2017-08-18 14:49:45 --> Email Class Initialized
DEBUG - 2017-08-18 14:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:49:45 --> Table Class Initialized
INFO - 2017-08-18 14:49:45 --> Controller Class Initialized
INFO - 2017-08-18 14:49:45 --> Helper loaded: form_helper
INFO - 2017-08-18 14:49:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:49:45 --> Final output sent to browser
DEBUG - 2017-08-18 14:49:45 --> Total execution time: 0.2285
INFO - 2017-08-18 14:49:52 --> Config Class Initialized
INFO - 2017-08-18 14:49:52 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:49:52 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:49:52 --> Utf8 Class Initialized
INFO - 2017-08-18 14:49:52 --> URI Class Initialized
INFO - 2017-08-18 14:49:52 --> Router Class Initialized
INFO - 2017-08-18 14:49:52 --> Output Class Initialized
INFO - 2017-08-18 14:49:52 --> Security Class Initialized
DEBUG - 2017-08-18 14:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:49:52 --> Input Class Initialized
INFO - 2017-08-18 14:49:52 --> Language Class Initialized
ERROR - 2017-08-18 14:49:52 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 47
ERROR - 2017-08-18 14:49:52 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 51
INFO - 2017-08-18 14:49:52 --> Loader Class Initialized
INFO - 2017-08-18 14:49:52 --> Helper loaded: url_helper
INFO - 2017-08-18 14:49:52 --> Helper loaded: file_helper
INFO - 2017-08-18 14:49:52 --> Database Driver Class Initialized
INFO - 2017-08-18 14:49:52 --> Email Class Initialized
DEBUG - 2017-08-18 14:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:49:52 --> Table Class Initialized
INFO - 2017-08-18 14:49:52 --> Controller Class Initialized
INFO - 2017-08-18 14:49:52 --> Helper loaded: form_helper
INFO - 2017-08-18 14:49:52 --> Upload Class Initialized
INFO - 2017-08-18 14:49:52 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 14:49:52 --> You did not select a file to upload.
INFO - 2017-08-18 14:49:52 --> Final output sent to browser
DEBUG - 2017-08-18 14:49:52 --> Total execution time: 0.2843
INFO - 2017-08-18 14:50:25 --> Config Class Initialized
INFO - 2017-08-18 14:50:25 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:50:25 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:50:25 --> Utf8 Class Initialized
INFO - 2017-08-18 14:50:25 --> URI Class Initialized
INFO - 2017-08-18 14:50:25 --> Router Class Initialized
INFO - 2017-08-18 14:50:25 --> Output Class Initialized
INFO - 2017-08-18 14:50:25 --> Security Class Initialized
DEBUG - 2017-08-18 14:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:50:25 --> Input Class Initialized
INFO - 2017-08-18 14:50:25 --> Language Class Initialized
ERROR - 2017-08-18 14:50:25 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 52
INFO - 2017-08-18 14:50:25 --> Loader Class Initialized
INFO - 2017-08-18 14:50:25 --> Helper loaded: url_helper
INFO - 2017-08-18 14:50:25 --> Helper loaded: file_helper
INFO - 2017-08-18 14:50:25 --> Database Driver Class Initialized
INFO - 2017-08-18 14:50:25 --> Email Class Initialized
DEBUG - 2017-08-18 14:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:50:25 --> Table Class Initialized
INFO - 2017-08-18 14:50:25 --> Controller Class Initialized
INFO - 2017-08-18 14:50:25 --> Helper loaded: form_helper
INFO - 2017-08-18 14:50:25 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:50:25 --> Final output sent to browser
DEBUG - 2017-08-18 14:50:25 --> Total execution time: 0.2308
INFO - 2017-08-18 14:50:48 --> Config Class Initialized
INFO - 2017-08-18 14:50:48 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:50:48 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:50:48 --> Utf8 Class Initialized
INFO - 2017-08-18 14:50:48 --> URI Class Initialized
INFO - 2017-08-18 14:50:48 --> Router Class Initialized
INFO - 2017-08-18 14:50:48 --> Output Class Initialized
INFO - 2017-08-18 14:50:48 --> Security Class Initialized
DEBUG - 2017-08-18 14:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:50:48 --> Input Class Initialized
INFO - 2017-08-18 14:50:48 --> Language Class Initialized
ERROR - 2017-08-18 14:50:48 --> Severity: Notice --> Undefined variable: t C:\xampp\htdocs\biokimia\application\controllers\Post.php 50
ERROR - 2017-08-18 14:50:48 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 54
INFO - 2017-08-18 14:50:48 --> Loader Class Initialized
INFO - 2017-08-18 14:50:48 --> Helper loaded: url_helper
INFO - 2017-08-18 14:50:48 --> Helper loaded: file_helper
INFO - 2017-08-18 14:50:48 --> Database Driver Class Initialized
INFO - 2017-08-18 14:50:48 --> Email Class Initialized
DEBUG - 2017-08-18 14:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:50:48 --> Table Class Initialized
INFO - 2017-08-18 14:50:48 --> Controller Class Initialized
INFO - 2017-08-18 14:50:48 --> Helper loaded: form_helper
INFO - 2017-08-18 14:50:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:50:48 --> Final output sent to browser
DEBUG - 2017-08-18 14:50:48 --> Total execution time: 0.2479
INFO - 2017-08-18 14:50:58 --> Config Class Initialized
INFO - 2017-08-18 14:50:58 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:50:58 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:50:58 --> Utf8 Class Initialized
INFO - 2017-08-18 14:50:58 --> URI Class Initialized
INFO - 2017-08-18 14:50:58 --> Router Class Initialized
INFO - 2017-08-18 14:50:58 --> Output Class Initialized
INFO - 2017-08-18 14:50:58 --> Security Class Initialized
DEBUG - 2017-08-18 14:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:50:58 --> Input Class Initialized
INFO - 2017-08-18 14:50:58 --> Language Class Initialized
ERROR - 2017-08-18 14:50:58 --> Severity: Parsing Error --> syntax error, unexpected '$t' (T_VARIABLE), expecting function (T_FUNCTION) C:\xampp\htdocs\biokimia\application\controllers\Post.php 5
INFO - 2017-08-18 14:51:17 --> Config Class Initialized
INFO - 2017-08-18 14:51:17 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:51:17 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:51:17 --> Utf8 Class Initialized
INFO - 2017-08-18 14:51:17 --> URI Class Initialized
INFO - 2017-08-18 14:51:17 --> Router Class Initialized
INFO - 2017-08-18 14:51:17 --> Output Class Initialized
INFO - 2017-08-18 14:51:17 --> Security Class Initialized
DEBUG - 2017-08-18 14:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:51:17 --> Input Class Initialized
INFO - 2017-08-18 14:51:17 --> Language Class Initialized
ERROR - 2017-08-18 14:51:17 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 56
INFO - 2017-08-18 14:51:17 --> Loader Class Initialized
INFO - 2017-08-18 14:51:17 --> Helper loaded: url_helper
INFO - 2017-08-18 14:51:18 --> Helper loaded: file_helper
INFO - 2017-08-18 14:51:18 --> Database Driver Class Initialized
INFO - 2017-08-18 14:51:18 --> Email Class Initialized
DEBUG - 2017-08-18 14:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:51:18 --> Table Class Initialized
INFO - 2017-08-18 14:51:18 --> Controller Class Initialized
INFO - 2017-08-18 14:51:18 --> Helper loaded: form_helper
INFO - 2017-08-18 14:51:18 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:51:18 --> Final output sent to browser
DEBUG - 2017-08-18 14:51:18 --> Total execution time: 0.2236
INFO - 2017-08-18 14:51:26 --> Config Class Initialized
INFO - 2017-08-18 14:51:26 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:51:26 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:51:26 --> Utf8 Class Initialized
INFO - 2017-08-18 14:51:26 --> URI Class Initialized
INFO - 2017-08-18 14:51:26 --> Router Class Initialized
INFO - 2017-08-18 14:51:26 --> Output Class Initialized
INFO - 2017-08-18 14:51:26 --> Security Class Initialized
DEBUG - 2017-08-18 14:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:51:26 --> Input Class Initialized
INFO - 2017-08-18 14:51:26 --> Language Class Initialized
ERROR - 2017-08-18 14:51:26 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 56
INFO - 2017-08-18 14:51:26 --> Loader Class Initialized
INFO - 2017-08-18 14:51:26 --> Helper loaded: url_helper
INFO - 2017-08-18 14:51:26 --> Helper loaded: file_helper
INFO - 2017-08-18 14:51:26 --> Database Driver Class Initialized
INFO - 2017-08-18 14:51:26 --> Email Class Initialized
DEBUG - 2017-08-18 14:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:51:26 --> Table Class Initialized
INFO - 2017-08-18 14:51:26 --> Controller Class Initialized
INFO - 2017-08-18 14:51:26 --> Helper loaded: form_helper
INFO - 2017-08-18 14:51:26 --> Upload Class Initialized
INFO - 2017-08-18 14:51:26 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 14:51:26 --> You did not select a file to upload.
INFO - 2017-08-18 14:51:26 --> Final output sent to browser
DEBUG - 2017-08-18 14:51:26 --> Total execution time: 0.3028
INFO - 2017-08-18 14:52:08 --> Config Class Initialized
INFO - 2017-08-18 14:52:08 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:52:08 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:52:08 --> Utf8 Class Initialized
INFO - 2017-08-18 14:52:08 --> URI Class Initialized
INFO - 2017-08-18 14:52:08 --> Router Class Initialized
INFO - 2017-08-18 14:52:08 --> Output Class Initialized
INFO - 2017-08-18 14:52:08 --> Security Class Initialized
DEBUG - 2017-08-18 14:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:52:08 --> Input Class Initialized
INFO - 2017-08-18 14:52:08 --> Language Class Initialized
ERROR - 2017-08-18 14:52:08 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 58
INFO - 2017-08-18 14:52:08 --> Loader Class Initialized
INFO - 2017-08-18 14:52:08 --> Helper loaded: url_helper
INFO - 2017-08-18 14:52:08 --> Helper loaded: file_helper
INFO - 2017-08-18 14:52:08 --> Database Driver Class Initialized
INFO - 2017-08-18 14:52:08 --> Email Class Initialized
DEBUG - 2017-08-18 14:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:52:08 --> Table Class Initialized
INFO - 2017-08-18 14:52:08 --> Controller Class Initialized
INFO - 2017-08-18 14:52:08 --> Helper loaded: form_helper
INFO - 2017-08-18 14:52:08 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:52:08 --> Final output sent to browser
DEBUG - 2017-08-18 14:52:08 --> Total execution time: 0.2397
INFO - 2017-08-18 14:52:34 --> Config Class Initialized
INFO - 2017-08-18 14:52:34 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:52:34 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:52:34 --> Utf8 Class Initialized
INFO - 2017-08-18 14:52:34 --> URI Class Initialized
INFO - 2017-08-18 14:52:34 --> Router Class Initialized
INFO - 2017-08-18 14:52:34 --> Output Class Initialized
INFO - 2017-08-18 14:52:34 --> Security Class Initialized
DEBUG - 2017-08-18 14:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:52:34 --> Input Class Initialized
INFO - 2017-08-18 14:52:34 --> Language Class Initialized
ERROR - 2017-08-18 14:52:34 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 58
INFO - 2017-08-18 14:52:34 --> Loader Class Initialized
INFO - 2017-08-18 14:52:35 --> Helper loaded: url_helper
INFO - 2017-08-18 14:52:35 --> Helper loaded: file_helper
INFO - 2017-08-18 14:52:35 --> Database Driver Class Initialized
INFO - 2017-08-18 14:52:35 --> Email Class Initialized
DEBUG - 2017-08-18 14:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:52:35 --> Table Class Initialized
INFO - 2017-08-18 14:52:35 --> Controller Class Initialized
INFO - 2017-08-18 14:52:35 --> Helper loaded: form_helper
INFO - 2017-08-18 14:52:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:52:35 --> Final output sent to browser
DEBUG - 2017-08-18 14:52:35 --> Total execution time: 0.2306
INFO - 2017-08-18 14:54:01 --> Config Class Initialized
INFO - 2017-08-18 14:54:01 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:54:01 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:54:01 --> Utf8 Class Initialized
INFO - 2017-08-18 14:54:01 --> URI Class Initialized
INFO - 2017-08-18 14:54:01 --> Router Class Initialized
INFO - 2017-08-18 14:54:01 --> Output Class Initialized
INFO - 2017-08-18 14:54:01 --> Security Class Initialized
DEBUG - 2017-08-18 14:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:54:01 --> Input Class Initialized
INFO - 2017-08-18 14:54:01 --> Language Class Initialized
ERROR - 2017-08-18 14:54:01 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 57
INFO - 2017-08-18 14:54:01 --> Loader Class Initialized
INFO - 2017-08-18 14:54:01 --> Helper loaded: url_helper
INFO - 2017-08-18 14:54:01 --> Helper loaded: file_helper
INFO - 2017-08-18 14:54:01 --> Database Driver Class Initialized
INFO - 2017-08-18 14:54:01 --> Email Class Initialized
DEBUG - 2017-08-18 14:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:54:01 --> Table Class Initialized
INFO - 2017-08-18 14:54:01 --> Controller Class Initialized
INFO - 2017-08-18 14:54:01 --> Helper loaded: form_helper
INFO - 2017-08-18 14:54:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:54:01 --> Final output sent to browser
DEBUG - 2017-08-18 14:54:01 --> Total execution time: 0.2469
INFO - 2017-08-18 14:54:49 --> Config Class Initialized
INFO - 2017-08-18 14:54:49 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:54:49 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:54:49 --> Utf8 Class Initialized
INFO - 2017-08-18 14:54:49 --> URI Class Initialized
INFO - 2017-08-18 14:54:49 --> Router Class Initialized
INFO - 2017-08-18 14:54:49 --> Output Class Initialized
INFO - 2017-08-18 14:54:49 --> Security Class Initialized
DEBUG - 2017-08-18 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:54:49 --> Input Class Initialized
INFO - 2017-08-18 14:54:49 --> Language Class Initialized
ERROR - 2017-08-18 14:54:49 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 57
INFO - 2017-08-18 14:54:49 --> Loader Class Initialized
INFO - 2017-08-18 14:54:49 --> Helper loaded: url_helper
INFO - 2017-08-18 14:54:49 --> Helper loaded: file_helper
INFO - 2017-08-18 14:54:49 --> Database Driver Class Initialized
INFO - 2017-08-18 14:54:49 --> Email Class Initialized
DEBUG - 2017-08-18 14:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:54:49 --> Table Class Initialized
INFO - 2017-08-18 14:54:49 --> Controller Class Initialized
INFO - 2017-08-18 14:54:49 --> Helper loaded: form_helper
INFO - 2017-08-18 14:54:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:54:49 --> Final output sent to browser
DEBUG - 2017-08-18 14:54:49 --> Total execution time: 0.2304
INFO - 2017-08-18 14:54:57 --> Config Class Initialized
INFO - 2017-08-18 14:54:57 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:54:57 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:54:57 --> Utf8 Class Initialized
INFO - 2017-08-18 14:54:57 --> URI Class Initialized
INFO - 2017-08-18 14:54:57 --> Router Class Initialized
INFO - 2017-08-18 14:54:57 --> Output Class Initialized
INFO - 2017-08-18 14:54:57 --> Security Class Initialized
DEBUG - 2017-08-18 14:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:54:57 --> Input Class Initialized
INFO - 2017-08-18 14:54:57 --> Language Class Initialized
ERROR - 2017-08-18 14:54:57 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 57
INFO - 2017-08-18 14:54:57 --> Loader Class Initialized
INFO - 2017-08-18 14:54:57 --> Helper loaded: url_helper
INFO - 2017-08-18 14:54:57 --> Helper loaded: file_helper
INFO - 2017-08-18 14:54:57 --> Database Driver Class Initialized
INFO - 2017-08-18 14:54:57 --> Email Class Initialized
DEBUG - 2017-08-18 14:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:54:57 --> Table Class Initialized
INFO - 2017-08-18 14:54:57 --> Controller Class Initialized
INFO - 2017-08-18 14:54:57 --> Helper loaded: form_helper
INFO - 2017-08-18 14:54:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:54:57 --> Final output sent to browser
DEBUG - 2017-08-18 14:54:57 --> Total execution time: 0.2320
INFO - 2017-08-18 14:55:06 --> Config Class Initialized
INFO - 2017-08-18 14:55:06 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:55:06 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:55:06 --> Utf8 Class Initialized
INFO - 2017-08-18 14:55:06 --> URI Class Initialized
INFO - 2017-08-18 14:55:06 --> Router Class Initialized
INFO - 2017-08-18 14:55:06 --> Output Class Initialized
INFO - 2017-08-18 14:55:06 --> Security Class Initialized
DEBUG - 2017-08-18 14:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:55:06 --> Input Class Initialized
INFO - 2017-08-18 14:55:06 --> Language Class Initialized
ERROR - 2017-08-18 14:55:06 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 57
INFO - 2017-08-18 14:55:06 --> Loader Class Initialized
INFO - 2017-08-18 14:55:06 --> Helper loaded: url_helper
INFO - 2017-08-18 14:55:06 --> Helper loaded: file_helper
INFO - 2017-08-18 14:55:06 --> Database Driver Class Initialized
INFO - 2017-08-18 14:55:06 --> Email Class Initialized
DEBUG - 2017-08-18 14:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:55:06 --> Table Class Initialized
INFO - 2017-08-18 14:55:06 --> Controller Class Initialized
INFO - 2017-08-18 14:55:06 --> Helper loaded: form_helper
INFO - 2017-08-18 14:55:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:55:06 --> Final output sent to browser
DEBUG - 2017-08-18 14:55:06 --> Total execution time: 0.2392
INFO - 2017-08-18 14:55:26 --> Config Class Initialized
INFO - 2017-08-18 14:55:26 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:55:27 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:55:27 --> Utf8 Class Initialized
INFO - 2017-08-18 14:55:27 --> URI Class Initialized
INFO - 2017-08-18 14:55:27 --> Router Class Initialized
INFO - 2017-08-18 14:55:27 --> Output Class Initialized
INFO - 2017-08-18 14:55:27 --> Security Class Initialized
DEBUG - 2017-08-18 14:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:55:27 --> Input Class Initialized
INFO - 2017-08-18 14:55:27 --> Language Class Initialized
ERROR - 2017-08-18 14:55:27 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 57
INFO - 2017-08-18 14:55:27 --> Loader Class Initialized
INFO - 2017-08-18 14:55:27 --> Helper loaded: url_helper
INFO - 2017-08-18 14:55:27 --> Helper loaded: file_helper
INFO - 2017-08-18 14:55:27 --> Database Driver Class Initialized
INFO - 2017-08-18 14:55:27 --> Email Class Initialized
DEBUG - 2017-08-18 14:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:55:27 --> Table Class Initialized
INFO - 2017-08-18 14:55:27 --> Controller Class Initialized
INFO - 2017-08-18 14:55:27 --> Helper loaded: form_helper
INFO - 2017-08-18 14:55:27 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:55:27 --> Final output sent to browser
DEBUG - 2017-08-18 14:55:27 --> Total execution time: 0.2307
INFO - 2017-08-18 14:55:55 --> Config Class Initialized
INFO - 2017-08-18 14:55:55 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:55:55 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:55:55 --> Utf8 Class Initialized
INFO - 2017-08-18 14:55:55 --> URI Class Initialized
INFO - 2017-08-18 14:55:55 --> Router Class Initialized
INFO - 2017-08-18 14:55:55 --> Output Class Initialized
INFO - 2017-08-18 14:55:55 --> Security Class Initialized
DEBUG - 2017-08-18 14:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:55:55 --> Input Class Initialized
INFO - 2017-08-18 14:55:55 --> Language Class Initialized
ERROR - 2017-08-18 14:55:55 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 57
INFO - 2017-08-18 14:55:55 --> Loader Class Initialized
INFO - 2017-08-18 14:55:55 --> Helper loaded: url_helper
INFO - 2017-08-18 14:55:55 --> Helper loaded: file_helper
INFO - 2017-08-18 14:55:55 --> Database Driver Class Initialized
INFO - 2017-08-18 14:55:55 --> Email Class Initialized
DEBUG - 2017-08-18 14:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:55:55 --> Table Class Initialized
INFO - 2017-08-18 14:55:55 --> Controller Class Initialized
INFO - 2017-08-18 14:55:55 --> Helper loaded: form_helper
INFO - 2017-08-18 14:55:55 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:55:55 --> Final output sent to browser
DEBUG - 2017-08-18 14:55:55 --> Total execution time: 0.2276
INFO - 2017-08-18 14:56:16 --> Config Class Initialized
INFO - 2017-08-18 14:56:16 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:56:16 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:56:16 --> Utf8 Class Initialized
INFO - 2017-08-18 14:56:16 --> URI Class Initialized
INFO - 2017-08-18 14:56:16 --> Router Class Initialized
INFO - 2017-08-18 14:56:16 --> Output Class Initialized
INFO - 2017-08-18 14:56:16 --> Security Class Initialized
DEBUG - 2017-08-18 14:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:56:16 --> Input Class Initialized
INFO - 2017-08-18 14:56:16 --> Language Class Initialized
ERROR - 2017-08-18 14:56:16 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 58
INFO - 2017-08-18 14:56:16 --> Loader Class Initialized
INFO - 2017-08-18 14:56:16 --> Helper loaded: url_helper
INFO - 2017-08-18 14:56:16 --> Helper loaded: file_helper
INFO - 2017-08-18 14:56:16 --> Database Driver Class Initialized
INFO - 2017-08-18 14:56:16 --> Email Class Initialized
DEBUG - 2017-08-18 14:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:56:16 --> Table Class Initialized
INFO - 2017-08-18 14:56:16 --> Controller Class Initialized
INFO - 2017-08-18 14:56:16 --> Helper loaded: form_helper
INFO - 2017-08-18 14:56:16 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:56:16 --> Final output sent to browser
DEBUG - 2017-08-18 14:56:16 --> Total execution time: 0.2294
INFO - 2017-08-18 14:56:24 --> Config Class Initialized
INFO - 2017-08-18 14:56:24 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:56:24 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:56:24 --> Utf8 Class Initialized
INFO - 2017-08-18 14:56:24 --> URI Class Initialized
INFO - 2017-08-18 14:56:24 --> Router Class Initialized
INFO - 2017-08-18 14:56:24 --> Output Class Initialized
INFO - 2017-08-18 14:56:24 --> Security Class Initialized
DEBUG - 2017-08-18 14:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:56:24 --> Input Class Initialized
INFO - 2017-08-18 14:56:24 --> Language Class Initialized
ERROR - 2017-08-18 14:56:24 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 58
INFO - 2017-08-18 14:56:24 --> Loader Class Initialized
INFO - 2017-08-18 14:56:24 --> Helper loaded: url_helper
INFO - 2017-08-18 14:56:24 --> Helper loaded: file_helper
INFO - 2017-08-18 14:56:24 --> Database Driver Class Initialized
INFO - 2017-08-18 14:56:24 --> Email Class Initialized
DEBUG - 2017-08-18 14:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:56:24 --> Table Class Initialized
INFO - 2017-08-18 14:56:24 --> Controller Class Initialized
INFO - 2017-08-18 14:56:24 --> Helper loaded: form_helper
INFO - 2017-08-18 14:56:24 --> Upload Class Initialized
INFO - 2017-08-18 14:56:24 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 14:56:24 --> You did not select a file to upload.
INFO - 2017-08-18 14:56:24 --> Final output sent to browser
DEBUG - 2017-08-18 14:56:24 --> Total execution time: 0.2877
INFO - 2017-08-18 14:56:45 --> Config Class Initialized
INFO - 2017-08-18 14:56:45 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:56:45 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:56:45 --> Utf8 Class Initialized
INFO - 2017-08-18 14:56:45 --> URI Class Initialized
INFO - 2017-08-18 14:56:45 --> Router Class Initialized
INFO - 2017-08-18 14:56:45 --> Output Class Initialized
INFO - 2017-08-18 14:56:45 --> Security Class Initialized
DEBUG - 2017-08-18 14:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:56:45 --> Input Class Initialized
INFO - 2017-08-18 14:56:45 --> Language Class Initialized
ERROR - 2017-08-18 14:56:45 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 59
INFO - 2017-08-18 14:56:45 --> Loader Class Initialized
INFO - 2017-08-18 14:56:45 --> Helper loaded: url_helper
INFO - 2017-08-18 14:56:45 --> Helper loaded: file_helper
INFO - 2017-08-18 14:56:45 --> Database Driver Class Initialized
INFO - 2017-08-18 14:56:45 --> Email Class Initialized
DEBUG - 2017-08-18 14:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:56:45 --> Table Class Initialized
INFO - 2017-08-18 14:56:45 --> Controller Class Initialized
INFO - 2017-08-18 14:56:45 --> Helper loaded: form_helper
INFO - 2017-08-18 14:56:45 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 14:56:45 --> Final output sent to browser
DEBUG - 2017-08-18 14:56:45 --> Total execution time: 0.2404
INFO - 2017-08-18 14:56:51 --> Config Class Initialized
INFO - 2017-08-18 14:56:51 --> Hooks Class Initialized
DEBUG - 2017-08-18 14:56:51 --> UTF-8 Support Enabled
INFO - 2017-08-18 14:56:51 --> Utf8 Class Initialized
INFO - 2017-08-18 14:56:51 --> URI Class Initialized
INFO - 2017-08-18 14:56:51 --> Router Class Initialized
INFO - 2017-08-18 14:56:51 --> Output Class Initialized
INFO - 2017-08-18 14:56:51 --> Security Class Initialized
DEBUG - 2017-08-18 14:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 14:56:51 --> Input Class Initialized
INFO - 2017-08-18 14:56:51 --> Language Class Initialized
ERROR - 2017-08-18 14:56:51 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 59
INFO - 2017-08-18 14:56:51 --> Loader Class Initialized
INFO - 2017-08-18 14:56:51 --> Helper loaded: url_helper
INFO - 2017-08-18 14:56:51 --> Helper loaded: file_helper
INFO - 2017-08-18 14:56:51 --> Database Driver Class Initialized
INFO - 2017-08-18 14:56:51 --> Email Class Initialized
DEBUG - 2017-08-18 14:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 14:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 14:56:51 --> Table Class Initialized
INFO - 2017-08-18 14:56:51 --> Controller Class Initialized
INFO - 2017-08-18 14:56:51 --> Helper loaded: form_helper
INFO - 2017-08-18 14:56:51 --> Upload Class Initialized
INFO - 2017-08-18 14:56:51 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 14:56:51 --> You did not select a file to upload.
INFO - 2017-08-18 14:56:51 --> Final output sent to browser
DEBUG - 2017-08-18 14:56:51 --> Total execution time: 0.2895
INFO - 2017-08-18 15:01:50 --> Config Class Initialized
INFO - 2017-08-18 15:01:50 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:01:50 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:01:50 --> Utf8 Class Initialized
INFO - 2017-08-18 15:01:50 --> URI Class Initialized
INFO - 2017-08-18 15:01:50 --> Router Class Initialized
INFO - 2017-08-18 15:01:50 --> Output Class Initialized
INFO - 2017-08-18 15:01:50 --> Security Class Initialized
DEBUG - 2017-08-18 15:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:01:50 --> Input Class Initialized
INFO - 2017-08-18 15:01:50 --> Language Class Initialized
ERROR - 2017-08-18 15:01:50 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 55
INFO - 2017-08-18 15:01:50 --> Loader Class Initialized
INFO - 2017-08-18 15:01:50 --> Helper loaded: url_helper
INFO - 2017-08-18 15:01:50 --> Helper loaded: file_helper
INFO - 2017-08-18 15:01:50 --> Database Driver Class Initialized
INFO - 2017-08-18 15:01:50 --> Email Class Initialized
DEBUG - 2017-08-18 15:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 15:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 15:01:51 --> Table Class Initialized
INFO - 2017-08-18 15:01:51 --> Controller Class Initialized
INFO - 2017-08-18 15:01:51 --> Helper loaded: form_helper
INFO - 2017-08-18 15:01:51 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 15:01:51 --> Final output sent to browser
DEBUG - 2017-08-18 15:01:51 --> Total execution time: 0.2418
INFO - 2017-08-18 15:01:56 --> Config Class Initialized
INFO - 2017-08-18 15:01:56 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:01:56 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:01:56 --> Utf8 Class Initialized
INFO - 2017-08-18 15:01:56 --> URI Class Initialized
INFO - 2017-08-18 15:01:56 --> Router Class Initialized
INFO - 2017-08-18 15:01:56 --> Output Class Initialized
INFO - 2017-08-18 15:01:56 --> Security Class Initialized
DEBUG - 2017-08-18 15:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:01:56 --> Input Class Initialized
INFO - 2017-08-18 15:01:56 --> Language Class Initialized
ERROR - 2017-08-18 15:01:56 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 55
INFO - 2017-08-18 15:01:56 --> Loader Class Initialized
INFO - 2017-08-18 15:01:56 --> Helper loaded: url_helper
INFO - 2017-08-18 15:01:56 --> Helper loaded: file_helper
INFO - 2017-08-18 15:01:56 --> Database Driver Class Initialized
INFO - 2017-08-18 15:01:56 --> Email Class Initialized
DEBUG - 2017-08-18 15:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 15:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 15:01:56 --> Table Class Initialized
INFO - 2017-08-18 15:01:56 --> Controller Class Initialized
INFO - 2017-08-18 15:01:56 --> Helper loaded: form_helper
INFO - 2017-08-18 15:01:56 --> Upload Class Initialized
INFO - 2017-08-18 15:01:56 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-18 15:01:56 --> You did not select a file to upload.
INFO - 2017-08-18 15:01:56 --> Final output sent to browser
DEBUG - 2017-08-18 15:01:56 --> Total execution time: 0.2997
INFO - 2017-08-18 15:08:33 --> Config Class Initialized
INFO - 2017-08-18 15:08:33 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:08:33 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:08:33 --> Utf8 Class Initialized
INFO - 2017-08-18 15:08:33 --> URI Class Initialized
INFO - 2017-08-18 15:08:33 --> Router Class Initialized
INFO - 2017-08-18 15:08:33 --> Output Class Initialized
INFO - 2017-08-18 15:08:33 --> Security Class Initialized
DEBUG - 2017-08-18 15:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:08:33 --> Input Class Initialized
INFO - 2017-08-18 15:08:33 --> Language Class Initialized
ERROR - 2017-08-18 15:08:33 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 55
INFO - 2017-08-18 15:08:33 --> Loader Class Initialized
INFO - 2017-08-18 15:08:33 --> Helper loaded: url_helper
INFO - 2017-08-18 15:08:33 --> Helper loaded: file_helper
INFO - 2017-08-18 15:08:33 --> Database Driver Class Initialized
INFO - 2017-08-18 15:08:33 --> Email Class Initialized
DEBUG - 2017-08-18 15:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 15:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 15:08:33 --> Table Class Initialized
INFO - 2017-08-18 15:08:33 --> Controller Class Initialized
INFO - 2017-08-18 15:08:33 --> Helper loaded: form_helper
INFO - 2017-08-18 15:08:33 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 15:08:33 --> Final output sent to browser
DEBUG - 2017-08-18 15:08:33 --> Total execution time: 0.2471
INFO - 2017-08-18 15:08:39 --> Config Class Initialized
INFO - 2017-08-18 15:08:39 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:08:39 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:08:39 --> Utf8 Class Initialized
INFO - 2017-08-18 15:08:39 --> URI Class Initialized
INFO - 2017-08-18 15:08:39 --> Router Class Initialized
INFO - 2017-08-18 15:08:39 --> Output Class Initialized
INFO - 2017-08-18 15:08:39 --> Security Class Initialized
DEBUG - 2017-08-18 15:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:08:39 --> Input Class Initialized
INFO - 2017-08-18 15:08:39 --> Language Class Initialized
ERROR - 2017-08-18 15:08:39 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 55
INFO - 2017-08-18 15:08:39 --> Loader Class Initialized
INFO - 2017-08-18 15:08:39 --> Helper loaded: url_helper
INFO - 2017-08-18 15:08:39 --> Helper loaded: file_helper
INFO - 2017-08-18 15:08:39 --> Database Driver Class Initialized
INFO - 2017-08-18 15:08:39 --> Email Class Initialized
DEBUG - 2017-08-18 15:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 15:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 15:08:39 --> Table Class Initialized
INFO - 2017-08-18 15:08:39 --> Controller Class Initialized
INFO - 2017-08-18 15:08:40 --> Helper loaded: form_helper
INFO - 2017-08-18 15:08:40 --> Upload Class Initialized
INFO - 2017-08-18 15:08:40 --> Final output sent to browser
DEBUG - 2017-08-18 15:08:40 --> Total execution time: 0.2859
INFO - 2017-08-18 15:10:58 --> Config Class Initialized
INFO - 2017-08-18 15:10:58 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:10:58 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:10:58 --> Utf8 Class Initialized
INFO - 2017-08-18 15:10:58 --> URI Class Initialized
INFO - 2017-08-18 15:10:58 --> Router Class Initialized
INFO - 2017-08-18 15:10:58 --> Output Class Initialized
INFO - 2017-08-18 15:10:58 --> Security Class Initialized
DEBUG - 2017-08-18 15:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:10:58 --> Input Class Initialized
INFO - 2017-08-18 15:10:58 --> Language Class Initialized
ERROR - 2017-08-18 15:10:58 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 55
INFO - 2017-08-18 15:10:58 --> Loader Class Initialized
INFO - 2017-08-18 15:10:58 --> Helper loaded: url_helper
INFO - 2017-08-18 15:10:58 --> Helper loaded: file_helper
INFO - 2017-08-18 15:10:58 --> Database Driver Class Initialized
INFO - 2017-08-18 15:10:58 --> Email Class Initialized
DEBUG - 2017-08-18 15:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 15:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 15:10:59 --> Table Class Initialized
INFO - 2017-08-18 15:10:59 --> Controller Class Initialized
INFO - 2017-08-18 15:10:59 --> Helper loaded: form_helper
INFO - 2017-08-18 15:10:59 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 15:10:59 --> Final output sent to browser
DEBUG - 2017-08-18 15:10:59 --> Total execution time: 0.2547
INFO - 2017-08-18 15:11:04 --> Config Class Initialized
INFO - 2017-08-18 15:11:04 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:11:04 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:11:04 --> Utf8 Class Initialized
INFO - 2017-08-18 15:11:04 --> URI Class Initialized
INFO - 2017-08-18 15:11:04 --> Router Class Initialized
INFO - 2017-08-18 15:11:04 --> Output Class Initialized
INFO - 2017-08-18 15:11:04 --> Security Class Initialized
DEBUG - 2017-08-18 15:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:11:04 --> Input Class Initialized
INFO - 2017-08-18 15:11:04 --> Language Class Initialized
ERROR - 2017-08-18 15:11:04 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 55
INFO - 2017-08-18 15:11:04 --> Loader Class Initialized
INFO - 2017-08-18 15:11:04 --> Helper loaded: url_helper
INFO - 2017-08-18 15:11:04 --> Helper loaded: file_helper
INFO - 2017-08-18 15:11:04 --> Database Driver Class Initialized
INFO - 2017-08-18 15:11:04 --> Email Class Initialized
DEBUG - 2017-08-18 15:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 15:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 15:11:04 --> Table Class Initialized
INFO - 2017-08-18 15:11:04 --> Controller Class Initialized
INFO - 2017-08-18 15:11:04 --> Helper loaded: form_helper
INFO - 2017-08-18 15:11:04 --> Upload Class Initialized
INFO - 2017-08-18 15:11:04 --> Final output sent to browser
DEBUG - 2017-08-18 15:11:04 --> Total execution time: 0.2812
INFO - 2017-08-18 15:16:15 --> Config Class Initialized
INFO - 2017-08-18 15:16:15 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:16:15 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:16:15 --> Utf8 Class Initialized
INFO - 2017-08-18 15:16:15 --> URI Class Initialized
INFO - 2017-08-18 15:16:15 --> Router Class Initialized
INFO - 2017-08-18 15:16:15 --> Output Class Initialized
INFO - 2017-08-18 15:16:15 --> Security Class Initialized
DEBUG - 2017-08-18 15:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:16:15 --> Input Class Initialized
INFO - 2017-08-18 15:16:15 --> Language Class Initialized
INFO - 2017-08-18 15:16:15 --> Loader Class Initialized
INFO - 2017-08-18 15:16:15 --> Helper loaded: url_helper
INFO - 2017-08-18 15:16:15 --> Helper loaded: file_helper
INFO - 2017-08-18 15:16:15 --> Database Driver Class Initialized
INFO - 2017-08-18 15:16:15 --> Email Class Initialized
DEBUG - 2017-08-18 15:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 15:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 15:16:15 --> Table Class Initialized
INFO - 2017-08-18 15:16:15 --> Controller Class Initialized
INFO - 2017-08-18 15:16:15 --> Helper loaded: form_helper
INFO - 2017-08-18 15:16:15 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-18 15:16:15 --> Final output sent to browser
DEBUG - 2017-08-18 15:16:15 --> Total execution time: 0.2422
INFO - 2017-08-18 15:16:22 --> Config Class Initialized
INFO - 2017-08-18 15:16:22 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:16:22 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:16:22 --> Utf8 Class Initialized
INFO - 2017-08-18 15:16:22 --> URI Class Initialized
INFO - 2017-08-18 15:16:22 --> Router Class Initialized
INFO - 2017-08-18 15:16:22 --> Output Class Initialized
INFO - 2017-08-18 15:16:22 --> Security Class Initialized
DEBUG - 2017-08-18 15:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:16:22 --> Input Class Initialized
INFO - 2017-08-18 15:16:22 --> Language Class Initialized
INFO - 2017-08-18 15:16:22 --> Loader Class Initialized
INFO - 2017-08-18 15:16:22 --> Helper loaded: url_helper
INFO - 2017-08-18 15:16:22 --> Helper loaded: file_helper
INFO - 2017-08-18 15:16:22 --> Database Driver Class Initialized
INFO - 2017-08-18 15:16:22 --> Email Class Initialized
DEBUG - 2017-08-18 15:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 15:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 15:16:22 --> Table Class Initialized
INFO - 2017-08-18 15:16:22 --> Controller Class Initialized
INFO - 2017-08-18 15:16:22 --> Helper loaded: form_helper
INFO - 2017-08-18 15:16:22 --> Upload Class Initialized
INFO - 2017-08-18 15:16:22 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-08-18 15:16:22 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2017-08-18 15:16:22 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_form.php
INFO - 2017-08-18 15:16:22 --> Final output sent to browser
DEBUG - 2017-08-18 15:16:22 --> Total execution time: 0.2475
INFO - 2017-08-18 15:16:31 --> Config Class Initialized
INFO - 2017-08-18 15:16:31 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:16:31 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:16:31 --> Utf8 Class Initialized
INFO - 2017-08-18 15:16:31 --> URI Class Initialized
INFO - 2017-08-18 15:16:31 --> Router Class Initialized
INFO - 2017-08-18 15:16:31 --> Output Class Initialized
INFO - 2017-08-18 15:16:31 --> Security Class Initialized
DEBUG - 2017-08-18 15:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:16:31 --> Input Class Initialized
INFO - 2017-08-18 15:16:31 --> Language Class Initialized
INFO - 2017-08-18 15:16:31 --> Loader Class Initialized
INFO - 2017-08-18 15:16:31 --> Helper loaded: url_helper
INFO - 2017-08-18 15:16:31 --> Helper loaded: file_helper
INFO - 2017-08-18 15:16:31 --> Database Driver Class Initialized
INFO - 2017-08-18 15:16:31 --> Email Class Initialized
DEBUG - 2017-08-18 15:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 15:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 15:16:31 --> Table Class Initialized
INFO - 2017-08-18 15:16:31 --> Controller Class Initialized
INFO - 2017-08-18 15:16:31 --> Helper loaded: form_helper
INFO - 2017-08-18 15:16:31 --> Upload Class Initialized
INFO - 2017-08-18 15:16:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\upload_success.php
INFO - 2017-08-18 15:16:31 --> Final output sent to browser
DEBUG - 2017-08-18 15:16:31 --> Total execution time: 0.2478
INFO - 2017-08-18 19:49:31 --> Config Class Initialized
INFO - 2017-08-18 19:49:31 --> Hooks Class Initialized
DEBUG - 2017-08-18 19:49:31 --> UTF-8 Support Enabled
INFO - 2017-08-18 19:49:31 --> Utf8 Class Initialized
INFO - 2017-08-18 19:49:31 --> URI Class Initialized
INFO - 2017-08-18 19:49:31 --> Router Class Initialized
INFO - 2017-08-18 19:49:31 --> Output Class Initialized
INFO - 2017-08-18 19:49:31 --> Security Class Initialized
DEBUG - 2017-08-18 19:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 19:49:32 --> Input Class Initialized
INFO - 2017-08-18 19:49:32 --> Language Class Initialized
ERROR - 2017-08-18 19:49:32 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 52
INFO - 2017-08-18 19:49:32 --> Loader Class Initialized
INFO - 2017-08-18 19:49:32 --> Helper loaded: url_helper
INFO - 2017-08-18 19:49:32 --> Helper loaded: file_helper
INFO - 2017-08-18 19:49:32 --> Database Driver Class Initialized
INFO - 2017-08-18 19:49:32 --> Email Class Initialized
DEBUG - 2017-08-18 19:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 19:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 19:49:32 --> Table Class Initialized
INFO - 2017-08-18 19:49:32 --> Controller Class Initialized
INFO - 2017-08-18 19:49:32 --> Helper loaded: form_helper
INFO - 2017-08-18 19:49:32 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 19:49:32 --> Final output sent to browser
DEBUG - 2017-08-18 19:49:32 --> Total execution time: 1.7572
INFO - 2017-08-18 19:49:56 --> Config Class Initialized
INFO - 2017-08-18 19:49:56 --> Hooks Class Initialized
DEBUG - 2017-08-18 19:49:56 --> UTF-8 Support Enabled
INFO - 2017-08-18 19:49:56 --> Utf8 Class Initialized
INFO - 2017-08-18 19:49:56 --> URI Class Initialized
INFO - 2017-08-18 19:49:56 --> Router Class Initialized
INFO - 2017-08-18 19:49:56 --> Output Class Initialized
INFO - 2017-08-18 19:49:56 --> Security Class Initialized
DEBUG - 2017-08-18 19:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 19:49:56 --> Input Class Initialized
INFO - 2017-08-18 19:49:56 --> Language Class Initialized
ERROR - 2017-08-18 19:49:56 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 52
INFO - 2017-08-18 19:49:56 --> Loader Class Initialized
INFO - 2017-08-18 19:49:56 --> Helper loaded: url_helper
INFO - 2017-08-18 19:49:56 --> Helper loaded: file_helper
INFO - 2017-08-18 19:49:56 --> Database Driver Class Initialized
INFO - 2017-08-18 19:49:56 --> Email Class Initialized
DEBUG - 2017-08-18 19:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 19:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 19:49:56 --> Table Class Initialized
INFO - 2017-08-18 19:49:56 --> Controller Class Initialized
INFO - 2017-08-18 19:49:56 --> Helper loaded: form_helper
INFO - 2017-08-18 19:49:56 --> Upload Class Initialized
INFO - 2017-08-18 19:49:56 --> Final output sent to browser
DEBUG - 2017-08-18 19:49:56 --> Total execution time: 0.3032
INFO - 2017-08-18 20:01:29 --> Config Class Initialized
INFO - 2017-08-18 20:01:29 --> Hooks Class Initialized
DEBUG - 2017-08-18 20:01:29 --> UTF-8 Support Enabled
INFO - 2017-08-18 20:01:29 --> Utf8 Class Initialized
INFO - 2017-08-18 20:01:29 --> URI Class Initialized
INFO - 2017-08-18 20:01:29 --> Router Class Initialized
INFO - 2017-08-18 20:01:29 --> Output Class Initialized
INFO - 2017-08-18 20:01:29 --> Security Class Initialized
DEBUG - 2017-08-18 20:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 20:01:29 --> Input Class Initialized
INFO - 2017-08-18 20:01:29 --> Language Class Initialized
ERROR - 2017-08-18 20:01:29 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 52
INFO - 2017-08-18 20:01:29 --> Loader Class Initialized
INFO - 2017-08-18 20:01:29 --> Helper loaded: url_helper
INFO - 2017-08-18 20:01:29 --> Helper loaded: file_helper
INFO - 2017-08-18 20:01:29 --> Database Driver Class Initialized
INFO - 2017-08-18 20:01:29 --> Email Class Initialized
DEBUG - 2017-08-18 20:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 20:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 20:01:29 --> Table Class Initialized
INFO - 2017-08-18 20:01:29 --> Controller Class Initialized
INFO - 2017-08-18 20:01:29 --> Helper loaded: form_helper
INFO - 2017-08-18 20:01:29 --> Upload Class Initialized
INFO - 2017-08-18 20:01:29 --> Final output sent to browser
DEBUG - 2017-08-18 20:01:29 --> Total execution time: 0.2541
INFO - 2017-08-18 20:01:50 --> Config Class Initialized
INFO - 2017-08-18 20:01:50 --> Hooks Class Initialized
DEBUG - 2017-08-18 20:01:50 --> UTF-8 Support Enabled
INFO - 2017-08-18 20:01:50 --> Utf8 Class Initialized
INFO - 2017-08-18 20:01:50 --> URI Class Initialized
INFO - 2017-08-18 20:01:50 --> Router Class Initialized
INFO - 2017-08-18 20:01:50 --> Output Class Initialized
INFO - 2017-08-18 20:01:50 --> Security Class Initialized
DEBUG - 2017-08-18 20:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 20:01:50 --> Input Class Initialized
INFO - 2017-08-18 20:01:50 --> Language Class Initialized
ERROR - 2017-08-18 20:01:50 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 52
INFO - 2017-08-18 20:01:50 --> Loader Class Initialized
INFO - 2017-08-18 20:01:50 --> Helper loaded: url_helper
INFO - 2017-08-18 20:01:50 --> Helper loaded: file_helper
INFO - 2017-08-18 20:01:50 --> Database Driver Class Initialized
INFO - 2017-08-18 20:01:50 --> Email Class Initialized
DEBUG - 2017-08-18 20:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 20:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 20:01:50 --> Table Class Initialized
INFO - 2017-08-18 20:01:50 --> Controller Class Initialized
INFO - 2017-08-18 20:01:50 --> Helper loaded: form_helper
INFO - 2017-08-18 20:01:50 --> Upload Class Initialized
INFO - 2017-08-18 20:01:50 --> Final output sent to browser
DEBUG - 2017-08-18 20:01:50 --> Total execution time: 0.2546
INFO - 2017-08-18 20:22:09 --> Config Class Initialized
INFO - 2017-08-18 20:22:09 --> Hooks Class Initialized
DEBUG - 2017-08-18 20:22:09 --> UTF-8 Support Enabled
INFO - 2017-08-18 20:22:09 --> Utf8 Class Initialized
INFO - 2017-08-18 20:22:09 --> URI Class Initialized
INFO - 2017-08-18 20:22:09 --> Router Class Initialized
INFO - 2017-08-18 20:22:09 --> Output Class Initialized
INFO - 2017-08-18 20:22:09 --> Security Class Initialized
DEBUG - 2017-08-18 20:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 20:22:09 --> Input Class Initialized
INFO - 2017-08-18 20:22:09 --> Language Class Initialized
ERROR - 2017-08-18 20:22:09 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 52
INFO - 2017-08-18 20:22:09 --> Loader Class Initialized
INFO - 2017-08-18 20:22:09 --> Helper loaded: url_helper
INFO - 2017-08-18 20:22:09 --> Helper loaded: file_helper
INFO - 2017-08-18 20:22:09 --> Database Driver Class Initialized
INFO - 2017-08-18 20:22:09 --> Email Class Initialized
DEBUG - 2017-08-18 20:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 20:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 20:22:09 --> Table Class Initialized
INFO - 2017-08-18 20:22:09 --> Controller Class Initialized
INFO - 2017-08-18 20:22:09 --> Helper loaded: form_helper
INFO - 2017-08-18 20:22:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 20:22:09 --> Final output sent to browser
DEBUG - 2017-08-18 20:22:09 --> Total execution time: 0.2526
INFO - 2017-08-18 20:22:15 --> Config Class Initialized
INFO - 2017-08-18 20:22:15 --> Hooks Class Initialized
DEBUG - 2017-08-18 20:22:15 --> UTF-8 Support Enabled
INFO - 2017-08-18 20:22:15 --> Utf8 Class Initialized
INFO - 2017-08-18 20:22:15 --> URI Class Initialized
INFO - 2017-08-18 20:22:15 --> Router Class Initialized
INFO - 2017-08-18 20:22:15 --> Output Class Initialized
INFO - 2017-08-18 20:22:15 --> Security Class Initialized
DEBUG - 2017-08-18 20:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 20:22:15 --> Input Class Initialized
INFO - 2017-08-18 20:22:15 --> Language Class Initialized
ERROR - 2017-08-18 20:22:15 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\biokimia\application\controllers\Post.php 52
INFO - 2017-08-18 20:22:15 --> Loader Class Initialized
INFO - 2017-08-18 20:22:16 --> Helper loaded: url_helper
INFO - 2017-08-18 20:22:16 --> Helper loaded: file_helper
INFO - 2017-08-18 20:22:16 --> Database Driver Class Initialized
INFO - 2017-08-18 20:22:16 --> Email Class Initialized
DEBUG - 2017-08-18 20:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 20:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 20:22:16 --> Table Class Initialized
INFO - 2017-08-18 20:22:16 --> Controller Class Initialized
INFO - 2017-08-18 20:22:16 --> Helper loaded: form_helper
INFO - 2017-08-18 20:22:16 --> Upload Class Initialized
INFO - 2017-08-18 20:22:16 --> Final output sent to browser
DEBUG - 2017-08-18 20:22:16 --> Total execution time: 0.2834
INFO - 2017-08-18 21:31:22 --> Config Class Initialized
INFO - 2017-08-18 21:31:22 --> Hooks Class Initialized
DEBUG - 2017-08-18 21:31:22 --> UTF-8 Support Enabled
INFO - 2017-08-18 21:31:22 --> Utf8 Class Initialized
INFO - 2017-08-18 21:31:22 --> URI Class Initialized
INFO - 2017-08-18 21:31:22 --> Router Class Initialized
INFO - 2017-08-18 21:31:22 --> Output Class Initialized
INFO - 2017-08-18 21:31:23 --> Security Class Initialized
DEBUG - 2017-08-18 21:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 21:31:23 --> Input Class Initialized
INFO - 2017-08-18 21:31:23 --> Language Class Initialized
INFO - 2017-08-18 21:31:23 --> Loader Class Initialized
INFO - 2017-08-18 21:31:23 --> Helper loaded: url_helper
INFO - 2017-08-18 21:31:23 --> Helper loaded: file_helper
INFO - 2017-08-18 21:31:23 --> Database Driver Class Initialized
INFO - 2017-08-18 21:31:23 --> Email Class Initialized
DEBUG - 2017-08-18 21:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 21:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 21:31:23 --> Table Class Initialized
INFO - 2017-08-18 21:31:23 --> Controller Class Initialized
INFO - 2017-08-18 21:31:23 --> Helper loaded: form_helper
INFO - 2017-08-18 21:31:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 21:31:23 --> Final output sent to browser
DEBUG - 2017-08-18 21:31:23 --> Total execution time: 0.2434
INFO - 2017-08-18 21:31:34 --> Config Class Initialized
INFO - 2017-08-18 21:31:34 --> Hooks Class Initialized
DEBUG - 2017-08-18 21:31:34 --> UTF-8 Support Enabled
INFO - 2017-08-18 21:31:34 --> Utf8 Class Initialized
INFO - 2017-08-18 21:31:34 --> URI Class Initialized
INFO - 2017-08-18 21:31:34 --> Router Class Initialized
INFO - 2017-08-18 21:31:34 --> Output Class Initialized
INFO - 2017-08-18 21:31:35 --> Security Class Initialized
DEBUG - 2017-08-18 21:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 21:31:35 --> Input Class Initialized
INFO - 2017-08-18 21:31:35 --> Language Class Initialized
INFO - 2017-08-18 21:31:35 --> Loader Class Initialized
INFO - 2017-08-18 21:31:35 --> Helper loaded: url_helper
INFO - 2017-08-18 21:31:35 --> Helper loaded: file_helper
INFO - 2017-08-18 21:31:35 --> Database Driver Class Initialized
INFO - 2017-08-18 21:31:35 --> Email Class Initialized
DEBUG - 2017-08-18 21:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 21:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 21:31:35 --> Table Class Initialized
INFO - 2017-08-18 21:31:35 --> Controller Class Initialized
INFO - 2017-08-18 21:31:35 --> Helper loaded: form_helper
INFO - 2017-08-18 21:31:35 --> Upload Class Initialized
INFO - 2017-08-18 21:31:35 --> Final output sent to browser
DEBUG - 2017-08-18 21:31:35 --> Total execution time: 0.2766
INFO - 2017-08-18 21:32:00 --> Config Class Initialized
INFO - 2017-08-18 21:32:00 --> Hooks Class Initialized
DEBUG - 2017-08-18 21:32:00 --> UTF-8 Support Enabled
INFO - 2017-08-18 21:32:00 --> Utf8 Class Initialized
INFO - 2017-08-18 21:32:00 --> URI Class Initialized
INFO - 2017-08-18 21:32:00 --> Router Class Initialized
INFO - 2017-08-18 21:32:00 --> Output Class Initialized
INFO - 2017-08-18 21:32:00 --> Security Class Initialized
DEBUG - 2017-08-18 21:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 21:32:00 --> Input Class Initialized
INFO - 2017-08-18 21:32:00 --> Language Class Initialized
INFO - 2017-08-18 21:32:00 --> Loader Class Initialized
INFO - 2017-08-18 21:32:00 --> Helper loaded: url_helper
INFO - 2017-08-18 21:32:00 --> Helper loaded: file_helper
INFO - 2017-08-18 21:32:00 --> Database Driver Class Initialized
INFO - 2017-08-18 21:32:00 --> Email Class Initialized
DEBUG - 2017-08-18 21:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 21:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 21:32:00 --> Table Class Initialized
INFO - 2017-08-18 21:32:00 --> Controller Class Initialized
INFO - 2017-08-18 21:32:00 --> Helper loaded: form_helper
INFO - 2017-08-18 21:32:00 --> Final output sent to browser
DEBUG - 2017-08-18 21:32:00 --> Total execution time: 0.2234
INFO - 2017-08-18 21:32:09 --> Config Class Initialized
INFO - 2017-08-18 21:32:09 --> Hooks Class Initialized
DEBUG - 2017-08-18 21:32:09 --> UTF-8 Support Enabled
INFO - 2017-08-18 21:32:09 --> Utf8 Class Initialized
INFO - 2017-08-18 21:32:09 --> URI Class Initialized
INFO - 2017-08-18 21:32:09 --> Router Class Initialized
INFO - 2017-08-18 21:32:09 --> Output Class Initialized
INFO - 2017-08-18 21:32:09 --> Security Class Initialized
DEBUG - 2017-08-18 21:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 21:32:09 --> Input Class Initialized
INFO - 2017-08-18 21:32:09 --> Language Class Initialized
INFO - 2017-08-18 21:32:09 --> Loader Class Initialized
INFO - 2017-08-18 21:32:09 --> Helper loaded: url_helper
INFO - 2017-08-18 21:32:09 --> Helper loaded: file_helper
INFO - 2017-08-18 21:32:09 --> Database Driver Class Initialized
INFO - 2017-08-18 21:32:09 --> Email Class Initialized
DEBUG - 2017-08-18 21:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 21:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 21:32:09 --> Table Class Initialized
INFO - 2017-08-18 21:32:09 --> Controller Class Initialized
INFO - 2017-08-18 21:32:09 --> Helper loaded: form_helper
INFO - 2017-08-18 21:32:09 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 21:32:09 --> Final output sent to browser
DEBUG - 2017-08-18 21:32:09 --> Total execution time: 0.2471
INFO - 2017-08-18 21:32:16 --> Config Class Initialized
INFO - 2017-08-18 21:32:16 --> Hooks Class Initialized
DEBUG - 2017-08-18 21:32:16 --> UTF-8 Support Enabled
INFO - 2017-08-18 21:32:16 --> Utf8 Class Initialized
INFO - 2017-08-18 21:32:16 --> URI Class Initialized
INFO - 2017-08-18 21:32:16 --> Router Class Initialized
INFO - 2017-08-18 21:32:16 --> Output Class Initialized
INFO - 2017-08-18 21:32:16 --> Security Class Initialized
DEBUG - 2017-08-18 21:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 21:32:16 --> Input Class Initialized
INFO - 2017-08-18 21:32:16 --> Language Class Initialized
INFO - 2017-08-18 21:32:16 --> Loader Class Initialized
INFO - 2017-08-18 21:32:16 --> Helper loaded: url_helper
INFO - 2017-08-18 21:32:16 --> Helper loaded: file_helper
INFO - 2017-08-18 21:32:16 --> Database Driver Class Initialized
INFO - 2017-08-18 21:32:16 --> Email Class Initialized
DEBUG - 2017-08-18 21:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 21:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 21:32:16 --> Table Class Initialized
INFO - 2017-08-18 21:32:16 --> Controller Class Initialized
INFO - 2017-08-18 21:32:16 --> Helper loaded: form_helper
INFO - 2017-08-18 21:32:16 --> Upload Class Initialized
INFO - 2017-08-18 21:32:16 --> Final output sent to browser
DEBUG - 2017-08-18 21:32:16 --> Total execution time: 0.2715
INFO - 2017-08-18 21:32:56 --> Config Class Initialized
INFO - 2017-08-18 21:32:56 --> Hooks Class Initialized
DEBUG - 2017-08-18 21:32:56 --> UTF-8 Support Enabled
INFO - 2017-08-18 21:32:56 --> Utf8 Class Initialized
INFO - 2017-08-18 21:32:56 --> URI Class Initialized
INFO - 2017-08-18 21:32:56 --> Router Class Initialized
INFO - 2017-08-18 21:32:56 --> Output Class Initialized
INFO - 2017-08-18 21:32:56 --> Security Class Initialized
DEBUG - 2017-08-18 21:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 21:32:56 --> Input Class Initialized
INFO - 2017-08-18 21:32:56 --> Language Class Initialized
INFO - 2017-08-18 21:32:56 --> Loader Class Initialized
INFO - 2017-08-18 21:32:56 --> Helper loaded: url_helper
INFO - 2017-08-18 21:32:56 --> Helper loaded: file_helper
INFO - 2017-08-18 21:32:56 --> Database Driver Class Initialized
INFO - 2017-08-18 21:32:56 --> Email Class Initialized
DEBUG - 2017-08-18 21:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 21:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 21:32:57 --> Table Class Initialized
INFO - 2017-08-18 21:32:57 --> Controller Class Initialized
INFO - 2017-08-18 21:32:57 --> Helper loaded: form_helper
INFO - 2017-08-18 21:32:57 --> Final output sent to browser
DEBUG - 2017-08-18 21:32:57 --> Total execution time: 0.2196
INFO - 2017-08-18 21:33:13 --> Config Class Initialized
INFO - 2017-08-18 21:33:13 --> Hooks Class Initialized
DEBUG - 2017-08-18 21:33:13 --> UTF-8 Support Enabled
INFO - 2017-08-18 21:33:13 --> Utf8 Class Initialized
INFO - 2017-08-18 21:33:13 --> URI Class Initialized
INFO - 2017-08-18 21:33:13 --> Router Class Initialized
INFO - 2017-08-18 21:33:13 --> Output Class Initialized
INFO - 2017-08-18 21:33:13 --> Security Class Initialized
DEBUG - 2017-08-18 21:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 21:33:13 --> Input Class Initialized
INFO - 2017-08-18 21:33:13 --> Language Class Initialized
INFO - 2017-08-18 21:33:13 --> Loader Class Initialized
INFO - 2017-08-18 21:33:13 --> Helper loaded: url_helper
INFO - 2017-08-18 21:33:13 --> Helper loaded: file_helper
INFO - 2017-08-18 21:33:13 --> Database Driver Class Initialized
INFO - 2017-08-18 21:33:13 --> Email Class Initialized
DEBUG - 2017-08-18 21:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 21:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 21:33:13 --> Table Class Initialized
INFO - 2017-08-18 21:33:13 --> Controller Class Initialized
INFO - 2017-08-18 21:33:13 --> Helper loaded: form_helper
INFO - 2017-08-18 21:33:13 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 21:33:13 --> Final output sent to browser
DEBUG - 2017-08-18 21:33:13 --> Total execution time: 0.2314
INFO - 2017-08-18 21:36:15 --> Config Class Initialized
INFO - 2017-08-18 21:36:15 --> Hooks Class Initialized
DEBUG - 2017-08-18 21:36:15 --> UTF-8 Support Enabled
INFO - 2017-08-18 21:36:15 --> Utf8 Class Initialized
INFO - 2017-08-18 21:36:15 --> URI Class Initialized
INFO - 2017-08-18 21:36:15 --> Router Class Initialized
INFO - 2017-08-18 21:36:15 --> Output Class Initialized
INFO - 2017-08-18 21:36:15 --> Security Class Initialized
DEBUG - 2017-08-18 21:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 21:36:15 --> Input Class Initialized
INFO - 2017-08-18 21:36:15 --> Language Class Initialized
INFO - 2017-08-18 21:36:15 --> Loader Class Initialized
INFO - 2017-08-18 21:36:15 --> Helper loaded: url_helper
INFO - 2017-08-18 21:36:15 --> Helper loaded: file_helper
INFO - 2017-08-18 21:36:15 --> Database Driver Class Initialized
INFO - 2017-08-18 21:36:15 --> Email Class Initialized
DEBUG - 2017-08-18 21:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 21:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 21:36:15 --> Table Class Initialized
INFO - 2017-08-18 21:36:15 --> Controller Class Initialized
INFO - 2017-08-18 21:36:15 --> Helper loaded: form_helper
INFO - 2017-08-18 21:36:15 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 21:36:15 --> Final output sent to browser
DEBUG - 2017-08-18 21:36:15 --> Total execution time: 0.2326
INFO - 2017-08-18 21:36:20 --> Config Class Initialized
INFO - 2017-08-18 21:36:20 --> Hooks Class Initialized
DEBUG - 2017-08-18 21:36:20 --> UTF-8 Support Enabled
INFO - 2017-08-18 21:36:20 --> Utf8 Class Initialized
INFO - 2017-08-18 21:36:20 --> URI Class Initialized
INFO - 2017-08-18 21:36:20 --> Router Class Initialized
INFO - 2017-08-18 21:36:20 --> Output Class Initialized
INFO - 2017-08-18 21:36:20 --> Security Class Initialized
DEBUG - 2017-08-18 21:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 21:36:20 --> Input Class Initialized
INFO - 2017-08-18 21:36:20 --> Language Class Initialized
INFO - 2017-08-18 21:36:20 --> Loader Class Initialized
INFO - 2017-08-18 21:36:20 --> Helper loaded: url_helper
INFO - 2017-08-18 21:36:20 --> Helper loaded: file_helper
INFO - 2017-08-18 21:36:20 --> Database Driver Class Initialized
INFO - 2017-08-18 21:36:20 --> Email Class Initialized
DEBUG - 2017-08-18 21:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 21:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 21:36:20 --> Table Class Initialized
INFO - 2017-08-18 21:36:20 --> Controller Class Initialized
INFO - 2017-08-18 21:36:20 --> Helper loaded: form_helper
INFO - 2017-08-18 21:36:20 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 21:36:20 --> Final output sent to browser
DEBUG - 2017-08-18 21:36:20 --> Total execution time: 0.2466
INFO - 2017-08-18 21:36:23 --> Config Class Initialized
INFO - 2017-08-18 21:36:23 --> Hooks Class Initialized
DEBUG - 2017-08-18 21:36:23 --> UTF-8 Support Enabled
INFO - 2017-08-18 21:36:23 --> Utf8 Class Initialized
INFO - 2017-08-18 21:36:23 --> URI Class Initialized
INFO - 2017-08-18 21:36:23 --> Router Class Initialized
INFO - 2017-08-18 21:36:23 --> Output Class Initialized
INFO - 2017-08-18 21:36:23 --> Security Class Initialized
DEBUG - 2017-08-18 21:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 21:36:23 --> Input Class Initialized
INFO - 2017-08-18 21:36:23 --> Language Class Initialized
INFO - 2017-08-18 21:36:23 --> Loader Class Initialized
INFO - 2017-08-18 21:36:23 --> Helper loaded: url_helper
INFO - 2017-08-18 21:36:23 --> Helper loaded: file_helper
INFO - 2017-08-18 21:36:23 --> Database Driver Class Initialized
INFO - 2017-08-18 21:36:23 --> Email Class Initialized
DEBUG - 2017-08-18 21:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 21:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 21:36:23 --> Table Class Initialized
INFO - 2017-08-18 21:36:23 --> Controller Class Initialized
INFO - 2017-08-18 21:36:23 --> Helper loaded: form_helper
INFO - 2017-08-18 21:36:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 21:36:23 --> Final output sent to browser
DEBUG - 2017-08-18 21:36:23 --> Total execution time: 0.2477
INFO - 2017-08-18 21:37:35 --> Config Class Initialized
INFO - 2017-08-18 21:37:35 --> Hooks Class Initialized
DEBUG - 2017-08-18 21:37:35 --> UTF-8 Support Enabled
INFO - 2017-08-18 21:37:35 --> Utf8 Class Initialized
INFO - 2017-08-18 21:37:35 --> URI Class Initialized
INFO - 2017-08-18 21:37:35 --> Router Class Initialized
INFO - 2017-08-18 21:37:35 --> Output Class Initialized
INFO - 2017-08-18 21:37:35 --> Security Class Initialized
DEBUG - 2017-08-18 21:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 21:37:35 --> Input Class Initialized
INFO - 2017-08-18 21:37:35 --> Language Class Initialized
INFO - 2017-08-18 21:37:35 --> Loader Class Initialized
INFO - 2017-08-18 21:37:35 --> Helper loaded: url_helper
INFO - 2017-08-18 21:37:35 --> Helper loaded: file_helper
INFO - 2017-08-18 21:37:35 --> Database Driver Class Initialized
INFO - 2017-08-18 21:37:35 --> Email Class Initialized
DEBUG - 2017-08-18 21:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-18 21:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-18 21:37:35 --> Table Class Initialized
INFO - 2017-08-18 21:37:35 --> Controller Class Initialized
INFO - 2017-08-18 21:37:35 --> Helper loaded: form_helper
INFO - 2017-08-18 21:37:35 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-18 21:37:35 --> Final output sent to browser
DEBUG - 2017-08-18 21:37:35 --> Total execution time: 0.2307
