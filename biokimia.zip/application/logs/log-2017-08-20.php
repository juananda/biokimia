<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-20 04:30:01 --> Config Class Initialized
INFO - 2017-08-20 04:30:01 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:30:02 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:30:02 --> Utf8 Class Initialized
INFO - 2017-08-20 04:30:02 --> URI Class Initialized
INFO - 2017-08-20 04:30:02 --> Router Class Initialized
INFO - 2017-08-20 04:30:02 --> Output Class Initialized
INFO - 2017-08-20 04:30:02 --> Security Class Initialized
DEBUG - 2017-08-20 04:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:30:02 --> Input Class Initialized
INFO - 2017-08-20 04:30:03 --> Language Class Initialized
INFO - 2017-08-20 04:30:03 --> Loader Class Initialized
INFO - 2017-08-20 04:30:03 --> Helper loaded: url_helper
INFO - 2017-08-20 04:30:03 --> Helper loaded: file_helper
INFO - 2017-08-20 04:30:03 --> Database Driver Class Initialized
INFO - 2017-08-20 04:30:03 --> Email Class Initialized
DEBUG - 2017-08-20 04:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 04:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 04:30:04 --> Table Class Initialized
INFO - 2017-08-20 04:30:04 --> Controller Class Initialized
INFO - 2017-08-20 04:30:04 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-20 04:30:04 --> Final output sent to browser
DEBUG - 2017-08-20 04:30:04 --> Total execution time: 3.0686
INFO - 2017-08-20 04:30:04 --> Config Class Initialized
INFO - 2017-08-20 04:30:04 --> Hooks Class Initialized
INFO - 2017-08-20 04:30:04 --> Config Class Initialized
DEBUG - 2017-08-20 04:30:04 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:30:04 --> Hooks Class Initialized
INFO - 2017-08-20 04:30:05 --> Utf8 Class Initialized
DEBUG - 2017-08-20 04:30:05 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:30:05 --> Config Class Initialized
INFO - 2017-08-20 04:30:05 --> Config Class Initialized
INFO - 2017-08-20 04:30:05 --> Config Class Initialized
INFO - 2017-08-20 04:30:05 --> URI Class Initialized
INFO - 2017-08-20 04:30:05 --> Hooks Class Initialized
INFO - 2017-08-20 04:30:05 --> Hooks Class Initialized
INFO - 2017-08-20 04:30:05 --> Utf8 Class Initialized
INFO - 2017-08-20 04:30:05 --> Hooks Class Initialized
INFO - 2017-08-20 04:30:05 --> Router Class Initialized
DEBUG - 2017-08-20 04:30:05 --> UTF-8 Support Enabled
DEBUG - 2017-08-20 04:30:05 --> UTF-8 Support Enabled
DEBUG - 2017-08-20 04:30:05 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:30:05 --> URI Class Initialized
INFO - 2017-08-20 04:30:05 --> Output Class Initialized
INFO - 2017-08-20 04:30:05 --> Utf8 Class Initialized
INFO - 2017-08-20 04:30:05 --> Utf8 Class Initialized
INFO - 2017-08-20 04:30:05 --> Utf8 Class Initialized
INFO - 2017-08-20 04:30:06 --> Router Class Initialized
INFO - 2017-08-20 04:30:06 --> Security Class Initialized
INFO - 2017-08-20 04:30:06 --> URI Class Initialized
INFO - 2017-08-20 04:30:06 --> URI Class Initialized
INFO - 2017-08-20 04:30:06 --> URI Class Initialized
INFO - 2017-08-20 04:30:06 --> Output Class Initialized
INFO - 2017-08-20 04:30:06 --> Router Class Initialized
INFO - 2017-08-20 04:30:06 --> Router Class Initialized
INFO - 2017-08-20 04:30:06 --> Router Class Initialized
DEBUG - 2017-08-20 04:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:30:06 --> Security Class Initialized
INFO - 2017-08-20 04:30:06 --> Input Class Initialized
INFO - 2017-08-20 04:30:06 --> Output Class Initialized
INFO - 2017-08-20 04:30:06 --> Output Class Initialized
INFO - 2017-08-20 04:30:06 --> Output Class Initialized
DEBUG - 2017-08-20 04:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:30:06 --> Language Class Initialized
INFO - 2017-08-20 04:30:06 --> Security Class Initialized
INFO - 2017-08-20 04:30:06 --> Security Class Initialized
INFO - 2017-08-20 04:30:06 --> Security Class Initialized
INFO - 2017-08-20 04:30:06 --> Input Class Initialized
INFO - 2017-08-20 04:30:06 --> Language Class Initialized
DEBUG - 2017-08-20 04:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-20 04:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-20 04:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:30:06 --> Input Class Initialized
INFO - 2017-08-20 04:30:06 --> Input Class Initialized
INFO - 2017-08-20 04:30:06 --> Input Class Initialized
INFO - 2017-08-20 04:30:06 --> Language Class Initialized
INFO - 2017-08-20 04:30:06 --> Language Class Initialized
INFO - 2017-08-20 04:30:06 --> Language Class Initialized
ERROR - 2017-08-20 04:30:06 --> 404 Page Not Found: Ext/vendor
ERROR - 2017-08-20 04:30:06 --> 404 Page Not Found: Ext/vendor
ERROR - 2017-08-20 04:30:06 --> 404 Page Not Found: Ext/vendor
ERROR - 2017-08-20 04:30:06 --> 404 Page Not Found: Ext/vendor
ERROR - 2017-08-20 04:30:06 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-20 04:30:06 --> Config Class Initialized
INFO - 2017-08-20 04:30:06 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:30:06 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:30:06 --> Utf8 Class Initialized
INFO - 2017-08-20 04:30:06 --> URI Class Initialized
INFO - 2017-08-20 04:30:06 --> Router Class Initialized
INFO - 2017-08-20 04:30:06 --> Output Class Initialized
INFO - 2017-08-20 04:30:06 --> Security Class Initialized
DEBUG - 2017-08-20 04:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:30:06 --> Input Class Initialized
INFO - 2017-08-20 04:30:06 --> Language Class Initialized
ERROR - 2017-08-20 04:30:06 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-20 04:30:07 --> Config Class Initialized
INFO - 2017-08-20 04:30:07 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:30:07 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:30:07 --> Utf8 Class Initialized
INFO - 2017-08-20 04:30:07 --> URI Class Initialized
INFO - 2017-08-20 04:30:07 --> Router Class Initialized
INFO - 2017-08-20 04:30:07 --> Output Class Initialized
INFO - 2017-08-20 04:30:07 --> Security Class Initialized
DEBUG - 2017-08-20 04:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:30:07 --> Input Class Initialized
INFO - 2017-08-20 04:30:07 --> Language Class Initialized
ERROR - 2017-08-20 04:30:07 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-20 04:31:48 --> Config Class Initialized
INFO - 2017-08-20 04:31:48 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:31:48 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:31:48 --> Utf8 Class Initialized
INFO - 2017-08-20 04:31:48 --> URI Class Initialized
INFO - 2017-08-20 04:31:48 --> Router Class Initialized
INFO - 2017-08-20 04:31:48 --> Output Class Initialized
INFO - 2017-08-20 04:31:48 --> Security Class Initialized
DEBUG - 2017-08-20 04:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:31:48 --> Input Class Initialized
INFO - 2017-08-20 04:31:48 --> Language Class Initialized
INFO - 2017-08-20 04:31:48 --> Loader Class Initialized
INFO - 2017-08-20 04:31:48 --> Helper loaded: url_helper
INFO - 2017-08-20 04:31:48 --> Helper loaded: file_helper
INFO - 2017-08-20 04:31:48 --> Database Driver Class Initialized
INFO - 2017-08-20 04:31:48 --> Email Class Initialized
DEBUG - 2017-08-20 04:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 04:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 04:31:48 --> Table Class Initialized
INFO - 2017-08-20 04:31:48 --> Controller Class Initialized
INFO - 2017-08-20 04:31:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-20 04:31:48 --> Final output sent to browser
DEBUG - 2017-08-20 04:31:48 --> Total execution time: 0.1766
INFO - 2017-08-20 04:31:48 --> Config Class Initialized
INFO - 2017-08-20 04:31:48 --> Config Class Initialized
INFO - 2017-08-20 04:31:48 --> Config Class Initialized
INFO - 2017-08-20 04:31:48 --> Config Class Initialized
INFO - 2017-08-20 04:31:48 --> Config Class Initialized
INFO - 2017-08-20 04:31:48 --> Hooks Class Initialized
INFO - 2017-08-20 04:31:48 --> Hooks Class Initialized
INFO - 2017-08-20 04:31:48 --> Hooks Class Initialized
INFO - 2017-08-20 04:31:48 --> Hooks Class Initialized
INFO - 2017-08-20 04:31:48 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:31:48 --> UTF-8 Support Enabled
DEBUG - 2017-08-20 04:31:48 --> UTF-8 Support Enabled
DEBUG - 2017-08-20 04:31:48 --> UTF-8 Support Enabled
DEBUG - 2017-08-20 04:31:48 --> UTF-8 Support Enabled
DEBUG - 2017-08-20 04:31:48 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:31:48 --> Utf8 Class Initialized
INFO - 2017-08-20 04:31:48 --> Utf8 Class Initialized
INFO - 2017-08-20 04:31:48 --> Utf8 Class Initialized
INFO - 2017-08-20 04:31:48 --> Utf8 Class Initialized
INFO - 2017-08-20 04:31:48 --> Utf8 Class Initialized
INFO - 2017-08-20 04:31:48 --> URI Class Initialized
INFO - 2017-08-20 04:31:48 --> URI Class Initialized
INFO - 2017-08-20 04:31:48 --> URI Class Initialized
INFO - 2017-08-20 04:31:48 --> URI Class Initialized
INFO - 2017-08-20 04:31:48 --> URI Class Initialized
INFO - 2017-08-20 04:31:48 --> Router Class Initialized
INFO - 2017-08-20 04:31:48 --> Router Class Initialized
INFO - 2017-08-20 04:31:48 --> Router Class Initialized
INFO - 2017-08-20 04:31:48 --> Router Class Initialized
INFO - 2017-08-20 04:31:48 --> Router Class Initialized
INFO - 2017-08-20 04:31:48 --> Output Class Initialized
INFO - 2017-08-20 04:31:48 --> Output Class Initialized
INFO - 2017-08-20 04:31:48 --> Output Class Initialized
INFO - 2017-08-20 04:31:48 --> Output Class Initialized
INFO - 2017-08-20 04:31:48 --> Output Class Initialized
INFO - 2017-08-20 04:31:48 --> Security Class Initialized
INFO - 2017-08-20 04:31:48 --> Security Class Initialized
INFO - 2017-08-20 04:31:48 --> Security Class Initialized
INFO - 2017-08-20 04:31:48 --> Security Class Initialized
INFO - 2017-08-20 04:31:48 --> Security Class Initialized
DEBUG - 2017-08-20 04:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-20 04:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-20 04:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-20 04:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:31:48 --> Input Class Initialized
DEBUG - 2017-08-20 04:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:31:48 --> Input Class Initialized
INFO - 2017-08-20 04:31:48 --> Input Class Initialized
INFO - 2017-08-20 04:31:48 --> Input Class Initialized
INFO - 2017-08-20 04:31:48 --> Input Class Initialized
INFO - 2017-08-20 04:31:48 --> Language Class Initialized
INFO - 2017-08-20 04:31:48 --> Language Class Initialized
INFO - 2017-08-20 04:31:48 --> Language Class Initialized
INFO - 2017-08-20 04:31:48 --> Language Class Initialized
INFO - 2017-08-20 04:31:48 --> Language Class Initialized
ERROR - 2017-08-20 04:31:48 --> 404 Page Not Found: Ext/vendor
ERROR - 2017-08-20 04:31:48 --> 404 Page Not Found: Ext/vendor
ERROR - 2017-08-20 04:31:48 --> 404 Page Not Found: Ext/vendor
ERROR - 2017-08-20 04:31:48 --> 404 Page Not Found: Ext/vendor
ERROR - 2017-08-20 04:31:48 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-20 04:31:48 --> Config Class Initialized
INFO - 2017-08-20 04:31:48 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:31:48 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:31:48 --> Utf8 Class Initialized
INFO - 2017-08-20 04:31:48 --> URI Class Initialized
INFO - 2017-08-20 04:31:48 --> Router Class Initialized
INFO - 2017-08-20 04:31:48 --> Output Class Initialized
INFO - 2017-08-20 04:31:48 --> Security Class Initialized
DEBUG - 2017-08-20 04:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:31:48 --> Input Class Initialized
INFO - 2017-08-20 04:31:48 --> Language Class Initialized
ERROR - 2017-08-20 04:31:48 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-20 04:31:48 --> Config Class Initialized
INFO - 2017-08-20 04:31:48 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:31:48 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:31:48 --> Utf8 Class Initialized
INFO - 2017-08-20 04:31:48 --> URI Class Initialized
INFO - 2017-08-20 04:31:48 --> Router Class Initialized
INFO - 2017-08-20 04:31:48 --> Output Class Initialized
INFO - 2017-08-20 04:31:48 --> Security Class Initialized
DEBUG - 2017-08-20 04:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:31:48 --> Input Class Initialized
INFO - 2017-08-20 04:31:49 --> Language Class Initialized
ERROR - 2017-08-20 04:31:49 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-20 04:32:00 --> Config Class Initialized
INFO - 2017-08-20 04:32:00 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:32:00 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:32:01 --> Utf8 Class Initialized
INFO - 2017-08-20 04:32:01 --> URI Class Initialized
INFO - 2017-08-20 04:32:01 --> Router Class Initialized
INFO - 2017-08-20 04:32:01 --> Output Class Initialized
INFO - 2017-08-20 04:32:01 --> Security Class Initialized
DEBUG - 2017-08-20 04:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:32:01 --> Input Class Initialized
INFO - 2017-08-20 04:32:01 --> Language Class Initialized
INFO - 2017-08-20 04:32:01 --> Loader Class Initialized
INFO - 2017-08-20 04:32:01 --> Helper loaded: url_helper
INFO - 2017-08-20 04:32:01 --> Helper loaded: file_helper
INFO - 2017-08-20 04:32:01 --> Database Driver Class Initialized
INFO - 2017-08-20 04:32:01 --> Email Class Initialized
DEBUG - 2017-08-20 04:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 04:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 04:32:01 --> Table Class Initialized
INFO - 2017-08-20 04:32:01 --> Controller Class Initialized
INFO - 2017-08-20 04:32:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-20 04:32:01 --> Final output sent to browser
DEBUG - 2017-08-20 04:32:01 --> Total execution time: 0.2320
INFO - 2017-08-20 04:32:01 --> Config Class Initialized
INFO - 2017-08-20 04:32:01 --> Config Class Initialized
INFO - 2017-08-20 04:32:01 --> Hooks Class Initialized
INFO - 2017-08-20 04:32:01 --> Config Class Initialized
INFO - 2017-08-20 04:32:01 --> Config Class Initialized
INFO - 2017-08-20 04:32:01 --> Config Class Initialized
INFO - 2017-08-20 04:32:01 --> Hooks Class Initialized
INFO - 2017-08-20 04:32:01 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:32:01 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:32:01 --> Hooks Class Initialized
INFO - 2017-08-20 04:32:01 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:32:01 --> UTF-8 Support Enabled
DEBUG - 2017-08-20 04:32:01 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:32:01 --> Utf8 Class Initialized
DEBUG - 2017-08-20 04:32:01 --> UTF-8 Support Enabled
DEBUG - 2017-08-20 04:32:01 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:32:01 --> Utf8 Class Initialized
INFO - 2017-08-20 04:32:01 --> URI Class Initialized
INFO - 2017-08-20 04:32:01 --> Utf8 Class Initialized
INFO - 2017-08-20 04:32:01 --> Utf8 Class Initialized
INFO - 2017-08-20 04:32:01 --> URI Class Initialized
INFO - 2017-08-20 04:32:01 --> Utf8 Class Initialized
INFO - 2017-08-20 04:32:01 --> Router Class Initialized
INFO - 2017-08-20 04:32:01 --> URI Class Initialized
INFO - 2017-08-20 04:32:01 --> URI Class Initialized
INFO - 2017-08-20 04:32:01 --> URI Class Initialized
INFO - 2017-08-20 04:32:01 --> Router Class Initialized
INFO - 2017-08-20 04:32:01 --> Router Class Initialized
INFO - 2017-08-20 04:32:01 --> Output Class Initialized
INFO - 2017-08-20 04:32:01 --> Router Class Initialized
INFO - 2017-08-20 04:32:01 --> Router Class Initialized
INFO - 2017-08-20 04:32:01 --> Output Class Initialized
INFO - 2017-08-20 04:32:01 --> Security Class Initialized
INFO - 2017-08-20 04:32:01 --> Output Class Initialized
INFO - 2017-08-20 04:32:01 --> Output Class Initialized
INFO - 2017-08-20 04:32:01 --> Security Class Initialized
INFO - 2017-08-20 04:32:01 --> Output Class Initialized
DEBUG - 2017-08-20 04:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:32:01 --> Security Class Initialized
INFO - 2017-08-20 04:32:01 --> Security Class Initialized
INFO - 2017-08-20 04:32:01 --> Security Class Initialized
DEBUG - 2017-08-20 04:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:32:01 --> Input Class Initialized
DEBUG - 2017-08-20 04:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-20 04:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-08-20 04:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:32:01 --> Input Class Initialized
INFO - 2017-08-20 04:32:01 --> Input Class Initialized
INFO - 2017-08-20 04:32:01 --> Input Class Initialized
INFO - 2017-08-20 04:32:01 --> Language Class Initialized
INFO - 2017-08-20 04:32:01 --> Language Class Initialized
INFO - 2017-08-20 04:32:01 --> Language Class Initialized
INFO - 2017-08-20 04:32:01 --> Language Class Initialized
INFO - 2017-08-20 04:32:01 --> Input Class Initialized
ERROR - 2017-08-20 04:32:01 --> 404 Page Not Found: Ext/vendor
ERROR - 2017-08-20 04:32:01 --> 404 Page Not Found: Ext/vendor
ERROR - 2017-08-20 04:32:01 --> 404 Page Not Found: Ext/vendor
ERROR - 2017-08-20 04:32:01 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-20 04:32:01 --> Language Class Initialized
ERROR - 2017-08-20 04:32:01 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-20 04:32:01 --> Config Class Initialized
INFO - 2017-08-20 04:32:01 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:32:01 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:32:01 --> Utf8 Class Initialized
INFO - 2017-08-20 04:32:01 --> URI Class Initialized
INFO - 2017-08-20 04:32:01 --> Router Class Initialized
INFO - 2017-08-20 04:32:01 --> Output Class Initialized
INFO - 2017-08-20 04:32:01 --> Security Class Initialized
DEBUG - 2017-08-20 04:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:32:01 --> Input Class Initialized
INFO - 2017-08-20 04:32:01 --> Language Class Initialized
ERROR - 2017-08-20 04:32:01 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-20 04:32:01 --> Config Class Initialized
INFO - 2017-08-20 04:32:01 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:32:01 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:32:01 --> Utf8 Class Initialized
INFO - 2017-08-20 04:32:01 --> URI Class Initialized
INFO - 2017-08-20 04:32:01 --> Router Class Initialized
INFO - 2017-08-20 04:32:01 --> Output Class Initialized
INFO - 2017-08-20 04:32:01 --> Security Class Initialized
DEBUG - 2017-08-20 04:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:32:01 --> Input Class Initialized
INFO - 2017-08-20 04:32:01 --> Language Class Initialized
ERROR - 2017-08-20 04:32:01 --> 404 Page Not Found: Ext/vendor
INFO - 2017-08-20 04:33:31 --> Config Class Initialized
INFO - 2017-08-20 04:33:31 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:33:31 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:33:31 --> Utf8 Class Initialized
INFO - 2017-08-20 04:33:31 --> URI Class Initialized
INFO - 2017-08-20 04:33:31 --> Router Class Initialized
INFO - 2017-08-20 04:33:31 --> Output Class Initialized
INFO - 2017-08-20 04:33:31 --> Security Class Initialized
DEBUG - 2017-08-20 04:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:33:31 --> Input Class Initialized
INFO - 2017-08-20 04:33:31 --> Language Class Initialized
INFO - 2017-08-20 04:33:31 --> Loader Class Initialized
INFO - 2017-08-20 04:33:31 --> Helper loaded: url_helper
INFO - 2017-08-20 04:33:31 --> Helper loaded: file_helper
INFO - 2017-08-20 04:33:31 --> Database Driver Class Initialized
INFO - 2017-08-20 04:33:31 --> Email Class Initialized
DEBUG - 2017-08-20 04:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 04:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 04:33:31 --> Table Class Initialized
INFO - 2017-08-20 04:33:31 --> Controller Class Initialized
INFO - 2017-08-20 04:33:31 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-20 04:33:31 --> Final output sent to browser
DEBUG - 2017-08-20 04:33:31 --> Total execution time: 0.5627
INFO - 2017-08-20 04:34:44 --> Config Class Initialized
INFO - 2017-08-20 04:34:44 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:34:44 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:34:44 --> Utf8 Class Initialized
INFO - 2017-08-20 04:34:44 --> URI Class Initialized
INFO - 2017-08-20 04:34:44 --> Router Class Initialized
INFO - 2017-08-20 04:34:44 --> Output Class Initialized
INFO - 2017-08-20 04:34:44 --> Security Class Initialized
DEBUG - 2017-08-20 04:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:34:44 --> Input Class Initialized
INFO - 2017-08-20 04:34:44 --> Language Class Initialized
INFO - 2017-08-20 04:34:44 --> Loader Class Initialized
INFO - 2017-08-20 04:34:44 --> Helper loaded: url_helper
INFO - 2017-08-20 04:34:44 --> Helper loaded: file_helper
INFO - 2017-08-20 04:34:44 --> Database Driver Class Initialized
INFO - 2017-08-20 04:34:44 --> Email Class Initialized
DEBUG - 2017-08-20 04:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 04:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 04:34:44 --> Table Class Initialized
INFO - 2017-08-20 04:34:44 --> Controller Class Initialized
INFO - 2017-08-20 04:34:44 --> Helper loaded: form_helper
INFO - 2017-08-20 04:34:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-20 04:34:44 --> Final output sent to browser
DEBUG - 2017-08-20 04:34:44 --> Total execution time: 0.3188
INFO - 2017-08-20 04:34:48 --> Config Class Initialized
INFO - 2017-08-20 04:34:48 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:34:48 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:34:48 --> Utf8 Class Initialized
INFO - 2017-08-20 04:34:48 --> URI Class Initialized
INFO - 2017-08-20 04:34:48 --> Router Class Initialized
INFO - 2017-08-20 04:34:48 --> Output Class Initialized
INFO - 2017-08-20 04:34:48 --> Security Class Initialized
DEBUG - 2017-08-20 04:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:34:48 --> Input Class Initialized
INFO - 2017-08-20 04:34:48 --> Language Class Initialized
INFO - 2017-08-20 04:34:48 --> Loader Class Initialized
INFO - 2017-08-20 04:34:48 --> Helper loaded: url_helper
INFO - 2017-08-20 04:34:48 --> Helper loaded: file_helper
INFO - 2017-08-20 04:34:48 --> Database Driver Class Initialized
INFO - 2017-08-20 04:34:48 --> Email Class Initialized
DEBUG - 2017-08-20 04:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 04:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 04:34:48 --> Table Class Initialized
INFO - 2017-08-20 04:34:48 --> Controller Class Initialized
INFO - 2017-08-20 04:34:48 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-20 04:34:48 --> Final output sent to browser
DEBUG - 2017-08-20 04:34:48 --> Total execution time: 0.1732
INFO - 2017-08-20 04:34:48 --> Config Class Initialized
INFO - 2017-08-20 04:34:48 --> Hooks Class Initialized
DEBUG - 2017-08-20 04:34:48 --> UTF-8 Support Enabled
INFO - 2017-08-20 04:34:48 --> Utf8 Class Initialized
INFO - 2017-08-20 04:34:48 --> URI Class Initialized
INFO - 2017-08-20 04:34:48 --> Router Class Initialized
INFO - 2017-08-20 04:34:48 --> Output Class Initialized
INFO - 2017-08-20 04:34:48 --> Security Class Initialized
DEBUG - 2017-08-20 04:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 04:34:48 --> Input Class Initialized
INFO - 2017-08-20 04:34:48 --> Language Class Initialized
INFO - 2017-08-20 04:34:48 --> Loader Class Initialized
INFO - 2017-08-20 04:34:48 --> Helper loaded: url_helper
INFO - 2017-08-20 04:34:48 --> Helper loaded: file_helper
INFO - 2017-08-20 04:34:48 --> Database Driver Class Initialized
INFO - 2017-08-20 04:34:49 --> Email Class Initialized
DEBUG - 2017-08-20 04:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 04:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 04:34:49 --> Table Class Initialized
INFO - 2017-08-20 04:34:49 --> Controller Class Initialized
INFO - 2017-08-20 04:34:49 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-20 04:34:49 --> Final output sent to browser
DEBUG - 2017-08-20 04:34:49 --> Total execution time: 0.1704
INFO - 2017-08-20 12:21:51 --> Config Class Initialized
INFO - 2017-08-20 12:21:51 --> Hooks Class Initialized
DEBUG - 2017-08-20 12:21:51 --> UTF-8 Support Enabled
INFO - 2017-08-20 12:21:51 --> Utf8 Class Initialized
INFO - 2017-08-20 12:21:51 --> URI Class Initialized
INFO - 2017-08-20 12:21:51 --> Router Class Initialized
INFO - 2017-08-20 12:21:51 --> Output Class Initialized
INFO - 2017-08-20 12:21:51 --> Security Class Initialized
DEBUG - 2017-08-20 12:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 12:21:51 --> Input Class Initialized
INFO - 2017-08-20 12:21:51 --> Language Class Initialized
ERROR - 2017-08-20 12:21:51 --> 404 Page Not Found: Biokimia/index
INFO - 2017-08-20 12:21:55 --> Config Class Initialized
INFO - 2017-08-20 12:21:55 --> Hooks Class Initialized
DEBUG - 2017-08-20 12:21:55 --> UTF-8 Support Enabled
INFO - 2017-08-20 12:21:55 --> Utf8 Class Initialized
INFO - 2017-08-20 12:21:55 --> URI Class Initialized
INFO - 2017-08-20 12:21:55 --> Router Class Initialized
INFO - 2017-08-20 12:21:55 --> Output Class Initialized
INFO - 2017-08-20 12:21:55 --> Security Class Initialized
DEBUG - 2017-08-20 12:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 12:21:55 --> Input Class Initialized
INFO - 2017-08-20 12:21:55 --> Language Class Initialized
INFO - 2017-08-20 12:21:55 --> Loader Class Initialized
INFO - 2017-08-20 12:21:55 --> Helper loaded: url_helper
INFO - 2017-08-20 12:21:55 --> Helper loaded: file_helper
INFO - 2017-08-20 12:21:56 --> Database Driver Class Initialized
INFO - 2017-08-20 12:21:56 --> Email Class Initialized
DEBUG - 2017-08-20 12:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 12:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 12:21:57 --> Table Class Initialized
INFO - 2017-08-20 12:21:57 --> Controller Class Initialized
INFO - 2017-08-20 12:21:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-20 12:21:57 --> Final output sent to browser
DEBUG - 2017-08-20 12:21:57 --> Total execution time: 1.8676
INFO - 2017-08-20 12:23:01 --> Config Class Initialized
INFO - 2017-08-20 12:23:01 --> Hooks Class Initialized
DEBUG - 2017-08-20 12:23:01 --> UTF-8 Support Enabled
INFO - 2017-08-20 12:23:01 --> Utf8 Class Initialized
INFO - 2017-08-20 12:23:01 --> URI Class Initialized
INFO - 2017-08-20 12:23:01 --> Router Class Initialized
INFO - 2017-08-20 12:23:01 --> Output Class Initialized
INFO - 2017-08-20 12:23:01 --> Security Class Initialized
DEBUG - 2017-08-20 12:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 12:23:01 --> Input Class Initialized
INFO - 2017-08-20 12:23:01 --> Language Class Initialized
INFO - 2017-08-20 12:23:01 --> Loader Class Initialized
INFO - 2017-08-20 12:23:01 --> Helper loaded: url_helper
INFO - 2017-08-20 12:23:01 --> Helper loaded: file_helper
INFO - 2017-08-20 12:23:01 --> Database Driver Class Initialized
INFO - 2017-08-20 12:23:01 --> Email Class Initialized
DEBUG - 2017-08-20 12:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 12:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 12:23:01 --> Table Class Initialized
INFO - 2017-08-20 12:23:01 --> Controller Class Initialized
INFO - 2017-08-20 12:23:01 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-20 12:23:01 --> Final output sent to browser
DEBUG - 2017-08-20 12:23:01 --> Total execution time: 0.1579
INFO - 2017-08-20 12:44:56 --> Config Class Initialized
INFO - 2017-08-20 12:44:56 --> Hooks Class Initialized
DEBUG - 2017-08-20 12:44:56 --> UTF-8 Support Enabled
INFO - 2017-08-20 12:44:56 --> Utf8 Class Initialized
INFO - 2017-08-20 12:44:56 --> URI Class Initialized
DEBUG - 2017-08-20 12:44:56 --> No URI present. Default controller set.
INFO - 2017-08-20 12:44:56 --> Router Class Initialized
INFO - 2017-08-20 12:44:57 --> Output Class Initialized
INFO - 2017-08-20 12:44:57 --> Security Class Initialized
DEBUG - 2017-08-20 12:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 12:44:57 --> Input Class Initialized
INFO - 2017-08-20 12:44:57 --> Language Class Initialized
INFO - 2017-08-20 12:44:57 --> Loader Class Initialized
INFO - 2017-08-20 12:44:57 --> Helper loaded: url_helper
INFO - 2017-08-20 12:44:57 --> Helper loaded: file_helper
INFO - 2017-08-20 12:44:57 --> Database Driver Class Initialized
INFO - 2017-08-20 12:44:57 --> Email Class Initialized
DEBUG - 2017-08-20 12:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 12:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 12:44:57 --> Table Class Initialized
INFO - 2017-08-20 12:44:57 --> Controller Class Initialized
INFO - 2017-08-20 12:44:57 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-20 12:44:57 --> Final output sent to browser
DEBUG - 2017-08-20 12:44:57 --> Total execution time: 0.1916
INFO - 2017-08-20 12:45:09 --> Config Class Initialized
INFO - 2017-08-20 12:45:09 --> Hooks Class Initialized
DEBUG - 2017-08-20 12:45:09 --> UTF-8 Support Enabled
INFO - 2017-08-20 12:45:09 --> Utf8 Class Initialized
INFO - 2017-08-20 12:45:09 --> URI Class Initialized
DEBUG - 2017-08-20 12:45:09 --> No URI present. Default controller set.
INFO - 2017-08-20 12:45:09 --> Router Class Initialized
INFO - 2017-08-20 12:45:09 --> Output Class Initialized
INFO - 2017-08-20 12:45:09 --> Security Class Initialized
DEBUG - 2017-08-20 12:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 12:45:09 --> Input Class Initialized
INFO - 2017-08-20 12:45:09 --> Language Class Initialized
INFO - 2017-08-20 12:45:10 --> Loader Class Initialized
INFO - 2017-08-20 12:45:10 --> Helper loaded: url_helper
INFO - 2017-08-20 12:45:10 --> Helper loaded: file_helper
INFO - 2017-08-20 12:45:10 --> Database Driver Class Initialized
INFO - 2017-08-20 12:45:10 --> Email Class Initialized
DEBUG - 2017-08-20 12:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 12:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 12:45:10 --> Table Class Initialized
INFO - 2017-08-20 12:45:10 --> Controller Class Initialized
INFO - 2017-08-20 12:45:10 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-20 12:45:10 --> Final output sent to browser
DEBUG - 2017-08-20 12:45:10 --> Total execution time: 0.1728
INFO - 2017-08-20 12:45:17 --> Config Class Initialized
INFO - 2017-08-20 12:45:17 --> Hooks Class Initialized
DEBUG - 2017-08-20 12:45:17 --> UTF-8 Support Enabled
INFO - 2017-08-20 12:45:17 --> Utf8 Class Initialized
INFO - 2017-08-20 12:45:17 --> URI Class Initialized
DEBUG - 2017-08-20 12:45:17 --> No URI present. Default controller set.
INFO - 2017-08-20 12:45:17 --> Router Class Initialized
INFO - 2017-08-20 12:45:17 --> Output Class Initialized
INFO - 2017-08-20 12:45:17 --> Security Class Initialized
DEBUG - 2017-08-20 12:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 12:45:17 --> Input Class Initialized
INFO - 2017-08-20 12:45:17 --> Language Class Initialized
INFO - 2017-08-20 12:45:17 --> Loader Class Initialized
INFO - 2017-08-20 12:45:17 --> Helper loaded: url_helper
INFO - 2017-08-20 12:45:17 --> Helper loaded: file_helper
INFO - 2017-08-20 12:45:17 --> Database Driver Class Initialized
INFO - 2017-08-20 12:45:17 --> Email Class Initialized
DEBUG - 2017-08-20 12:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 12:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 12:45:17 --> Table Class Initialized
INFO - 2017-08-20 12:45:17 --> Controller Class Initialized
INFO - 2017-08-20 12:45:17 --> File loaded: C:\xampp\htdocs\biokimia\application\views\index.php
INFO - 2017-08-20 12:45:17 --> Final output sent to browser
DEBUG - 2017-08-20 12:45:17 --> Total execution time: 0.1828
INFO - 2017-08-20 13:01:43 --> Config Class Initialized
INFO - 2017-08-20 13:01:44 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:01:44 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:01:44 --> Utf8 Class Initialized
INFO - 2017-08-20 13:01:44 --> URI Class Initialized
INFO - 2017-08-20 13:01:44 --> Router Class Initialized
INFO - 2017-08-20 13:01:44 --> Output Class Initialized
INFO - 2017-08-20 13:01:44 --> Security Class Initialized
DEBUG - 2017-08-20 13:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:01:44 --> Input Class Initialized
INFO - 2017-08-20 13:01:44 --> Language Class Initialized
INFO - 2017-08-20 13:01:44 --> Loader Class Initialized
INFO - 2017-08-20 13:01:44 --> Helper loaded: url_helper
INFO - 2017-08-20 13:01:44 --> Helper loaded: file_helper
INFO - 2017-08-20 13:01:44 --> Database Driver Class Initialized
INFO - 2017-08-20 13:01:44 --> Email Class Initialized
DEBUG - 2017-08-20 13:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:01:44 --> Table Class Initialized
INFO - 2017-08-20 13:01:44 --> Controller Class Initialized
INFO - 2017-08-20 13:01:44 --> Helper loaded: form_helper
INFO - 2017-08-20 13:01:44 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-20 13:01:44 --> Final output sent to browser
DEBUG - 2017-08-20 13:01:44 --> Total execution time: 0.3782
INFO - 2017-08-20 13:01:53 --> Config Class Initialized
INFO - 2017-08-20 13:01:54 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:01:54 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:01:54 --> Utf8 Class Initialized
INFO - 2017-08-20 13:01:54 --> URI Class Initialized
INFO - 2017-08-20 13:01:54 --> Router Class Initialized
INFO - 2017-08-20 13:01:54 --> Output Class Initialized
INFO - 2017-08-20 13:01:54 --> Security Class Initialized
DEBUG - 2017-08-20 13:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:01:54 --> Input Class Initialized
INFO - 2017-08-20 13:01:54 --> Language Class Initialized
INFO - 2017-08-20 13:01:54 --> Loader Class Initialized
INFO - 2017-08-20 13:01:54 --> Helper loaded: url_helper
INFO - 2017-08-20 13:01:54 --> Helper loaded: file_helper
INFO - 2017-08-20 13:01:54 --> Database Driver Class Initialized
INFO - 2017-08-20 13:01:54 --> Email Class Initialized
DEBUG - 2017-08-20 13:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:01:54 --> Table Class Initialized
INFO - 2017-08-20 13:01:54 --> Controller Class Initialized
INFO - 2017-08-20 13:01:54 --> Helper loaded: form_helper
INFO - 2017-08-20 13:01:54 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-20 13:01:54 --> Final output sent to browser
DEBUG - 2017-08-20 13:01:54 --> Total execution time: 0.2297
INFO - 2017-08-20 13:01:58 --> Config Class Initialized
INFO - 2017-08-20 13:01:58 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:01:58 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:01:58 --> Utf8 Class Initialized
INFO - 2017-08-20 13:01:58 --> URI Class Initialized
INFO - 2017-08-20 13:01:58 --> Router Class Initialized
INFO - 2017-08-20 13:01:58 --> Output Class Initialized
INFO - 2017-08-20 13:01:58 --> Security Class Initialized
DEBUG - 2017-08-20 13:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:01:58 --> Input Class Initialized
INFO - 2017-08-20 13:01:58 --> Language Class Initialized
INFO - 2017-08-20 13:01:58 --> Loader Class Initialized
INFO - 2017-08-20 13:01:58 --> Helper loaded: url_helper
INFO - 2017-08-20 13:01:58 --> Helper loaded: file_helper
INFO - 2017-08-20 13:01:58 --> Database Driver Class Initialized
INFO - 2017-08-20 13:01:58 --> Email Class Initialized
DEBUG - 2017-08-20 13:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:01:58 --> Table Class Initialized
INFO - 2017-08-20 13:01:58 --> Controller Class Initialized
INFO - 2017-08-20 13:01:58 --> Helper loaded: form_helper
INFO - 2017-08-20 13:01:58 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-20 13:01:58 --> Final output sent to browser
DEBUG - 2017-08-20 13:01:58 --> Total execution time: 0.2186
INFO - 2017-08-20 13:04:07 --> Config Class Initialized
INFO - 2017-08-20 13:04:07 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:04:07 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:04:07 --> Utf8 Class Initialized
INFO - 2017-08-20 13:04:07 --> URI Class Initialized
INFO - 2017-08-20 13:04:07 --> Router Class Initialized
INFO - 2017-08-20 13:04:07 --> Output Class Initialized
INFO - 2017-08-20 13:04:07 --> Security Class Initialized
DEBUG - 2017-08-20 13:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:04:07 --> Input Class Initialized
INFO - 2017-08-20 13:04:07 --> Language Class Initialized
INFO - 2017-08-20 13:04:07 --> Loader Class Initialized
INFO - 2017-08-20 13:04:07 --> Helper loaded: url_helper
INFO - 2017-08-20 13:04:07 --> Helper loaded: file_helper
INFO - 2017-08-20 13:04:07 --> Database Driver Class Initialized
INFO - 2017-08-20 13:04:07 --> Email Class Initialized
DEBUG - 2017-08-20 13:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:04:07 --> Table Class Initialized
INFO - 2017-08-20 13:04:07 --> Controller Class Initialized
INFO - 2017-08-20 13:04:07 --> Helper loaded: form_helper
INFO - 2017-08-20 13:04:07 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-20 13:04:07 --> Final output sent to browser
DEBUG - 2017-08-20 13:04:07 --> Total execution time: 0.2086
INFO - 2017-08-20 13:05:36 --> Config Class Initialized
INFO - 2017-08-20 13:05:36 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:05:36 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:05:36 --> Utf8 Class Initialized
INFO - 2017-08-20 13:05:36 --> URI Class Initialized
INFO - 2017-08-20 13:05:36 --> Router Class Initialized
INFO - 2017-08-20 13:05:36 --> Output Class Initialized
INFO - 2017-08-20 13:05:36 --> Security Class Initialized
DEBUG - 2017-08-20 13:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:05:36 --> Input Class Initialized
INFO - 2017-08-20 13:05:36 --> Language Class Initialized
INFO - 2017-08-20 13:05:36 --> Loader Class Initialized
INFO - 2017-08-20 13:05:36 --> Helper loaded: url_helper
INFO - 2017-08-20 13:05:36 --> Helper loaded: file_helper
INFO - 2017-08-20 13:05:36 --> Database Driver Class Initialized
INFO - 2017-08-20 13:05:36 --> Email Class Initialized
DEBUG - 2017-08-20 13:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:05:36 --> Table Class Initialized
INFO - 2017-08-20 13:05:36 --> Controller Class Initialized
INFO - 2017-08-20 13:05:36 --> Helper loaded: form_helper
INFO - 2017-08-20 13:05:36 --> Upload Class Initialized
INFO - 2017-08-20 13:05:36 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-20 13:05:36 --> You did not select a file to upload.
INFO - 2017-08-20 13:05:36 --> Final output sent to browser
DEBUG - 2017-08-20 13:05:36 --> Total execution time: 0.2891
INFO - 2017-08-20 13:07:32 --> Config Class Initialized
INFO - 2017-08-20 13:07:32 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:07:32 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:07:32 --> Utf8 Class Initialized
INFO - 2017-08-20 13:07:32 --> URI Class Initialized
INFO - 2017-08-20 13:07:32 --> Router Class Initialized
INFO - 2017-08-20 13:07:32 --> Output Class Initialized
INFO - 2017-08-20 13:07:32 --> Security Class Initialized
DEBUG - 2017-08-20 13:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:07:32 --> Input Class Initialized
INFO - 2017-08-20 13:07:32 --> Language Class Initialized
INFO - 2017-08-20 13:07:32 --> Loader Class Initialized
INFO - 2017-08-20 13:07:32 --> Helper loaded: url_helper
INFO - 2017-08-20 13:07:32 --> Helper loaded: file_helper
INFO - 2017-08-20 13:07:32 --> Database Driver Class Initialized
INFO - 2017-08-20 13:07:32 --> Email Class Initialized
DEBUG - 2017-08-20 13:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:07:32 --> Table Class Initialized
INFO - 2017-08-20 13:07:32 --> Controller Class Initialized
INFO - 2017-08-20 13:07:32 --> Helper loaded: form_helper
INFO - 2017-08-20 13:07:32 --> Upload Class Initialized
INFO - 2017-08-20 13:07:32 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-20 13:07:32 --> You did not select a file to upload.
INFO - 2017-08-20 13:07:32 --> Final output sent to browser
DEBUG - 2017-08-20 13:07:32 --> Total execution time: 0.2200
INFO - 2017-08-20 13:08:25 --> Config Class Initialized
INFO - 2017-08-20 13:08:25 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:08:25 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:08:25 --> Utf8 Class Initialized
INFO - 2017-08-20 13:08:25 --> URI Class Initialized
INFO - 2017-08-20 13:08:25 --> Router Class Initialized
INFO - 2017-08-20 13:08:25 --> Output Class Initialized
INFO - 2017-08-20 13:08:25 --> Security Class Initialized
DEBUG - 2017-08-20 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:08:25 --> Input Class Initialized
INFO - 2017-08-20 13:08:26 --> Language Class Initialized
INFO - 2017-08-20 13:08:26 --> Loader Class Initialized
INFO - 2017-08-20 13:08:26 --> Helper loaded: url_helper
INFO - 2017-08-20 13:08:26 --> Helper loaded: file_helper
INFO - 2017-08-20 13:08:26 --> Database Driver Class Initialized
INFO - 2017-08-20 13:08:26 --> Email Class Initialized
DEBUG - 2017-08-20 13:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:08:26 --> Table Class Initialized
INFO - 2017-08-20 13:08:26 --> Controller Class Initialized
INFO - 2017-08-20 13:08:26 --> Helper loaded: form_helper
INFO - 2017-08-20 13:08:26 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-20 13:08:26 --> Final output sent to browser
DEBUG - 2017-08-20 13:08:26 --> Total execution time: 0.1953
INFO - 2017-08-20 13:08:36 --> Config Class Initialized
INFO - 2017-08-20 13:08:36 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:08:36 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:08:36 --> Utf8 Class Initialized
INFO - 2017-08-20 13:08:36 --> URI Class Initialized
INFO - 2017-08-20 13:08:36 --> Router Class Initialized
INFO - 2017-08-20 13:08:36 --> Output Class Initialized
INFO - 2017-08-20 13:08:36 --> Security Class Initialized
DEBUG - 2017-08-20 13:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:08:36 --> Input Class Initialized
INFO - 2017-08-20 13:08:36 --> Language Class Initialized
INFO - 2017-08-20 13:08:36 --> Loader Class Initialized
INFO - 2017-08-20 13:08:36 --> Helper loaded: url_helper
INFO - 2017-08-20 13:08:36 --> Helper loaded: file_helper
INFO - 2017-08-20 13:08:36 --> Database Driver Class Initialized
INFO - 2017-08-20 13:08:36 --> Email Class Initialized
DEBUG - 2017-08-20 13:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:08:36 --> Table Class Initialized
INFO - 2017-08-20 13:08:36 --> Controller Class Initialized
INFO - 2017-08-20 13:08:36 --> Helper loaded: form_helper
INFO - 2017-08-20 13:08:36 --> Upload Class Initialized
INFO - 2017-08-20 13:08:36 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-20 13:08:36 --> You did not select a file to upload.
INFO - 2017-08-20 13:08:36 --> Final output sent to browser
DEBUG - 2017-08-20 13:08:36 --> Total execution time: 0.2611
INFO - 2017-08-20 13:09:06 --> Config Class Initialized
INFO - 2017-08-20 13:09:06 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:09:06 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:09:06 --> Utf8 Class Initialized
INFO - 2017-08-20 13:09:06 --> URI Class Initialized
INFO - 2017-08-20 13:09:06 --> Router Class Initialized
INFO - 2017-08-20 13:09:06 --> Output Class Initialized
INFO - 2017-08-20 13:09:06 --> Security Class Initialized
DEBUG - 2017-08-20 13:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:09:06 --> Input Class Initialized
INFO - 2017-08-20 13:09:06 --> Language Class Initialized
INFO - 2017-08-20 13:09:06 --> Loader Class Initialized
INFO - 2017-08-20 13:09:06 --> Helper loaded: url_helper
INFO - 2017-08-20 13:09:06 --> Helper loaded: file_helper
INFO - 2017-08-20 13:09:06 --> Database Driver Class Initialized
INFO - 2017-08-20 13:09:06 --> Email Class Initialized
DEBUG - 2017-08-20 13:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:09:06 --> Table Class Initialized
INFO - 2017-08-20 13:09:06 --> Controller Class Initialized
INFO - 2017-08-20 13:09:06 --> Helper loaded: form_helper
INFO - 2017-08-20 13:09:06 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-20 13:09:06 --> Final output sent to browser
DEBUG - 2017-08-20 13:09:06 --> Total execution time: 0.2082
INFO - 2017-08-20 13:09:10 --> Config Class Initialized
INFO - 2017-08-20 13:09:10 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:09:10 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:09:10 --> Utf8 Class Initialized
INFO - 2017-08-20 13:09:10 --> URI Class Initialized
INFO - 2017-08-20 13:09:10 --> Router Class Initialized
INFO - 2017-08-20 13:09:11 --> Output Class Initialized
INFO - 2017-08-20 13:09:11 --> Security Class Initialized
DEBUG - 2017-08-20 13:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:09:11 --> Input Class Initialized
INFO - 2017-08-20 13:09:11 --> Language Class Initialized
INFO - 2017-08-20 13:09:11 --> Loader Class Initialized
INFO - 2017-08-20 13:09:11 --> Helper loaded: url_helper
INFO - 2017-08-20 13:09:11 --> Helper loaded: file_helper
INFO - 2017-08-20 13:09:11 --> Database Driver Class Initialized
INFO - 2017-08-20 13:09:11 --> Email Class Initialized
DEBUG - 2017-08-20 13:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:09:11 --> Table Class Initialized
INFO - 2017-08-20 13:09:11 --> Controller Class Initialized
INFO - 2017-08-20 13:09:11 --> Helper loaded: form_helper
INFO - 2017-08-20 13:09:11 --> Upload Class Initialized
INFO - 2017-08-20 13:09:11 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-20 13:09:11 --> You did not select a file to upload.
INFO - 2017-08-20 13:09:11 --> Final output sent to browser
DEBUG - 2017-08-20 13:09:11 --> Total execution time: 0.2398
INFO - 2017-08-20 13:09:28 --> Config Class Initialized
INFO - 2017-08-20 13:09:28 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:09:28 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:09:28 --> Utf8 Class Initialized
INFO - 2017-08-20 13:09:28 --> URI Class Initialized
INFO - 2017-08-20 13:09:28 --> Router Class Initialized
INFO - 2017-08-20 13:09:28 --> Output Class Initialized
INFO - 2017-08-20 13:09:28 --> Security Class Initialized
DEBUG - 2017-08-20 13:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:09:28 --> Input Class Initialized
INFO - 2017-08-20 13:09:28 --> Language Class Initialized
INFO - 2017-08-20 13:09:28 --> Loader Class Initialized
INFO - 2017-08-20 13:09:28 --> Helper loaded: url_helper
INFO - 2017-08-20 13:09:28 --> Helper loaded: file_helper
INFO - 2017-08-20 13:09:28 --> Database Driver Class Initialized
INFO - 2017-08-20 13:09:28 --> Email Class Initialized
DEBUG - 2017-08-20 13:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:09:28 --> Table Class Initialized
INFO - 2017-08-20 13:09:28 --> Controller Class Initialized
INFO - 2017-08-20 13:09:28 --> Helper loaded: form_helper
INFO - 2017-08-20 13:09:28 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-20 13:09:28 --> Final output sent to browser
DEBUG - 2017-08-20 13:09:28 --> Total execution time: 0.2118
INFO - 2017-08-20 13:09:35 --> Config Class Initialized
INFO - 2017-08-20 13:09:35 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:09:35 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:09:35 --> Utf8 Class Initialized
INFO - 2017-08-20 13:09:35 --> URI Class Initialized
INFO - 2017-08-20 13:09:35 --> Router Class Initialized
INFO - 2017-08-20 13:09:35 --> Output Class Initialized
INFO - 2017-08-20 13:09:35 --> Security Class Initialized
DEBUG - 2017-08-20 13:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:09:35 --> Input Class Initialized
INFO - 2017-08-20 13:09:35 --> Language Class Initialized
INFO - 2017-08-20 13:09:35 --> Loader Class Initialized
INFO - 2017-08-20 13:09:35 --> Helper loaded: url_helper
INFO - 2017-08-20 13:09:35 --> Helper loaded: file_helper
INFO - 2017-08-20 13:09:35 --> Database Driver Class Initialized
INFO - 2017-08-20 13:09:35 --> Email Class Initialized
DEBUG - 2017-08-20 13:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:09:35 --> Table Class Initialized
INFO - 2017-08-20 13:09:35 --> Controller Class Initialized
INFO - 2017-08-20 13:09:35 --> Helper loaded: form_helper
INFO - 2017-08-20 13:09:35 --> Upload Class Initialized
INFO - 2017-08-20 13:09:35 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-20 13:09:35 --> You did not select a file to upload.
INFO - 2017-08-20 13:09:35 --> Final output sent to browser
DEBUG - 2017-08-20 13:09:35 --> Total execution time: 0.2257
INFO - 2017-08-20 13:11:56 --> Config Class Initialized
INFO - 2017-08-20 13:11:56 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:11:56 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:11:56 --> Utf8 Class Initialized
INFO - 2017-08-20 13:11:56 --> URI Class Initialized
INFO - 2017-08-20 13:11:56 --> Router Class Initialized
INFO - 2017-08-20 13:11:56 --> Output Class Initialized
INFO - 2017-08-20 13:11:56 --> Security Class Initialized
DEBUG - 2017-08-20 13:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:11:56 --> Input Class Initialized
INFO - 2017-08-20 13:11:56 --> Language Class Initialized
INFO - 2017-08-20 13:11:56 --> Loader Class Initialized
INFO - 2017-08-20 13:11:56 --> Helper loaded: url_helper
INFO - 2017-08-20 13:11:56 --> Helper loaded: file_helper
INFO - 2017-08-20 13:11:56 --> Database Driver Class Initialized
INFO - 2017-08-20 13:11:56 --> Email Class Initialized
DEBUG - 2017-08-20 13:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:11:56 --> Table Class Initialized
INFO - 2017-08-20 13:11:56 --> Controller Class Initialized
INFO - 2017-08-20 13:11:56 --> Helper loaded: form_helper
INFO - 2017-08-20 13:11:56 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-20 13:11:56 --> Final output sent to browser
DEBUG - 2017-08-20 13:11:56 --> Total execution time: 0.1859
INFO - 2017-08-20 13:12:01 --> Config Class Initialized
INFO - 2017-08-20 13:12:01 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:12:01 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:12:01 --> Utf8 Class Initialized
INFO - 2017-08-20 13:12:01 --> URI Class Initialized
INFO - 2017-08-20 13:12:01 --> Router Class Initialized
INFO - 2017-08-20 13:12:01 --> Output Class Initialized
INFO - 2017-08-20 13:12:01 --> Security Class Initialized
DEBUG - 2017-08-20 13:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:12:01 --> Input Class Initialized
INFO - 2017-08-20 13:12:01 --> Language Class Initialized
INFO - 2017-08-20 13:12:01 --> Loader Class Initialized
INFO - 2017-08-20 13:12:01 --> Helper loaded: url_helper
INFO - 2017-08-20 13:12:02 --> Helper loaded: file_helper
INFO - 2017-08-20 13:12:02 --> Database Driver Class Initialized
INFO - 2017-08-20 13:12:02 --> Email Class Initialized
DEBUG - 2017-08-20 13:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:12:02 --> Table Class Initialized
INFO - 2017-08-20 13:12:02 --> Controller Class Initialized
INFO - 2017-08-20 13:12:02 --> Helper loaded: form_helper
INFO - 2017-08-20 13:12:02 --> Upload Class Initialized
INFO - 2017-08-20 13:12:02 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-08-20 13:12:02 --> You did not select a file to upload.
INFO - 2017-08-20 13:12:02 --> Final output sent to browser
DEBUG - 2017-08-20 13:12:02 --> Total execution time: 0.2289
INFO - 2017-08-20 13:12:38 --> Config Class Initialized
INFO - 2017-08-20 13:12:38 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:12:38 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:12:38 --> Utf8 Class Initialized
INFO - 2017-08-20 13:12:38 --> URI Class Initialized
INFO - 2017-08-20 13:12:38 --> Router Class Initialized
INFO - 2017-08-20 13:12:38 --> Output Class Initialized
INFO - 2017-08-20 13:12:38 --> Security Class Initialized
DEBUG - 2017-08-20 13:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:12:38 --> Input Class Initialized
INFO - 2017-08-20 13:12:38 --> Language Class Initialized
INFO - 2017-08-20 13:12:38 --> Loader Class Initialized
INFO - 2017-08-20 13:12:38 --> Helper loaded: url_helper
INFO - 2017-08-20 13:12:38 --> Helper loaded: file_helper
INFO - 2017-08-20 13:12:38 --> Database Driver Class Initialized
INFO - 2017-08-20 13:12:38 --> Email Class Initialized
DEBUG - 2017-08-20 13:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:12:38 --> Table Class Initialized
INFO - 2017-08-20 13:12:38 --> Controller Class Initialized
INFO - 2017-08-20 13:12:38 --> Helper loaded: form_helper
INFO - 2017-08-20 13:12:38 --> File loaded: C:\xampp\htdocs\biokimia\application\views\kirim_tulisan.php
INFO - 2017-08-20 13:12:38 --> Final output sent to browser
DEBUG - 2017-08-20 13:12:38 --> Total execution time: 0.2142
INFO - 2017-08-20 13:12:45 --> Config Class Initialized
INFO - 2017-08-20 13:12:45 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:12:45 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:12:45 --> Utf8 Class Initialized
INFO - 2017-08-20 13:12:45 --> URI Class Initialized
INFO - 2017-08-20 13:12:45 --> Router Class Initialized
INFO - 2017-08-20 13:12:45 --> Output Class Initialized
INFO - 2017-08-20 13:12:45 --> Security Class Initialized
DEBUG - 2017-08-20 13:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:12:45 --> Input Class Initialized
INFO - 2017-08-20 13:12:45 --> Language Class Initialized
INFO - 2017-08-20 13:12:45 --> Loader Class Initialized
INFO - 2017-08-20 13:12:45 --> Helper loaded: url_helper
INFO - 2017-08-20 13:12:45 --> Helper loaded: file_helper
INFO - 2017-08-20 13:12:45 --> Database Driver Class Initialized
INFO - 2017-08-20 13:12:45 --> Email Class Initialized
DEBUG - 2017-08-20 13:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:12:45 --> Table Class Initialized
INFO - 2017-08-20 13:12:45 --> Controller Class Initialized
INFO - 2017-08-20 13:12:45 --> Helper loaded: form_helper
INFO - 2017-08-20 13:12:45 --> Upload Class Initialized
INFO - 2017-08-20 13:12:45 --> Final output sent to browser
DEBUG - 2017-08-20 13:12:45 --> Total execution time: 0.2213
INFO - 2017-08-20 13:15:23 --> Config Class Initialized
INFO - 2017-08-20 13:15:23 --> Hooks Class Initialized
DEBUG - 2017-08-20 13:15:23 --> UTF-8 Support Enabled
INFO - 2017-08-20 13:15:23 --> Utf8 Class Initialized
INFO - 2017-08-20 13:15:23 --> URI Class Initialized
INFO - 2017-08-20 13:15:23 --> Router Class Initialized
INFO - 2017-08-20 13:15:23 --> Output Class Initialized
INFO - 2017-08-20 13:15:23 --> Security Class Initialized
DEBUG - 2017-08-20 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-20 13:15:23 --> Input Class Initialized
INFO - 2017-08-20 13:15:23 --> Language Class Initialized
INFO - 2017-08-20 13:15:23 --> Loader Class Initialized
INFO - 2017-08-20 13:15:23 --> Helper loaded: url_helper
INFO - 2017-08-20 13:15:23 --> Helper loaded: file_helper
INFO - 2017-08-20 13:15:23 --> Database Driver Class Initialized
INFO - 2017-08-20 13:15:23 --> Email Class Initialized
DEBUG - 2017-08-20 13:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-20 13:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-20 13:15:23 --> Table Class Initialized
INFO - 2017-08-20 13:15:23 --> Controller Class Initialized
INFO - 2017-08-20 13:15:23 --> Helper loaded: form_helper
INFO - 2017-08-20 13:15:23 --> Model Class Initialized
INFO - 2017-08-20 13:15:23 --> File loaded: C:\xampp\htdocs\biokimia\application\views\post_success.php
INFO - 2017-08-20 13:15:23 --> Final output sent to browser
DEBUG - 2017-08-20 13:15:23 --> Total execution time: 0.4658
